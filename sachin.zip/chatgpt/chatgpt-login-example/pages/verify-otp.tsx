import { useState } from "react";
import { useRouter } from "next/router";
import { verifyOTP } from "../utils/api";

const VerifyOTPPage: React.FC = () => {
  const [otp, setOTP] = useState("");
  const router = useRouter();

  const handleOTPVerification = async () => {
    try {
      const token = localStorage.getItem("token"); // Replace with your preferred token storage mechanism
      if (token) {
        await verifyOTP(token, otp);
        console.log("OTP verified successfully.");
        // Redirect to the desired page after successful OTP verification
        router.push("/dashboard");
      } else {
        console.error("Token not found.");
      }
    } catch (error) {
      console.error("OTP verification failed:", error);
    }
  };

  return (
    <div>
      <input
        type="text"
        value={otp}
        onChange={(e) => setOTP(e.target.value)}
        placeholder="OTP"
      />
      <button onClick={handleOTPVerification}>Verify OTP</button>
    </div>
  );
};

export default VerifyOTPPage;
