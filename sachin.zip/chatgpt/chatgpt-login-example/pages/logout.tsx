import { useEffect } from "react";
import { useRouter } from "next/router";
import { logout } from "../utils/api";

const LogoutPage: React.FC = () => {
  const router = useRouter();

  useEffect(() => {
    const handleLogout = async () => {
      const token = localStorage.getItem("token"); // Replace with your preferred token storage mechanism
      if (token) {
        try {
          await logout(token);
          // Remove the token from local storage or state
          console.log("Logged out successfully.");
        } catch (error) {
          console.error("Logout failed:", error);
        }
      }
      router.push("/login");
    };

    handleLogout();
  }, [router]);

  return null;
};

export default LogoutPage;
