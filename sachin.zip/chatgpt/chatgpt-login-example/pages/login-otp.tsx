const handleOTPVerification = async () => {
  try {
    await sendOTP(token);
    // Redirect to the OTP verification page
    router.push("/verify-otp");
  } catch (error) {
    console.error("Sending OTP failed:", error);
  }
};

// Call this function after successful login
handleOTPVerification();
