import axios from "axios";

const api = axios.create({
  baseURL: process.env.API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

export async function login(
  username: string,
  password: string
): Promise<string> {
  const response = await api.post("/login", { username, password });
  return response.data.token;
}

export async function logout(token: string): Promise<void> {
  await api.post("/logout", null, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
}

export async function sendOTP(token: string): Promise<void> {
  await api.post("/otp/send", null, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
}

export async function verifyOTP(token: string, otp: string): Promise<void> {
  await api.post(
    "/otp/verify",
    { otp },
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
}
