import Cookies from "js-cookie";

const TOKEN_COOKIE_NAME = "token";

export const setUserToken = (token: string) => {
  Cookies.set(TOKEN_COOKIE_NAME, token, { expires: 1 }); // Store token in a cookie for 1 day
};

export const getUserToken = () => {
  return Cookies.get(TOKEN_COOKIE_NAME);
};

export const removeUserToken = () => {
  Cookies.remove(TOKEN_COOKIE_NAME);
};
