import axios from "axios";

export const fetchData = async (token: string) => {
  try {
    const response = await axios.get("https://api.example.com/data", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};

export const login = async (email: string, password: string) => {
  try {
    const response = await axios.post("https://api.example.com/login", {
      email,
      password,
    });
    return response.data;
  } catch (error) {
    console.error("Error logging in:", error);
    throw error;
  }
};
