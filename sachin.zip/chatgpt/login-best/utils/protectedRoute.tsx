import { useRouter } from "next/router";
import { useEffect } from "react";
import { getUserToken } from "./auth";

const protectedRoute = (WrappedComponent: React.FC) => {
  const Wrapper: React.FC = () => {
    const router = useRouter();

    useEffect(() => {
      const token = getUserToken();

      if (!token) {
        router.push("/login");
      }
    }, [router]);

    return <WrappedComponent />;
  };

  return Wrapper;
};

export default protectedRoute;
