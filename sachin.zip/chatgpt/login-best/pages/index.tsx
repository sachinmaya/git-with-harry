import Link from "next/link";

const HomePage = () => {
  return (
    <div>
      <h1>Welcome to My App</h1>
      <Link href="/login">Login</Link>
    </div>
  );
};

export default HomePage;
