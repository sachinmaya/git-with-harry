import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { getUserToken } from "../utils/auth";
import { fetchData } from "../utils/api";

const DashboardPage = () => {
  const [data, setData] = useState("");
  const router = useRouter();

  useEffect(() => {
    const token = getUserToken();

    if (!token) {
      router.push("/login");
    } else {
      fetchData(token)
        .then((response) => setData(response.data))
        .catch((error) => {
          console.error("Error fetching data:", error);
          setData("Error fetching data");
        });
    }
  }, [router]);

  return (
    <div>
      <h2>Dashboard</h2>
      <p>{data}</p>
    </div>
  );
};

export default DashboardPage;
