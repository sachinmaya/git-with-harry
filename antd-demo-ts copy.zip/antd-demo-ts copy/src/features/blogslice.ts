import {createSlice, PayloadAction} from '@reduxjs/toolkit'

interface blogs {
    name: string,
    address: string
}

const initialState: blogs[] = []
const blogslice = createSlice({
    name: 'blogs',
    initialState,
    reducers: {

    }

})

export default blogslice.reducer