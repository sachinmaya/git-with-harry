import React from 'react';
import logo from './logo.svg';
import {Route, Routes} from 'react-router-dom'
import 'antd/dist/reset.css';
// import 'antd/dist/antd.css';
import LoginFrom from './pages/login2'
// import ClientProfile from './pages/clientProfile'
// import RegistrationForm from './pages/RegistrationForm'
// import DevFormik from './pages/devFormik'
// import DependentFields from './pages/dependentFields'
// import FieldArrays from './pages/fieldArray'
// import FieldArrayValidation from './pages/fieldArrayValidation'
import TypeForm from './pages/typeForm'
import LearnTypeScript from './pages/learnTypeScript'

import TsClass from './pages/tsClass'
import Home from './pages/Home'
import TypeScript from './pages/TypeScript'
import Layout from './layout/index'
import AntForm from './pages/antForm'
import Reactpolymorephic from './pages/Reactpolymorephic'
import VirtuosoGroup from './pages/VirtuosoGroup'
import VirtuosoGroupOnDemand from './pages/VirtuosoGroupOnDemand'
import HeaderFooterContent from './pages/HeaderFooterContent'
import TreedataEntry from './pages/treedataEntry'
// enum Gender {
//   male = 1,
//   female = 2

// }
// interface user<T,G> {
//   name:T,
//   address: T,
//   gender: G
// }
// const userObjects:user<string,Gender>[] = [
//   {
//     name:'Sachin',
//     address:'Bhw, Nepal',
//     gender: 1
//   },
//   {
//     name:'Sanskar',
//     address:'Bhw, Nepal',
//     gender: 1
//   },
//   {
//     name:'Maya',
//     address:'Bhw, Nepal',
//     gender: 2
//   },
//   {
//     name:'Gyanendra',
//     address:'Bhw, Nepal',
//     gender: 1
//   }
// ]
function App() {
  return (
    <div className="App">
      {/* <Layout /> */}
      <Routes>
        <Route path='/' element={<Layout />}> 
            <Route path='/' element={<Home />} />
            <Route path='/typescript' element={<TypeScript />} />
            <Route path='/typescript-and-react' element={<TsClass />} />
            <Route path='/virtuoso-scroll-to-group' element={<VirtuosoGroup />} />
            <Route path='/antform' element={<AntForm />} />   
            <Route path='/login' element={<LoginFrom />} />  
            <Route path='/load-on-demand' element={<VirtuosoGroupOnDemand />} />  
            <Route path='/treedataentry' element={<TreedataEntry />} />
        </Route>
        <Route path='/layout' element={<HeaderFooterContent />} />  
      </Routes>
    </div>
    
  );
}

export default App;
