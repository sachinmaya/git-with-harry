import {userItem, groupItem} from '../type'

export const users = [
    {
        firstName: 'Sachin',
        lastName: 'Bishwokarma',
        userName: 'sachinfb2018',
        phoneNumber: 9821991650,
        gender: 1,
        userType: 2,
        creationDate: 9874561253,
        status: 1
    },
    {
        firstName: 'Sanskar',
        lastName: 'Bishwokarma',
        userName: 'sanskar2018',
        phoneNumber: 9821991650,
        gender: 1,
        userType: 2,
        creationDate: 9874561253,
        status: 0
    },
    {
        firstName: 'Phullmaya',
        lastName: 'Bishwokarma',
        userName: 'maya2018',
        phoneNumber: 9821991650,
        gender: 1,
        userType: 2,
        creationDate: 9874561253,
        status: 1
    }
]

export const groups = [
    {
        groupName:'Respect Duabi',
        groupId: 23,
        ownerId: 12,
        groupMembers: users,
        status: 1,
        creationDate: 1234568795
    },
    {
        groupName:'Feuture Musium Duabi',
        groupId: 23,
        ownerId: 12,
        groupMembers: users,
        status: 1,
        creationDate: 1234568795
    }
]


