enum Status  {
    active = 1,
    inactive = 0
}
enum Gender {
    male = 1,
    female = 2
}
enum UserType {
    superAdmin = 1,
    normalAdmin = 2,
    userAdmin = 3,
    guest = 4
}
export interface groupItem<T,S>{
    groupName: T,
    groupId: T,
    ownerId:S,
    groupMembers:userItem<T,S>[],
    status: Status,
    creationDate: S
}

export interface userItem<T,S> {
    firstName: T,
    lastName: T,
    userName: T,
    phoneNumber: S,
    gender: Gender,
    userType: UserType,
    creationDate: S,
    status: Status
}