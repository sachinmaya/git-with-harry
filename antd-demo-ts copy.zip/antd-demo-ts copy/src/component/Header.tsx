/* @jsxImportSource @emotion/react */
import React,{ FC, useState } from 'react'
import type { MenuProps } from 'antd';
import {Menu} from 'antd'
import { AppstoreOutlined, MailOutlined, SettingOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import {useNavigate} from 'react-router-dom'

const logoCSS = css`
  float: left;
  width: 120px;
  height: 31px;
  margin: 16px 24px 16px 0;
  background: rgba(255, 255, 255, 0.3);
`
const items: MenuProps['items'] = [
    {
      label: 'Home',
      key: '/',
      icon: <MailOutlined />,
    },
    {
      label: 'About TS/React',
      key: '/typescript-and-react',
      icon: <AppstoreOutlined />,
      // disabled: true,
    },
    {
      label: 'Documents',
      key: '/SubMenu',
      icon: <SettingOutlined />,
      children: [
        {
          type: 'group',
          label: 'Read Documents',
          children: [
            {
              label: 'About TypeScript',
              key: '/typescript',
            },
            {
              label: 'About ReactJS',
              key: '/reactjs',
            },
          ],
        }
      ],
    },
    {
      label: 'Virtuoso',
      key: '/SubMenu2',
      icon: <SettingOutlined />,
      children: [
        {
          label: 'Scroll to Group',
          key: '/virtuoso-scroll-to-group',
          
        },
        {
          label: 'Load on Demand',
          key: '/load-on-demand',
          
        }
      ],
    },
    {
      label: 'Login',
      key: 'login',
      danger: true
    },
    {
      label: 'Antd From',
      key: 'antform',
    }
  ];

const Header: FC = () => {
  const [current, setCurrent] = useState('mail');
  const navigate = useNavigate();
  const handleLink: MenuProps['onClick'] = (e) => {
        console.log('click ', e);
        navigate(e.key);
        setCurrent(e.key);
  };
  return (
    <>
      <div css={logoCSS} />
        {/* <Menu
          theme="dark"
          mode="horizontal"
          defaultSelectedKeys={['2']}
          items={new Array(15).fill(null).map((_, index) => {
            const key = index + 1;
            return {
              key,
              label: `nav ${key}`,
            };
          })}
        /> */}

      <Menu 
        onClick={handleLink} 
        defaultSelectedKeys={[window.location.pathname]} 
        selectedKeys={[current]} 
        mode="horizontal" 
        items={items} />
    </>
  )
}

export default Header