import React,{ FC } from 'react'

import { Route, Routes } from "react-router-dom"

const renderRoutes: FC = routes => {
  return (
    <Routes>        
       
    </Routes>
  )
  
}

export default renderRoutes