/* @jsxImportSource @emotion/react */
import React, { FC, useState,useCallback } from 'react';

import { Layout } from 'antd';
import { Link, Outlet } from 'react-router-dom';
import TopHeader from '../component/Header'

const { Header, Footer, Content } = Layout;

const LayoutofSite: FC = (props) => {
  
  return (
    <Layout>
      <Header>
            <TopHeader/>
      </Header>
      <Content> 
        <Outlet />
      </Content>
      <Footer>Footer</Footer>
                  
    </Layout>
  )
}

export default LayoutofSite