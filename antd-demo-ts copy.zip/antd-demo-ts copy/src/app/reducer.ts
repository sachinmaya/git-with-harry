import blogReducer from '../features/blogslice'

const rootReducer = {
    blogs: blogReducer
}

export default  rootReducer;