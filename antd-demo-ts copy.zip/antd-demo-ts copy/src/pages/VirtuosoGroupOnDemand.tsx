/* @jsxImportSource @emotion/react */
import { GroupedVirtuoso, VirtuosoHandle } from 'react-virtuoso'
import { useCallback, useState, useRef, useEffect, useMemo, FC } from 'react'
import { generateGroupedUsers, toggleBg } from '../api/data2'
import { render } from 'react-dom';
import { Row, Col, Input, Select, Button } from 'antd'
import { css } from '@emotion/react';

const containerCSS = css`
  max-width: 1440px;
  height: 100vh;
  background-color: #edf7ff;
  margin: auto;
  /* position  : relative ; */
`
const pTitleCSS = css`
  color: #000;
  text-align: center;
  padding: 20px 0;
  width: 100%;
  .userList{
    text-align: left;
  }
  h4{
    color: #006e9d;
    font-size : 18px;
  }
  .indexHead{
    font-weight: bolder;
    font-size : 20px;
  }
`;

const VirtuosoGroupOnDemand: FC = () => {
    const { users, groups, groupCounts } = useMemo(() =>
        generateGroupedUsers(500),
        []
    )
    const virtuoso = useRef<VirtuosoHandle>(null)
    const calculateGroupsSoFar = useCallback((totalGroups:number[], count:number):any => {
        const groups = []
        let i = 0
        do {
          const group = totalGroups[i]
          groups.push(Math.min(group, count))
          count -= group
          i++
        } while (count > 0 && i <= totalGroups.length)
        return groups
      }, [])
    
      const [currentGroupCounts, setCurrentGroupCounts] = useState([])
      const loadedItems = useRef(0)
      const [loading, setLoading] = useState(false)

      const loadMore = useCallback(() => {
        setLoading(true)
        return setTimeout(() => {
          loadedItems.current += 50
          setLoading(false)
          setCurrentGroupCounts(
            calculateGroupsSoFar(groupCounts, loadedItems.current)
          )
        }, 500)
      }, [])
      
      useEffect(() => {
        const timeoutRef = loadMore()
        return () => clearTimeout(timeoutRef)
      }, [])
    
      
    return (
        <>
            <Row css={containerCSS}>
                <Col css={pTitleCSS}>
                <GroupedVirtuoso
                    style={{ height: 400 }}
                    groupCounts={currentGroupCounts}
                    groupContent={index => (
                        <div style={{ backgroundColor: 'var(--ifm-background-color)', paddingTop: '1rem' }}>Group {groups[index]}</div>
                    )}
                    itemContent={index => (
                        <div style={{ backgroundColor: toggleBg(index) }}>{users[index].name}</div>
                    )}
                    components={{
                        Footer: () => {
                        return (
                            <div
                            style={{
                                padding: '2rem',
                                display: 'flex',
                                justifyContent: 'center',
                            }}
                            >
                           
                            </div>
                        )
                        },
                    }}
                />
                 <button disabled={loading} onClick={loadMore}>
                                {loading ? 'Loading...' : 'Press to load more'}
                            </button>
                </Col>
            </Row>
        
        </>
    )
}

export default VirtuosoGroupOnDemand