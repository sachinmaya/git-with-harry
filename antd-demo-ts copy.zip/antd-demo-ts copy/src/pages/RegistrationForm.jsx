import React from 'react'
import { Button, Checkbox, Input,Row, Col } from 'antd';
// import { Grid, Paper, Button, Typography } from '@material-ui/core'
// import { TextField } from '@material-ui/core'
import { Formik, Form, Field, ErrorMessage } from 'formik'
import * as Yup from 'yup'

const RegistrationForm = () => {
    const paperStyle = { padding: '40px 20px', width: 250, margin: '20px auto' }
    const btnStyle = { marginTop: 10 }
    const phoneRegExp=/^[2-9]{2}[0-9]{8}/
    const passwordRegExp=/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/
    const initialValues = {
        name: '',
        email: '',
        phoneNumber: '',
        password: '',
        confirmPassword:''
    }
    const validationSchema = Yup.object().shape({
        name: Yup.string().min(3, "It's too short").required("Required"),
        email: Yup.string().email("Enter valid email").required("Required"),
        // phoneNumber: Yup.number().typeError("Enter valid Phone number").required("Required"),
        phoneNumber:Yup.string().matches(phoneRegExp,"Enter valid Phone number").required("Required"),
        password: Yup.string().min(8, "Minimum characters should be 8")
        .matches(passwordRegExp,"Password must have one upper, lower case, number, special symbol").required('Required'),
        confirmPassword:Yup.string().oneOf([Yup.ref('password')],"Password not matches").required('Required')
    })
    const onSubmit = (values, props) => {

        alert(JSON.stringify(values), null, 2)
        props.resetForm()
    }
    return (
        <div>
            <div>
                <div>
                    <p variant='h6'>Register Here</p>
                    <p variant='caption'>Fill the form to create an account</p>
                </div>
                <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
                    {(props) => (
                        <Form noValidate>
                            {/* <TextField label='Name' name="name" fullWidth value={props.values.name}
                    onChange={props.handleChange} /> */}

                            <Field name='name' label='Name' 
                                error={props.errors.name && props.touched.name}
                                 required />

                            {/* <TextField label='Email' name='email' type='Email'  
                    {...props.getFieldProps('email')}/> */}

                            <Field name='email' label='Email' 
                                error={props.errors.email && props.touched.email}
                                 required />

                            <Field name="phoneNumber" label='Phone Number' 
                                error={props.errors.phoneNumber && props.touched.phoneNumber}
                                 required />

                            <Field name='password' label='Password' type='password' 
                                error={props.errors.password && props.touched.password}
                                 required />

                            <Field name='confirmPassword' label='Confirm Password' type='password' 
                                error={props.errors.confirmPassword && props.touched.confirmPassword}
                                 required />

                            <button type='submit' style={btnStyle} variant='contained'
                                color='primary'>Register</button>
                        </Form>
                    )}
                </Formik>
            </div>
        </div>
    )
}

export default RegistrationForm;