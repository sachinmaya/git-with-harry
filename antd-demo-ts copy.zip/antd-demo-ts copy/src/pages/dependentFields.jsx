import React from 'react';
import ReactDOM from 'react-dom';
import { Formik, Field, Form, useField, useFormikContext } from 'formik';
// import './styles.css';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function fetchNewTextC(a, b) {
  await new Promise((r) => setTimeout(r, 500));
  return `textA: ${a}, textB: ${b}`;
}

const MyField = (props) => {
  const {
    values: { textA, textB },
    setFieldValue,
  } = useFormikContext();
  const [field, meta] = useField(props);

  React.useEffect(() => {
    let isCurrent = true;
    // your business logic around when to fetch goes here.
    if (textA.trim() !== '' && textB.trim() !== '') {
      fetchNewTextC(textA, textB).then((textC) => {
        if (!!isCurrent) {
          // prevent setting old values
          setFieldValue(props.name, textC);
        }
      });
    }
    return () => {
      isCurrent = false;
    };
  }, [textB, textA, setFieldValue, props.name]);

  return (
    <>
      <input {...props} {...field} />
      {!!meta.touched && !!meta.error && <div>{meta.error}</div>}
    </>
  );
};

const DependentFields = () => {
    const initialValues = { textA: '', textB: '', textC: '' };

    return (
      <div className="App">
        <Formik
          initialValues={initialValues}
          onSubmit={async (values) => {
            await sleep(3500);
            console.log(JSON.stringify(values, null, 2))
          }}
        >
        
            
            {({ isSubmitting }) => (
            <Form>
              <label>
                textA
                <Field name="textA" />
              </label>
              <label>
                textB
                <Field name="textB" />
              </label>
              <label>
                textC
                <MyField name="textC" />
                <small>
                  (the result of <code>fetchNewTextC(textA, textB))</code>
                </small>
              </label>
              <button type="submit" disabled={isSubmitting}>Submit</button>
            </Form>
            )}
          
        </Formik>
      </div>
    );
}

export default DependentFields