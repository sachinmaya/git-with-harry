/* @jsxImportSource @emotion/react */
import React, { FC, useEffect, useReducer, useState } from 'react'
import { css } from '@emotion/react';
import { Button } from 'antd';

const buttonCSS = css`
   margin-right : 10px ;
   cursor: pointer;
`
const initialState = {count: 0}

type ACTIONTYPE = 
| {type: "increment"; payload: number}
| {type: "decrement"; payload: string}
const reducer = (state: typeof initialState, action: ACTIONTYPE) => {
    switch(action.type){
        case 'increment':
            if(state.count > 50){
                state.count = 0;
                // return true;
            }
            return {count: state.count + action.payload };
        case 'decrement':
            return {count: state.count - Number(action.payload) };
        default:
            throw new Error();
    }
}
enum msgType {
    image = 1,
    video = 2,
    text = 3
}
type avatar = {
    faceUrl: string,
    defaultUrl:string,
}
type userInfo = {
    name: string,
    userid: number,
    faceUrl: avatar,
}
interface msgItem {
    msg:string,
    sender:userInfo,
    reciver:userInfo,
    msgType: msgType
}
const avatar2:avatar = {
    faceUrl: "abc.jpg",
    defaultUrl:"xyz.jpg",
}
const userInfo2:userInfo = 
    {   
        name: "sachin",
        userid: 5,
        faceUrl: avatar2,
    }

const msgList:msgItem[] = [
    {
        msg:"Hello world",
        sender:userInfo2,
        reciver:userInfo2,
        msgType: 1
    },
    {
        msg:"Yes Please",
        sender:userInfo2,
        reciver:userInfo2,
        msgType: 1
    },
    {
        msg:"What can i help you",
        sender:userInfo2,
        reciver:userInfo2,
        msgType: 1
    },
    {
        msg:"Thank you uae",
        sender:userInfo2,
        reciver:userInfo2,
        msgType: 1
    }
]
const ReducerTs:FC = () => {
 const[state, dispatch] = useReducer(reducer, initialState)
 const [cve,setCve] = useState<msgItem[] | null>(null)

 useEffect(()=> {
    setCve(msgList);
 },[])

 console.log(cve)
  return (
    <>
        <p>Count: {state.count}</p>
        <button css={buttonCSS} onClick={() => dispatch({type: "decrement", payload: "5"})}>-</button>
        <button css={buttonCSS} onClick={() => dispatch({type: "increment", payload: 5})}>+</button>
    </>
  )
}

export default ReducerTs