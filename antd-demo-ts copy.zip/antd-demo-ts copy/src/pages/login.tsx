import React, { FC } from 'react';
import { Button, Checkbox, Input,Row, Col } from 'antd';
import { EyeTwoTone, EyeInvisibleOutlined,InfoCircleOutlined } from '@ant-design/icons';
import * as Yup from "yup";
import {
    Formik,
    FormikHelpers,
    FormikProps,
    Field,
    FieldProps,
    Form,
    FormikErrors,
    FormikValues
  } from 'formik';
  
import '../App.css'

const formFieldWwrap = {
    display: 'flex',
    gap: '10px',
    margin: '10px 0px 30px 0px',
    alignItems: 'center',
    justifyContent: 'space-between'
}
const LoginFrom: FC = () => {   
    // const formvalidation = (values:any) => {
    //     const re = /^[0-9\b]+$/;
    //     let errors: FormikErrors<FormikValues> = {};
    //     if (!values.phonenumber) {
    //           errors.phonenumber = 'Please enter phone number';
    //     } else if (!re.test(values.phonenumber)) {
    //         values.phonenumber = '';
    //         errors.phonenumber = 'Only number is allow';
    //     } else if ((values.phonenumber).length > 13) {
    //         errors.phonenumber = 'Phone number must be less then 13 digit';
    //     } else if (!values.password) {
    //         errors.password = 'Please enter password';
    //     } else if (!values.password) {
    //         errors.password = 'Please enter password';
    //     }
    //       return errors;
    // }
    const LoginSchema = Yup.object().shape({
        phonenumber: Yup.string()
        .required()
        .matches(/^\d+$/, 'The field should have digits number only')
        .max(15, "Must be 15 characters or less"),
        password: Yup.string()
          .max(20, "Password must be 20 characters or less")
          .min(6, "Password must be 6 characters or more")
          .required("Password is required") 
          .matches(
            /^(?=.*\d)/,
            "Must contain one number"
          ) 
          .matches(
            /^(?=.*[~@$!%*#?&^*()])/,
            "Must Contain one special case Character"
          ) 
          .matches(
            /^(?=.*[A-Z])/,
            "Must Contain one Uppercase case Character"
          ) 
          .matches(
            /^(?=.*[a-z])/,
            "Must Contain one Lowercase case Character"
          )
        //   .test("isValidPass", " ch problem", (value:any, context) => {
        //         const hasUpperCase = /[\u4E00-\u9FA5]/i.test(value);
        //         let validConditions = 0;
        //         const numberOfMustBeValidConditions = 3;
        //         const conditions = [ hasUpperCase];
        //         conditions.forEach((condition) =>
        //           condition ? validConditions++ : null
        //         );
        //         if (validConditions >= numberOfMustBeValidConditions) {
        //           return true;
        //         }
        //         return false;
        //    }) 
        //   .matches(
        //     /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/,
        //     "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
        //   )
        //   .test("isValidPass", " is not valid", (value:any, context) => {
        //     const hasUpperCase = /[A-Z]/.test(value);
        //     const hasLowerCase = /[a-z]/.test(value);
        //     const hasNumber = /[0-9]/.test(value);
        //     const hasSymbole = /["!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"]/.test(value);
        //     let validConditions = 0;
        //     const numberOfMustBeValidConditions = 3;
        //     const conditions = [hasLowerCase, hasUpperCase, hasNumber, hasSymbole];
        //     conditions.forEach((condition) =>
        //       condition ? validConditions++ : null
        //     );
        //     if (validConditions >= numberOfMustBeValidConditions) {
        //       return true;
        //     }
        //     return false;
        //   })     
      })
    return (
        <Formik
        initialValues={{ phonenumber: '', password: '' }}
        //validate= {values => formvalidation(values)}
        validationSchema={LoginSchema}
        onSubmit={(values, actions) => {
            console.log({ values, actions });
            alert(JSON.stringify(values, null, 2));
            actions.setSubmitting(false);
          }}
        >
            {({
         values,
         errors,
         touched,
         handleChange,
         handleBlur,
         handleSubmit,
         isSubmitting,
         /* and other goodies */
       }) => (
            <Row gutter={[24, 32]}>
                
                <Col span={4} offset={10}>
                <Form>
                    <div className='form-field-wrap' style={formFieldWwrap}>
                    <label>Phone Number</label>
                        <div className='form-field'>
                            <Input placeholder="Enter username" name='phonenumber' id='phonenumber' 
                            onChange={handleChange}
                            onBlur={handleBlur}
                            autoComplete="off"
                            value={values.phonenumber}
                            className={errors.phonenumber &&  'field-error'}
                            suffix={errors.phonenumber &&  <InfoCircleOutlined  style={{ color: 'rgba(255,0,0,1)' }} />}
                            />  
                            {errors.phonenumber && touched.phonenumber && (<div className={'error-text'}>{errors.phonenumber}</div>)}
                        </div>
                    </div>
                    

                    <div className='form-field-wrap' style={formFieldWwrap}>
                    <label>Passwrod</label>                    
                        <div className='form-field'>
                            <Input.Password
                            placeholder="Enter password"
                            id='password'
                            name='password'
                            iconRender={(visible) => (visible ? <EyeTwoTone /> : <EyeInvisibleOutlined/>)}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            className={errors.password &&  'field-error'}
                            />  
                             {errors.password && touched.password && (<div className={'error-text'}>{errors.password}</div>)}                
                        </div>
                    </div>
                    

      <div>
                  
                
      </div>      
      <Button type="primary" onClick={(event: React.MouseEvent<HTMLDivElement, MouseEvent>)=>handleSubmit()}>Login</Button>
      {/* <button type="submit" disabled={isSubmitting}>
             Submit Normal From
       </button> */}
      </Form>
                </Col>
                
            </Row>
       )}
        </Formik> 
    );
  };

export default LoginFrom;