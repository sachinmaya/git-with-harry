/* @jsxImportSource @emotion/react */
import React,{ FC } from 'react'
import { Row, Col, Input, Select, Button } from 'antd'
import { css } from '@emotion/react';

const containerCSS = css`
  /* max-width: 1440px;
  height: 100vh; */
  background-color: #edf7ff;
  margin: auto;  
`
const pTitleCSS = css`
  color: #650404;
  text-align: center;
  padding: 20px 0;
  width: 100%;
`;

const TypeScript: FC = () => {
  const pageTitle: string = "About React Typescript"
  return (
    <Row css={containerCSS}>
          <h2 css={pTitleCSS}>{pageTitle} </h2>

    </Row>
  )
}

export default  TypeScript