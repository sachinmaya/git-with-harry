import React from 'react';
import * as Yup from 'yup';
import { withFormik, FormikProps, FormikErrors, Form, Field } from 'formik';

// Shape of form values
interface FormValues {
  email: string;
  password: string;
}

interface OtherProps {
  message: string;
}

// Aside: You may see InjectedFormikProps<OtherProps, FormValues> instead of what comes below in older code.. InjectedFormikProps was artifact of when Formik only exported a HoC. It is also less flexible as it MUST wrap all props (it passes them through).
const InnerForm = (props: OtherProps & FormikProps<FormValues>) => {
  const { touched, errors, isSubmitting, message } = props;
  return (
    <Form>
      <h1>{message}</h1>
      <Field type="email" name="email" />
      {touched.email && errors.email && <div>{errors.email}</div>}

      <Field type="password" name="password" />
      {touched.password && errors.password && <div>{errors.password}</div>}

      <button type="submit" disabled={isSubmitting}>
        Submit
      </button>
    </Form>
  );
};

// The type of props MyForm receives
interface MyFormProps {
  initialEmail?: string;
  message: string; // if this passed all the way through you might do this or make a union type
}
const isValidEmail = (value:string | number | undefined):boolean => {
    return false;
}
// Wrap our form with the withFormik HoC
const MyForm = withFormik<MyFormProps, FormValues>({
  
  // Transform outer props into form values
  mapPropsToValues: props => {
    return {
      email: props.initialEmail || '',
      password: '',
    };
  },

  // Add a custom validation function (this can be async too!)
  validate: (values: FormValues) => {
    let errors: FormikErrors<FormValues> = {};
    if (!values.email) {
      errors.email = 'Required';
    } else if (!isValidEmail(values.email)) {
      errors.email = 'Invalid email address';
    }
    return errors;
  },

  handleSubmit: values => {
    // do submitting things
  },
})(InnerForm);


let abc: string = 'sachin'
abc = '23';

interface user<S,T> {
    name: S,
    addres: S,
    age: T,
    entrytime : T,
    status: 0 | 1
}

const users: user<string, number>[] = [
    {name:'Sachin', addres:'Bhw, Nepal', age:38, entrytime: 1235645655, status:1},
    {name:'Kapil', addres:'Bhw, Nepal', age:38, entrytime: 1235645655, status:1},
    {name:'Sanskar', addres:'Bhw, Nepal', age:38, entrytime: 1235645655, status:1}
]

type groupItemInfo = {
    groupId: number,
    groupOwnerId: number,
    groupMembers: user<string, number>[],
    status: 0 | 1,
    createDate: number
}

const activeGroupList: groupItemInfo[] = [
    {
        groupId: 25,
        groupOwnerId: 45,
        groupMembers: users,
        status: 1,
        createDate: 12345665754 
    },
    {
        groupId: 11,
        groupOwnerId: 31,
        groupMembers: users,
        status: 0,
        createDate: 12345665754 
    },
    {
        groupId: 9,
        groupOwnerId: 4,
        groupMembers: users,
        status: 1,
        createDate: 12345665754 
    }
]
const getGroupInfo = activeGroupList.find(item => item.groupId === 25);
const todayTime = Date.now();
console.log(todayTime);
const getGroupInfo2 = {...getGroupInfo,createDate : todayTime};
console.log(getGroupInfo);
console.log(getGroupInfo2);

const getUserInfo: groupItemInfo = {
    groupId: 5,
    groupOwnerId: 1,
    groupMembers: users,
    status: 1,
    createDate: 12345665754 
}
console.log(getUserInfo);
// Use <MyForm /> wherevs
const Basic = () => (
  <div>
    <h1>My App</h1>
    <p>This can be anywhere in your application</p>
    <MyForm message="Sign up" />
  </div>
);

export default Basic;