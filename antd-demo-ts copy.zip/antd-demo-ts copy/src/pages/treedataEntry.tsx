import React, { useState } from 'react';
import { Space, Switch, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import type { TableRowSelection } from 'antd/es/table/interface';

interface DataType {
  key: React.ReactNode;
  name: string;
  age: string;
  address: string;
  children?: DataType[];
}

const columns: ColumnsType<DataType> = [
  {
    title: 'Page Name',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Page Url',
    dataIndex: 'age',
    key: 'age',
    width: '12%',
  },
  {
    title: 'Action',
    dataIndex: '',
    width: '30%',
    key: 'address',
  },
];

const data: DataType[] = [
  {
    key: 1,
    name: 'Statistics',
    age: 'users/usersList',
    address: 'statistics/usersSta',
    children: [
      {
        key: 11,
        name: 'User Statistics',
        age: 'statistics/usersSta',
        address: 'New York No. 2 Lake Park',
      },
      {
        key: 12,
        name: 'Group Statistics',
        age: 'statistics/groupsSta',
        address: 'New York No. 3 Lake Park',
      },
      {
        key: 13,
        name: 'Message Statistics',
        age: 'statistics/messagesSta',
        address: 'New York No. 3 Lake Park',
      },      
    ],
  },
  {
    key: 2,
    name: 'Platform Management',
    age: '/platformManagement/googleAuthSetting',
    address: 'statistics/usersSta',
    children: [
      {
        key: 14,
        name: 'Google Authenticator Setting',
        age: '/platformManagement/googleAuthSetting',
        address: 'New York No. 2 Lake Park',
      }    
    ],
  },
  {
    key: 3,
    name: 'Users',
    age: 'users/usersList',
    address: 'statistics/usersSta',
    children: [
      {
        key: 15,
        name: 'User List',
        age: 'users/usersList',
        address: 'New York No. 2 Lake Park',
      }    
    ],
  },
];

// rowSelection objects indicates the need for row selection
const rowSelection: TableRowSelection<DataType> = {
  onChange: (selectedRowKeys, selectedRows) => {
    // console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
    console.log(selectedRowKeys)
  },
  onSelect: (record, selected, selectedRows) => {
    // console.log(record, selected, selectedRows);
  },
  onSelectAll: (selected, selectedRows, changeRows) => {
    // console.log(selected, selectedRows, changeRows);
  },
};
class Person{
    private firstName: string;
    private lastName: string;
  
    constructor(firstName:string, lastName: string){
      this.firstName = firstName;
      this.lastName = lastName;
    }
    protected getPersonFullName = () => {
      return `${this.firstName} ${this.lastName}`
    }
  }
  
  class Employee extends Person{
    department:string;
    degination: string;
  
    constructor(firstName:string, lastName:string, department:string, degination:string){
      super(firstName,lastName);
      this.department = department;
      this.degination = degination;
    }
  
    getEmployeeInfo = () =>{
      return  `Hi, Mr ${this.getPersonFullName}. Your department is ${this.department} and degination is ${this.degination}`
    }
  }
  
  const employeeInfo = new Employee("Sachin","Bishwokarma", "It Department", "Software Developer")
  employeeInfo.getEmployeeInfo();
  
  
const TreedataEntry: React.FC = () => {
  const [checkStrictly, setCheckStrictly] = useState(true);

  return (
    <>
      <Space align="center" style={{ marginBottom: 16 }}>
        CheckStrictly: <Switch checked={checkStrictly} onChange={setCheckStrictly} />
      </Space>
      <Table
        columns={columns}
        rowSelection={{ ...rowSelection, checkStrictly }}
        dataSource={data}
      />
    </>
  );
};

export default TreedataEntry;