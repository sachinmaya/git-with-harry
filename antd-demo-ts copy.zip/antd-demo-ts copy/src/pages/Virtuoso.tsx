/* @jsxImportSource @emotion/react */
import React, { Component, FC, useEffect, useMemo, useState } from 'react';
import { TableVirtuoso } from 'react-virtuoso'
import { render } from 'react-dom';
import { Row, Col, Input, Select, Button } from 'antd'
import { css } from '@emotion/react';

const containerCSS = css`
  max-width: 1440px;
  height: 100vh;
  background-color: #edf7ff;
  margin: auto;
  /* position  : relative ; */
`
const pTitleCSS = css`
  color: #650404;
  /* text-align: center; */
  padding: 20px 0;
  width: 100%;
`;

const Virtuoso3: FC = () => {
    const [posts,setPosts] = useState([])
    useEffect(() =>{
        fetch('https://jsonplaceholder.typicode.com/posts')
        .then((response) => response.json())
        .then((json) =>  {
            const data = json;
            setPosts(data) 
        });
    },[])
    // console.log(posts);
    return (
        <>
            <Row css={containerCSS}>
                <Col css={pTitleCSS}>
                <TableVirtuoso
                style={{ height: 400 }}
                data={posts}
                itemContent={(index, post) => 
                    {
                        // console.log(post)
                        const {id, title} = post;
                        return (<>
                        <td style={{ width: 150 }}>{id}</td>
                        <td>{title}</td>
                        </>)
                    }
                }
                />
                </Col>
            </Row>
        
        </>
    )
}

export default Virtuoso3