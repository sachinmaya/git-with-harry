/* @jsxImportSource @emotion/react */
import React,{ FC, useEffect, useState }  from'react'
import { Row, Col, Input, Select, Button } from 'antd'
import { css } from '@emotion/react';
import {groupItem, userItem} from '../type'
import {users,groups} from '../api/data'
import { boolean, string } from 'yup';
import { date, number } from 'yup/lib/locale';
import _ from 'lodash'
const containerCSS = css`
  /* max-width: 1440px;
  height: 100vh; */
  background-color: #edf7ff;
  margin: auto;  
`
const pTitleCSS = css`
  color: #650404;
  text-align: center;
  padding: 20px 0;
  width: 100%;
`;

const TsClass: FC = () => {
  const pageTitle: string = "Welcome To React Typescript Class"
  
  const [userList, setUserList] = useState<userItem<string, number>[] | undefined>([])
  
  
  useEffect(() =>{
    // const userList:userItem<string,number>[] = users;
    // const currentUsers:userItem<string,number>[] = users;
    setUserList(users) 
  },[])
  // console.log(userList);
  // if (currentUsers.length > 0){
      
  // }
  // let firstname: any = 'sachin';
  // firstname = 23 
  // firstname = true
  // firstname = []
  
  // const users2: readonly string[] = ['test'];
  // users2.push("sachin")
  // users2.push("binam")
  // users2.push("sanskar")
  // users2.push("sibam")
  // console.log(users2)


  // const student = ['Binod'];
  // student.push('2300')


  // let myTupple:[string,number,boolean,any];
  // myTupple = ["sachin", 2365, true, "sachin"]; //type match
  // myTupple = ["sachin", 23, true, "sachin"];  // not match

  // let myTupple2:readonly [string[], number[],boolean[],[{}]]
  // myTupple2 = [["sdfsd","Kapil"],[34,65],[true,false],[{name:"sachin",address:"Nepal"}]] 
  // myTupple2.push("kapil")
  // console.log(myTupple2)

///Type script objects
useEffect(() =>{
const teachers: {name: string, addres: string, age: number, friends: string[]} = {
  name:'Sachin Bishwokarma',
  addres: "Omsatiya-1, Nepal",
  age: 38,
  friends: ["Kapil","Gyanendra lal srivastav","Sallo","Navin"]
}
// console.log(teachers)
},[])

const teacher2:{[index:string] :number} = {}
teacher2.sachin = 38
teacher2.umer = 25
teacher2.hamdan = 25
teacher2.kapil = 42

// console.log(teacher2);

interface Abc<T,S> {
  name:T,
  age:S,
  status: 0 | 1
}

interface Xyz<T,S> extends Abc<T,S>{
  username: T,
  password: T
} 

const studentList:Xyz<string, number>[] = [
  {
    name:"Sachin",
    age:38,
    status: 1,
    username: "sachinfb2014",
    password:"kapil207"
  }
]
// console.log(studentList);

// function abc(username:string, password: string){
//   return `your username is ${username} and password ${password}`
// }
// const abcInfo = abc("sachinfb2018","loveme@07");
// console.log(abcInfo);
function abc<T,S>(username:T, password?: T):string | number{
  return `your username is ${username} and password ${password === undefined ? "Not set":password}`
}
const abcInfo = abc<string,number>("sachinfb2018");
// console.log(abcInfo);

const myFunc = (a: string, b: string, ...rest: number[]) => {
    console.log(a)
    console.log(b)
    console.log(rest)
}
const myValue:any[] = ["Sachin","Kapil",12,34,56,67]
// myFunc("Sachin","Kapil",12,34,56,67);

type userInfo = (id: number) => any[];

const getUserInfo:userInfo = (id) => {
  const user = [id,"Sachin","Omsatiya-1, Nepal",38,"Broun"]
  return user;
}
// console.log(getUserInfo(1))

let user:unknown = "Sachin";
// console.log(user as string)

class Friends<S,T>{
  public firstname: S;
  private lastname: S;
  private age : T;

  constructor(firstname:S,lastname:S,age:T){
    this.firstname = firstname;
    this.lastname = lastname;
    this.age = age;
  }

 getFriendInf = ():string|number => {
  return `Your firend name is ${this.firstname} ${this.lastname} and you are ${this.age} years old`
 }
}

// class SanskarFriends extends Friends<S,T>{

// }

useEffect( () =>{
  const friendObj = new Friends<string,number>("Anji","Gurung",12);
  // console.log(friendObj.getFriendInf())
  // console.log(friendObj.firstname)
},[])

class Furits<T,S>{
  constructor(public furitsName:T,public price:S){};

  getFuritsInf():string{
    return `Furits details ${this.furitsName} and price is ${this.price}`
  }
}

useEffect( () =>{
  const furitsInfo = new Furits<string,number>("Apple",250);
  // console.log(furitsInfo.getFuritsInf())
  // console.log(friendObj.firstname)
},[])

interface Shape{
  getArea: () => number;
}

class Rectangle implements Shape{
  public constructor(protected readonly width: number, protected readonly height:number){}

  public getArea = ():number => {
    return this.width * this.height
  };
}
// const getRectangleInfo = new Rectangle(200,300)
// console.log(getRectangleInfo.getArea())


interface Person<T,S>{
  name: T,
  age: S
  class?:number
}

const getPropertyValuePerson = <T,S>(person: Person<T,S>, property: keyof Person<T,S>):string => {
  return `${person[property]}`
}

const person:Person<string,number> = {
  name: "sachin",
  age: 25
}
let ourTuple : [string, number, boolean, string[],number[]]
ourTuple = ["Sachin", 9821991650, true,["Sachin","Bikash"],[12,23,45]]

getPropertyValuePerson<string,number>(person, "class");


type NameType<T,S> = {
  name: T,
  age: S
}

class Collection<T extends NameType<string,number>>{
  protected items: T[] = [];
  constructor( items: T[]){
    this.items.push(...items)
  }
  addItem(items:T){
    this.items.push(items)
  }
  removeItem(index:number){
    this.items.splice(index, 1);
  }
  getItem = (index:number) => {
    console.log(this.items[index])
  }
}

class SearchableCollection<T extends NameType<string,number>> extends Collection<T> {
  find(name: string): T | undefined {
    return this.items.find(item => item.name === name);
  }
}

interface Person2 {
  name: string;
  age: number;
}

const obj:SearchableCollection<Person2> = new SearchableCollection<Person2>([{name:"Sachin Bishowkarma", age:25},{name:"Sachin Bishowkarma", age:25},{name:"Sachin Bishowkarma", age:25}])
obj.getItem(2)
// console.log(obj.find("Sachin Bishowkarma"))

enum GenderType{
  male = 1,
  female = 2
}
interface OurUser {
  name:string,
  email:string,
  userName:string,
  password:string,
  addres:string,
  gender: GenderType,
  contact: number,
  status: 1 | 2,
}
type pUserType = Pick<OurUser, "name" | "email" | "password" | "gender">

const partialUserInfo: pUserType[] = [
  {
    name:'Sachin',
    email: 'sachin.web2@gmail.com',
    password: 'testme@07',
    gender: 1
  }
]

// const partialUserInfo: Pick<OurUser, 'name' | 'email'>[] = [
//   {
//     name:'Sachin',
//     email: 'sachin.web2@gmail.com'
//   }
// ]

interface UserType {
  firstName: string;
  lastName: string;
  userAge: number;
  dateOfBirth: string;
}
class User{
  private firstName: string;
  private lastName: string;
  private userAge: number;
  private dateOfBirth: string;

  constructor(firstName: string, lastName: string, userAge: number, dateOfBirth:string){
    this.firstName = firstName;
    this.lastName = lastName;
    this.userAge = userAge;
    this.dateOfBirth = dateOfBirth;
  }

  getUserInformation = ():UserType[] =>{
    const firstName = this.firstName;
    const lastName = this.lastName
    const userAge = this.userAge
    const dateOfBirth = this.dateOfBirth
    return [{firstName, lastName, userAge, dateOfBirth}]
  }

}

const friendName: unknown = "Sachin Bishwokarma";
// console.log((friendName as string).length)

const furitsList:string[] = ["a","b","c","d"];
const evenNumberList: number[] = [1,3,5,7,9]
// const numbers = 
const myNums: number[] = _.uniq([1,2,34,23,2,23,1,6,77,87,34])
// console.log(myNums)

var users1 = [
  { 'user': 'barney',  'active': false },
  { 'user': 'barney',    'active': false },
  { 'user': 'pebbles', 'active': true }
];

// console.log(_.findIndex(users1,(val) => val.user === "pebbles"));
const amyarr: number[] = [1,2,3];
// console.log(_.fill(amyarr, 5))
// console.log(_.fill(Array(5),'a'))
// console.log(_.fill([4, 6, 8, 10], '*',1, 4))
interface TeacherType{
  id: number,
  user: string,
  active: boolean
}
const teacher:TeacherType[] = [
  { 'id': 1, 'user': 'barney',  'active': false },
  { 'id': 2, 'user': 'barney',    'active': false },
  { 'id': 3, 'user': 'pebbles', 'active': true }
];
 
const newTeacherList = _.dropWhile(teacher,(data:TeacherType) => data.id === 1)

const pCSS = css`
font-size:62.5%;
`;
const aCSS = css`font-size:1rem;`;
const bCSS = css`
font-size:10rem;
@media (max-width: 768px) {
    font-size:10rem;
    /* color: red; */
  }
`;
console.log(newTeacherList);
  return (
    <Row css={containerCSS}>
          <h2 css={pTitleCSS}>{pageTitle} </h2>

          <Col span={16} offset={3}>
            {
              userList?.map((item , index) => {
                const {firstName, lastName, userName, phoneNumber, gender, userType}  = item;
                // console.log(firstName);
                return(
                  <p key={index}>Hello world</p>
                )
              })
            }
            <div css={pCSS}>
              <div css={aCSS}>Hello UAE</div>
              <div css={bCSS}>Hello UAE</div>
            </div>
          </Col>
    </Row>
  )
}

export default TsClass