/* @jsxImportSource @emotion/react */
import React, { FC, useEffect, useState } from 'react'
import { Row, Col, Input, Select, Button } from 'antd'
import { css } from '@emotion/react';

import ReducerTs from './hooks/ReducerTs'

const containerCSS = css`
  /* max-width: 1440px;
  height: 100vh; */
  background-color: #edf7ff;
  margin: auto;  
`
const pTitleCSS = css`
  color: #650404;
  /* text-align: center; */
  padding: 20px;
  background-color: #fff;
  width: 100%;
  .userItem{
    cursor: pointer;
    padding: 10px;
    &:hover{
    background-color: #ccc;
    }
  }
`;

enum Gender {
    male = 1,
    female = 2
  
  }
  interface user<T,G> {
    name:T,
    address: T,
    gender: G
  }

  type userType = {
    userslist:user<string,Gender>[],
    userId: number | undefined,
    cve: string[]
  }
  type t1 = {
    userslist:user<string,Gender> | null | undefined
  }
  interface student {
    name: string;
    add: string;
  } 
const UserList:FC<userType> = ({userslist, userId, cve}): JSX.Element => {
  const [userList,setUserList] = useState<user<string,Gender>[] | null>(null)
  const [submitResult,setSubmitResult] = useState<student[] | undefined>(undefined)
//   console.log(userslist)
  useEffect(() =>{
    const sutdents:student[] = [
        {
            name: 'sachin',
            add: 'nepal'
        },
        {
            name: 'kapil',
            add: 'india'
        },
        {
            name: 'sunita',
            add: 'pakistan'
        }
    ]
    setUserList(userslist)
    setSubmitResult(sutdents)
  },[])

  interface Person  {
    name:string,
    age: number
  }

  const printPersonProperty = (person: Person,property: keyof Person) =>{
    return person[property];
  }
  let person: Person = {
    name: "Sanskar",
    age:4
  }
  
  console.log(printPersonProperty(person, "name"))
  return (
    <>
    <Row css={containerCSS}>
        <Col css={pTitleCSS} span={12} offset={6}>
            <h1>UserList</h1>
            {userList?.map((item, index)=> {
                const {name, address, gender} = item;
                return (
                    <>
                        <div className='userItem' key={index}>
                            <p>Name: {name}</p>
                            <p>Adress: {address}</p>
                            <p>Gender: {gender}</p>
                        </div>
                        <hr />
                    </>
                )
            })}
            <div>
                <ReducerTs />
            </div>
        </Col>
    </Row>
    </>    
  )
}

export default UserList