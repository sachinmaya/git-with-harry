/* @jsxImportSource @emotion/react */
import React, { FC, useState,useCallback } from 'react';
import type { MenuProps } from 'antd';
import { Layout, Menu, Row, Col, Input, Select, Button } from 'antd';
import { AppstoreOutlined, MailOutlined, SettingOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { string } from 'yup';
import {useNavigate} from 'react-router-dom'
import {Formik, Form, FormikValues} from 'formik'
import * as Yup from "yup";
const { Header, Footer, Content } = Layout;
const { TextArea } = Input;
const { Option } = Select;
const logoCSS = css`
  float: left;
  width: 120px;
  height: 31px;
  margin: 16px 24px 16px 0;
  background: rgba(255, 255, 255, 0.3);
`
const containerCSS = css`
  /* max-width: 1440px;
  height: 100vh; */
  background-color: #edf7ff;
  margin: auto;  
`
const pTitleCSS = css`
  color: #650404;
  text-align: center;
  padding: 20px 0;
  width: 100%;
`;
const groupWrapCSS = css`
  .subTitleCSS{
    text-align: center;
    }
  .groupList{
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
    justify-content: space-between;
    .groupItem{
      background-color: #ccc;
      /* flex: 1; */
      width: 20rem;
      .groupImage{
        background-color: #2d2d55;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #fff;
      }
      .groupInfo{
        padding:20px;
      }
    }
  }
`
const groupWrap2CSS = css`
  .subTitleCSS{
    text-align: center;
    }
  .groupList2{
    .groupItem{
      /* background-color: #ccc; */
      /* flex: 1; */
      width: 20rem;
      .groupImage{
        background-color: #2d2d55;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #fff;
      }
      .groupInfo{
        padding:20px;
      }
    }
  }
`

const items: MenuProps['items'] = [
  {
    label: 'Home',
    key: '/',
    icon: <MailOutlined />,
  },
  {
    label: 'About TS/React',
    key: '/typescript-and-react',
    icon: <AppstoreOutlined />,
    // disabled: true,
  },
  {
    label: 'Documents',
    key: '/SubMenu',
    icon: <SettingOutlined />,
    children: [
      {
        type: 'group',
        label: 'Read Documents',
        children: [
          {
            label: 'About TypeScript',
            key: '/typescript',
          },
          {
            label: 'About ReactJS',
            key: '/reactjs',
          },
        ],
      }
    ],
  },
  {
    label: (
      <a href="https://ant.design" target="_blank" rel="noopener noreferrer">
        Offical Links
      </a>
    ),
    key: 'alipay',
    danger: true
  },
];

enum Gender {
  male = 1,
  female = 2
}
const LearnTypeScript: FC = (props) => {
  const pageTitle: string = "Welcome to typeScript and React"
  const [current, setCurrent] = useState('mail');
  const navigate = useNavigate();
  // const onClick: MenuProps['onClick'] = (e) => {
  //   console.log('click ', e);
    
  //   setCurrent(e.key);
  // };

  interface user<S,T> {
    username: S,
    firstname: S | null,
    lastname: S | null,
    address: S | null,
    email: S,
    gender: Gender,
    status: 0 | 1
  }

  const userList:user<string,number>[] = [
    {
      username:"sachinme2022",
      firstname: "Sachin",
      lastname: null,
      address: "Omsatiya-1, Nepal",
      email: "sachin.web2@gmail.com",
      gender: 1,
      status: 1
    },
    {
      username:"sanskar2022",
      firstname: "Sanskar",
      lastname: "Bishwokarma",
      address: "Omsatiya-1, Nepal",
      email: "sachin.web2@gmail.com",
      gender: 1,
      status: 1
    },
    {
      username:"gyanendraMG",
      firstname: "Gyanendra Lal Srivastav",
      lastname: null,
      address: "Omsatiya-1, Nepal",
      email: "sachin.web2@gmail.com",
      gender: 1,
      status: 1
    },
    {
      username:"mayabk",
      firstname: "Phull Maya Bishokarma",
      lastname: null,
      address: "Omsatiya-1, Nepal",
      email: "sachin.web2@gmail.com",
      gender: 1,
      status: 1
    },
    {
      username:"mohandl",
      firstname: "Mohaan Dotel",
      lastname: null,
      address: "Kumarigal,Kathmandu nepal, Nepal",
      email: "sachin.web2@gmail.com",
      gender: 1,
      status: 1
    }
  ]

  type groupsItem<S,T> = {
    groupId: T,
    groupMemberId: T,
    groupName: S,
    groupMembers: user<string,number>[],
    groupCreatedDate:T,
    status: 0 | 1
  }

  const grouplists:groupsItem<string, number>[] = [
    {
      groupId: 1,
      groupMemberId: 12,
      groupName: "Dubai world cup 2022 fan",
      groupMembers: userList,
      groupCreatedDate:1234567895,
      status:  1
    },
    {
      groupId: 2,
      groupMemberId: 11,
      groupName: "Dubai future musium",
      groupMembers: userList,
      groupCreatedDate:1234567895,
      status:  1
    },
    {
      groupId: 3,
      groupMemberId: 18,
      groupName: "Skew Dubai",
      groupMembers: userList,
      groupCreatedDate:1234567895,
      status:  1
    },
    {
      groupId: 4,
      groupMemberId: 33,
      groupName: "Expo Dubai 2020",
      groupMembers: userList,
      groupCreatedDate:1234567895,
      status:  0
    },
    {
      groupId: 5,
      groupMemberId: 43,
      groupName: "Mall of Emirates",
      groupMembers: userList,
      groupCreatedDate:1234567895,
      status:  0
    },
    {
      groupId: 6,
      groupMemberId: 76,
      groupName: "We love dubai,",
      groupMembers: userList,
      groupCreatedDate:1234567895,
      status:  1
    },
    {
      groupId: 8,
      groupMemberId: 22,
      groupName: "Dubai love jobs",
      groupMembers: userList,
      groupCreatedDate:1234567895,
      status:  0
    },
    {
      groupId: 9,
      groupMemberId: 14,
      groupName: "Youth Dubai",
      groupMembers: userList,
      groupCreatedDate:1234567895,
      status:  1
    }
  ]
  
  const handleLink: MenuProps['onClick'] = (e) => {
    console.log('click ', e);
    navigate(e.key);
    setCurrent(e.key);
  };
  const Jobvalidation = Yup.object().shape({
    username: Yup.string()
    .max(20, "Username must be 20 characters or less")
    .min(8, "Username must be 8 characters or more")
    .required("Please enter username"),
    password: Yup.string()
    .required("Please enter password")
    .max(20, "Password must be 20 characters or less")
    .min(8, "Password must be 8 characters or more"),
    cpassword: Yup.string()
    .required("Please enter confirm password")
    .oneOf([Yup.ref('password')],"Password not matches")
  })
  return (
    <Layout>
      <Header>
        <div css={logoCSS} />
        {/* <Menu
          theme="dark"
          mode="horizontal"
          defaultSelectedKeys={['2']}
          items={new Array(15).fill(null).map((_, index) => {
            const key = index + 1;
            return {
              key,
              label: `nav ${key}`,
            };
          })}
        /> */}

      <Menu 
        onClick={handleLink} 
        defaultSelectedKeys={[window.location.pathname]} 
        selectedKeys={[current]} 
        mode="horizontal" 
        items={items} />
      </Header>
      <Content> 
        <Row css={containerCSS}>
          <h2 css={pTitleCSS}>{pageTitle} </h2>
          <Col span={18} offset={3}>
            <div css={groupWrap2CSS}>
            <h3 className='subTitleCSS'>Group List</h3>
              <Row gutter={15} className='groupList2'>
              {grouplists.map(({groupName, groupMembers, status},index) => {               
                    return (
                      <Col span={6} className='groupItem' key={index}>
                          <div className='groupImage'>
                              <p>Thumb Image</p>
                          </div>
                          <div className='groupInfo'>
                                <h4>Group Name: {groupName}</h4>
                                <div className='groupOtherInfo'>
                                    <p>Total Members: {groupMembers.length}</p>
                                    <p>Status: {status === 1 ? "Active":"Inactive"}</p>
                                </div>
                          </div>
                      
                      </Col>
                    )
                  })}

                
                 
              </Row>
            </div>
            <Row>
              <Col span={8} offset={8}>
                <h2>Apply For Jobs</h2>
                <Formik
                  initialValues={{username:'',password:'',cpassword:'',firstname:'',lastname:'',jobType:'',trems:false}}
                  validationSchema={Jobvalidation}
                  onSubmit={(values, actions)=>{
                      console.log("Form Submit")
                  }}
                  >
                    {({
                      values,
                      errors,
                      touched,
                      handleChange,
                      handleBlur,
                      handleSubmit,
                      isSubmitting,
                      /* and other goodies */
                    }) => (
                    <Form>
                      <Input placeholder="Please enter Username" id='username' name='username'
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.username}
                      />
                      <br />
                      {errors.username && touched.username && (<div>{errors.username}</div>)}
                        <br />
                        <br />
                        <Input.Password placeholder="Please enter password" id='password' name='password'
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.password}
                        />
                        <br />
                        {errors.password && touched.password && (<div>{errors.password}</div>)}
                       
                        <br />
                        <br />
                        <Input.Password placeholder="Please enter confirm password" id='cpassword' name='cpassword'
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.cpassword}
                        />
                        <br />
                        {errors.cpassword && touched.cpassword && (<div>{errors.cpassword}</div>)}
                        <br />
                        <br />
                        <Input placeholder="Please enter Firstname" id='firstname' name='firstname' />
                        <br />
                        <br />
                        <Input placeholder="Please enter lastname" id='lastname' name='lastname' />
                        <br />
                        <br />
                        <TextArea rows={4} placeholder="Enter some text about you." maxLength={6} name='shortletter' id='shortletter' />  
                        <br />
                        <br />
                        <Select defaultValue="1">
                            <Option value="1">Admin</Option>
                            <Option value="2">HR</Option>
                            <Option value="3">OP</Option>
                            <Option value="4">Web</Option>
                            <Option value="5">Android</Option>
                            <Option value="6">IOS</Option>
                        </Select>
                        <br />
                        <br />
                        <input
                          type="checkbox"
                          placeholder="Subscribe to Newsletter"
                          id="trems"
                          name='trems'
                        />
                        <label htmlFor="customCheck1">&nbsp;I Agree with TC</label>
                        <br />
                        <br />
                        <Button type="primary" onClick={(event: React.MouseEvent<HTMLDivElement, MouseEvent>)=>handleSubmit()}>Apply Now</Button>
                        
                    </Form>
                    )}
                  </Formik>
              </Col>
            </Row>
          </Col>
        </Row>

      </Content>
      <Footer>Footer</Footer>
                  
    </Layout>
  )
}

export default LearnTypeScript