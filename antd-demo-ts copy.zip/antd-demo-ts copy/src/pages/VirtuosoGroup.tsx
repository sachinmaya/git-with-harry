/* @jsxImportSource @emotion/react */
import { GroupedVirtuoso, VirtuosoHandle } from 'react-virtuoso'
import { useCallback, useState, useRef, useEffect, useMemo, FC } from 'react'
import { generateGroupedUsers, toggleBg } from '../api/data2'
import { render } from 'react-dom';
import { Row, Col, Input, Select, Button } from 'antd'
import { css } from '@emotion/react';

const containerCSS = css`
  max-width: 1440px;
  height: 100vh;
  background-color: #edf7ff;
  margin: auto;
  /* position  : relative ; */
`
const pTitleCSS = css`
  color: #000;
  text-align: center;
  padding: 20px 0;
  width: 100%;
  .userList{
    text-align: left;
  }
  h4{
    color: #006e9d;
    font-size : 18px;
  }
  .indexHead{
    font-weight: bolder;
    font-size : 20px;
  }
`;

const VirtuosoGroup: FC = () => {
    const { users, groups, groupCounts } = generateGroupedUsers(500)
    const virtuoso = useRef<VirtuosoHandle>(null)
    const [posts,setPosts] = useState([])
    useEffect(() =>{
        fetch('https://jsonplaceholder.typicode.com/posts')
        .then((response) => response.json())
        .then((json) =>  {
            const data = json;
            setPosts(data) 
        });
    },[])
    // const users = posts;
    // const groups2 = ["#","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    // const groupCounts = [12,34,45,19,10]
    // users[0].name= "21312312321";
    // users[1].name= "12245435344";
    // users[2].name= "43332356456";
    // users[3].name= "92342443432";
    // const groups2 = [...["#"], ...groups]
    // console.log(users)
    return (
        <>
            <Row css={containerCSS}>
                <Col css={pTitleCSS}>
                <div style={{ display: 'flex' }}>
                    <div style={{ flex: 1 }} className={'userList'}>
                        <GroupedVirtuoso
                        ref={virtuoso}
                        groupCounts={groupCounts}
                        groupContent={index => {
                        return <div style={{ 
                            backgroundColor: 'white', 
                            padding: '0.3rem 1rem'
                        }} className={"indexHead"}>{groups[index]}</div>
                        }}
                        itemContent={index => {
                            return <div style={{ padding: '0.5rem 1rem', backgroundColor: toggleBg(index) }}>
                            <h4>{users[index].name}</h4>

                            <p style={{ marginBottom: 0 }}>{users[index].description}</p>
                            </div>
                        }}
                        />
                    </div>

                    <ul
                        style={{
                        marginLeft: '0.5rem',
                        paddingLeft: '0',
                        listStyle: 'none',
                        fontSize: '0.8rem',
                        }}
                    >
                        {groupCounts
                        .reduce(
                            ({ firstItemsIndexes, offset }, count):any => {
                            return {
                                firstItemsIndexes: [...firstItemsIndexes, offset],
                                offset: offset + count,
                            }
                            },
                            { firstItemsIndexes: [], offset: 0 }
                        )
                        .firstItemsIndexes.map((itemIndex, index) => (
                            <li key={index}>
                            <a
                                href="#"
                                onClick={e => {
                                e.preventDefault()
                                virtuoso.current?.scrollToIndex({
                                    index: itemIndex,
                                })
                                }}
                            >
                                {groups[index]}
                            </a>
                            </li>
                        ))}
                    </ul>
    </div>
      
                </Col>
            </Row>
        
        </>
    )
}

export default VirtuosoGroup