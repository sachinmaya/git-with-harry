import React from "react";
import { Breadcrumb, Col, Layout, Menu, Row } from "antd";

const { Header, Content, Footer } = Layout;

const HeaderFooterContent: React.FC = () => (
  <Layout className="layout">
    <Header>
      <Row>
        <Col span={18} offset={3}>
          <div className="logo" />
          <Menu
            theme="dark"
            mode="horizontal"
            defaultSelectedKeys={["2"]}
            items={new Array(15).fill(null).map((_, index) => {
              const key = index + 1;
              return {
                key,
                label: `nav ${key}`,
              };
            })}
          />
        </Col>
      </Row>
    </Header>
    <Row>
      <Col span={18} offset={3}>
        <Content style={{ padding: "0 50px" }}>
          <Breadcrumb style={{ margin: "16px 0" }}>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>List</Breadcrumb.Item>
            <Breadcrumb.Item>App</Breadcrumb.Item>
          </Breadcrumb>
          <div className="site-layout-content">Content</div>
        </Content>
      </Col>
    </Row>
    <Footer style={{ textAlign: "center" }}>
      Ant Design ©2018 Created by Ant UED
    </Footer>
  </Layout>
);

export default HeaderFooterContent;
