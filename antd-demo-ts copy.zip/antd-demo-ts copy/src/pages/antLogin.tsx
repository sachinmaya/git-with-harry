/* @jsxImportSource @emotion/react */
import React,{ FC, useEffect } from 'react'
import {css} from '@emotion/react'
import { Col, Row, Form, Input, Checkbox, Button } from 'antd'



const containerCSS = css`
  /* max-width: 1440px;
  height: 100vh; */
  background-color: #edf7ff;
  margin: auto; 
  padding: 2rem;
`
const LoginHeadCSS = css`
  color: #650404;
  text-align: center;
  padding: 20px 0;
  width: 100%;
`;
const formAreaCSS = css `
    
`
const AntLogin: FC = () => {
  const [form] = Form.useForm(); 
  const onFinish = (values:any) =>{
    console.log("Success",values)
  }
  const onFinishedFaild = (errorInfo: any) => {
    console.log("Failed",errorInfo)      
  }
//   useEffect(()=>{
//     form.setFieldsValue({
//         username: 'Hello world!',
//         password: 'male',
//       });
//   },[])
  return (
    <Row css={containerCSS}>
        <h1 css={LoginHeadCSS}>TS ANTD Login</h1>
        <Col span={12} offset={6} css={formAreaCSS}>
            <Form
                name='loginForm'
                labelCol={{span:4}}
                wrapperCol={{span:16}}
                initialValues = {{remember:true}}
                onFinish = {onFinish}
                onFinishFailed = {onFinishedFaild}
                autoComplete = "off"
                form={form}
            >
                <Form.Item
                    label="Username"
                    name="username"
                    rules = {[{required:true, message: 'Please input your username'}]}
                >
                    <Input />
                </Form.Item>

                <Form.Item
                    label="Passwrod"
                    name="password"
                    rules = {[{required:true, message: 'Please input your username'}]}
                >
                    <Input.Password />
                </Form.Item>

                <Form.Item name={"remember"} valuePropName="checked" wrapperCol={{offset: 4, span:16}}>
                    <Checkbox>Remember Me</Checkbox>
                </Form.Item>

                <Form.Item wrapperCol={{offset:4, span:16}}>
                    <Button type='primary' htmlType='submit'>
                        Login Now
                    </Button>
                </Form.Item>


            </Form>
        </Col>
    </Row>
    
  )
}

export default AntLogin