import React, { FC } from 'react'
type Rainbow = 
| "red"
| "orange"
| "yellow"
| "green"
| "blue"
| "indigo"
| "violet";

type TextProps<C extends React.ElementType>  =  {
    as?:C;
    color?: Rainbow | "Black";
    // children: React.ReactNode;
}
// } & React.ComponentPropsWithoutRef<C>;

type Props <C extends React.ElementType> = React.PropsWithChildren<TextProps<C>> & 
// React.ComponentPropsWithoutRef<C>
Omit<React.ComponentPropsWithoutRef<C>, keyof TextProps<C>>;

export const MyComponent =<C extends React.ElementType = "span">({as,color, children, ...restProps}:Props<C>) =>{
    const Component = as || "span";
    const style = color ? { style: { color } } : {};
    return <Component {...restProps} {...style}>{children}</Component>
}


type Vowels = {
    a: 'a',
    e: 'e',
    i: 'i',
    o: 'o',
    u: 'u'
  }

type VowelsInOhans = Omit<Vowels, 'e' | 'i' | 'u'>

const Reactpolymorephic: FC = () => {
  return (
    <>
    <MyComponent as="button" color='red' type="submit">Welcome to React Polymorephic</MyComponent>
    <MyComponent as="p" color='green'>Welcome to React Polymorephic</MyComponent>
    <MyComponent color='orange'>Welcome to React Polymorephic</MyComponent>
    </>
  )
}

export default Reactpolymorephic