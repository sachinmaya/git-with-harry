import { Image } from "antd";
import React, { FC } from "react";
import { ContentVideosArrayType } from "~/api/types";
import { PlaySquareOutlined } from "@ant-design/icons";
import classes from "./styles.module.scss";

interface VideoContentProps {
  videoInfo: ContentVideosArrayType;
  playVideo: (video: ContentVideosArrayType) => void;
  width?: number;
  height?: number;
}

const VideoContent: FC<VideoContentProps> = ({ videoInfo, playVideo, width = 60, height = 40 }) => {
  return (
    <div onClick={() => playVideo(videoInfo)} className={classes.videoContainer} style={{ width: `${width}px`, height: `${height}px` }}>
      <Image src={videoInfo.snap_shot_url} preview={false} width={width} height={height} />
      <div className={classes.playButton}>
        <PlaySquareOutlined />
      </div>
    </div>
  );
};

export default VideoContent;
