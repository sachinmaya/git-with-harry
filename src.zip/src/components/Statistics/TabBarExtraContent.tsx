import { DatePicker } from "antd";
import { FC, useState } from "react";
import { useTranslation } from "react-i18next";
import classes from "./styles.module.scss";
const { RangePicker } = DatePicker;
import clsx from "clsx";
import dayjs from "dayjs";
import type { Dayjs } from "dayjs";

export type tabRightButtonType = "day" | "week" | "month" | "year";
const ButtonLable: tabRightButtonType[] = ["day", "week", "month", "year"];

interface TabBarExtraContentProps {
  changeParams: (value: tabRightButtonType) => void;
  search: (from: string, to: string) => void;
}
const dateDisableCondition = (current: any) => {
  return dayjs().toDate() <= current;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;

const TabBarExtraContent: FC<TabBarExtraContentProps> = ({ changeParams, search }) => {
  const { t } = useTranslation("user-statistics-view");
  const [dates, setDates] = useState<RangeValue>(null);
  const [activeBtn, setActiveBtn] = useState<tabRightButtonType | undefined>("week");

  const handleSearch = () => {
    if (dates !== null && dates[1] && dates[0]) {
      setActiveBtn(undefined);
      return search(dates[0].format("YYYY-MM-DD"), dates[1].format("YYYY-MM-DD"));
    }
    return;
  };
  const handleBtnClik = (item: tabRightButtonType) => {
    setDates(null);
    setActiveBtn(item);
    return changeParams(item);
  };
  return (
    <>
      {ButtonLable.map((item: tabRightButtonType, index: number) => {
        return (
          <button key={index} onClick={() => handleBtnClik(item)} className={clsx(classes.unstyledBtn, activeBtn === item && classes.activeBtn)}>
            {t(`buttons.filters.${item}`)}
          </button>
        );
      })}
      <RangePicker value={dates} className={classes.datePicker} onChange={(val) => setDates(val)} disabledDate={dateDisableCondition} />
      <button className={clsx(classes.searchBtn, dates !== null && classes.activesearchBtn)} onClick={handleSearch}>
        {t("buttons.filters.apply")}
      </button>
    </>
  );
};

export default TabBarExtraContent;
