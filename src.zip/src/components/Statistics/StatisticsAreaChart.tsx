import { FC } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import classes from "./styles.module.scss";
type chartItem = {
  date: string;
  value: number;
};
interface StatisticsAreaChartProps {
  data: chartItem[];
  text: string;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className={classes.chartTooltip}>
        {label}
        <div>
          <b>{`${payload[0].name} : ${payload[0].value}`}</b>
        </div>
      </div>
    );
  }
  return null;
};
const StatisticsAreaChart: FC<StatisticsAreaChartProps> = ({ data, text }) => {
  const gradientOffset = () => {
    const dataMax = Math.max(...data.map((i: chartItem) => i.value));
    const dataMin = Math.min(...data.map((i: chartItem) => i.value));

    if (dataMax <= 0) {
      return 0;
    }
    if (dataMin >= 0) {
      return 1;
    }

    return dataMax / (dataMax - dataMin);
  };

  const off = gradientOffset();
  return (
    <div className={classes.areaChart}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          width={500}
          height={400}
          data={data}
          margin={{
            top: 10,
            right: 30,
            left: 0,
            bottom: 0,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip content={<CustomTooltip />} />
          <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#30B7E8" stopOpacity={0.8} />
              <stop offset="100%" stopColor="#30B7E8" stopOpacity={0} />
            </linearGradient>
          </defs>
          <Area
            type="monotone"
            dataKey="value"
            name={text}
            stroke="#30B7E8"
            fill="url(#grad1)"
            activeDot={{ r: 6, stopColor: "#fff", stroke: "#111", fill: "#111" }}
            dot={{ r: 6, fill: "#ffff", stroke: "#30B7E8", strokeWidth: "2px" }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default StatisticsAreaChart;
