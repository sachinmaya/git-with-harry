import clsx from "clsx";
import React, { FC } from "react";
import classes from "./styles.module.scss";

interface StatisticsCardProps {
  icon: JSX.Element;
  title: string;
  count: number | undefined;
}

const StatisticsCard: FC<StatisticsCardProps> = ({ icon, title, count }) => {
  return (
    <div className={clsx(classes.statisticsCard, classes.statisticsCardLayout)}>
      {icon}
      <div className={classes.statisticsCardData}>
        {title}
        <p>{count ? count : 0}</p>
      </div>
    </div>
  );
};

export default StatisticsCard;
