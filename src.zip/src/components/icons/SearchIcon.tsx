import React from "react";

const SearchIcon: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg width="1em" height="1em" version="1.1" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="currentColor" {...props}>
    <g transform="translate(-1059 -175)">
      <path
        d="M22.439,20.306a1.059,1.059,0,0 ,1-1.534,0l-3.4-3.4a7.619,7.619,0,0,1-9.752-.438A7.773,7.773,0,0,1,7.428,5.514,7.673,7.673,0,0,1,18.385,5.4a7.544,7.544,0,0,1,.657,9.971l3.4,3.4A1.059,1.059,0,0,1,22.439,20.306ZM17.289,7.6A5.49,5.49,0,0,0,8.414,14.06,5.49,5.49,0,0,0,17.289,7.6Z"
        transform="translate(1054.953 173.104)"
        strokeWidth="1"
      />
    </g>
  </svg>
);

export default SearchIcon;
