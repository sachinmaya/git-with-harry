import React from "react";

const BackIcon: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg width="1em" height="1em" version="1.1" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" fill="currentColor" {...props}>
    <g transform="translate(-1059 -175)">
      <path
        d="M11002,10961a9,9,0,1,1,9-9A9.01,9.01,0,0,1,11002,10961Zm2.129-14.479a.777.777,0,0,0-.555.231l-4.854,4.852a.794.794,0,0,0-.23.558.8.8,0,0,0,.23.555l4.854,4.852a.785.785,0,0,0,1.34-.551.781.781,0,0,0-.229-.557l-4.3-4.3,4.3-4.3a.787.787,0,0,0-.556-1.342Z"
        transform="translate(-9933 -10767)"
      />
    </g>
  </svg>
);

export default BackIcon;
