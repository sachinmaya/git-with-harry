import React from "react";

const EditIcon: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg width="1em" height="1em" version="1.1" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" fill="currentColor" {...props}>
    <g transform="translate(-1161 -176)">
      <path
        d="M179.25,173.565l6.354,6.354L177.02,188.5h-6.354v-6.354Zm0,3.233-6.354,6.354v3.121h3.121l6.354-6.354Zm3.01-6.131,6.242,6.354-1.895,1.9-6.354-6.354Z"
        transform="translate(991.333 6.333)"
      />
    </g>
  </svg>
);

export default EditIcon;
