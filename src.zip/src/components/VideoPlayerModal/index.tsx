import React, { useMemo } from "react";
import { Modal, ModalProps } from "antd";
import { ContentVideosArrayType } from "~/api/types";
import classes from "./styles.module.scss";

interface VideoModalProps extends ModalProps {
  video: ContentVideosArrayType;
}

const VideoPlayer: React.FC<VideoModalProps> = ({ video, ...rest }) => {
  const type = useMemo(() => {
    let vArr = video.video_url.split(".");
    return `video/${vArr[vArr.length - 1]}`;
  }, [video]);

  return (
    <Modal
      centered
      title={null}
      footer={null}
      className={classes.videoModal}
      closable={true}
      width={video.video_width}
      bodyStyle={{ width: video.video_width, height: video.video_height, maxHeight: "80vh" }}
      {...rest}
    >
      <video controls autoPlay poster={video.snap_shot_url} className={classes.video}>
        <source src={video.video_url} type={type} />
      </video>
    </Modal>
  );
};

export default VideoPlayer;
