import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Button, Input, Modal, ModalProps, Table } from "antd";
import { DeleteOutlined, SearchOutlined } from "@ant-design/icons";
import { useQuery } from "@tanstack/react-query";
import { actions } from "~/api/constants";
import { GetUsersRequestParams } from "~/api/types";
import useRequest from "~/hooks/useRequest";
import { useTranslation } from "react-i18next";
import { ColumnsType } from "antd/es/table";
import classes from "./styles.module.scss";

interface UserSelectUserItem {
  userID: string;
  nickname: string;
}

interface UserSelectModalProps extends ModalProps {
  userList: UserSelectUserItem[];
  selectedUsers: UserSelectUserItem[];
  userListLoading: boolean;
  onSelectedUsersChange: (selectedUsers: UserSelectUserItem[]) => void;
  disabledUserIDList?: string[];
  pagination: {
    pageNumber: number;
    totalNumber: number;
  };
  onPaginationChange: (page: number, pageSize: number) => void;
  search: string;
  onSearchChange: (search: string) => void;
  selectionLoading: boolean;
}

type UserSelectModalType = React.FC<UserSelectModalProps> & { WithGetUsers: typeof WithGetUsers };

const UserSelectModal: UserSelectModalType = ({
  userList,
  selectedUsers,
  userListLoading,
  onSelectedUsersChange,
  disabledUserIDList,
  pagination,
  onPaginationChange,
  search,
  onSearchChange,
  selectionLoading,
  ...rest
}) => {
  const { t } = useTranslation("user-select-modal");

  const selectColumns: ColumnsType<UserSelectUserItem> = useMemo(
    () => [
      {
        key: "nickname",
        dataIndex: "nickname",
        title: t("columns.nickname"),
      },
      {
        key: "account",
        dataIndex: "userID",
        title: t("columns.account"),
      },
    ],
    [t]
  );

  const selectedColumns: ColumnsType<UserSelectUserItem> = useMemo(
    () => [
      {
        key: "nickname",
        dataIndex: "nickname",
      },
      {
        key: "account",
        dataIndex: "userID",
      },
      {
        key: "options",
        dataIndex: "userID",
        width: 64,
        render: (userID) => (
          <Button type="text" shape="circle" icon={<DeleteOutlined />} onClick={() => onSelectedUsersChange(selectedUsers.filter((item) => item.userID !== userID))} />
        ),
      },
    ],
    [onSelectedUsersChange, selectedUsers]
  );

  const handleSelectedRowsChange = (selectedKeys: React.Key[], selectedRows: UserSelectUserItem[]) => {
    const otherSelectedUsers = selectedUsers.filter((selectedUser) => !userList.some((user) => user.userID === selectedUser.userID));
    onSelectedUsersChange([...otherSelectedUsers, ...selectedRows]);
  };

  return (
    <Modal closable={false} width={980} okButtonProps={{ disabled: selectedUsers.length === 0 }} destroyOnClose okText={t("buttons.ok")} cancelText={t("buttons.cancel")} {...rest}>
      <div className={classes.root}>
        <div className={classes.leftSide}>
          <Input value={search} onChange={(e) => onSearchChange(e.target.value)} prefix={<SearchOutlined />} placeholder={t("search.placeholder")} />
          <Table
            rowKey="userID"
            rootClassName={classes.selectTable}
            columns={selectColumns}
            loading={selectionLoading || userListLoading}
            dataSource={userList}
            scroll={{ y: 320 }}
            rowSelection={{
              selectedRowKeys: selectedUsers.map(({ userID }) => userID),
              onChange: handleSelectedRowsChange,
              getCheckboxProps: (record) => ({ disabled: disabledUserIDList?.includes(record.userID) }),
            }}
            pagination={{
              current: pagination.pageNumber,
              total: pagination.totalNumber,
              onChange: onPaginationChange,
              pageSizeOptions: [10, 20, 50, 100, 1000],
              size: "small",
              showQuickJumper: true,
            }}
          />
        </div>
        <div className={classes.divider} />
        <div className={classes.rightSide}>
          <div className={classes.selectedMembers}>{t("selected-members", { count: selectedUsers.length })}</div>
          <Table rowKey="userID" rootClassName={classes.selectedTable} columns={selectedColumns} dataSource={selectedUsers} scroll={{ y: 400 }} pagination={false} />
        </div>
      </div>
    </Modal>
  );
};

const initialParams: GetUsersRequestParams = {
  page_number: 1,
  show_number: 10,
  order_by: "start_time:desc",
};

type WithGetUsers = Omit<
  UserSelectModalProps,
  "userList" | "selectedUsers" | "userListLoading" | "onSelectedUsersChange" | "pagination" | "onPaginationChange" | "search" | "onSearchChange" | "onOk"
> & {
  onSubmit: (selectedUserIdList: string[]) => void;
};

const WithGetUsers: React.FC<WithGetUsers> = ({ onSubmit, ...props }) => {
  const request = useRequest();
  const [selectedUsers, setSelectedUsers] = useState<UserSelectUserItem[]>([]);
  const [search, setSearch] = useState<string>("");
  const [params, setParams] = useState<GetUsersRequestParams>(initialParams);
  const { data, isPreviousData } = useQuery({
    queryKey: [actions.GET_USERS, params],
    queryFn: () => request(actions.GET_USERS, params),
    keepPreviousData: true,
    enabled: props.open,
  });

  const userList = useMemo(
    () =>
      data?.data.users?.map(({ user_id, nick_name }) => ({
        userID: user_id,
        nickname: nick_name,
      })) ?? [],
    [data]
  );

  const handleSelectedUsersChange = useCallback((value: UserSelectUserItem[]) => setSelectedUsers(value), [setSelectedUsers]);

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  useEffect(() => {
    const timeout = setTimeout(() => {
      setParams((state) => ({
        ...state,
        user_id: search,
        page_number: 1,
      }));
    }, 300);
    return () => clearTimeout(timeout);
  }, [search, setParams]);

  const resetModal = useCallback(() => {
    setSearch("");
    setParams(initialParams);
    setSelectedUsers([]);
  }, [setSearch, setParams, setSelectedUsers]);

  const handleOk = useCallback(() => onSubmit(selectedUsers.map((item) => item.userID)), [selectedUsers]);

  return (
    <UserSelectModal
      userList={userList || []}
      selectedUsers={selectedUsers}
      userListLoading={isPreviousData}
      onSelectedUsersChange={handleSelectedUsersChange}
      pagination={{ pageNumber: data?.data.current_number || 0, totalNumber: data?.data.user_nums || 0 }}
      onPaginationChange={handlePaginationChange}
      search={search}
      onSearchChange={setSearch}
      afterClose={resetModal}
      onOk={handleOk}
      {...props}
    />
  );
};

UserSelectModal.WithGetUsers = WithGetUsers;

export default UserSelectModal;
