import React, { useMemo } from "react";
import { Input, Modal, ModalProps, Table } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import { useTranslation } from "react-i18next";
import { ColumnsType } from "antd/es/table";
import classes from "./styles.module.scss";

interface UserSelectUserItem {
  userID: string;
  nickname: string;
}

interface UserPickModalProps extends ModalProps {
  userList: UserSelectUserItem[];
  selectedUserID: string | undefined;
  userListLoading: boolean;
  onSelectedUserIDChange: (selectedUserID: string) => void;
  disabledUserIDList?: string[];
  pagination: {
    pageNumber: number;
    totalNumber: number;
  };
  onPaginationChange: (page: number, pageSize: number) => void;
  search: string;
  onSearchChange: (search: string) => void;
}

const UserPickModal: React.FC<UserPickModalProps> = ({
  userList,
  selectedUserID,
  userListLoading,
  onSelectedUserIDChange,
  disabledUserIDList,
  pagination,
  onPaginationChange,
  search,
  onSearchChange,
  ...rest
}) => {
  const { t } = useTranslation("user-pick-modal");

  const selectColumns: ColumnsType<UserSelectUserItem> = useMemo(
    () => [
      {
        key: "nickname",
        dataIndex: "nickname",
        title: t("columns.nickname"),
      },
      {
        key: "account",
        dataIndex: "userID",
        title: t("columns.account"),
      },
    ],
    [t]
  );

  return (
    <Modal
      closable={false}
      width={480}
      okButtonProps={{ disabled: selectedUserID === undefined }}
      destroyOnClose
      okText={t("buttons.ok")}
      cancelText={t("buttons.cancel")}
      {...rest}
    >
      <div className={classes.root}>
        <Input value={search} onChange={(e) => onSearchChange(e.target.value)} prefix={<SearchOutlined />} placeholder={t("search.placeholder")} />
        <Table
          rowKey="userID"
          rootClassName={classes.selectTable}
          columns={selectColumns}
          loading={userListLoading}
          dataSource={userList}
          scroll={{ y: 320 }}
          rowSelection={{
            type: "radio",
            selectedRowKeys: selectedUserID !== undefined ? [selectedUserID] : [],
            onChange: ([selectedRowKey]) => onSelectedUserIDChange(selectedRowKey as string),
            getCheckboxProps: (record) => ({ disabled: disabledUserIDList?.includes(record.userID) }),
          }}
          pagination={{
            current: pagination.pageNumber,
            total: pagination.totalNumber,
            onChange: onPaginationChange,
            pageSizeOptions: [10, 20, 50, 100, 1000],
            size: "small",
            showQuickJumper: true,
          }}
        />
      </div>
    </Modal>
  );
};

export default UserPickModal;
