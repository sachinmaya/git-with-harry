import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation, Trans } from "react-i18next";
import { QueryClient, useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import {
  ApiRequest,
  DeleteOfficialAccountParams,
  GetInerestListParams,
  GetOfficialAccountItem,
  GetOfficialAccountsRequestParams,
  InterestItem,
  ProcessOfficialAccountParams,
} from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, message, Select, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import { TableRowSelection } from "antd/es/table/interface";
import Icon from "@ant-design/icons";
import Text from "antd/lib/typography/Text";
import dayjs, { Dayjs } from "dayjs";
import { FieldData } from "rc-field-form/lib/interface";
import useGetInterestListQuery from "~/hooks/useGetInterestListQuery";
import FailOfficialAccountModal from "./failOfficialAccountModal";
import { InternalServerError, NetworkError } from "~/api/errors";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import usePermissions from "~/hooks/usePermissions";
import ConfirmModal from "./confirmModal";
import AddAccountModal from "./AddAccountModal";
import EditAccountModal from "./EditAccountModal";
import AddIcon from "~/components/icons/AddIcon";
import { Language } from "~/lib/i18next";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";
import "./index.scss";

const initialParams: GetOfficialAccountsRequestParams = {
  page_number: 1,
  show_number: 10,
  order_by: "start_time:desc",
  process_status: -1,
};

const interestListParams: GetInerestListParams = {
  show_number: -1,
  page_number: 1,
  time_type: 0,
};

const getOfficialAccountsQuery = (request: ApiRequest, params: GetOfficialAccountsRequestParams = initialParams) => ({
  queryKey: [actions.GET_OFFICIAL_ACCOUNTS, params],
  queryFn: async () => request(actions.GET_OFFICIAL_ACCOUNTS, params),
});

export const officialAccountManagementViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getOfficialAccountsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

const getAccountType = (id_type: number) => {
  switch (id_type) {
    case 1:
      return "personal";
    case 2:
      return "business";
  }
};

const getIdType = (id_type: number) => {
  switch (id_type) {
    case 1:
      return "passport";
    case 2:
      return "national-id";
    case 3:
      return "business-license";
  }
};
interface FormValues {
  officialAccount: string;
  accountType: number;
  idType: number;
  idNumber: string;
  processStatus: number;
  tags: number[];
  introduction: string;
  filterType: number;
  filterRange: null | Dayjs[];
  defaultAllowed: number;
}

const initialValues: FormValues = {
  officialAccount: "",
  accountType: 0,
  idType: 0,
  idNumber: "",
  processStatus: -1,
  tags: [],
  introduction: "",
  filterType: 0,
  filterRange: null,
  defaultAllowed: 0,
};

type ModalKey = "multiple-delete" | "delete-account" | "verify-account";

enum process_status {
  verify = 1,
  fail = 2,
}
const OfficialAccountManagementView: React.FC = () => {
  const { t, i18n } = useTranslation("official-account-view");
  const queryClient = useQueryClient();
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const { isActionAllowed } = usePermissions();
  const [params, setParams] = useState<GetOfficialAccountsRequestParams>(initialParams);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<GetOfficialAccountItem> | undefined>(undefined);

  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; accountID: number }>({
    open: false,
    key: "multiple-delete",
    accountID: 0,
  });
  const [openFailAccountModal, setFailAccountModalOpen] = useState<{ open: boolean; accountID: number }>({
    open: false,
    accountID: 0,
  });

  const [openAddAccountModal, setAddAccountModalOpen] = useState<{ open: boolean }>({
    open: false,
  });
  const [openEditAccountModal, setEditAccountModalOpen] = useState<{ open: boolean; accountDetail: GetOfficialAccountItem | undefined }>({
    open: false,
    accountDetail: undefined,
  });

  const showPendingNotification = (pendingNumbers: number) => {
    message.info({
      key: t("toasts.pending-requests", {
        count: pendingNumbers,
      }),
      content: <Trans t={t} components={{ h2: <h2 /> }} i18nKey={"toasts.pending-requests"} values={{ count: pendingNumbers }} />,
      duration: 4,
      className: "notification-popup",
    });
  };
  const getFilteredInterestList = (Interests: InterestItem[]) => {
    let filteredInterests =
      Interests !== null && Interests !== undefined
        ? Interests.map((item) => ({
            value: item.id,
            label:
              item.name !== null && item.name !== undefined
                ? item.name?.find((item) => item.language_type === t(`backend-locales.${i18n.language as Language}`))?.name || item?.name[0]?.name || ""
                : "",
          }))
        : [];

    return filteredInterests;
  };

  const getAccountStatus = (process_status: number, account_id: number) => {
    switch (process_status) {
      case 0:
        return (
          <>
            <Button className="optionBtn" onClick={() => setOpenModal({ open: true, key: "verify-account", accountID: account_id })}>
              {t("form.buttons.verified")}
            </Button>
            <Button className="optionBtn optionBtnDanger" onClick={() => setFailAccountModalOpen({ open: true, accountID: account_id })}>
              {t("form.buttons.failed")}
            </Button>
          </>
        );
      case 1:
        return t("account-status.verified");
      case 2:
        return t("account-status.failed");
    }
  };
  const { data, refetch, isPreviousData } = useQuery({
    ...getOfficialAccountsQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.account-list-query-failed"),
      });
    },
  });
  const interestListQuery = useGetInterestListQuery(interestListParams, request, {
    onError: () => {
      // TODO: show error message
    },
  });

  const verifyOfficialAccountMutation = useMutation((params: ProcessOfficialAccountParams) => request(actions.PROCESS_OFFICIAL_ACCOUNT, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_OFFICIAL_ACCOUNTS]);
      message.open({
        key: "process-successfully",
        type: "success",
        content: t("toasts.process-account-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "process-account-failed",
        type: "error",
        content: t("toasts.process-account-failed"),
      });
    },
  });

  const deleteOfficialAccountMutation = useMutation((params: DeleteOfficialAccountParams) => request(actions.DELETE_OFFICIAL_ACCOUNT, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_OFFICIAL_ACCOUNTS]);
      message.open({
        key: "process-successfully",
        type: "success",
        content: t("toasts.delete-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "process-account-failed",
        type: "error",
        content: t("toasts.process-account-failed"),
      });
    },
  });

  useEffect(() => {
    setDashboardHeading("official-account", "official-account-management");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  useEffect(() => {
    if (data) {
      if (data.data.pending_nums > 0) {
        showPendingNotification(data?.data.pending_nums);
      }
    }
  }, [data?.data.pending_nums]);

  const columns: ColumnsType<GetOfficialAccountItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "account",
        dataIndex: "user_id",
        width: 160,
        title: t("columns.account"),
        render: (value) => value || "-",
      },
      {
        key: "register-nickname",
        width: 160,
        dataIndex: "initial_nickname",
        title: t("columns.register-nickname"),
        render: (value) => (
          <Text
            style={{ width: 140 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "last-edit-nickname",
        width: 200,
        dataIndex: "nickname",
        title: t("columns.last-edit-nickname"),
        render: (value) => (
          <Text
            style={{ width: 180 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "profile-photo",
        width: 160,
        dataIndex: "face_url",
        title: t("columns.profile-photo"),
        render: (value) => (value === "" ? "-" : <Image src={value} width={30} height={30} />),
      },
      {
        key: "account-type",
        width: 160,
        dataIndex: "type",
        title: t("columns.type"),
        render: (value) => {
          const type = getAccountType(value);
          return type ? t(`account-type.${type}`) : "-";
        },
      },
      {
        key: "certificate-name",
        width: 160,
        dataIndex: "id_name",
        title: t("columns.certificate-name"),
        render: (value) => (
          <Text
            style={{ width: 140 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "create-time",
        width: 160,
        dataIndex: "create_time",
        title: t("columns.create-time"),
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "id-type",
        width: 160,
        dataIndex: "id_type",
        title: t("columns.id-type"),
        render: (value) => {
          const idType = getIdType(value);
          return idType ? t(`id-type.${idType}`) : "-";
        },
      },
      {
        key: "id-number",
        width: 160,
        dataIndex: "id_number",
        title: t("columns.id-number"),
        render: (value) => (
          <Text
            style={{ width: 140 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "process-time",
        width: 160,
        dataIndex: "process_time",
        title: t("columns.process-time"),
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "process",
        width: 160,
        dataIndex: "process_status",
        title: t("columns.process"),
        render: (value, record) => getAccountStatus(value, record.id),
      },

      {
        key: "introduction",
        width: 160,
        dataIndex: "bio",
        title: t("columns.introduction"),
        render: (value) => (
          <Text
            style={{ width: 140 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "tags",
        width: 160,
        dataIndex: "Interests",
        title: t("columns.tags"),
        render: (value) => {
          const filteredInterests = getFilteredInterestList(value);
          const interestsTags = filteredInterests.map((item, index) => item.label).filter((item) => item !== "");
          if (interestsTags.length === 0) {
            return "-";
          }
          return (
            <>
              <Text
                style={{ width: 250 }}
                ellipsis={{
                  tooltip: interestsTags.join(","),
                }}
              >
                {interestsTags.join(",")}
              </Text>
            </>
          );
        },
      },
      {
        key: "verified-by",
        width: 160,
        dataIndex: "process_by",
        title: t("columns.verified-by"),
        render: (value) => (
          <Text
            style={{ width: 140 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "feedback",
        width: 160,
        dataIndex: "process_feedback",
        title: t("columns.feedback"),
        render: (value) => (
          <Text
            style={{ width: 140 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "default-allowed",
        width: 200,
        dataIndex: "is_system",
        title: t("columns.default-allowed"),
        render: (value) => (value === 1 ? t("default-allowed.yes") : t("default-allowed.no")),
      },
      {
        key: "operations",
        width: 160,
        title: t("columns.operations"),
        fixed: "right",
        render: (record) => {
          return (
            <>
              {isActionAllowed(actions.ALTER_OFFICIAL_ACCOUNT) && (
                <Button className="optionBtn" type="primary" onClick={() => setEditAccountModalOpen({ open: true, accountDetail: record })}>
                  {t("form.buttons.edit")}
                </Button>
              )}

              {isActionAllowed(actions.DELETE_OFFICIAL_ACCOUNT) && (
                <Button className="optionBtn optionBtnDanger" type="primary" onClick={() => setOpenModal({ open: true, accountID: record.id, key: "delete-account" })}>
                  {t("form.buttons.delete")}
                </Button>
              )}
            </>
          );
        },
      },
    ],
    [t]
  );

  const handleMultipleDeleteClick = useCallback(
    () =>
      setDeleteSelection({
        columnWidth: 50,
        selectedRowKeys: [],
        onChange: (selectedRowKeys) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );

  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ filterRange, officialAccount, accountType, idType, idNumber, filterType, defaultAllowed, processStatus, tags, introduction }: FormValues) => {
      setParams(({ show_number, order_by }) => {
        const state: GetOfficialAccountsRequestParams = { page_number: 1, show_number, order_by };
        if (officialAccount !== "") {
          state.official_account = officialAccount.trim();
        }
        if (accountType !== 0) {
          state.account_type = accountType;
        }
        if (idType !== 0) {
          state.id_type = idType;
        }
        if (idNumber !== "") {
          state.id_number = idNumber.trim();
        }
        if (processStatus !== null) {
          state.process_status = processStatus;
        }
        if (tags.length > 0) {
          state.tags_id = tags.toString();
        }
        if (introduction !== "") {
          state.bio = introduction.trim();
        }
        if (defaultAllowed !== 0) {
          state.is_system = defaultAllowed;
        }
        if (filterType !== 0) {
          state.time_type = filterType;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = startTime;
          state.end_time = endTime;
        }

        return state;
      });
      setSearchLoading(true);
    },
    [setParams, refetch]
  );

  const handleFieldsChange = useCallback(([fieldData]: FieldData[]) => {
    const { name, value } = fieldData;
  }, []);
  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    switch (openModal.key) {
      case "verify-account":
        verifyOfficialAccountMutation.mutate({ official_id: openModal.accountID, process_feedback: "", process_status: process_status.verify });
        return;
      case "delete-account":
        deleteOfficialAccountMutation.mutate({ officials: [openModal.accountID.toString()] });
        return;
      case "multiple-delete":
        if (deleteSelection !== undefined && deleteSelection.selectedRowKeys !== undefined) {
          deleteOfficialAccountMutation.mutate({ officials: deleteSelection.selectedRowKeys.map(String) as string[] });
        }
        return;
    }
  }, [verifyOfficialAccountMutation.mutate, openModal, deleteOfficialAccountMutation.mutate]);

  if (interestListQuery.data === undefined) {
    return null;
  }
  const interestList = interestListQuery.data.data;
  const filteredInterestList = getFilteredInterestList(interestList.interests);

  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="officialAccount" label={t("form.official-account")}>
          <Input style={{ width: 158 }} />
        </Form.Item>
        <Form.Item name="accountType" label={t("form.account-type.label")}>
          <Select
            style={{ width: 158 }}
            options={(["all", "personal", "business"] as const).map((key, value) => ({
              value,
              label: t(`form.account-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="idType">
          <Select
            style={{ width: 158 }}
            options={(["all", "passport", "national-id", "business-license"] as const).map((key, value) => ({
              value,
              label: t(`form.id-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="idNumber">
          <Input style={{ width: 158 }} />
        </Form.Item>
        <Form.Item name="processStatus" label={t("form.account-status.label")}>
          <Select
            style={{ width: 158 }}
            options={[
              {
                value: -1,
                label: t("form.account-status.options.all"),
              },
              {
                value: 1,
                label: t("form.account-status.options.verified"),
              },
              {
                value: 2,
                label: t("form.account-status.options.failed"),
              },
              {
                value: 0,
                label: t("form.account-status.options.pending"),
              },
            ]}
          />
        </Form.Item>
        <Form.Item name="tags" label={t("form.tags")}>
          <Select mode="multiple" options={filteredInterestList} style={{ width: 300 }} />
        </Form.Item>
        <Form.Item name="introduction" label={t("form.introduction")}>
          <Input style={{ width: 208 }} />
        </Form.Item>
        <Form.Item name="filterType">
          <Select
            style={{ width: 160 }}
            options={(["all", "create-time", "process-time"] as const).map((key, value) => ({
              value,
              label: t(`form.filter-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="filterRange">
          <DatePicker.RangePicker style={{ width: 282 }} disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item name="defaultAllowed" label={t("form.default-allowed.label")}>
          <Select
            style={{ width: 160 }}
            options={(["all", "no", "yes"] as const).map((key, value) => ({
              value,
              label: t(`form.default-allowed.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        {deleteSelection !== undefined && (
          <>
            <Form.Item>
              <Button htmlType="button" className="filterBtn filterBtnPlain" onClick={handleMultipleDeleteCancelClick}>
                {t("modals.multiple-delete.buttons.cancel")}
              </Button>
            </Form.Item>
            <Form.Item>
              <Button
                type="primary"
                htmlType="button"
                className="filterBtn filterBtnDanger"
                danger
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", accountID: 0 })}
                disabled={deleteSelection.selectedRowKeys === undefined || deleteSelection.selectedRowKeys.length === 0}
              >
                {t("form.buttons.delete")}
              </Button>
            </Form.Item>
          </>
        )}

        {isActionAllowed(actions.DELETE_OFFICIAL_ACCOUNT) && deleteSelection === undefined && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" htmlType="button" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleDeleteClick}>
              {t("form.buttons.multiple-delete")}
            </Button>
          </Form.Item>
        )}
        {isActionAllowed(actions.REGISTER_OFFICIAL_ACCOUNT) && (
          <Form.Item>
            <Button
              className="filterBtn filterBtnSuccess"
              type="primary"
              htmlType="button"
              icon={<Icon component={AddIcon} />}
              onClick={() => setAddAccountModalOpen({ open: true })}
            >
              {t("form.buttons.add")}
            </Button>
          </Form.Item>
        )}
      </Form>
      <Table
        className="customTable"
        rowKey="id"
        dataSource={data?.data.official}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        rowSelection={deleteSelection}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.official_nums,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
      <ConfirmModal open={openModal.open} type={openModal.key} onOk={handleModalOk} onCancel={handleModalCancel} confirmLoading={verifyOfficialAccountMutation.isLoading} />
      <FailOfficialAccountModal
        open={openFailAccountModal.open}
        onCancel={() => setFailAccountModalOpen((state) => ({ ...state, open: false }))}
        processStatus={process_status.fail}
        handleCancel={() => setFailAccountModalOpen((state) => ({ ...state, open: false }))}
        accountID={openFailAccountModal.accountID}
      />
      <AddAccountModal
        open={openAddAccountModal.open}
        onCancel={() => setAddAccountModalOpen((state) => ({ ...state, open: false }))}
        handleCancel={() => setAddAccountModalOpen((state) => ({ ...state, open: false }))}
      />

      <EditAccountModal
        open={openEditAccountModal.open}
        onCancel={() => setEditAccountModalOpen((state) => ({ ...state, open: false }))}
        handleCancel={() => setEditAccountModalOpen((state) => ({ ...state, open: false }))}
        accountItem={openEditAccountModal.accountDetail as GetOfficialAccountItem}
      />
    </>
  );
};

export default OfficialAccountManagementView;
