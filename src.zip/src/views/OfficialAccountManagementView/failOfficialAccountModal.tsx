import React from "react";
import { Modal, ModalProps } from "antd";
import { Form, Input, message } from "antd";
import { useForm } from "antd/lib/form/Form";
import { useTranslation } from "react-i18next";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ProcessOfficialAccountParams } from "~/api/types";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface FormValues {
  feedBacktext: string;
}

const initialValues: FormValues = {
  feedBacktext: "",
};
interface failOfficialAccountModalProps extends ModalProps {
  accountID: number;
  processStatus: number;
  handleCancel: () => void;
}

const FailOfficialAccountModal: React.FC<failOfficialAccountModalProps> = ({ accountID, processStatus, handleCancel, ...props }) => {
  const { t } = useTranslation("official-account-view");
  const [failAccountForm] = useForm();
  const request = useRequest();
  const queryClient = useQueryClient();
  const failOfficialAccountMutation = useMutation((params: ProcessOfficialAccountParams) => request(actions.PROCESS_OFFICIAL_ACCOUNT, params), {
    onSuccess: () => {
      handleCancel();
      queryClient.invalidateQueries([actions.GET_OFFICIAL_ACCOUNTS]);
      message.open({
        key: "process-successfully",
        type: "success",
        content: t("toasts.process-account-successfully"),
      });
    },
  });

  const handleFinish = ({ feedBacktext }: FormValues) =>
    failOfficialAccountMutation.mutate({ official_id: accountID, process_feedback: feedBacktext, process_status: processStatus });

  return (
    <Modal
      okText={t(`modals.fail-account.buttons.ok`)}
      cancelText={t(`modals.fail-account.buttons.cancel`)}
      destroyOnClose={true}
      {...props}
      onOk={failAccountForm.submit}
      onCancel={handleCancel}
    >
      <Form onFinish={handleFinish} form={failAccountForm} initialValues={initialValues}>
        <Form.Item label={t(`modals.fail-account.label`)} preserve={false} name="feedBacktext" rules={[{ required: true, message: t(`modals.fail-account.placeholder`) }]}>
          <Input.TextArea maxLength={50} showCount={true} placeholder={t(`modals.fail-account.placeholder`)} style={{ height: 100, resize: "none" }} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default FailOfficialAccountModal;
