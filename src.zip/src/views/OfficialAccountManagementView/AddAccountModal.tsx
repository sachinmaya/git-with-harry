import React, { useState } from "react";
import { Modal, ModalProps } from "antd";
import { Form, Input, message, Row, Col, Upload, Select } from "antd";
import { PlusOutlined } from "@ant-design/icons";
import { useForm } from "antd/lib/form/Form";
import { useTranslation } from "react-i18next";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { RegisterOfficialAccountParams, GetInerestListParams, InterestItem } from "~/api/types";
import { UploadParams } from "~/api";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import type { RcFile, UploadProps } from "antd/es/upload";
import type { UploadFile } from "antd/es/upload/interface";
import useUpload from "~/hooks/useUpload";
import useGetInterestListQuery from "~/hooks/useGetInterestListQuery";
import { ResponseError } from "~/api/errors";
import { errorCode } from "~/api/constants";
import {Language} from "~/lib/i18next";

const { TextArea } = Input;

interface FormValues {
  userId: string;
  registerNickname: string;
  lastNickname: string;
  accountType: number;
  idType: number;
  realName: string;
  idNumber: string;
  isSystem: number;
  interests: number[];
  profilePhoto: string;
  bio: string;
}

const initialValues: FormValues = {
  userId: "",
  registerNickname: "",
  lastNickname: "",
  accountType: 1,
  idType: 1,
  realName: "",
  idNumber: "",
  isSystem: 0,
  interests: [],
  profilePhoto: "",
  bio: "",
};
interface AddOfficialAccountModalProps extends ModalProps {
  handleCancel: () => void;
}

const interestListParams: GetInerestListParams = {
  show_number: -1,
  page_number: 1,
  time_type: 0,
};

const AddAccountModal: React.FC<AddOfficialAccountModalProps> = ({ handleCancel, ...props }) => {
  const { t, i18n } = useTranslation("official-account-view");
  const [addAccountForm] = useForm();
  const request = useRequest();
  const upload = useUpload();
  const queryClient = useQueryClient();
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [defaultAllowed, setDefaultAllowed] = useState<boolean>(true);
  const [selectedTags, setSelecetedTags] = useState<number[]>([]);

  const uploadQuery = useMutation((params: UploadParams) => upload(params), {
    onSuccess: ({ URL }) => {
      addAccountForm.setFieldValue("profilePhoto", URL);
    },
    onError: () => {},
  });
  const addOfficialAccountMutation = useMutation((params: RegisterOfficialAccountParams) => request(actions.REGISTER_OFFICIAL_ACCOUNT, params), {
    onSuccess: () => {
      handleCancel();
      queryClient.invalidateQueries([actions.GET_OFFICIAL_ACCOUNTS]);

      message.open({
        key: "process-successfully",
        type: "success",
        content: t("toasts.process-account-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof ResponseError) {
        if (error.errCode === errorCode.ID_NOT_EXIST) {
          message.open({
            key: "id-not-exist",
            type: "error",
            content: t("toasts.account-id-not-exist"),
          });
          return;
        }
      }
    },
  });

  const interestListQuery = useGetInterestListQuery(interestListParams, request, {
    onError: () => {
      // TODO: show error message
    },
  });

  if (interestListQuery.data === undefined) {
    return null;
  }
  const interestList = interestListQuery.data.data;

  const filteredInterestList = interestList.interests.map((item: InterestItem) => ({
    value: item.id,
    disabled: selectedTags.length >= 10 ? (selectedTags.includes(item.id) ? false : true) : false,
    label: item.name.find((item) => item.language_type === t(`backend-locales.${i18n.language as Language}`))?.name || item.name[0].name || "",
  }));

  const handlePreviewCancel = () => setPreviewOpen(false);

  const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj!);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };

  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) => setFileList(newFileList);
  const handleCustomRequest = (options: any) => {
    const { file, onSuccess, onError } = options;
    try {
      uploadQuery.mutate({ file, type: 3, persist: true });
      onSuccess("ok");
    } catch (error) {
      onError("error");
    }
  };

  const handleDefaultAllowed = () => {
    let isDefault = addAccountForm.getFieldValue("isSystem");
    switch (isDefault) {
      case 0:
        setDefaultAllowed(true);
        return;

      case 1:
        setDefaultAllowed(false);
        return;
    }
  };

  const handleTagChange = (value: number[]) => {
    addAccountForm.setFieldValue("interests", value);
    setSelecetedTags(value);
  };
  const handleFinish = ({ realName, idNumber, idType, profilePhoto, bio, isSystem, interests, registerNickname, userId, accountType }: FormValues) => {
    addOfficialAccountMutation.mutate({
      user_id: userId,
      nickname: registerNickname,
      initial_nickname: registerNickname,
      type: accountType,
      id_type: idType,
      id_name: realName,
      id_number: idNumber,
      interests: defaultAllowed ? interests : [],
      is_system: isSystem,
      bio: bio,
      profile_photo: profilePhoto,
    });
  };

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("modals.add-account.form.errors.upload-photo")}</div>
    </div>
  );
  return (
    <Modal
      title={t("modals.add-account.title")}
      okText={t(`modals.add-account.buttons.ok`)}
      cancelText={t(`modals.add-account.buttons.cancel`)}
      destroyOnClose={true}
      {...props}
      onOk={addAccountForm.submit}
      onCancel={handleCancel}
    >
      <Form layout="horizontal" onFinish={handleFinish} form={addAccountForm} initialValues={initialValues}>
        <Row>
          <Col span={16}>
            <Form.Item
              preserve={false}
              name="userId"
              label={t("modals.add-account.form.labels.xlink-account")}
              rules={[{ required: true, message: t("modals.add-account.form.errors.xlink-account") }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="registerNickname"
              label={t("modals.add-account.form.labels.register-nickname")}
              rules={[{ required: true, message: t("modals.add-account.form.errors.register-name"), max: 12 }]}
              preserve={false}
            >
              <Input maxLength={12} showCount />
            </Form.Item>
            <Form.Item name="registerNickname" label={t("modals.add-account.form.labels.last-edit-nickname")} preserve={false}>
              <Input disabled={true} maxLength={12} showCount />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item name={"profilePhoto"} rules={[{ required: true, message: "upload" }]} preserve={false}>
              <Upload listType="picture-card" fileList={fileList} customRequest={handleCustomRequest} onPreview={handlePreview} onChange={handleChange}>
                {fileList.length === 0 ? uploadButton : null}
              </Upload>
              <Modal open={previewOpen} footer={null} onCancel={handlePreviewCancel}>
                <img alt="example" style={{ width: "100%" }} src={previewImage} />
              </Modal>
            </Form.Item>
          </Col>
        </Row>
        <Form.Item name="accountType" label={t("modals.add-account.form.account-type.label")} preserve={false}>
          <Select
            options={[
              { value: 1, label: t("modals.add-account.form.account-type.options.personal") },
              { value: 2, label: t("modals.add-account.form.account-type.options.business") },
            ]}
          />
        </Form.Item>
        <Form.Item
          name="realName"
          label={t("modals.add-account.form.labels.real-name")}
          rules={[{ required: true, message: t("modals.add-account.form.errors.real-name") }]}
          preserve={false}
        >
          <Input />
        </Form.Item>
        <Form.Item name="idType" label={t("modals.add-account.form.id-type.label")} preserve={false}>
          <Select
            options={[
              { value: 1, label: t("modals.add-account.form.id-type.options.passport") },
              { value: 2, label: t("modals.add-account.form.id-type.options.business-license") },
              { value: 3, label: t("modals.add-account.form.id-type.options.national-id") },
            ]}
          />
        </Form.Item>
        <Form.Item
          name="idNumber"
          label={t("modals.add-account.form.labels.id-number")}
          rules={[{ required: true, message: t("modals.add-account.form.errors.id-number") }]}
          preserve={false}
        >
          <Input />
        </Form.Item>
        <Form.Item name="bio" label={t("modals.add-account.form.labels.introduction")} preserve={false}>
          <TextArea rows={4} maxLength={500} showCount />
        </Form.Item>
        <Form.Item name="isSystem" label={t("modals.add-account.form.default-allowed.label")} preserve={false}>
          <Select
            options={[
              { value: 1, label: t("modals.add-account.form.default-allowed.options.yes") },
              { value: 0, label: t("modals.add-account.form.default-allowed.options.no") },
            ]}
            onChange={handleDefaultAllowed}
          />
        </Form.Item>
        {defaultAllowed && (
          <Form.Item
            name="interests"
            label={t("modals.add-account.form.labels.tags")}
            rules={defaultAllowed ? [] : [{ required: true, message: t("modals.add-account.form.errors.tags"), min: 1, max: 10, type: "array" }]}
            preserve={false}
          >
            <Select mode="multiple" options={filteredInterestList} onChange={handleTagChange} />
            <div style={{ float: "right" }}>{`${selectedTags.length}/10`}</div>
          </Form.Item>
        )}
      </Form>
    </Modal>
  );
};

export default AddAccountModal;
