import React, { useState, useEffect, useMemo } from "react";
import { Modal, ModalProps } from "antd";
import { Form, Input, message, Row, Col, Upload, Select } from "antd";
import { PlusOutlined } from "@ant-design/icons";
import { useForm } from "antd/lib/form/Form";
import { useTranslation } from "react-i18next";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { EditOfficialAccountParams, GetInerestListParams, GetOfficialAccountItem, InterestItem } from "~/api/types";
import { UploadParams } from "~/api";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import type { RcFile, UploadProps } from "antd/es/upload";
import type { UploadFile } from "antd/es/upload/interface";
import useUpload from "~/hooks/useUpload";
import useGetInterestListQuery from "~/hooks/useGetInterestListQuery";
import { ResponseError } from "~/api/errors";
import { errorCode } from "~/api/constants";
import { Language } from "~/lib/i18next";

const { TextArea } = Input;

interface FormValues {
  officialAccount: number;
  registerNickname: string;
  lastEditNickname: string;
  accountType: number;
  idType: number;
  realName: string;
  idNumber: string;
  isSystem: number;
  interests: InterestItem[] | number[];
  profilePhoto: string;
  bio: string;
}

interface EditOfficialAccountModalProps extends ModalProps {
  handleCancel: () => void;
  accountItem: GetOfficialAccountItem;
}

const interestListParams: GetInerestListParams = {
  show_number: -1,
  page_number: 1,
  time_type: 0,
};

const EditAccountModal: React.FC<EditOfficialAccountModalProps> = ({ accountItem, handleCancel, ...props }) => {
  const { t, i18n } = useTranslation("official-account-view");
  const [editAccountForm] = useForm();
  const request = useRequest();
  const upload = useUpload();
  const queryClient = useQueryClient();
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [defaultAllowed, setDefaultAllowed] = useState<boolean>(true);
  const [selectedTags, setSelecetedTags] = useState<number[]>([]);

  const filterInterests = (interests: InterestItem[]) => {
    return interests.map((item: InterestItem) => ({
      value: item.id,
      disabled: selectedTags.length >= 10 ? (selectedTags.includes(item.id) ? false : true) : false,
      label: item.name.find((item) => item.language_type === t(`backend-locales.${i18n.language as Language}`))?.name || item.name[0].name || "",
    }));
  };

  const initialValues: FormValues = useMemo(() => {
    if (accountItem === undefined) {
      return {
        officialAccount: 0,
        registerNickname: "",
        lastEditNickname: "",
        accountType: 1,
        idType: 1,
        realName: "",
        idNumber: "",
        isSystem: 0,
        interests: [],
        profilePhoto: "",
        bio: "",
      };
    } else {
      if (accountItem.Interests !== null && accountItem.Interests !== undefined) {
        setSelecetedTags(accountItem.Interests.map((item) => item.id));
      }

      setFileList([
        {
          uid: `${accountItem.id}`,
          name: `image.png`,
          status: `done`,
          url: accountItem.face_url,
        },
      ]);

      return {
        officialAccount: accountItem.id,
        registerNickname: accountItem.initial_nickname,
        lastEditNickname: accountItem.nickname,
        accountType: accountItem.type,
        idType: accountItem.id_type,
        realName: accountItem.id_name,
        idNumber: accountItem.id_number,
        isSystem: accountItem.is_system,
        interests: selectedTags,
        profilePhoto: accountItem.face_url,
        bio: accountItem.bio,
      };
    }
  }, [accountItem]);

  const uploadQuery = useMutation((params: UploadParams) => upload(params), {
    onSuccess: ({ URL }) => {
      editAccountForm.setFieldValue("profilePhoto", URL);
    },
    onError: () => {},
  });
  const editOfficialAccountMutation = useMutation((params: EditOfficialAccountParams) => request(actions.ALTER_OFFICIAL_ACCOUNT, params), {
    onSuccess: () => {
      handleCancel();
      queryClient.invalidateQueries([actions.GET_OFFICIAL_ACCOUNTS]);

      message.open({
        key: "updated-successfully",
        type: "success",
        content: t("toasts.official-account-updated-success"),
      });
    },
    onError: (error) => {
      if (error instanceof ResponseError) {
        if (error.errCode === errorCode.ID_NOT_EXIST) {
          message.open({
            key: "id-not-exist",
            type: "error",
            content: t("toasts.account-id-not-exist"),
          });
          return;
        }
      }
    },
  });

  const interestListQuery = useGetInterestListQuery(interestListParams, request, {
    onError: () => {
      // TODO: show error message
    },
  });

  if (interestListQuery.data === undefined) {
    return null;
  }
  const filteredInterestList = filterInterests(interestListQuery.data.data.interests);

  const handlePreviewCancel = () => setPreviewOpen(false);

  const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj!);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };

  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) => setFileList(newFileList);
  const handleCustomRequest = (options: any) => {
    const { file, onSuccess, onError } = options;
    try {
      uploadQuery.mutate({ file, type: 3, persist: true });
      onSuccess("ok");
    } catch (error) {
      onError("error");
    }
  };

  const handleDefaultAllowed = () => {
    let isDefault = editAccountForm.getFieldValue("isSystem");
    switch (isDefault) {
      case 0:
        setDefaultAllowed(true);
        return;

      case 1:
        setDefaultAllowed(false);
        return;
    }
  };

  const handleTagChange = (value: number[]) => {
    setSelecetedTags(value);
  };
  const handleFinish = ({ realName, idNumber, idType, profilePhoto, bio, isSystem, interests, lastEditNickname, officialAccount, accountType }: FormValues) => {
    editOfficialAccountMutation.mutate({
      id: officialAccount,
      nickname: lastEditNickname,
      type: accountType,
      id_type: idType,
      id_name: realName,
      id_number: idNumber,
      interests: defaultAllowed ? selectedTags : [],
      is_system: isSystem,
      bio: bio,
      face_url: profilePhoto,
    });
  };

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("modals.edit-account.form.errors.upload-photo")}</div>
    </div>
  );
  return (
    <Modal
      title={t("modals.edit-account.title")}
      okText={t(`modals.edit-account.buttons.ok`)}
      cancelText={t(`modals.edit-account.buttons.cancel`)}
      className="editModal"
      destroyOnClose={true}
      {...props}
      onOk={editAccountForm.submit}
      onCancel={handleCancel}
    >
      <Form layout="horizontal" onFinish={handleFinish} form={editAccountForm} initialValues={initialValues}>
        <Row>
          <Col span={16}>
            <Form.Item
              preserve={false}
              name="officialAccount"
              label={t("modals.edit-account.form.labels.official-account")}
              rules={[{ required: true, message: t("modals.edit-account.form.errors.xlink-account") }]}
            >
              <Input disabled={true} />
            </Form.Item>
            <Form.Item name="registerNickname" label={t("modals.edit-account.form.labels.register-nickname")} preserve={false}>
              <Input disabled={true} />
            </Form.Item>
            <Form.Item
              name="lastEditNickname"
              label={t("modals.edit-account.form.labels.last-edit-nickname")}
              rules={[{ required: true, message: t("modals.edit-account.form.errors.last-edit-nickname") }]}
              preserve={false}
            >
              <Input maxLength={12} showCount />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item name="profilePhoto" rules={[{ required: true, message: "upload" }]} preserve={false}>
              <Upload listType="picture-card" fileList={fileList} customRequest={handleCustomRequest} onPreview={handlePreview} onChange={handleChange}>
                {fileList.length === 0 ? uploadButton : null}
              </Upload>
              <Modal open={previewOpen} footer={null} onCancel={handlePreviewCancel}>
                <img alt="example" style={{ width: "100%" }} src={previewImage} />
              </Modal>
            </Form.Item>
          </Col>
        </Row>
        <Form.Item name="accountType" label={t("modals.edit-account.form.account-type.label")} preserve={false}>
          <Select
            options={[
              { value: 1, label: t("modals.edit-account.form.account-type.options.personal") },
              { value: 2, label: t("modals.edit-account.form.account-type.options.business") },
            ]}
          />
        </Form.Item>
        <Form.Item
          name="realName"
          label={t("modals.edit-account.form.labels.real-name")}
          rules={[{ required: true, message: t("modals.edit-account.form.errors.real-name") }]}
          preserve={false}
        >
          <Input />
        </Form.Item>
        <Form.Item name="idType" label={t("modals.edit-account.form.id-type.label")} preserve={false}>
          <Select
            options={[
              { value: 1, label: t("modals.edit-account.form.id-type.options.passport") },
              { value: 2, label: t("modals.edit-account.form.id-type.options.business-license") },
              { value: 3, label: t("modals.edit-account.form.id-type.options.national-id") },
            ]}
          />
        </Form.Item>
        <Form.Item
          name="idNumber"
          label={t("modals.edit-account.form.labels.id-number")}
          rules={[{ required: true, message: t("modals.edit-account.form.errors.id-number") }]}
          preserve={false}
        >
          <Input />
        </Form.Item>
        <Form.Item name="bio" label={t("modals.edit-account.form.labels.introduction")} preserve={false}>
          <TextArea rows={4} maxLength={500} showCount />
        </Form.Item>
        <Form.Item name="isSystem" label={t("modals.edit-account.form.default-allowed.label")} preserve={false}>
          <Select
            options={[
              { value: 1, label: t("modals.edit-account.form.default-allowed.options.yes") },
              { value: 0, label: t("modals.edit-account.form.default-allowed.options.no") },
            ]}
            onChange={handleDefaultAllowed}
          />
        </Form.Item>
        {defaultAllowed && (
          <Form.Item
            name="interests"
            label={t("modals.edit-account.form.labels.tags")}
            rules={defaultAllowed ? [] : [{ required: true, message: t("modals.edit-account.form.errors.tags"), min: 1, max: 10, type: "array" }]}
            preserve={false}
          >
            <Select mode="multiple" value={selectedTags} options={filteredInterestList} onChange={handleTagChange} />
            <div style={{ float: "right" }}>{`${selectedTags.length}/10`}</div>
          </Form.Item>
        )}
      </Form>
    </Modal>
  );
};

export default EditAccountModal;
