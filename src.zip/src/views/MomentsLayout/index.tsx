import { Tabs, TabsProps } from "antd";
import React, { FC, Suspense } from "react";
import { useTranslation } from "react-i18next";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import MomentPostView from "../MomentPostView";
import MomentsCommentView from "../MomentsCommentView";
import MomentsLikesView from "../MomentsLikesView";

interface MomentsLayoutProps {}

const MomentsLayout: FC<MomentsLayoutProps> = () => {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { t } = useTranslation("moments-layout");

  const items: TabsProps["items"] = [
    {
      key: "/moments/momentsPost",
      label: t("tabs.post-view"),
      children: <MomentPostView />,
    },
    {
      key: "/moments/momentsComments",
      label: t("tabs.comment-view"),
      children: <MomentsCommentView />,
    },
    {
      key: "/moments/momentsLikes",
      label: t("tabs.like-view"),
      children: <MomentsLikesView />,
    },
  ];
  const onChange = (key: string) => navigate(key);

  return (
    <Tabs defaultActiveKey="1" items={items} activeKey={pathname} onChange={onChange} className="tab">
      <Suspense>
        <Outlet />
      </Suspense>
    </Tabs>
  );
};

export default MomentsLayout;
