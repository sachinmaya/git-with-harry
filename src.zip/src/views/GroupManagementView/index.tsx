import {
  ApiRequest,
  BanGroupChatRequestParams,
  DeleteGroupRequestParams,
  GetGroupsItem,
  GetGroupsRequestParams,
  OpenGroupChatRequestParams,
  SetVideoAudioStatusRequestParams,
} from "~/api/types";
import { actions } from "~/api/constants";
import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { useDashboardView } from "~/views/DashboardView";
import useRequest from "~/hooks/useRequest";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import usePermissions from "~/hooks/usePermissions";
import { InternalServerError, NetworkError } from "~/api/errors";
import { Button, DatePicker, Form, Image, Input, message, Select, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import Icon, { EyeOutlined } from "@ant-design/icons";
import dayjs, { Dayjs } from "dayjs";
import SearchIcon from "~/components/icons/SearchIcon";
import AddIcon from "~/components/icons/AddIcon";
import ConfirmModal, { ModalType } from "./ConfirmModal";
import { useNavigate } from "react-router-dom";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";

const getGroupType = (type: 0 | 1) => {
  switch (type) {
    case 0:
      return "private";
    case 1:
      return "public";
  }
};

const initialParams: GetGroupsRequestParams = {
  page_number: 1,
  show_number: 10,
  order_by: "create_time:desc",
};

const getGroupsQuery = (request: ApiRequest, params: GetGroupsRequestParams = initialParams) => ({
  queryKey: [actions.GET_GROUPS, params],
  queryFn: () => request(actions.GET_GROUPS, params),
});

export const groupManagementViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getGroupsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  keyword: string;
  owner: string;
  type: null | 0 | 1;
  remark: string;
  creator: string;
  status: number[];
  filterType: "create_time:desc";
  filterRange: null | Dayjs[];
}

const initialValues: FormValues = {
  keyword: "",
  owner: "",
  type: null,
  remark: "",
  creator: "",
  status: [],
  filterType: "create_time:desc",
  filterRange: null,
};

const GroupManagementView = () => {
  const { t } = useTranslation("group-management-view");
  const { setDashboardHeading } = useDashboardView();
  const navigate = useNavigate();
  const request = useRequest();
  const [params, setParams] = useState<GetGroupsRequestParams>(initialParams);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const { isActionAllowed, isPageAllowed } = usePermissions();
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalType; groupID: string }>({
    open: false,
    key: "delete-group",
    groupID: "",
  });
  const queryClient = useQueryClient();

  const { data, isPreviousData } = useQuery({
    ...getGroupsQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.get-groups-query-failed"),
      });
    },
  });

  const banGroupChatMutation = useMutation((params: BanGroupChatRequestParams) => request(actions.BAN_GROUP_CHAT, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_GROUPS]);
      message.open({
        key: "ban-group-chat-successfully",
        type: "success",
        content: t("toasts.ban-group-chat-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "ban-group-chat-failed",
        type: "error",
        content: t("toasts.ban-group-chat-failed"),
      });
    },
  });

  const openGroupChatMutation = useMutation((params: OpenGroupChatRequestParams) => request(actions.OPEN_GROUP_CHAT, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_GROUPS]);
      message.open({
        key: "open-group-chat-successfully",
        type: "success",
        content: t("toasts.open-group-chat-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "open-group-chat-failed",
        type: "error",
        content: t("toasts.open-group-chat-failed"),
      });
    },
  });

  const setVideoAudioStatusMutation = useMutation((params: SetVideoAudioStatusRequestParams) => request(actions.SET_VIDEO_AUDIO_STATUS, params), {
    onSuccess: (data, { status, status_type }) => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_GROUPS]);
      let key: "enable-video-successfully" | "disable-video-successfully" | "enable-audio-successfully" | "disable-audio-successfully";
      switch (status_type) {
        case 1:
          switch (status) {
            case 1:
              key = "enable-video-successfully";
              break;
            case 2:
              key = "disable-video-successfully";
              break;
          }
          break;
        case 2:
          switch (status) {
            case 1:
              key = "enable-audio-successfully";
              break;
            case 2:
              key = "disable-audio-successfully";
              break;
          }
          break;
      }
      message.open({
        key,
        type: "success",
        content: t(`toasts.${key}`),
      });
    },
    onError: (error, { status_type, status }) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      let key: "enable-video-failed" | "disable-video-failed" | "enable-audio-failed" | "disable-audio-failed";
      switch (status_type) {
        case 1:
          switch (status) {
            case 1:
              key = "enable-video-failed";
              break;
            case 2:
              key = "disable-video-failed";
              break;
          }
          break;
        case 2:
          switch (status) {
            case 1:
              key = "enable-audio-failed";
              break;
            case 2:
              key = "disable-audio-failed";
              break;
          }
          break;
      }
      message.open({
        key,
        type: "error",
        content: t(`toasts.${key}`),
      });
    },
  });

  const deleteGroupMutation = useMutation((params: DeleteGroupRequestParams) => request(actions.DELETE_GROUP, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_GROUPS]);
      message.open({
        key: "delete-group-successfully",
        type: "success",
        content: t("toasts.delete-group-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-group-failed",
        type: "error",
        content: t("toasts.delete-group-failed"),
      });
    },
  });

  useEffect(() => {
    setDashboardHeading("groups", "group-management");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ keyword, owner, type, remark, creator, status, filterType, filterRange }: FormValues) => {
      setParams(({ show_number }) => {
        const state: GetGroupsRequestParams = { page_number: 1, show_number, order_by: filterType };
        if (keyword !== "") {
          state.group = keyword;
        }
        if (owner !== "") {
          state.owner = owner;
        }
        if (type !== null) {
          state.is_open = type;
        }
        if (remark !== "") {
          state.remark = remark;
        }
        if (creator !== "") {
          state.creator = creator;
        }
        if (status.length > 0) {
          state.group_status = JSON.stringify(status.map((item) => item.toString()));
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = startTime;
          state.end_time = endTime;
        }
        return state;
      });
      setSearchLoading(true);
    },
    [setParams]
  );

  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);

  const handleModalOk = useCallback(() => {
    let status: 1 | 2, status_type: 1 | 2;
    switch (openModal.key) {
      case "enable-group-chat":
        openGroupChatMutation.mutate({ group_id: openModal.groupID });
        return;
      case "disable-group-chat":
        banGroupChatMutation.mutate({ group_id: openModal.groupID });
        return;
      case "enable-private-chat":
      case "disable-private-chat":
        return;
      case "delete-group":
        deleteGroupMutation.mutate({ group_id: openModal.groupID });
        return;
      case "disable-video":
        status_type = 1;
        status = 2;
        break;
      case "enable-video":
        status_type = 1;
        status = 1;
        break;
      case "disable-audio":
        status_type = 2;
        status = 2;
        break;
      case "enable-audio":
        status_type = 2;
        status = 1;
        break;
    }
    setVideoAudioStatusMutation.mutate({ status, status_type, groupID: openModal.groupID });
  }, [openModal, openGroupChatMutation.mutate, banGroupChatMutation.mutate, setVideoAudioStatusMutation.mutate]);

  const columns: ColumnsType<GetGroupsItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => ((data?.data.current_number || 0) - 1) * (data?.data.show_number || 0) + (index + 1),
      },
      {
        key: "group-name",
        dataIndex: "group_name",
        width: 160,
        title: t("columns.group-name"),
      },
      {
        key: "group-id",
        width: 140,
        dataIndex: "group_id",
        title: t("columns.group-id"),
      },
      {
        key: "group-avatar",
        width: 160,
        dataIndex: "profile_photo",
        title: t("columns.group-avatar"),
        render: (value) => (value === "" ? "-" : <Image src={value} rootClassName="thumbImagePreview" width={30} height={30} preview={{ mask: <EyeOutlined /> }} />),
      },
      {
        key: "type",
        width: 100,
        dataIndex: "is_open",
        title: t("columns.type"),
        render: (value) => t(`enums.group-type.${getGroupType(value)}`),
      },
      {
        key: "owners-show-name",
        width: 180,
        title: t("columns.owners-show-name"),
        render: (value, record) => `${record.group_master_id}/${record.group_master_name}`,
      },
      {
        key: "members",
        width: 100,
        dataIndex: "members",
        title: t("columns.members"),
      },
      {
        key: "group-description",
        width: 180,
        dataIndex: "group_introduction",
        title: t("columns.group-description"),
        render: (value) => value || "-",
      },
      {
        key: "group-announcement",
        width: 180,
        dataIndex: "group_notification",
        title: t("columns.group-announcement"),
        render: (value) => value || "-",
      },
      {
        key: "remark",
        width: 180,
        dataIndex: "remark",
        title: t("columns.remark"),
        render: (value) => value || "-",
      },
      {
        key: "creation-time",
        width: 160,
        dataIndex: "create_time",
        title: t("columns.creation-time"),
        render: (value) => dayjs(value).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "status",
        width: 160,
        title: t("columns.status"),
        render: (value, record) => (
          <>
            <div>{t(`enums.group-status.${record.is_ban_chat ? "off" : "on"}`)}</div>
            <div>{t(`enums.private-chat-status.${record.is_ban_private_chat ? "off" : "on"}`)}</div>
            <div>{t(`enums.video-status.${record.video_status ? "on" : "off"}`)}</div>
            <div>{t(`enums.audio-status.${record.audio_status ? "on" : "off"}`)}</div>
          </>
        ),
      },
      {
        key: "options",
        width: 240,
        title: t("columns.options"),
        fixed: "right",
        render: (value, record) => (
          <>
            <button type="button" className="optionBtn">
              {t("options.edit")}
            </button>
            {isPageAllowed("/groups/groupsAdm/:groupID") && (
              <button type="button" className="optionBtn" onClick={() => navigate(`/groups/groupsAdm/${record.group_id}`)}>
                {t("options.details")}
              </button>
            )}
            <button type="button" className="optionBtn">
              {t("options.group-messages")}
            </button>
            {isActionAllowed(actions.OPEN_GROUP_CHAT) && record.is_ban_chat && (
              <button
                type="button"
                className="optionBtn optionBtnSuccess"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "enable-group-chat",
                    groupID: record.group_id,
                  })
                }
              >
                {t("options.enable-group-chat")}
              </button>
            )}
            {isActionAllowed(actions.BAN_GROUP_CHAT) && !record.is_ban_chat && (
              <button
                type="button"
                className="optionBtn optionBtnDanger"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "disable-group-chat",
                    groupID: record.group_id,
                  })
                }
              >
                {t("options.disable-group-chat")}
              </button>
            )}
            <button
              type="button"
              className="optionBtn optionBtnDanger"
              onClick={() =>
                setOpenModal({
                  open: true,
                  key: "disable-private-chat",
                  groupID: record.group_id,
                })
              }
            >
              {t("options.disable-group-chat")}
            </button>
            {isActionAllowed(actions.SWITCH_STATUS) && record.video_status === 2 && (
              <button
                type="button"
                className="optionBtn optionBtnSuccess"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "enable-video",
                    groupID: record.group_id,
                  })
                }
              >
                {t("options.enable-video")}
              </button>
            )}
            {isActionAllowed(actions.SWITCH_STATUS) && record.video_status === 1 && (
              <button
                type="button"
                className="optionBtn optionBtnDanger"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "disable-video",
                    groupID: record.group_id,
                  })
                }
              >
                {t("options.disable-video")}
              </button>
            )}
            {isActionAllowed(actions.SWITCH_STATUS) && record.audio_status === 2 && (
              <button
                type="button"
                className="optionBtn optionBtnSuccess"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "enable-audio",
                    groupID: record.group_id,
                  })
                }
              >
                {t("options.enable-audio")}
              </button>
            )}
            {isActionAllowed(actions.SWITCH_STATUS) && record.audio_status === 1 && (
              <button
                type="button"
                className="optionBtn optionBtnDanger"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "disable-audio",
                    groupID: record.group_id,
                  })
                }
              >
                {t("options.disable-audio")}
              </button>
            )}
            <button
              type="button"
              className="optionBtn optionBtnDanger"
              onClick={() =>
                setOpenModal({
                  open: true,
                  key: "delete-group",
                  groupID: record.group_id,
                })
              }
            >
              {t("options.delete-group")}
            </button>
          </>
        ),
      },
    ],
    [t, data]
  );

  if (!isPageAllowed("/groups/groupsAdm")) {
    return null;
  }

  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish}>
        <Form.Item name="keyword">
          <Input placeholder={t("form.keyword.placeholder")} style={{ width: 188 }} />
        </Form.Item>
        <Form.Item name="owner">
          <Input placeholder={t("form.owner.placeholder")} style={{ width: 268 }} />
        </Form.Item>
        <Form.Item name="type">
          <Select
            style={{ width: 120 }}
            placeholder={t("form.type.placeholder")}
            allowClear
            options={(
              [
                ["private", 1],
                ["public", 2],
              ] as const
            ).map(([key, value]) => ({
              value,
              label: t(`form.type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="remark">
          <Input placeholder={t("form.remark.placeholder")} style={{ width: 220 }} />
        </Form.Item>
        <Form.Item name="creator">
          <Input placeholder={t("form.creator.placeholder")} style={{ width: 226 }} />
        </Form.Item>
        <Form.Item name="status">
          <Select
            mode="multiple"
            placeholder={t("form.status.placeholder")}
            options={([1, 2, 3, 4, 5, 6, 7, 8] as const).map((value) => ({
              value,
              label: t(`form.status.options.${value}`),
            }))}
            style={{ width: 132 }}
          />
        </Form.Item>
        <Form.Item name="filterType">
          <Select
            options={([["create-time", "create_time:desc"]] as const).map(([key, value]) => ({
              value,
              label: t(`form.filter-type.options.${key}`),
            }))}
            style={{ width: 120 }}
          />
        </Form.Item>
        <Form.Item name="filterRange">
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} style={{ width: 232 }} />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnSuccess" type="primary" htmlType="button" icon={<Icon component={AddIcon} />}>
            {t("form.buttons.create-new-group")}
          </Button>
        </Form.Item>
      </Form>
      <Table
        rowKey="user_id"
        className="customTable"
        dataSource={data?.data.groups}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.group_nums,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
      <ConfirmModal open={openModal.open} type={openModal.key} onCancel={handleModalCancel} onOk={handleModalOk} confirmLoading={banGroupChatMutation.isLoading} />
    </>
  );
};

export default GroupManagementView;
