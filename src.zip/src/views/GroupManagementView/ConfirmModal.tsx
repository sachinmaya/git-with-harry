import React from "react";
import { Modal, ModalProps } from "antd";
import { useTranslation } from "react-i18next";

export type ModalType = "enable-group-chat" | "disable-group-chat" | "enable-private-chat" | "disable-private-chat" | "disable-video" | "enable-video" | "disable-audio" | "enable-audio" | "delete-group";

interface ConfirmModalProps extends ModalProps {
  type: ModalType;
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({ type, ...props }) => {
  const { t } = useTranslation("group-management-view");
  return (
    <Modal
      className="confirmModal"
      okButtonProps={{ danger: ["disable-group-chat", "disable-private-chat", "disable-video", "disable-audio", "delete-group"].includes(type) }}
      okText={t(`modals.${type}.buttons.ok`)}
      cancelText={t(`modals.${type}.buttons.cancel`)}
      destroyOnClose
      {...props}
    >
      {t(`modals.${type}.content`)}
    </Modal>
  );
};

export default ConfirmModal;
