import { QueryClient, useQuery } from "@tanstack/react-query";
import { message, Table, Tabs, TabsProps } from "antd";
import { ColumnsType } from "antd/es/table";
import Empty from "antd/lib/empty";
import dayjs from "dayjs";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { actions } from "~/api/constants";
import { InternalServerError, NetworkError } from "~/api/errors";
import { ActiveUserStatistics, ApiRequest, GetStatisticsParams } from "~/api/types";
import StatisticsAreaChart from "~/components/Statistics/StatisticsAreaChart";
import usePermissions from "~/hooks/usePermissions";
import useRequest from "~/hooks/useRequest";
import { useDashboardView } from "../DashboardView";
import Heart from "./Icons/Heart";
import Paper from "./Icons/Paper";
import User from "./Icons/User";
import Text from "antd/lib/typography/Text";
import TabBarExtraContent, { tabRightButtonType } from "~/components/Statistics/TabBarExtraContent";
import StatisticsCard from "~/components/Statistics/StatisticsCard";
import monthOrWeekRange from "~/utils/monthOrWeekRange";
import yearRange from "~/utils/yearRange";

const today = dayjs(new Date());

const initialParams: GetStatisticsParams = {
  from: dayjs(today).startOf("week").format("YYYY-MM-DD"),
  to: dayjs(today).endOf("week").format("YYYY-MM-DD"),
};

const getUserStatisticsQuery = (request: ApiRequest, params: GetStatisticsParams = initialParams) => ({
  queryKey: [actions.GET_USER_STATISTICS, params],
  queryFn: async () => request(actions.GET_USER_STATISTICS, params),
});

export const userStaticsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getUserStatisticsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

const getActiveUserStatisticsQuery = (request: ApiRequest, params: GetStatisticsParams = initialParams) => ({
  queryKey: [actions.GET_ACTIVE_USER_STATISTICS, params],
  queryFn: async () => request(actions.GET_ACTIVE_USER_STATISTICS, params),
});

export const activeUserStaticsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getActiveUserStatisticsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};
const UserStatisticsView = () => {
  const { t } = useTranslation("user-statistics-view");
  const [params, setParams] = useState<GetStatisticsParams>(initialParams);
  const { setDashboardHeading } = useDashboardView();
  const { isActionAllowed } = usePermissions();
  const request = useRequest();
  const { data: userStat, refetch } = useQuery({
    ...getUserStatisticsQuery(request, params),
    keepPreviousData: true,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.user-statistics-query-failed"),
      });
    },
  });
  const { data: activeUserStat } = useQuery({
    ...getActiveUserStatisticsQuery(request, params),
    keepPreviousData: true,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.active-user-statistics-query-failed"),
      });
    },
  });

  const newUserGraphData = useMemo(() => {
    if (userStat) {
      return userStat.data.increase_user_num_list.map((item) => {
        return {
          date: dayjs(item.date).format("DD/MM/YYYY"),
          value: item.increase_user_num,
        };
      });
    }
    return [];
  }, [userStat?.data.increase_user_num_list]);

  const activeUserGraphData = useMemo(() => {
    if (userStat) {
      return userStat.data.active_user_num_list.map((item) => {
        return {
          date: dayjs(item.date).format("DD/MM/YYYY"),
          value: item.active_user_num,
        };
      });
    }
    return [];
  }, [userStat?.data.active_user_num_list]);

  const totalUserGraphData = useMemo(() => {
    if (userStat) {
      return userStat.data.total_user_num_list.map((item) => {
        return {
          date: dayjs(item.date).format("DD/MM/YYYY"),
          value: item.total_user_num,
        };
      });
    }
    return [];
  }, [userStat?.data.total_user_num_list]);

  useEffect(() => {
    setDashboardHeading("statistics", "user-statistics");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const handleRefetch = useCallback((from: string, to: string) => {
    setParams({ from: from, to: to });
    return refetch();
  }, []);

  const handleTabBtns = (value: tabRightButtonType) => {
    switch (value) {
      case "day":
        let day = today.format("YYYY-MM-DD");
        return handleRefetch(day, day);
      case "week":
      case "month":
        const [from, to] = monthOrWeekRange(value);
        return handleRefetch(from, to);
      case "year":
        const [yearFrom, yearTo] = yearRange();
        return handleRefetch(yearFrom, yearTo);
      default:
        return;
    }
  };

  const items: TabsProps["items"] = [
    {
      key: "1",
      label: t("chart.tabs.new"),
      children: <StatisticsAreaChart data={newUserGraphData} text={t("chart.fields.users")} />,
    },
    {
      key: "2",
      label: t("chart.tabs.active"),
      children: <StatisticsAreaChart data={activeUserGraphData} text={t("chart.fields.users")} />,
    },
    {
      key: "3",
      label: t("chart.tabs.cumulative"),
      children: <StatisticsAreaChart data={totalUserGraphData} text={t("chart.fields.users")} />,
    },
  ];
  const findeIndex = (record: ActiveUserStatistics, index: number) => {
    if (activeUserStat && activeUserStat?.data.active_user_list !== null) {
      let serilNo = activeUserStat.data.active_user_list.indexOf(record) + 1;
      return serilNo;
    }
    return index + 1;
  };

  const columns: ColumnsType<ActiveUserStatistics> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        render: (value, record, index) => findeIndex(record, index),
      },
      {
        key: "nickname",
        dataIndex: "nick_name",
        title: t("columns.nickname"),
        render: (text) => (
          <Text style={{ width: 150 }} ellipsis={{ tooltip: text }}>
            {text}
          </Text>
        ),
      },
      {
        key: "user_id",
        dataIndex: "user_id",
        title: t("columns.id"),
        render: (text) => (text.length === 11 ? text.slice(0, 3) + "***" + text.slice(-3) : text),
      },
      {
        key: "message_num",
        dataIndex: "message_num",
        title: t("columns.messages"),
      },
    ],
    [t, activeUserStat]
  );
  if (!isActionAllowed(actions.GET_USER_STATISTICS) && !isActionAllowed(actions.GET_ACTIVE_USER_STATISTICS)) {
    return <Empty description={false} />;
  }

  return (
    <>
      {isActionAllowed(actions.GET_USER_STATISTICS) && (
        <>
          <div className="statisticsCardContainer">
            <StatisticsCard title={t("new-users")} count={userStat?.data.increase_user_num} icon={<User />} />
            <StatisticsCard title={t("active-users")} count={userStat?.data.active_user_num} icon={<Heart />} />
            <StatisticsCard title={t("cumulative-users")} count={userStat?.data.total_user_num} icon={<Paper />} />
          </div>
          <Tabs defaultActiveKey="1" items={items} size="small" className="tab" tabBarExtraContent={<TabBarExtraContent changeParams={handleTabBtns} search={handleRefetch} />} />
        </>
      )}
      {isActionAllowed(actions.GET_ACTIVE_USER_STATISTICS) && (
        <>
          <div className="statiTableTitle">{t("active-users")}</div>
          <div className="statisticsCardLayout statiTable">
            <Table
              dataSource={activeUserStat?.data.active_user_list === null ? [] : activeUserStat?.data.active_user_list.slice(0, 10) || []}
              bordered
              columns={columns}
              size="small"
              pagination={false}
            />
            <Table
              dataSource={activeUserStat?.data.active_user_list === null ? [] : activeUserStat?.data.active_user_list.slice(10) || []}
              bordered
              columns={columns}
              size="small"
              pagination={false}
            />
          </div>
        </>
      )}
    </>
  );
};

export default UserStatisticsView;
