import React from "react";
import { Modal, ModalProps } from "antd";
import { useTranslation } from "react-i18next";

export type ModalType = "unmute-member" | "delete-member" | "set-as-admin" | "set-as-member" | "delete-group";

interface ConfirmModalProps extends ModalProps {
  type: ModalType;
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({ type, ...props }) => {
  const { t } = useTranslation("group-details-management-view");
  return (
    <Modal
      className="confirmModal"
      okButtonProps={{ danger: ["delete-member", "delete-group"].includes(type) }}
      okText={t(`modals.${type}.buttons.ok`)}
      cancelText={t(`modals.${type}.buttons.cancel`)}
      destroyOnClose
      {...props}
    >
      {t(`modals.${type}.content`)}
    </Modal>
  );
};

export default ConfirmModal;
