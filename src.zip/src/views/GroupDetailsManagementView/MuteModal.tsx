import React, { useState } from "react";
import { InputNumber, Modal, ModalProps, Radio, Space } from "antd";
import { useTranslation } from "react-i18next";

interface MuteModalProps extends ModalProps {
  onSubmit: (muteTime: number) => void;
}

const radioValues = {
  "10m": 10 * 60,
  "1h": 60 * 60,
  "12h": 12 * 60 * 60,
  "1d": 24 * 60 * 60,
  permanent: 315360000,
} as const;

type RadioValue = keyof typeof radioValues | "custom";

const MuteModal: React.FC<MuteModalProps> = ({ onSubmit, ...props }) => {
  const [value, setValue] = useState<RadioValue>();
  const [customValue, setCustomValue] = useState<number | null>(null);
  const { t } = useTranslation("group-details-management-view");

  return (
    <Modal
      title={t("modals.mute-member.title")}
      okText={t("modals.mute-member.buttons.ok")}
      cancelText={t("modals.mute-member.buttons.cancel")}
      okButtonProps={{ disabled: value === undefined || (value === "custom" && customValue === null) }}
      onOk={() => onSubmit(value === "custom" ? customValue! : radioValues[value!])}
      {...props}
    >
      <p>{t("modals.mute-member.content")}</p>
      <Radio.Group onChange={(e) => setValue(e.target.value)} value={value}>
        <Space direction="vertical">
          {Object.keys(radioValues).map((value) => (
            <Radio value={value}>{t(`modals.mute-member.options.${value as keyof typeof radioValues}`)}</Radio>
          ))}
          <Space>
            <Radio value="custom">{t("modals.mute-member.options.customise.label")}</Radio>
            <InputNumber
              value={customValue}
              onChange={setCustomValue}
              min={1}
              max={radioValues.permanent}
              disabled={value !== "custom"}
              placeholder={t("modals.mute-member.options.customise.placeholder")}
            />
          </Space>
        </Space>
      </Radio.Group>
    </Modal>
  );
};

export default MuteModal;
