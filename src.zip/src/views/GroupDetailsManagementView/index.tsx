import { useTranslation } from "react-i18next";
import {
  AddMembersRequestParams,
  ApiRequest,
  CancelMuteGroupMemberRequestParams,
  DeleteGroupRequestParams,
  GetGroupByIdRequestParams,
  GetGroupMembersItem,
  GetGroupMembersRequestParams,
  MuteGroupMemberRequestParams,
  RemoveMembersRequestParams,
  SetGroupAdminRequestParams,
  SetGroupMasterRequestParams,
  SetGroupOrdinaryUserRequestParams,
} from "~/api/types";
import { actions } from "~/api/constants";
import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { LoaderFunctionArgs, useNavigate, useParams } from "react-router-dom";
import usePermissions from "~/hooks/usePermissions";
import useRequest from "~/hooks/useRequest";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { InternalServerError, NetworkError } from "~/api/errors";
import { Button, DatePicker, Form, Input, message, Select, Table } from "antd";
import { useDashboardView } from "~/views/DashboardView";
import { ColumnsType } from "antd/es/table";
import dayjs, { Dayjs } from "dayjs";
import ConfirmModal, { ModalType } from "./ConfirmModal";
import Icon from "@ant-design/icons";
import SearchIcon from "~/components/icons/SearchIcon";
import AddIcon from "~/components/icons/AddIcon";
import EditIcon from "~/components/icons/EditIcon";
import BackIcon from "~/components/icons/BackIcon";
import UserSelectModal from "~/components/overlay/UserSelectModal";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";
import TransferOwnerModal from "./TransferOwnerModal";
import MuteModal from "./MuteModal";

const getRoleLevel = (roleLevel: 1 | 2 | 3) => {
  switch (roleLevel) {
    case 1:
      return "member";
    case 2:
      return "owner";
    case 3:
      return "admin";
  }
};

const getGroupMemberRightsByRoleLevel = (roleLevel: 1 | 2 | 3) => {
  switch (roleLevel) {
    case 1:
      return ["invite"] as const;
    case 2:
      return ["add-admin", "delete-admin", "invite", "accept-join", "reject-join", "delete", "mute", "unmute", "transfer-owner", "chat-during-mute"] as const;
    case 3:
      return ["add-admin", "delete-admin", "invite", "accept-join", "reject-join", "delete", "mute", "unmute"] as const;
  }
};

const initialParams: GetGroupMembersRequestParams = {
  page_number: 1,
  show_number: 10,
  group_id: "",
  status: JSON.stringify([]),
  permission: JSON.stringify([]),
  role_level: JSON.stringify([]),
};

const getGroupMembersQuery = (request: ApiRequest, params: GetGroupMembersRequestParams) => ({
  queryKey: [actions.GET_GROUP_MEMBERS, params],
  queryFn: () => request(actions.GET_GROUP_MEMBERS, params),
});

const getGroupByIdQuery = (request: ApiRequest, params: GetGroupByIdRequestParams) => ({
  queryKey: [actions.GET_GROUP_BY_ID, params],
  queryFn: () => request(actions.GET_GROUP_BY_ID, params),
});

export const groupGroupsMembersViewLoader =
  (queryClient: QueryClient, request: ApiRequest) =>
  async ({ params }: LoaderFunctionArgs) => {
    const queryGroupMembers = getGroupMembersQuery(request, {
      ...initialParams,
      group_id: params.groupID as string,
    });
    const queryGroup = getGroupByIdQuery(request, { group_id: params.groupID as string });
    return await Promise.all([
      queryClient.getQueryData(queryGroupMembers.queryKey) ?? queryClient.fetchQuery(queryGroupMembers),
      queryClient.getQueryData(queryGroup.queryKey) ?? queryClient.fetchQuery(queryGroup),
    ]);
  };

interface FormValues {
  role: number[];
  member: string;
  nickname: string;
  remark: string;
  joinTimeRangeFilter: null | Dayjs[];
  permissions: number[];
  status: number[];
}

const initialValues: FormValues = {
  role: [],
  member: "",
  nickname: "",
  remark: "",
  joinTimeRangeFilter: null,
  status: [],
  permissions: [],
};

const GroupDetailsManagementView = () => {
  const { t } = useTranslation("group-details-management-view");
  const { setDashboardHeading } = useDashboardView();
  const { isActionAllowed, isPageAllowed } = usePermissions();
  const request = useRequest();
  const { groupID } = useParams<{ groupID: string }>();
  const [params, setParams] = useState<GetGroupMembersRequestParams>({ ...initialParams, group_id: groupID! });
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalType; memberID: string }>({
    open: false,
    key: "delete-group",
    memberID: "",
  });
  const [muteModal, setMuteModal] = useState<{ open: boolean; memberID: string }>({ open: false, memberID: "" });
  const [addMembersModalOpen, setAddMembersModalOpen] = useState<boolean>(false);
  const [transferOwnerModalOpen, setTransferOwnerModalOpen] = useState<boolean>(false);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  useEffect(() => {
    setDashboardHeading("groups", "group-management");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const groupQuery = useQuery(getGroupByIdQuery(request, { group_id: groupID! }));

  const { data, isPreviousData } = useQuery({
    ...getGroupMembersQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.get-group-members-query-failed"),
      });
    },
  });

  const allGroupMembers = useQuery({
    ...getGroupMembersQuery(request, {
      page_number: 1,
      show_number: -1,
      group_id: groupID!,
      status: JSON.stringify([]),
      permission: JSON.stringify([]),
      role_level: JSON.stringify([]),
    }),
    keepPreviousData: true,
    enabled: addMembersModalOpen,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.get-group-members-query-failed"),
      });
    },
  });

  const muteGroupMemberMutation = useMutation((params: MuteGroupMemberRequestParams) => request(actions.MUTE_GROUP_MEMBER, params), {
    onSuccess: () => {
      setMuteModal({ open: false, memberID: "" });
      queryClient.invalidateQueries([actions.GET_GROUP_MEMBERS]);
      message.open({
        key: "mute-group-member-successfully",
        type: "success",
        content: t("toasts.mute-group-member-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "mute-group-member-failed",
        type: "error",
        content: t("toasts.mute-group-member-failed"),
      });
    },
  });

  const cancelMuteGroupMemberMutation = useMutation((params: CancelMuteGroupMemberRequestParams) => request(actions.CANCEL_MUTE_GROUP_MEMBER, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_GROUP_MEMBERS]);
      message.open({
        key: "cancel-mute-group-member-successfully",
        type: "success",
        content: t("toasts.cancel-mute-group-member-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "cancel-mute-group-member-failed",
        type: "error",
        content: t("toasts.cancel-mute-group-member-failed"),
      });
    },
  });

  const setGroupAdminMutation = useMutation((params: SetGroupAdminRequestParams) => request(actions.SET_GROUP_ADMIN, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_GROUP_MEMBERS]);
      message.open({
        key: "set-group-admin-successfully",
        type: "success",
        content: t("toasts.set-group-admin-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "set-group-admin-failed",
        type: "error",
        content: t("toasts.set-group-admin-failed"),
      });
    },
  });

  const setGroupOrdinaryUserMutation = useMutation((params: SetGroupOrdinaryUserRequestParams) => request(actions.SET_GROUP_ORDINARY_USER, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_GROUP_MEMBERS]);
      message.open({
        key: "set-group-ordinary-user-successfully",
        type: "success",
        content: t("toasts.set-group-ordinary-user-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "set-group-ordinary-user-failed",
        type: "error",
        content: t("toasts.set-group-ordinary-user-failed"),
      });
    },
  });

  const removeMembersMutation = useMutation((params: RemoveMembersRequestParams) => request(actions.REMOVE_MEMBERS, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_GROUP_MEMBERS]);
      message.open({
        key: "remove-members-successfully",
        type: "success",
        content: t("toasts.remove-members-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "remove-members-failed",
        type: "error",
        content: t("toasts.remove-members-failed"),
      });
    },
  });

  const deleteGroupMutation = useMutation((params: DeleteGroupRequestParams) => request(actions.DELETE_GROUP, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_GROUPS]);
      navigate("/groups/groupsAdm");
      message.open({
        key: "delete-group-successfully",
        type: "success",
        content: t("toasts.delete-group-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-group-failed",
        type: "error",
        content: t("toasts.delete-group-failed"),
      });
    },
  });

  const addMembersMutation = useMutation((params: AddMembersRequestParams) => request(actions.ADD_MEMBERS, params), {
    onSuccess: () => {
      setAddMembersModalOpen(false);
      queryClient.invalidateQueries([actions.GET_GROUP_MEMBERS]);
      message.open({
        key: "add-members-successfully",
        type: "success",
        content: t("toasts.add-members-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "add-members-failed",
        type: "error",
        content: t("toasts.add-members-failed"),
      });
    },
  });

  const setGroupOwnerMutation = useMutation((params: SetGroupMasterRequestParams) => request(actions.SET_GROUP_MASTER, params), {
    onSuccess: () => {
      setTransferOwnerModalOpen(false);
      queryClient.invalidateQueries([actions.GET_GROUP_MEMBERS]);
      queryClient.invalidateQueries([actions.GET_GROUP_BY_ID, { group_id: groupID! }]);
      message.open({
        key: "set-group-master-successfully",
        type: "success",
        content: t("toasts.set-group-master-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "set-group-master-failed",
        type: "error",
        content: t("toasts.set-group-master-failed"),
      });
    },
  });

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);

  const handleModalOk = useCallback(() => {
    switch (openModal.key) {
      case "unmute-member":
        cancelMuteGroupMemberMutation.mutate({ groupID: groupID!, userID: openModal.memberID });
        return;
      case "delete-member":
        removeMembersMutation.mutate({ group_Id: groupID!, members: [openModal.memberID] });
        return;
      case "set-as-admin":
        setGroupAdminMutation.mutate({ group_id: groupID!, user_id: openModal.memberID });
        return;
      case "set-as-member":
        setGroupOrdinaryUserMutation.mutate({ group_id: groupID!, user_id: openModal.memberID });
        return;
      case "delete-group":
        deleteGroupMutation.mutate({ group_id: groupID! });
        return;
    }
  }, [
    openModal,
    cancelMuteGroupMemberMutation.mutate,
    removeMembersMutation.mutate,
    setGroupAdminMutation.mutate,
    setGroupOrdinaryUserMutation.mutate,
    deleteGroupMutation.mutate,
  ]);

  const handleMuteSubmit = useCallback(
    (mutedSeconds: number) =>
      muteGroupMemberMutation.mutate({
        mutedSeconds,
        groupID: groupID!,
        userID: muteModal.memberID,
      }),
    [muteGroupMemberMutation.mutate, muteModal]
  );

  const handleBackClick = useCallback(() => navigate(-1), [navigate]);

  const handleFinnish = useCallback(
    ({ role, member, nickname, remark, joinTimeRangeFilter, permissions, status }: FormValues) => {
      setParams(({ show_number, group_id }) => {
        const state: GetGroupMembersRequestParams = {
          page_number: 1,
          show_number,
          group_id,
          role_level: JSON.stringify(role),
          member: member,
          remark_name: nickname,
          remark,
          permission: JSON.stringify(permissions),
          status: JSON.stringify(status),
        };
        if (joinTimeRangeFilter !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(joinTimeRangeFilter);
          state.start_time = startTime;
          state.end_time = endTime;
        }
        return state;
      });
    },
    [setParams]
  );

  const handleAddGroupMemberSelection = useCallback(
    (members: string[]) =>
      addMembersMutation.mutate({
        group_Id: groupID!,
        members,
      }),
    [addMembersMutation.mutate, groupID]
  );

  const handleTransferGroupOwnerSubmit = useCallback(
    (user_id: string) => {
      if (groupQuery.data?.data.group_master_id === user_id) {
        setTransferOwnerModalOpen(false);
        return;
      }
      setGroupOwnerMutation.mutate({
        group_id: groupID!,
        user_id,
      })
    },
    [groupID, groupQuery.data?.data.group_master_id, setGroupOwnerMutation.mutate, setTransferOwnerModalOpen]
  );

  const columns: ColumnsType<GetGroupMembersItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => ((data?.data.current_number || 0) - 1) * (data?.data.show_number || 0) + (index + 1),
      },
      {
        key: "role-in-group",
        dataIndex: "role_level",
        width: 160,
        title: t("columns.role-in-group"),
        render: (value) => t(`enums.role-level.${getRoleLevel(value)}`),
      },
      {
        key: "nickname",
        dataIndex: "member_name",
        width: 160,
        title: t("columns.nickname"),
        render: (value, record) => value || record.member_nick_name,
      },
      {
        key: "member-account",
        dataIndex: "member_id",
        width: 160,
        title: t("columns.member-account"),
      },
      {
        key: "nickname-in-group",
        dataIndex: "member_nick_name",
        width: 160,
        title: t("columns.nickname-in-group"),
      },
      {
        key: "joining-time",
        dataIndex: "join_time",
        width: 160,
        title: t("columns.joining-time"),
        render: (value) => dayjs(value).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "remark",
        width: 160,
        dataIndex: "remark",
        title: t("columns.remark"),
        render: (value) => value || "-",
      },
      {
        key: "rights",
        width: 160,
        dataIndex: "role_level",
        title: t("columns.rights"),
        render: (value) => getGroupMemberRightsByRoleLevel(value).map((key) => <div>{t(`enums.rights.${key}`)}</div>),
      },
      {
        key: "options",
        width: 240,
        title: t("columns.options"),
        fixed: "right",
        render: (value, record) => (
          <>
            <button type="button" className="optionBtn">
              {t("options.user-messages")}
            </button>
            {isActionAllowed(actions.MUTE_GROUP_MEMBER) && record.mute_end_time === 0 && (
              <button type="button" className="optionBtn optionBtnDanger" onClick={() => setMuteModal({ open: true, memberID: record.member_id })}>
                {t("options.mute")}
              </button>
            )}
            {isActionAllowed(actions.CANCEL_MUTE_GROUP_MEMBER) && record.mute_end_time > 0 && (
              <button
                type="button"
                className="optionBtn"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "unmute-member",
                    memberID: record.member_id,
                  })
                }
              >
                {t("options.unmute")}
              </button>
            )}
            {getRoleLevel(record.role_level) === "owner" && (
              <button type="button" className="optionBtn" onClick={() => setTransferOwnerModalOpen(true)}>
                {t("options.transfer-owner")}
              </button>
            )}
            {isActionAllowed(actions.SET_GROUP_ORDINARY_USER) && getRoleLevel(record.role_level) === "admin" && (
              <button
                type="button"
                className="optionBtn"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "set-as-member",
                    memberID: record.member_id,
                  })
                }
              >
                {t("options.set-as-member")}
              </button>
            )}
            {isActionAllowed(actions.SET_GROUP_ADMIN) && getRoleLevel(record.role_level) === "member" && (
              <button
                type="button"
                className="optionBtn"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "set-as-admin",
                    memberID: record.member_id,
                  })
                }
              >
                {t("options.set-as-admin")}
              </button>
            )}
            {isActionAllowed(actions.DELETE_GROUP) && getRoleLevel(record.role_level) === "owner" && (
              <button
                type="button"
                className="optionBtn optionBtnDanger"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "delete-group",
                    memberID: record.member_id,
                  })
                }
              >
                {t("options.dissolve-group")}
              </button>
            )}
            {isActionAllowed(actions.REMOVE_MEMBERS) && getRoleLevel(record.role_level) !== "owner" && (
              <button
                type="button"
                className="optionBtn optionBtnDanger"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "delete-member",
                    memberID: record.member_id,
                  })
                }
              >
                {t("options.remove")}
              </button>
            )}
          </>
        ),
      },
    ],
    [t, data]
  );

  if (!isPageAllowed("/groups/groupsAdm/:groupID") || !groupQuery.isSuccess) {
    return null;
  }

  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish}>
        <Form.Item label={t("form.group.label")}>
          <Input value={`${groupQuery.data.data.group_name}/${groupQuery.data.data.group_id}`} style={{ width: 172 }} readOnly />
        </Form.Item>
        <Form.Item name="role">
          <Select
            mode="multiple"
            placeholder={t("form.role.placeholder")}
            options={([2, 3, 1] as const).map((value) => ({
              value,
              label: t(`form.role.options.${value}`),
            }))}
            style={{ width: 268 }}
          />
        </Form.Item>
        <Form.Item name="member">
          <Input placeholder={t("form.member.placeholder")} style={{ width: 220 }} />
        </Form.Item>
        <Form.Item name="nickname">
          <Input placeholder={t("form.nickname.placeholder")} style={{ width: 226 }} />
        </Form.Item>
        <Form.Item name="remark">
          <Input placeholder={t("form.remark.placeholder")} style={{ width: 226 }} />
        </Form.Item>
        <Form.Item name="joinTimeRangeFilter" label={t("form.join-time-range-filter.label")}>
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} style={{ width: 232 }} />
        </Form.Item>
        <Form.Item name="permissions">
          <Select
            mode="multiple"
            placeholder={t("form.permissions.placeholder")}
            options={([1, 2, 3, 4, 5, 6, 7, 8, 9, 10] as const).map((value) => ({
              value,
              label: t(`form.permissions.options.${value}`),
            }))}
            style={{ width: 188 }}
          />
        </Form.Item>
        <Form.Item name="status">
          <Select
            mode="multiple"
            placeholder={t("form.status.placeholder")}
            options={([1, 2, 3, 4, 5, 6, 7, 8] as const).map((value) => ({
              value,
              label: t(`form.status.options.${value}`),
            }))}
            style={{ width: 188 }}
          />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnSuccess" type="primary" htmlType="button" icon={<Icon component={AddIcon} />} onClick={() => setAddMembersModalOpen(true)}>
            {t("form.buttons.add-members")}
          </Button>
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="button" icon={<Icon component={EditIcon} />}>
            {t("form.buttons.edit-group-info")}
          </Button>
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnDark" type="primary" htmlType="button" icon={<Icon component={BackIcon} />} onClick={handleBackClick}>
            {t("form.buttons.back")}
          </Button>
        </Form.Item>
      </Form>
      <Table
        rowKey="member_id"
        className="customTable"
        dataSource={data?.data.group_members}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.member_nums,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
      <ConfirmModal
        open={openModal.open}
        type={openModal.key}
        onCancel={handleModalCancel}
        onOk={handleModalOk}
        confirmLoading={
          muteGroupMemberMutation.isLoading ||
          cancelMuteGroupMemberMutation.isLoading ||
          setGroupAdminMutation.isLoading ||
          setGroupOrdinaryUserMutation.isLoading ||
          removeMembersMutation.isLoading ||
          deleteGroupMutation.isLoading
        }
      />
      <MuteModal
        open={muteModal.open}
        onCancel={() => setMuteModal({ open: false, memberID: "" })}
        onSubmit={handleMuteSubmit}
        confirmLoading={muteGroupMemberMutation.isLoading}
      />
      <UserSelectModal.WithGetUsers
        open={addMembersModalOpen}
        onCancel={() => setAddMembersModalOpen(false)}
        disabledUserIDList={allGroupMembers.data?.data.group_members.map((item) => item.member_id)}
        onSubmit={handleAddGroupMemberSelection}
        selectionLoading={allGroupMembers.isLoading}
        confirmLoading={addMembersMutation.isLoading}
      />
      <TransferOwnerModal
        groupID={groupID!}
        ownerID={groupQuery.data.data.group_master_id}
        open={transferOwnerModalOpen}
        onCancel={() => setTransferOwnerModalOpen(false)}
        onSubmit={handleTransferGroupOwnerSubmit}
        confirmLoading={setGroupOwnerMutation.isLoading}
      />
    </>
  );
};

export default GroupDetailsManagementView;
