import UserPickModal from "~/components/overlay/UserPickModal";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { GetGroupMembersRequestParams } from "~/api/types";
import { useQuery } from "@tanstack/react-query";
import { actions } from "~/api/constants";
import useRequest from "~/hooks/useRequest";

const initialParams: GetGroupMembersRequestParams = {
  page_number: 1,
  show_number: 10,
  group_id: "",
  status: JSON.stringify([]),
  permission: JSON.stringify([]),
  role_level: JSON.stringify([]),
};

type TransferOwnerModalProps = { groupID: string; ownerID: string; onSubmit: (ownerID: string) => void } & Omit<
  React.ComponentProps<typeof UserPickModal>,
  "userList" | "userListLoading" | "selectedUserID" | "onSelectedUserIDChange" | "pagination" | "onPaginationChange" | "search" | "onSearchChange"
>;

const TransferOwnerModal: React.FC<TransferOwnerModalProps> = ({ groupID, ownerID, onSubmit, ...props }) => {
  const [selectedMemberID, setSelectedMemberID] = useState<string>(ownerID);
  const [searchValue, setSearchValue] = useState<string>("");
  const request = useRequest();
  const [params, setParams] = useState<GetGroupMembersRequestParams>(initialParams);
  const { data, isPreviousData } = useQuery({
    queryKey: [actions.GET_GROUP_MEMBERS, { ...params, group_id: groupID }],
    queryFn: () => request(actions.GET_GROUP_MEMBERS, { ...params, group_id: groupID }),
    keepPreviousData: true,
    enabled: props.open,
  });

  const userList = useMemo(
    () =>
      data?.data.group_members?.map(({ member_id, member_nick_name }) => ({
        userID: member_id,
        nickname: member_nick_name,
      })) ?? [],
    [data]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  useEffect(() => {
    setSelectedMemberID(ownerID);
  }, [setSelectedMemberID, ownerID]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      setParams((state) => ({
        ...state,
        member: searchValue,
        page_number: 1,
      }));
    }, 300);
    return () => clearTimeout(timeout);
  }, [searchValue, setParams]);

  const resetModal = useCallback(() => {
    setSearchValue("");
    setParams(initialParams);
    setSelectedMemberID(ownerID);
  }, [ownerID, setSearchValue, setParams, setSelectedMemberID]);

  return (
    <UserPickModal
      userList={userList || []}
      userListLoading={isPreviousData}
      selectedUserID={selectedMemberID}
      onSelectedUserIDChange={setSelectedMemberID}
      pagination={{ pageNumber: data?.data.current_number || 0, totalNumber: data?.data.member_nums || 0 }}
      onPaginationChange={handlePaginationChange}
      search={searchValue}
      onSearchChange={setSearchValue}
      afterClose={resetModal}
      onOk={() => onSubmit(selectedMemberID)}
      {...props}
    />
  );
};

export default TransferOwnerModal;
