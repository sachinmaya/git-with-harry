import { ApiRequest, GetUsersThirdInfoRequestParams, ThirdUserItem } from "~/api/types";
import { actions } from "~/api/constants";
import { QueryClient, useQuery } from "@tanstack/react-query";
import { InternalServerError, NetworkError } from "~/api/errors";
import { Button, Form, Input, message, Select, Table } from "antd";
import useRequest from "~/hooks/useRequest";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { useDashboardView } from "~/views/DashboardView";
import { ColumnsType } from "antd/es/table";
import Icon from "@ant-design/icons";
import SearchIcon from "~/components/icons/SearchIcon";
import usePermissions from "~/hooks/usePermissions";
import { useLocation } from "react-router-dom";

const initialParams: GetUsersThirdInfoRequestParams = {
  user_id: "",
  page_number: 1,
  show_number: 10,
};

const getLinkedAccountsQuery = (request: ApiRequest, params: GetUsersThirdInfoRequestParams = initialParams) => ({
  queryKey: [actions.GET_USERS_THIRD_INFO, params],
  queryFn: async () => request(actions.GET_USERS_THIRD_INFO, params),
});

export const linkedAccountsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getLinkedAccountsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  keyword: string;
  type: number;
  thirdId: string;
}

const LinkedAccountView = () => {
  const { t } = useTranslation("linked-accounts-view");
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const location = useLocation();
  const [params, setParams] = useState<GetUsersThirdInfoRequestParams>(() => ({ ...initialParams, user_id: location.state?.keyword || "" }));
  const [searchLoading, setSearchLoading] = useState<boolean>(false);

  const { isActionAllowed } = usePermissions();

  const initialValues: FormValues = useMemo(() => ({
    keyword: location.state?.keyword || "",
    type: 0,
    thirdId: "",
  }), [location.state]);

  const { data, isPreviousData } = useQuery({
    ...getLinkedAccountsQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.linked-accounts-query-failed"),
      });
    },
  });

  useEffect(() => {
    setDashboardHeading("users", "linked-accounts");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ keyword, type, thirdId }: FormValues) => {
      setParams(({ show_number }) => {
        const state: GetUsersThirdInfoRequestParams = { page_number: 1, show_number };
        if (keyword !== "") {
          state.user_id = keyword;
        }
        if (type !== 0) {
          state.third_type = type;
        }
        if (thirdId !== "") {
          state.third_name = thirdId;
        }
        return state;
      });
      setSearchLoading(true);
    },
    [setParams]
  );

  const columns: ColumnsType<ThirdUserItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
          render: (value, record, index) => ((data?.data.current_number || 0) - 1) * (data?.data.show_number || 0) + (index + 1),
      },
      {
        key: "nickname",
        dataIndex: "nick_name",
        width: 160,
        title: t("columns.nickname"),
      },
      {
        key: "phone",
        width: 180,
        dataIndex: "phone_number",
        title: t("columns.phone"),
        render: (value) => value || "-",
      },
      {
        key: "account",
        width: 160,
        dataIndex: "user_id",
        title: t("columns.account"),
      },
      {
        key: "email",
        width: 200,
        dataIndex: "email",
        title: t("columns.email"),
        render: (value) => value || "-",
      },
      {
        key: "official",
        width: 140,
        dataIndex: "official_name",
        title: t("columns.official"),
        render: (value) => value || "-",
      },
      {
        key: "wallet",
        width: 140,
        dataIndex: "wallet",
        title: t("columns.wallet"),
        render: (value) => value || "-",
      },
      {
        key: "facebook",
        width: 140,
        dataIndex: "facebook",
        title: t("columns.facebook"),
        render: (value) => value || "-",
      },
      {
        key: "google",
        width: 140,
        dataIndex: "google",
        title: t("columns.google"),
        render: (value) => value || "-",
      },
      {
        key: "apple",
        width: 140,
        dataIndex: "apple",
        title: t("columns.apple"),
        render: (value) => value || "-",
      },
    ],
    [t, data]
  );

  if (!isActionAllowed(actions.GET_USERS_THIRD_INFO)) {
    return null;
  }

  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish}>
        <Form.Item name="keyword">
          <Input placeholder={t("form.keyword.placeholder")} style={{ width: 188 }} />
        </Form.Item>
        <Form.Item name="type">
          <Select
            style={{ width: 160 }}
            options={([["all", 0], ["official", 5], ["wallet", 4], ["facebook", 1], ["google", 2], ["apple", 3]] as const).map(([key, value]) => ({
              value,
              label: t(`form.type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="thirdId">
          <Input placeholder={t("form.third_id.placeholder")} style={{ width: 250 }} />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
      </Form>
      <Table
        rowKey="user_id"
        className="customTable"
        dataSource={data?.data.users}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.user_nums,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
    </>
  );
};

export default LinkedAccountView;
