import React from "react";
import { Modal, ModalProps } from "antd";

interface MeidaModalProps extends ModalProps {
  mediaURL: string;
}

const MediaModal: React.FC<MeidaModalProps> = ({ mediaURL, ...props }) => {
  return (
    <Modal className="video-container" destroyOnClose closable={false} {...props}>
      <video src={mediaURL} autoPlay controls></video>
    </Modal>
  );
};

export default MediaModal;
