import { Button, Form, Input, Modal, ModalProps, Select, Switch } from "antd";
import { t } from "i18next";
import React, { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import dayjs, { Dayjs } from "dayjs";
import { EditFavoritesRequestParams, EditFavoritesResponse, GetFavoritesItem } from "~/api/types";
import classes from "./styles.module.scss";
interface EditFavoritesModalProps extends ModalProps {
  favourite?: GetFavoritesItem;
  onFormSubmit: (values: EditFavoritesRequestParams, favoriteID:string) => void;
  getContent: (content:string,type:number | undefined,viewFrom:string,keyworkd:string) => void;
  favoriteID: string;
}

export interface EditFavouritesFormValues { 
  user_id: string;
  content_type: number | undefined;
  content: any;
  create_time: any;
  publish_time: any;
  remark: string;
  favorite_id: string
}

const initialFormValues: EditFavouritesFormValues = {
  user_id: "",
  content_type: undefined,
  content: "",
  create_time: undefined,
  publish_time: undefined,
  remark: "",
  favorite_id:""
};

const initialParams: EditFavoritesRequestParams = {
    operation_id:"",
    favorite_id: "",
    remark: ""
};
const date = new Date();
const new_date = date.toLocaleString();
const time = Date.parse(new_date);
const EditFavouritesModal: React.FC<EditFavoritesModalProps> = ({  favourite, getContent, onFormSubmit, favoriteID, ...props }) => {
  const { t } = useTranslation("favourites-view");
  const [form] = Form.useForm();
  const [editFavoritesParams, setEditFavoritesParams] = useState<EditFavoritesRequestParams>(initialParams);
  const [contentValue,setContentValue] = useState<any>("");
  
  useEffect(() => {
    if(favourite) {
        const contents = getContent(favourite.content,favourite.content_type,"form",'')
        setContentValue(contents);
        const newFormValue:EditFavouritesFormValues = {
            user_id: favourite.user_id,
            content_type: favourite.content_type,
            content: contents,
            create_time: dayjs(favourite.create_time * 1000).format("YYYY/MM/DD HH:mm:ss"),
            publish_time: dayjs(favourite.publish_time * 1000).format("YYYY/MM/DD HH:mm:ss"),
            remark: favourite.remark,
            favorite_id:favourite.favorite_id
        }
        form.setFieldsValue(newFormValue);
    }
  }, [favourite]);

  const handleFormSubmit = useCallback(
    ({ user_id, content_type, content, create_time, publish_time, remark }: EditFavouritesFormValues) => {    
     
      setEditFavoritesParams(() => {
        const state: EditFavoritesRequestParams = initialParams;
        state.operation_id = JSON.stringify(time);
        state.remark = remark;
        return state;
      });
      form.resetFields();
      onFormSubmit(editFavoritesParams, favoriteID);
    },
    [setEditFavoritesParams, favoriteID]
  );

  return (
    <Modal title={t("modals.edit-favourites.modal-title")} okText={t("modals.buttons.edit")} cancelText={t(`modals.buttons.cancel`)} onOk={form.submit} {...props} width={600}>
      <Form initialValues={favourite} form={form} onFinish={handleFormSubmit}>
        <Form.Item name="user_id" label={t("modals.added-by.label")}>
          <Input disabled={true}/>
        </Form.Item>
        <Form.Item name="content_type" label={t("modals.content-type.label")}>
          {/* <Input /> */}
          <Select
            mode="multiple"
            placeholder={t("form.type.placeholder")}
            options={([1, 2, 3, 4, 5, 6] as const).map((value) => ({
              value,
              disabled:true,
              label: t(`form.type.options.${value}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="content" label={t("modals.content.label")}>
          <div className={classes.cusotmFields}>{contentValue}</div>          
        </Form.Item>
        <Form.Item name="create_time" label={t("modals.create-time.label")}>
         <Input  disabled={true}/>
        </Form.Item>
        <Form.Item name="publish_time" label={t("modals.publish-time.label")}>
          <Input disabled={true}/>
        </Form.Item>
        <Form.Item name="remark" label={t("modals.remark.label")}>
          <Input.TextArea showCount maxLength={200} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default EditFavouritesModal;