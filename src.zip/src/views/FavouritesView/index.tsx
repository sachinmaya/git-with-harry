import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, GetFavoritesItem, GetFavoritesRequestParams, EditFavoritesRequestParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, Select, Table,message } from "antd";
import Icon, { PlaySquareOutlined} from "@ant-design/icons";
import Text from "antd/lib/typography/Text";
import { ColumnsType } from "antd/es/table";
import { Link } from "react-router-dom";
import dayjs, { Dayjs } from "dayjs";
import classes from "./styles.module.scss";

import { FieldData } from "rc-field-form/lib/interface";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import { TableRowSelection } from "antd/es/table/interface";
import { InternalServerError, NetworkError } from "~/api/errors";
import PdfFile from '~/views/FavouritesView/icons/PdfFile';
import WorldFile from '~/views/FavouritesView/icons/WorldFile';
import ArchiveFile from '~/views/FavouritesView/icons/ArchiveFile';
import ExcelFile from '~/views/FavouritesView/icons/ExcelFile';
import ImageFile from '~/views/FavouritesView/icons/ImageFile';
import PowerpointFile from '~/views/FavouritesView/icons/PowerpointFile';
import TextFile from '~/views/FavouritesView/icons/TextFile';
import UnknownFile from '~/views/FavouritesView/icons/UnknownFile';
import ConfirmModal from '~/views/FavouritesView/ConfirmModal';
import MediaModal from "~/views/FavouritesView/MediaModal";
import EditFavouritesModal, { EditFavouritesFormValues } from "./EditFavouritesModal";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";
const initialParams: GetFavoritesRequestParams = {
  page_number: 1,
  show_number: 10,
  content_type: '[1,2,3,4,5,6]',
  order_by: "create_time:desc",
};

const getUsersQuery = (request: ApiRequest, params: GetFavoritesRequestParams = initialParams) => ({
  queryKey: [actions.GET_FAVORITES, params],
  queryFn: async () => request(actions.GET_FAVORITES, params),
});

export const favouritesViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getUsersQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};


interface FormValues {
  account: string;
  content: string;
  content_type: number[];
  time_type: number;
  filterRange: null | Dayjs[];
  publish_user: string;
}

const initialValues: FormValues = {
  account: "",
  content: "",
  content_type: [1,2,3,4,5,6],
  time_type: 0,
  filterRange: null,
  publish_user: "",
};
type ModalKey = "multiple-delete" | "delete-favourites" ;
type ModalEditKey = "edit-favourites" ;
const FavouritesView: React.FC = () => {
  const { t } = useTranslation("favourites-view");
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const [sourceValue, setSourceValue] = useState<number>(0);
  const [params, setParams] = useState<GetFavoritesRequestParams>(initialParams);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<GetFavoritesItem> | undefined>(undefined);
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; favoriteID: string }>({
    open: false,
    key: "multiple-delete",
    favoriteID: "",
  });
  const [openEditModal, setOpenEditModal] = useState<{ open: boolean; key: ModalEditKey; favourite?: GetFavoritesItem,favoriteID:string }>({
    open: false,
    key: "edit-favourites",
    favoriteID:""
  });
  const [openMediaModal, setOpenMediaModal] = useState<{ open: boolean; mediaURL: string }>({ open: false, mediaURL: "" });
  const queryClient = useQueryClient();
  const { data, refetch, isRefetching,isPreviousData } = useQuery({
    ...getUsersQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.favourites-list-query-failed"),
      });
    },

  });
  
  const deleteFavouritesMutation = useMutation((favorite_ids: string[]) => request(actions.DELETE_FAVORITES, { favorite_ids }), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_FAVORITES]);
      message.open({
        key: "user-delete-successfully",
        type: "success",
        content: t("toasts.favourites-delete-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-favourites-failed",
        type: "error",
        content: t("toasts.delete-favourites-failed"),
      });
    },
  });

  useEffect(() => {
    setDashboardHeading("me", "favourites");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);
  const getContentTypeValue = (cntType:number):string => {
    switch(cntType){
      case 1:
        return t('form.type.options.1');
        break;
      case 2:
        return t('form.type.options.2');
        break;
      case 3:
        return t('form.type.options.3');
        break;
      case 4:
        return t('form.type.options.4');
        break;
      case 5:
        return t('form.type.options.5');
        break;
      case 6:
        return t('form.type.options.6');
        break;
      default:
        return '-';
    }
  }
  const openVideos = (videoUrl:string):string =>{
    return '';
  }
  const renderMedia = (content:string,viewFrom:string) => {
   
    const mediaObject = content ? JSON.parse(content):'';
    const thumbImage = mediaObject.thumbnail;
    const url = mediaObject.url;
    if(thumbImage === ""){
      return <div className="imgWrapper"><Image
              width={viewFrom==='table' ? 50:150}
              // height={viewFrom==='table' ? 50:150}
              src={url}
            /></div>;
    }else{
          return <div className="video-cover"><Image
          width={viewFrom==='table' ? 50:150}
          // height={viewFrom==='table' ? 50:150}
          preview={false}
          src={thumbImage}
          onClick={()=>openVideos(url)}
        /><span className="video-play-icon" onClick={() => setOpenMediaModal({ open: true, mediaURL: url })}>
          <PlaySquareOutlined />
          </span></div>
    }
    
    // return content;
  }
  const getLinkContent = (content:string,keywords:string,viewFrom:string) => {
    
    try {
      const linkObj = JSON.parse(content); 
      return viewFrom === 'table' ? <Text
      ellipsis={{ tooltip: linkObj.title }}
      style={{ width: 200 }}
      >
        <a href={linkObj.url} target={"_blank"}> {linkObj.title}</a>
      </Text>: <a href={linkObj.url} target={"_blank"}> {linkObj.title}</a> 
    } catch (e) {
       // return false;
    }
    if(keywords === ""){
      return viewFrom === 'table' ? <Text
      style={{ width: 200 }}
      ellipsis={{ tooltip: content }}
      >
        <a href={content} target={"_blank"}> {content}</a>
      </Text>: <a href={content} target={"_blank"}> {content}</a>
    }else{
      return viewFrom === 'table' ? <Text
      style={{ width: 200 }}
      ellipsis={{ tooltip: keywords }}
      >
       <a href={content} target={"_blank"}> {keywords}</a>
      </Text>: <a href={content} target={"_blank"}> {keywords}</a>;
    }
  }

  const getChatMessage = (content:any) =>{
    try{
      const messageObject = content=== 0 ? '': JSON.parse(content);
      return 'Marge Message will Here';
    }catch(error){
      return content;
    }
  }
  const getIconByType = (fileExt:string) => {
    if(fileExt === "pdf" || fileExt === "PDF"){
      return <PdfFile className={classes.svgStyle}/>
    }else if(fileExt === "docx" || fileExt === "doc" || fileExt === "DOCX" || fileExt === "DOC"){
      return <WorldFile  className={classes.svgStyle}/>
    }else if(fileExt === "jar" || fileExt === "rar" || fileExt === "zip" || fileExt === "JAR" || fileExt === "RAR" || fileExt === "ZIP"){
      return <ArchiveFile  className={classes.svgStyle} />
    }else if(fileExt === "ppt" || fileExt === "pptx" || fileExt === "PPT" || fileExt === "PPTX"){
      return <PowerpointFile  className={classes.svgStyle} />
    }else if(fileExt === "txt" || fileExt === "TXT"){
      return <TextFile  className={classes.svgStyle} />
    }else if(fileExt === "xls" || fileExt === "xlsx" || fileExt === "XLS" || fileExt === "XLSX"){
      return <ExcelFile  className={classes.svgStyle}/>
    }else if(fileExt === "jpg" || fileExt === "jpeg" || fileExt === "png" || fileExt === "JPG" || fileExt === "JPEG" || fileExt === "PNG"){
      return <ImageFile  className={classes.svgStyle} />
    }else {
      return <UnknownFile  className={classes.svgStyle} />
    }
  }

  const renderFile = (content:any,from:string) =>{
    try {
      const mediaObject = content=== 0 ? '': JSON.parse(content);
      const thumbImage = mediaObject.thumbnail;
      const url = mediaObject.fileName;
      const urlArry = url.split(".");
      const getFileExtn = urlArry[urlArry.length-1]
      const fileIcon = getIconByType(getFileExtn);
      return <div className="filecontent"><Text
      style={{ width: 200 }}
      ellipsis={{ tooltip: url }}
      ><a href={url} target="_blank">{fileIcon}
      {url}</a></Text></div>;
    } catch (error) {
      return "-";
    }
   
  }
  const getContent = (content:string,type:any,viewFrom='table',keyworkd:string='') => {
    switch(type){
      case 1:
        return renderFile(content,viewFrom);
        break;
      case 2:
        return getLinkContent(content,keyworkd,viewFrom);
        break;
      case 3:
        const content2 = renderMedia(content,viewFrom);
        return content2;
        break;
      case 4:
        return '';
        break;
      case 5:
        return getChatMessage(content);
        break;
      case 6:
        return '';
        break;
      default:
        return '-';
    }
  }

  const columns: ColumnsType<GetFavoritesItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "user_name",
        dataIndex: "user_name",
        width: 160,
        title: t("columns.added-by"),
        render: (value) => value || "-",
      },
      {
        key: "content_type",
        width: 160,
        dataIndex: "content_type",
        title: t("columns.type"),
        render: (value) => {
          return getContentTypeValue(value);
        },
      },
      {
        key: "content",
        width: 160,
        dataIndex: "content",
        title: t("columns.favourites"),
        render: (_,record) => {
          return  getContent(record.content,record.content_type,'table');
        },
      },
      {
        key: "create_time",
        width: 160,
        dataIndex: "create_time",
        title: t("columns.adding-time"),
        render: (value) => value === 0 ? "-" : dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "content_creator_name",
        width: 160,
        dataIndex: "content_creator_name",
        title: t("columns.posted-by"),
        render: (text) => {
          const creatorInfo = JSON.parse(text);
          return (creatorInfo.ContentCreatorName)
        },
      },
      {
        key: "publish_time",
        width: 160,
        dataIndex: "publish_time",
        title: t("columns.post-time"),
        render: (value) => value === 0 ? "-" : dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "remark",
        width: 160,
        dataIndex: "remark",
        title: t("columns.remark"),
        render: (value) => value || "-",
      },
      {
        key: "edited-by",
        width: 160,
        dataIndex: "edited-by",
        title: t("columns.edited-by"),
        render: (value) => value || "-",
      },
      {
        key: "update_time",
        width: 160,
        dataIndex: "update_time",
        title: t("columns.editing-time"),
        render: (value) => value === 0 ? "-" : dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "options",
        width: 160,
        title: t("columns.options"),
        fixed: "right",
        render: (value, record) => (
          <>
            <button type="button" className="optionBtn" onClick={() => setOpenEditModal({ open: true, key: "edit-favourites", favourite: record, favoriteID: record.favorite_id  })}>
              {t("options.edit")}
            </button>
            <button type="button" className="optionBtn optionBtnDanger" onClick={() => setOpenModal({ open: true, key: "delete-favourites", favoriteID: record.favorite_id })}>
              {t("options.delete")}
            </button>
          </>
        )
      },
    ],
    [t]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ filterRange, account, content, content_type, time_type, publish_user }: FormValues) => {
      setParams(({ show_number, order_by }) => {
        const state: GetFavoritesRequestParams = { page_number: 1, show_number, order_by };
        const trimAccount = account.trim();
        if (trimAccount !== "") {
          state.account = trimAccount;
        }
        const trimContent = content.trim();
        if (trimContent !== "") {
          state.content = trimContent;
        }
        if (content_type.length !== 0) {
          state.content_type = JSON.stringify(content_type);
        }else{
          state.content_type = JSON.stringify([]);
        }
        if (time_type !== 0) {
          state.time_type = time_type;
        }
        const trimPublishUser = publish_user.trim();
        if (trimPublishUser !== "") {
          state.publish_user = trimPublishUser;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = startTime;
          state.end_time = endTime;
        }
        return state;
      });
      refetch();
    },
    [setParams, refetch]
  );

  const handleFieldsChange = useCallback(([fieldData]: FieldData[]) => {
    const { name, value } = fieldData;
    if (Array.isArray(name) && name[0] === "source") {
      setSourceValue(value);
    }
  }, [setSourceValue]);
  
  const handleMultipleDeleteClick = useCallback(
    () =>
      setDeleteSelection({
        columnWidth: 50,
        selectedRowKeys: [],
        onChange: (selectedRowKeys) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );
  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);
  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    let status: 1 | 2, status_type: 1 | 2 | 3;
    switch (openModal.key) {
      case "multiple-delete":
        if (deleteSelection !== undefined) {
          deleteFavouritesMutation.mutate(deleteSelection.selectedRowKeys as string[]);
        }
        return;
      case "delete-favourites":
        deleteFavouritesMutation.mutate([openModal.favoriteID]);            
        break;
    }
  }, [deleteFavouritesMutation.mutate, deleteSelection, openModal]);
  
  const editFavouritesMutation = useMutation(
    (editFavourite: EditFavoritesRequestParams) => (request(actions.EDIT_FAVORITES, editFavourite)),
    {
      onSuccess: () => {
        setOpenEditModal((state) => ({ ...state, open: false }));
        queryClient.invalidateQueries([actions.GET_FAVORITES, params]);
        message.open({
          key: "favourites-edited-success",
          type: "success",
          content: t("toasts.favourites-edited-success"),
        });
      },
      onError: (error) => {
        if (error instanceof NetworkError) {
          return message.open({
            key: "network-error",
            type: "error",
            content: t("errors.network-error.message"),
          });
        }
        if (error instanceof InternalServerError) {
          return message.open({
            key: "internal-server-error",
            type: "error",
            content: t("errors.internal-server-error.message"),
          });
        }
      },
    }
  );


  const handleEditModalOk = useCallback(
    (values: EditFavoritesRequestParams,favoriteID:string) => {     
      const newMutateData = {...values,favorite_id:favoriteID}
      editFavouritesMutation.mutate(newMutateData);
    },
    [editFavouritesMutation.mutate, openModal]
  );

  const handleEditModalCancel = useCallback(() => setOpenEditModal((state) => ({ ...state, open: false })), [setOpenEditModal]);
  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="account" label={t("form.added-by.label")}>
          <Input placeholder={t("form.added-by.placeholder")} style={{ width: 270 }}/>
        </Form.Item>

        <Form.Item name="content" label={t("form.favourites.label")}>
          <Input placeholder={t("form.favourites.placeholder")} style={{ width: 250 }}/>
        </Form.Item>

        
        <Form.Item name="content_type" label={t("form.type.label")}>
          <Select
            mode="multiple"
            placeholder={t("form.type.placeholder")}
            style={{ minWidth: 120 }}
            options={([1, 2, 3, 4, 5, 6] as const).map((value) => ({
              value,
              label: t(`form.type.options.${value}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="time_type">
          <Select
            style={{ minWidth: 120 }}
            options={(["all", "create-time", "last-login-time"] as const).map((key, value) => ({
              value,
              label: t(`form.filter-time.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="filterRange">
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item name="publish_user" label={t("form.posted-by.label")}>
          <Input placeholder={t("form.posted-by.placeholder")} style={{ width: 270 }} />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={isRefetching} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        
        {deleteSelection !== undefined && (
          <>
            <Form.Item>
              <Button className="filterBtn filterBtnPlain" htmlType="button" onClick={handleMultipleDeleteCancelClick}>
                {t("form.buttons.cancel")}
              </Button>
            </Form.Item>
            <Form.Item>
              <Button
                className="filterBtn filterBtnDanger"
                type="primary"
                htmlType="button"
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", favoriteID: "" })}
                disabled={deleteSelection.selectedRowKeys === undefined || deleteSelection.selectedRowKeys.length === 0}
              >
                {t("form.buttons.delete")}
              </Button>
            </Form.Item>
          </>
        )}
        {deleteSelection === undefined && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" htmlType="button" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleDeleteClick}>
              {t("form.buttons.multiple-delete")}
            </Button>
          </Form.Item>
        )}

        
      </Form>
      <Table
        rowKey="favorite_id"
        dataSource={data?.data.favorites}
        className="customTable"
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        rowSelection={deleteSelection}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.favorite_nums,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />

      <ConfirmModal
        open={openModal.open}
        type={openModal.key}
        onCancel={handleModalCancel}
        onOk={handleModalOk}
        confirmLoading={deleteFavouritesMutation.isLoading}
      />
      <EditFavouritesModal  
        favourite={openEditModal.favourite} 
        getContent={getContent} 
        onFormSubmit={handleEditModalOk} 
        open={openEditModal.open} 
        onCancel={handleEditModalCancel} 
        favoriteID={openEditModal.favoriteID}
        />
      <MediaModal open={openMediaModal.open} onCancel={() => setOpenMediaModal((state) => ({ ...state, open: false }))} mediaURL={openMediaModal.mediaURL} />
    </>
  );
};

export default FavouritesView;
