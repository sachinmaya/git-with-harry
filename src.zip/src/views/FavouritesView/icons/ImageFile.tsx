import React from "react";

const WorldFile: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 50 50" {...props}>
    <g transform="translate(-145.983 -63.591)">
        <g transform="translate(-3.017 -0.409)">
            <path d="M155.4,64h26.144l12.444,12.584V112.6a1.4,1.4,0,0,1-1.4,1.4H155.4a1.4,1.4,0,0,1-1.4-1.4V65.4A1.4,1.4,0,0,1,155.4,64Z"
                  fill="#fcc852"/>
            <path d="M647.5,64V74.472a1.306,1.306,0,0,0,1.306,1.306h10.341Z" transform="translate(-465.164)"
                  fill="#e5a513"/>
            <path d="M8.254,140.865a.946.946,0,0,0-1.658,0L.222,149.955c-.459.653-.185,1.183.609,1.183H30.024c.8,0,1.062-.528.6-1.18l-10.1-14.236a.96.96,0,0,0-1.675,0L11.709,145.8l-3.457-4.931Zm-4.047-9.972a2.849,2.849,0,0,0,2.8,2.892,2.894,2.894,0,0,0,0-5.784,2.849,2.849,0,0,0-2.8,2.892Z"
                  transform="translate(158.567 -46.658)" fill="#fff"/>
        </g>
    </g>
</svg>
);

export default WorldFile;
