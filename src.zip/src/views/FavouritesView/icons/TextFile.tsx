import React from "react";

const WorldFile: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 50 50" {...props}>
    <g transform="translate(-143.992 -63.591)">
        <g transform="translate(-5.008 -0.409)">
            <path d="M155.4,64h26.144l12.444,12.584V112.6a1.4,1.4,0,0,1-1.4,1.4H155.4a1.4,1.4,0,0,1-1.4-1.4V65.4A1.4,1.4,0,0,1,155.4,64Z"
                  fill="#53bcfd"/>
            <path d="M647.5,64V74.472a1.306,1.306,0,0,0,1.306,1.306h10.341Z" transform="translate(-465.164)"
                  fill="#209fed"/>
            <path d="M263.919,513.673h-2.978v8.351h-2v-8.351H256V512h7.919Zm4.621,1.783L270.363,512h2.3l-2.831,4.971,2.9,5.053h-2.331l-1.869-3.511-1.87,3.511H264.34l2.905-5.053L264.414,512h2.3Zm12.526-1.783h-2.978v8.351h-2v-8.351h-2.938V512h7.92Z"
                  transform="translate(-95.301 -415.343)" fill="#fff" opacity="0.9"/>
        </g>
    </g>
</svg>
);

export default WorldFile;
