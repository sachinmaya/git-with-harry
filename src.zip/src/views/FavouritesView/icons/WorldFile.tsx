import React from "react";

const WorldFile: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 50 50" {...props}>
  <g transform="translate(-143.992 -63.591)">
    <g transform="translate(-5.008 -0.409)">
      <path d="M155.4,64h26.144l12.444,12.584V112.6a1.4,1.4,0,0,1-1.4,1.4H155.4a1.4,1.4,0,0,1-1.4-1.4V65.4A1.4,1.4,0,0,1,155.4,64Z" fill="#4a8dff"/>
      <path d="M647.5,64V74.494a1.308,1.308,0,0,0,1.308,1.308h10.363Z" transform="translate(-465.188)" fill="#e5f0ff"/>
      <path d="M307.576,409.7a2.051,2.051,0,0,0,3.506-1.235V389h-4.034v14.747l-8.018-7.977a2.157,2.157,0,0,0-2.979,0l-8.018,7.977V389H284v19.47a2.051,2.051,0,0,0,3.506,1.235l10.035-9.983Z" transform="translate(-123.196 -305.926)" fill="#fff"/>
    </g>
  </g>
</svg>
);

export default WorldFile;
