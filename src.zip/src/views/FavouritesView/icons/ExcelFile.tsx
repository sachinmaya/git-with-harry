import React from "react";

const WorldFile: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 50 50" {...props}>
  <g transform="translate(-143.992 -63.59)">
    <g transform="translate(-5.008 -0.41)">
      <path d="M155.4,64h26.144l12.444,12.584V112.6a1.4,1.4,0,0,1-1.4,1.4H155.4a1.4,1.4,0,0,1-1.4-1.4V65.4A1.4,1.4,0,0,1,155.4,64Z" fill="#00c090"/>
      <path d="M647.5,64V74.472a1.306,1.306,0,0,0,1.306,1.306h10.341Z" transform="translate(-465.164)" fill="#68dbbf"/>
      <path d="M309.591,378.538l-22,19.888a1.7,1.7,0,0,0,0,2.585,2.187,2.187,0,0,0,2.867,0l22-19.888a1.7,1.7,0,0,0,0-2.585,2.187,2.187,0,0,0-2.867,0Z" transform="translate(-126.054 -294.398)" fill="#fff"/>
      <path d="M287.592,380.119l22,19.888a2.187,2.187,0,0,0,2.867,0,1.7,1.7,0,0,0,0-2.585l-22-19.888a2.187,2.187,0,0,0-2.867,0A1.7,1.7,0,0,0,287.592,380.119Z" transform="translate(-126.054 -293.449)" fill="#fff"/>
    </g>
  </g>
</svg>
);

export default WorldFile;
