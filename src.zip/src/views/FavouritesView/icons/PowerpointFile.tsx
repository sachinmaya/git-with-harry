import React from "react";

const WorldFile: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 50 50" {...props}>
    <g transform="translate(-145.992 -63.591)">
        <g transform="translate(-3 -0.409)">
            <path d="M155.4,64h26.144l12.444,12.584V112.6a1.4,1.4,0,0,1-1.4,1.4H155.4a1.4,1.4,0,0,1-1.4-1.4V65.4A1.4,1.4,0,0,1,155.4,64Z"
                  fill="#ff7861"/>
            <path d="M647.5,64V74.472a1.306,1.306,0,0,0,1.306,1.306h10.341Z" transform="translate(-465.164)"
                  fill="#ffb0a4"/>
            <path d="M305.332,394.6a2.976,2.976,0,0,1,0,3.8,4.613,4.613,0,0,1-2.492.945h-17.82A1.931,1.931,0,0,0,283,401.177v8.2a2.029,2.029,0,0,0,4.038,0V403H302.99a2.232,2.232,0,0,0,.286-.018c4.313-.558,6.782-2.844,6.782-6.484s-2.468-5.926-6.781-6.484a2.232,2.232,0,0,0-.286-.018h-17.97a1.837,1.837,0,1,0,0,3.656h17.82A4.613,4.613,0,0,1,305.332,394.6Z"
                  transform="translate(-122.263 -306.842)" fill="#fff"/>
        </g>
    </g>
</svg>
);

export default WorldFile;
