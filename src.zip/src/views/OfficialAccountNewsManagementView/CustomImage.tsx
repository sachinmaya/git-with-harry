import Quill from "quill";
const Image = Quill.import("formats/image");
import { UploadType } from "~/api";
import Api from "~/api";
import { API_BASE_URL } from "~/config/constants";
import imageDimensionsByUrl from "~/utils/imageDimensionsByUrl";

export interface CustomImageCreateParams {
  url: string;
  width: number;
  height: number;
}

interface AuthState {
  token: string;
  username: string;
}

class CustomImage extends Image {
  static create(data: string | CustomImageCreateParams) {
    const img = super.create();
    const storage = JSON.parse(localStorage.getItem("auth") || "");
    if (data && typeof data === "string") {
      fetch(data)
        .then((r) => r.blob())
        .then((res) =>
          new Api({ baseURL: API_BASE_URL, token: storage?.token, onTokenInvalidated: storage?.remove })
            .upload({
              file: new File([res], `.png`),
              type: UploadType.picture,
              persist: true,
            })
            .then((res) => {
              imageDimensionsByUrl(res.URL).then(({ width, height }) => {
                img.setAttribute("src", res.URL);
                if (width !== undefined) {
                  img.setAttribute("width", width.toString());
                }
                if (height !== undefined) {
                  img.setAttribute("height", height.toString());
                }
              });
            })
        );
    }
    if (data && typeof data === "object") {
      let { url, width, height } = data;
      img.setAttribute("src", url);
      if (width !== undefined) {
        img.setAttribute("width", width.toString());
      }
      if (height !== undefined) {
        img.setAttribute("height", height.toString());
      }
    }
    return img;
  }

  static value(node: HTMLImageElement) {
    return { url: node.src, width: node.src, height: node.height };
  }
}

export default CustomImage;
