import React from "react";
import { Modal, ModalProps } from "antd";
import { Form, Input, message, Select } from "antd";
import { useForm } from "antd/lib/form/Form";
import { useTranslation } from "react-i18next";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ChangeNewsPrivacyParams } from "~/api/types";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface FormValues {
  newsPrivacy: number;
}

interface ChangePrivacyModalProps extends ModalProps {
  articleID: number;
  privacy: number;
  handleCancel: () => void;
}

const ChangePrivacyModal: React.FC<ChangePrivacyModalProps> = ({ articleID, privacy, handleCancel, ...props }) => {
  const { t } = useTranslation("news-management-view");
  const [privacyForm] = useForm();
  const request = useRequest();
  const queryClient = useQueryClient();
  const initialValues: FormValues = {
    newsPrivacy: privacy,
  };
  const changePrivacyMutation = useMutation((params: ChangeNewsPrivacyParams) => request(actions.CHANGE_NEWS_PRIVACY, params), {
    onSuccess: () => {
      handleCancel();
      queryClient.invalidateQueries([actions.GET_NEWS_LIST]);
      message.open({
        key: "process-successfully",
        type: "success",
        content: t("toasts.news-privacy-changed-success"),
      });
    },
  });

  const handleFinish = ({ newsPrivacy }: FormValues) => {
    changePrivacyMutation.mutate({ article_id: articleID, privacy: newsPrivacy });
  };

  return (
    <Modal
      className="confirmModal"
      okText={t(`modals.change-visibility.buttons.ok`)}
      cancelText={t(`modals.change-visibility.buttons.cancel`)}
      destroyOnClose={true}
      {...props}
      onOk={privacyForm.submit}
      onCancel={handleCancel}
    >
      <Form layout="inline" onFinish={handleFinish} form={privacyForm} initialValues={initialValues}>
        <Form.Item label={t("modals.change-visibility.content")} name="newsPrivacy" preserve={false}>
          <Select
            style={{ width: 120 }}
            options={[
              { value: 1, label: t("form.buttons.public") },
              { value: 2, label: t("form.buttons.private") },
            ]}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default ChangePrivacyModal;
