import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, DeleteNewsParams, GetNewsListParams, NewsItem } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, message, Select, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import Icon from "@ant-design/icons";
import { TableRowSelection } from "antd/es/table/interface";
import Text from "antd/lib/typography/Text";
import dayjs, { Dayjs } from "dayjs";
import { Link } from "react-router-dom";
import { FieldData } from "rc-field-form/lib/interface";
import { InternalServerError, NetworkError } from "~/api/errors";
import usePermissions from "~/hooks/usePermissions";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import ConfirmModal from "./ConfirmModal";
import ChangePrivacyModal from "./ChangePrivacyModal";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";
import EditModal from "./EditModal";

const initialParams: GetNewsListParams = {
  page_number: 1,
  show_number: 10,
  order_by: "start_time:desc",
};

const getNewsListQuery = (request: ApiRequest, params: GetNewsListParams = initialParams) => ({
  queryKey: [actions.GET_NEWS_LIST, params],
  queryFn: async () => request(actions.GET_NEWS_LIST, params),
});

export const officialAccountNewsManagementViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getNewsListQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  officialAccount: string;
  accountType: number;
  ip: string;
  postTopic: string;
  filterType: number;
  filterRange: null | Dayjs[];
}

const initialValues: FormValues = {
  officialAccount: "",
  accountType: 0,
  ip: "",
  postTopic: "",
  filterType: 0,
  filterRange: null,
};

type ModalKey = "multiple-delete" | "delete-news";

const OfficialAccountNewsManagementView: React.FC = () => {
  const { t } = useTranslation("news-management-view");
  const { t: tc } = useTranslation("common");
  const { setDashboardHeading } = useDashboardView();
  const { isActionAllowed, isPageAllowed } = usePermissions();
  const request = useRequest();
  const queryClient = useQueryClient();
  const [params, setParams] = useState<GetNewsListParams>(initialParams);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<NewsItem> | undefined>(undefined);
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; articleID: number }>({
    open: false,
    key: "multiple-delete",
    articleID: 0,
  });
  const [openPrivacyModal, setOpenPrivacyModal] = useState<{ open: boolean; articleID: number; privacy: number }>({
    open: false,
    articleID: 0,
    privacy: 0,
  });
  const [openEditModal, setEditModalOpen] = useState<{ open: boolean; articleID: number; articleTitle: string; articleContent: string }>({
    open: false,
    articleID: 0,
    articleContent: "",
    articleTitle: "",
  });
  const { data, refetch, isPreviousData } = useQuery({
    ...getNewsListQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: tc("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: tc("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "query-failed",
        type: "error",
        content: t("toasts.news-list-query-failed"),
      });
    },
  });

  const deleteNewsMutation = useMutation((params: DeleteNewsParams) => request(actions.DELETE_NEWS, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_NEWS_LIST]);
      message.open({
        key: "delete-successfully",
        type: "success",
        content: t("toasts.delete-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: tc("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: tc("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-failed",
        type: "error",
        content: t("toasts.delete-failed"),
      });
    },
  });
  useEffect(() => {
    setDashboardHeading("official-account", "official-account-news-management");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const columns: ColumnsType<NewsItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "official_account",
        dataIndex: "official_name",
        width: 160,
        title: t("columns.account"),
        render: (value) => value || "-",
      },
      {
        key: "account_type",
        width: 160,
        dataIndex: "official_type",
        title: t("columns.account-type"),
        render: (value) => (
          <>
            {value === 1 && t("form.account-type.options.personal")}
            {value === 2 && t("form.account-type.options.business")}
          </>
        ),
      },

      {
        key: "post",
        width: 160,
        dataIndex: "title",
        title: t("columns.post-topic"),
        render: (value) => (
          <Text
            style={{ width: 180 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "cover_picture",
        width: 160,
        dataIndex: "cover_photo",
        title: t("columns.cover-picture"),
        render: (value) => (value === "" ? "-" : <Image src={value} width={30} height={30} />),
      },
      {
        key: "comments",
        width: 160,
        dataIndex: "comment_counts",
        title: t("columns.comments"),
        render: (value, record) =>
          isPageAllowed("/officialAccount/commentManagement") && value > 0 ? (
            <Link to="/officialAccount/commentManagement" state={{ title: record.title }}>
              {value}
            </Link>
          ) : (
            value
          ),
      },
      {
        key: "likes",
        width: 160,
        dataIndex: "like_counts",
        title: t("columns.likes"),
        render: (value, record) =>
          isPageAllowed("/officialAccount/likeManagemnet") && value > 0 ? (
            <Link to="/officialAccount/likeManagemnet" state={{ title: record.title }}>
              {value}
            </Link>
          ) : (
            value
          ),
      },
      {
        key: "share",
        width: 160,
        dataIndex: "repost_counts",
        title: t("columns.share"),
        render: (value, record) =>
          isPageAllowed("/officialAccount/shareManagement") && value > 0 ? (
            <Link to="/officialAccount/shareManagement" state={{ title: record.title }}>
              {value}
            </Link>
          ) : (
            value
          ),
      },
      {
        key: "post_time",
        width: 160,
        dataIndex: "create_time",
        title: t("columns.post-time"),
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "ip",
        width: 160,
        dataIndex: "last_login_ip",
        title: t("columns.last-login-ip"),
        render: (value) => value,
      },
      {
        key: "operations",
        width: 270,
        title: t("columns.operations"),
        fixed: "right",
        render: (record) => {
          return (
            <>
              {isActionAllowed(actions.ALTER_NEWS) && (
                <Button
                  className="optionBtn"
                  onClick={() => setEditModalOpen({ open: true, articleID: record.article_id, articleTitle: record.title, articleContent: record.content })}
                >
                  {t("form.buttons.edit-post")}
                </Button>
              )}
              {isActionAllowed(actions.CHANGE_NEWS_PRIVACY) && record.privacy === 1 && (
                <Button onClick={() => setOpenPrivacyModal({ open: true, articleID: record.article_id, privacy: record.privacy })} className="optionBtn optionBtnSuccess">
                  {t("form.buttons.public")}
                </Button>
              )}
              {isActionAllowed(actions.CHANGE_NEWS_PRIVACY) && record.privacy === 2 && (
                <Button onClick={() => setOpenPrivacyModal({ open: true, articleID: record.article_id, privacy: record.privacy })}>{t("form.buttons.private")}</Button>
              )}
              {isActionAllowed(actions.DELETE_NEWS) && (
                <Button className="optionBtn optionBtnDanger" onClick={() => setOpenModal({ open: true, articleID: record.article_id, key: "delete-news" })}>
                  {t("form.buttons.delete")}
                </Button>
              )}
            </>
          );
        },
      },
    ],
    [t]
  );
  const handleMultipleDeleteClick = useCallback(
    () =>
      setDeleteSelection({
        columnWidth: 50,
        selectedRowKeys: [],
        onChange: (selectedRowKeys) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          console.log("selected rows", selectedRowKeys);
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );

  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );
  const handleFinnish = useCallback(
    ({ filterRange, officialAccount, ip, postTopic, filterType, accountType }: FormValues) => {
      setParams(({ show_number, order_by }) => {
        const state: GetNewsListParams = { page_number: 1, show_number, order_by };
        if (officialAccount !== "") {
          state.official_account = officialAccount;
        }
        if (ip !== "") {
          state.ip = ip.trim();
        }
        if (postTopic !== "") {
          state.title = postTopic.trim();
        }
        if (accountType !== 0) {
          state.account_type = accountType;
        }
        if (filterType !== 0) {
          state.time_type = filterType;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = startTime;
          state.end_time = endTime;
        }

        return state;
      });
      setSearchLoading(true);
    },
    [setParams, refetch]
  );

  const handleFieldsChange = useCallback(([fieldData]: FieldData[]) => {
    const { name, value } = fieldData;
  }, []);
  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    switch (openModal.key) {
      case "delete-news":
        deleteNewsMutation.mutate({ articles: [openModal.articleID] });
        return;
      case "multiple-delete":
        if (openModal.key === "multiple-delete" && deleteSelection !== undefined && deleteSelection.selectedRowKeys !== undefined) {
          deleteNewsMutation.mutate({
            articles: deleteSelection.selectedRowKeys as number[],
          });
        }
        return;
    }
  }, [deleteNewsMutation.mutate, openModal]);
  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="officialAccount" label={t("form.official-account")}>
          <Input style={{ width: 158 }} />
        </Form.Item>
        <Form.Item name="accountType" label={t("form.account-type.label")}>
          <Select
            style={{ width: 158 }}
            options={(["all", "personal", "business"] as const).map((key, value) => ({
              value,
              label: t(`form.account-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="ip" label={t("form.ip")}>
          <Input style={{ width: 200 }} />
        </Form.Item>

        <Form.Item name="filterType">
          <Select
            style={{ width: 158 }}
            options={(["all", "post-time"] as const).map((key, value) => ({
              value,
              label: t(`form.filter-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="filterRange">
          <DatePicker.RangePicker style={{ width: 280 }} disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>

        <Form.Item name="postTopic" label={t("form.post-topic")}>
          <Input style={{ width: 389 }} />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        {deleteSelection !== undefined && (
          <>
            <Form.Item>
              <Button htmlType="button" className="filterBtn filterBtnPlain" onClick={handleMultipleDeleteCancelClick}>
                {t("modals.multiple-delete.buttons.cancel")}
              </Button>
            </Form.Item>

            <Form.Item>
              <Button
                type="primary"
                htmlType="button"
                className="filterBtn filterBtnDanger"
                danger
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", articleID: 0 })}
                disabled={deleteSelection.selectedRowKeys === undefined || deleteSelection.selectedRowKeys.length === 0}
              >
                {t("form.buttons.delete")}
              </Button>
            </Form.Item>
          </>
        )}
        {isActionAllowed(actions.DELETE_NEWS_LIKES) && deleteSelection === undefined && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" htmlType="button" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleDeleteClick}>
              {t("form.buttons.multiple-delete")}
            </Button>
          </Form.Item>
        )}
      </Form>
      <Table
        rowKey={"article_id"}
        className="customTable"
        dataSource={data?.data.articles}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        rowSelection={deleteSelection}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.news_nums,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => tc("pagination.show-total-text", { total }),
        }}
      />
      <ConfirmModal open={openModal.open} type={openModal.key} onOk={handleModalOk} onCancel={handleModalCancel} confirmLoading={deleteNewsMutation.isLoading} />
      <ChangePrivacyModal
        open={openPrivacyModal.open}
        onCancel={() => setOpenPrivacyModal((state) => ({ ...state, open: false }))}
        privacy={openPrivacyModal.privacy}
        handleCancel={() => setOpenPrivacyModal((state) => ({ ...state, open: false }))}
        articleID={openPrivacyModal.articleID}
      />
      <EditModal
        open={openEditModal.open}
        handleCancel={() => setEditModalOpen((state) => ({ ...state, open: false, articleID: 0 }))}
        articleContent={openEditModal.articleContent}
        articleID={openEditModal.articleID}
        articleTitle={openEditModal.articleTitle}
      />
    </>
  );
};

export default OfficialAccountNewsManagementView;
