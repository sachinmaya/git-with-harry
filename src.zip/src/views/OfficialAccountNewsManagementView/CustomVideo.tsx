import Quill from "quill";
const Video = Quill.import("formats/video");

export interface CustomVideoCreateParams {
  url: string;
  snapshotUrl: string;
  width: number;
  height: number;
  mimeType: string;
}
class CustomVideo extends Video {
  static create({ url, snapshotUrl, width, height, mimeType }: CustomVideoCreateParams) {
    const video = super.create();
    video.setAttribute("controls", "true");
    video.setAttribute("type", mimeType);
    video.removeAttribute("src");
    video.setAttribute("poster", snapshotUrl);
    if (width !== undefined) {
      video.setAttribute("width", width.toString());
    }
    if (height !== undefined) {
      video.setAttribute("height", height.toString());
    }
    const source = document.createElement("SOURCE");
    source.setAttribute("type", mimeType);
    source.setAttribute("src", url);
    video.append(source);

    return video;
  }

  static value(node: HTMLVideoElement) {
    const source = node.childNodes[0] as HTMLSourceElement;
    return {
      url: source.src,
      snapshotUrl: node.poster,
      width: node.width,
      height: node.height,
      mimeType: source.type,
    };
  }
}
export default CustomVideo;
