import React, { useRef, useState, useCallback, useMemo, useEffect } from "react";
import { Modal, ModalProps } from "antd";
import { Form, Input, message } from "antd";
import { useForm } from "antd/lib/form/Form";
import { useTranslation } from "react-i18next";
import "quill-paste-smart";
import VideoSnapshot from "video-snapshot";
import "react-quill/dist/quill.snow.css";
import * as linkify from "linkifyjs";
import ReactQuill from "react-quill";
import Quill from "quill";
import "quill-paste-smart";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { EditNewsParams } from "~/api/types";
import { UploadType } from "~/api";
import fileFromUrl from "~/utils/fileFromUrl";
import imageDimensionsByUrl from "~/utils/imageDimensionsByUrl";
import { ImagePaste } from "./ImagePaste";
import CustomVideo, { CustomVideoCreateParams } from "./CustomVideo";
import CustomImage, { CustomImageCreateParams } from "./CustomImage";
import useUpload from "~/hooks/useUpload";

const MAX_CHAR_LIMIT_EDITOR = 50000;

const Link = Quill.import("formats/link");

Link.sanitize = (url: string) => {
  if (url !== undefined) {
    const trimmedUrl = url.trim();
    const [result] = linkify.find(trimmedUrl);
    if (result !== undefined && result.start === 0 && result.end === trimmedUrl.length) {
      return result.href;
    }
  }
  return url;
};

CustomVideo.blotName = "video";
CustomVideo.className = "ql-video";
CustomVideo.tagName = "VIDEO";

CustomImage.blotName = "image";
CustomImage.className = "ql-image";
CustomImage.tagName = "IMG";

Quill.register("formats/video", CustomVideo);
Quill.register("formats/image", CustomImage);
Quill.register("modules/imagePaste", ImagePaste);

interface FormValues {
  article_title: string;
  article_content: string;
}

interface EditModalProps extends ModalProps {
  articleTitle: string;
  articleContent: string;
  articleID: number;
  handleCancel: () => void;
}

const initialValues: FormValues = {
  article_content: "",
  article_title: "",
};
const EditModal: React.FC<EditModalProps> = ({ articleTitle, articleContent, articleID, handleCancel, ...props }) => {
  const { t } = useTranslation("news-management-view");
  const [editForm] = useForm();
  const request = useRequest();
  const upload = useUpload();
  const queryClient = useQueryClient();
  const quillRef = useRef<ReactQuill>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [snapshot, setSnapshot] = useState<File | undefined>(undefined);
  const [snapshotBlobUrl, setSnapshotBlobUrl] = useState<string | undefined>(undefined);
  const [mediaFile, setMediaFile] = useState<File | undefined>(undefined);
  const [editorValue, setEditorValue] = useState(articleContent);
  const [charCount, setCharCount] = useState(0);
  const [contentError, setContentError] = useState<boolean>(false);

  useEffect(() => {
    setEditorValue(articleContent);
    initialValues.article_content = articleContent;
    initialValues.article_title = articleTitle;
    editForm.setFieldsValue({
      article_content: articleContent,
      article_title: articleTitle,
    });
    const div = document.createElement("DIV");
    div.innerHTML = articleContent;
    setCharCount(div.innerText.length);
  }, [articleID, articleTitle, articleContent, initialValues, editForm]);
  const handleSnapshotFailed = useCallback(() => {
    setMediaFile(undefined);
    message.open({ type: "error", content: "Video type not supported" });
  }, [setMediaFile]);

  const handleImageSubmit = () => {
    if (quillRef.current) {
      const editor = quillRef!.current.getEditor();
      const input = document.createElement("input");
      input.setAttribute("type", "file");
      input.setAttribute("accept", "image/*");
      input.click();
      input.onchange = () => {
        if (input.files) {
          const file = input.files[0];
          uploadImage(file);
          setMediaFile(file);
        }
      };
    }
  };

  const handleVideoSubmit = () => {
    if (quillRef.current) {
      const editor = quillRef!.current.getEditor();
      const input = document.createElement("input");
      input.setAttribute("type", "file");
      input.setAttribute("accept", "video/mp4");
      input.click();
      input.onchange = () => {
        if (input.files) {
          const file = input.files[0];
          uploadVideo(file);
          setMediaFile(file);
        }
      };
    }
  };

  const uploadImage = (file: File) => {
    const formData = new FormData();
    formData.append("image", file);
    uploadMediaMutation.mutate({
      file: file,
      type: UploadType.picture,
      persist: true,
      onProgress: handleUploadProgress,
      signal: abortControllerRef.current?.signal,
    });
  };

  const uploadVideo = (file: File) => {
    if (file.type !== "video/mp4") return;
    const formData = new FormData();
    formData.append("video", file);
    const snapshoter = new VideoSnapshot(file);
    snapshoter
      .takeSnapshot()
      .then(fileFromUrl)
      .then((snapshot) => {
        setSnapshot(snapshot);
        setSnapshotBlobUrl(URL.createObjectURL(snapshot));
        uploadMediaMutation.mutate({
          file: file,
          snapshot,
          type: UploadType.video,
          persist: true,
          onProgress: handleUploadProgress,
          signal: abortControllerRef.current?.signal,
        });
      })
      .catch(handleSnapshotFailed);
  };

  const uploadMediaMutation = useMutation(upload, {
    onMutate: () => setUploadProgress(0),
    onSuccess: (data, variables) => {
      const { URL, snapshotURL } = data;
      if (variables.file.type.startsWith("image/")) {
        imageDimensionsByUrl(URL).then(({ width, height }) => insertImageToEditor({ url: URL, width, height }));
      } else {
        imageDimensionsByUrl(snapshotURL as string).then(({ width, height }) =>
          insertVideoToEditor({
            url: URL,
            snapshotUrl: snapshotURL as string,
            width,
            height,
            mimeType: variables.file.type,
          })
        );
      }
    },
  });

  const handleUploadProgress = useCallback(({ percent }: { percent: number }) => setUploadProgress(percent), [setUploadProgress]);

  const insertImageToEditor = (url: CustomImageCreateParams) => {
    if (quillRef.current) {
      const quill = quillRef.current.getEditor();
      quill.focus();
      let range = quill.getSelection();
      let position = range ? range.index : 0;
      quill.insertEmbed(position, "image", url);
      quill.setSelection(position + 1, 0);
    }
  };

  const insertVideoToEditor = (url: CustomVideoCreateParams) => {
    if (quillRef.current) {
      const quill = quillRef.current.getEditor();
      quill.focus();
      let range = quill.getSelection();
      let position = range ? range.index : 0;
      quill.insertEmbed(position, "video", url);
      quill.setSelection(position + 1, 0);
    }
  };

  const handleEditorChange = (value: string, delta: any, source: any, editor: any) => {
    if (quillRef.current) {
      const editor = quillRef.current.getEditor();
      // Checking against n + 2 as limit as quill by default has length 1 due to a  "/n" and we need n characters to be allowed
      if (editor.getText().length < MAX_CHAR_LIMIT_EDITOR + 2) {
        setEditorValue(value);
        setCharCount(editor.getText().length - 1);
        editForm.setFieldValue("article_content", value);
      } else {
        editor.deleteText(MAX_CHAR_LIMIT_EDITOR, editor.getLength());
        setCharCount(editor.getLength() - 1);
      }
    }
  };

  const modules = useMemo(() => {
    return {
      toolbar: {
        container: [
          ["bold", "italic", "underline", "strike"],
          [{ list: "ordered" }, { list: "bullet" }],
          [{ indent: "-1" }, { indent: "+1" }],
          [{ header: "1" }, { header: "2" }, "blockquote"],
          ["link", "image", "video"],
          [{ color: [] }],
        ],
        handlers: {
          image: handleImageSubmit,
          video: handleVideoSubmit,
        },
      },
      clipboard: {
        allowed: {
          tags: ["a", "b", "strong", "u", "s", "i", "p", "br", "ul", "ol", "li", "span"],
          attributes: ["href", "rel", "target", "class"],
        },
      },
      imagePaste: true,
    };
  }, []);

  const editNewsMutation = useMutation((params: EditNewsParams) => request(actions.ALTER_NEWS, params), {
    onSuccess: () => {
      handleCancel();
      queryClient.invalidateQueries([actions.GET_NEWS_LIST]);
      message.open({
        key: "update-successfully",
        type: "success",
        content: t("toasts.news-update-success"),
      });
    },
  });

  const handleFinish = ({ article_content, article_title }: FormValues) => {
    return editNewsMutation.mutate({ title: article_title, content: article_content, article_id: articleID });
  };

  const handleAfterClose = () => {
    editForm.setFieldsValue({
      article_title: articleTitle,
      article_content: articleContent,
    });
    setEditorValue(articleContent);
    setCharCount(0);
    setContentError(false);
  };
  return (
    <Modal
      okText={t(`modals.edit-post.buttons.ok`)}
      cancelText={t(`modals.edit-post.buttons.cancel`)}
      title={t("modals.edit-post.title")}
      destroyOnClose={true}
      {...props}
      onOk={editForm.submit}
      onCancel={handleCancel}
      afterClose={handleAfterClose}
      className="editModal"
    >
      <Form layout="horizontal" onFinish={handleFinish} form={editForm} initialValues={initialValues}>
        <Form.Item name="article_title" preserve={false} rules={[{ required: true, message: t("modals.edit-post.errors.title-error") }]}>
          <Input />
        </Form.Item>
        <Form.Item
          name="article_content"
          preserve={false}
          rules={[
            {
              message: t("modals.edit-post.errors.content-error"),
              validator: (_, value) => {
                if (value === "<p><img class=`ql-image` src=`` width=`` height=`0`></p>" || value === "<p><br></p>") {
                  setContentError(true);
                  return Promise.reject();
                } else {
                  setContentError(false);
                  return Promise.resolve();
                }
              },
            },
          ]}
        >
          <div style={contentError ? { border: "1px solid red" } : { border: "unset" }}>
            <ReactQuill
              style={{ height: 300, marginBottom: 70 }}
              ref={quillRef}
              theme="snow"
              modules={modules}
              value={editorValue}
              onChange={handleEditorChange}
              scrollingContainer="html"
              preserveWhitespace={true}
            />
            <div style={{ float: "right" }}>
              {charCount}/{MAX_CHAR_LIMIT_EDITOR}
            </div>
          </div>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default EditModal;
