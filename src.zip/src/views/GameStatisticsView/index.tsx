import { QueryClient, useQuery } from "@tanstack/react-query";
import { Empty, message, Table } from "antd";
import dayjs from "dayjs";
import { FC, useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { actions } from "~/api/constants";
import { InternalServerError, NetworkError } from "~/api/errors";
import { ActiveGameList, ApiRequest, GetStatisticsParams } from "~/api/types";
import StatisticsAreaChart from "~/components/Statistics/StatisticsAreaChart";
import StatisticsCard from "~/components/Statistics/StatisticsCard";
import TabBarExtraContent, { tabRightButtonType } from "~/components/Statistics/TabBarExtraContent";
import usePermissions from "~/hooks/usePermissions";
import useRequest from "~/hooks/useRequest";
import { useDashboardView } from "../DashboardView";
import Text from "antd/lib/typography/Text";
import { ColumnsType } from "antd/es/table";
import Game from "./icons/Game";
import Todo from "./icons/Todo";
import monthOrWeekRange from "~/utils/monthOrWeekRange";
import yearRange from "~/utils/yearRange";

const today = dayjs(new Date());

const initialParams: GetStatisticsParams = {
  from: dayjs(today).startOf("week").format("YYYY-MM-DD"),
  to: dayjs(today).endOf("week").format("YYYY-MM-DD"),
};

const getGameStatisticsQuery = (request: ApiRequest, params: GetStatisticsParams = initialParams) => ({
  queryKey: [actions.GET_GAME_STATISTICS, params],
  queryFn: async () => request(actions.GET_GAME_STATISTICS, params),
});

export const gameStaticsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getGameStatisticsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};
const GameStatisticsView = () => {
  const { t, i18n } = useTranslation("game-statistics-view");
  const [params, setParams] = useState<GetStatisticsParams>(initialParams);
  const { setDashboardHeading } = useDashboardView();
  const { isActionAllowed } = usePermissions();
  const request = useRequest();
  const { data: gameStat, refetch } = useQuery({
    ...getGameStatisticsQuery(request, params),
    keepPreviousData: true,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "game-statistics-query-failed",
        type: "error",
        content: t("toasts.game-statistics-query-failed"),
      });
    },
  });
  const gamePlayedGraphData = useMemo(() => {
    if (gameStat) {
      return gameStat.data.game_played_num_list.map((item) => {
        return {
          date: dayjs(item.data).format("DD/MM/YYYY"),
          value: item.num,
        };
      });
    }
    return [];
  }, [gameStat?.data.game_played_num_list]);

  useEffect(() => {
    setDashboardHeading("statistics", "game-statistics");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  if (!isActionAllowed(actions.GET_GAME_STATISTICS)) {
    return <Empty description={false} />;
  }

  const handleRefetch = useCallback((from: string, to: string) => {
    setParams({ from: from, to: to });
    return refetch();
  }, []);

  const handleTabBtns = (value: tabRightButtonType) => {
    switch (value) {
      case "day":
        let day = today.format("YYYY-MM-DD");
        return handleRefetch(day, day);
      case "week":
      case "month":
        const [from, to] = monthOrWeekRange(value);
        return handleRefetch(from, to);
      case "year":
        const [yearFrom, yearTo] = yearRange();
        return handleRefetch(yearFrom, yearTo);
      default:
        return;
    }
  };
  const handleGameName = (text: { cn: string; en: string }) => {
    if (i18n.language === "zh-CN") {
      return (
        <Text style={{ width: 200 }} ellipsis={{ tooltip: text?.cn }}>
          {text?.cn}
        </Text>
      );
    }
    return (
      <Text style={{ width: 200 }} ellipsis={{ tooltip: text?.en }}>
        {text?.en}
      </Text>
    );
  };
  const findeIndex = (record: ActiveGameList, index: number) => {
    if (gameStat && gameStat?.data.ActiveGameList !== null) {
      let serilNo = gameStat.data.ActiveGameList.indexOf(record) + 1;
      return serilNo;
    }
    return index + 1;
  };
  const columns: ColumnsType<ActiveGameList> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        render: (value, record, index) => findeIndex(record, index),
      },
      {
        key: "game_name",
        dataIndex: "game_name",
        title: t("columns.activeGames"),
        render: (text) => handleGameName(text),
      },
      {
        key: "played_number",
        title: t("columns.numOfPlayed"),
        dataIndex: "played_number",
        width: 250,
      },
    ],
    [t, gameStat?.data.ActiveGameList]
  );

  return (
    <>
      {isActionAllowed(actions.GET_GAME_STATISTICS) && (
        <div>
          <div className="statisticsCardContainer">
            <StatisticsCard title={t("game-played-today")} count={gameStat?.data.game_played_today} icon={<Game />} />
            <StatisticsCard title={t("cumulative-played")} count={gameStat?.data.cumulative_played} icon={<Todo />} />
          </div>
          <TabBarExtraContent changeParams={handleTabBtns} search={handleRefetch} />
          <br />
          <br />
          <StatisticsAreaChart data={gamePlayedGraphData} text={t("chart.fields.games")} />
          <div className="statiTableTitle">{t("activeGames")}</div>
          <div className="statisticsCardLayout statiTable">
            <Table
              dataSource={gameStat?.data.ActiveGameList === null ? [] : gameStat?.data.ActiveGameList.slice(0, 10) || []}
              bordered
              columns={columns}
              size="small"
              pagination={false}
            />
            <Table
              dataSource={gameStat?.data.ActiveGameList === null ? [] : gameStat?.data.ActiveGameList.slice(10) || []}
              bordered
              columns={columns}
              size="small"
              pagination={false}
            />
          </div>
        </div>
      )}
    </>
  );
};

export default GameStatisticsView;
