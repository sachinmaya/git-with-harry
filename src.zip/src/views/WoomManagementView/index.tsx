import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import {
  ApiRequest,
  GetWoomListRequestParams,
  GetWoomListItem,
  GetInterestListRequestParams,
  GetInterestListItem,
  EditWoomListRequestParams,
  DeleteWoomListRequestParams,
} from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, Select, Table, Typography, Modal, Row, Col, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { Link } from "react-router-dom";
import dayjs, { Dayjs } from "dayjs";
import { FieldData } from "rc-field-form/lib/interface";
import Icon, { EyeOutlined } from "@ant-design/icons";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import { TableRowSelection } from "antd/es/table/interface";
import { PlayCircleOutlined, DownOutlined, UpOutlined } from "@ant-design/icons";
import { InternalServerError, NetworkError } from "~/api/errors";
import MediaModal from "./MediaModal";
import ConfirmModal from "~/views/WoomManagementView/ConfirmModal";
import "./index.scss";
import usePermissions from "~/hooks/usePermissions";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";
const { TextArea } = Input;
const { Paragraph } = Typography;

const initialParams: GetWoomListRequestParams = {
  page_number: 1,
  show_number: 10,
};

const getWoomListQuery = (request: ApiRequest, params: GetWoomListRequestParams = initialParams) => ({
  queryKey: [actions.WOOMMANAGE_GETVIDEOLIST, params],
  queryFn: async () => request(actions.WOOMMANAGE_GETVIDEOLIST, params),
});
const getInterestListQuery = (request: ApiRequest, params: GetInterestListRequestParams = { page_number: 1, show_number: -1, time_type: 0 }) => ({
  queryKey: [actions.GET_INTERESTLIST, params],
  queryFn: async () => request(actions.GET_INTERESTLIST, params),
});

export const woomManagementViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getWoomListQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  userId: string;
  status: any;
  emptyDesc: number;
  desc: string;
  filterRange: null | Dayjs[];
}

const initialValues: FormValues = {
  userId: "",
  status: 0,
  emptyDesc: 0,
  desc: "",
  filterRange: null,
};
type ModalKey = "multiple-delete" | "delete-video";

const WoomManagementView: React.FC = () => {
  const [form] = Form.useForm();
  const { t } = useTranslation("woom-management-view");
  const { isActionAllowed } = usePermissions();
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const [emptyDescSelectValue, setEmptyDescSelectValue] = useState<number>(0);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [params, setParams] = useState<GetWoomListRequestParams>(initialParams);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<GetWoomListItem> | undefined>(undefined);
  const [dataList, setDataList] = useState<GetWoomListItem[] | undefined>([]);
  const queryClient = useQueryClient();
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; fileID: string }>({
    open: false,
    key: "multiple-delete",
    fileID: "",
  });

  if (!isActionAllowed(actions.WOOMMANAGE_GETVIDEOLIST)) return null;

  const { data: interestlist } = useQuery({
    ...getInterestListQuery(request, { page_number: 1, show_number: -1, time_type: 0 }),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
  });
  const [interestList, setInterestList] = useState<GetInterestListItem[] | undefined>([]);
  useEffect(() => {
    const datalist = interestlist?.data.interests;
    setInterestList(datalist);
  }, [interestlist]);

  const { data, isPreviousData } = useQuery({
    ...getWoomListQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "woom-list-query-failed",
        type: "error",
        content: t("toast.woom-list-query-failed"),
      });
    },
  });
  useEffect(() => {
    const datalist = data?.data.shortVideoList?.map((item, index) => ({
      ...item,
      key: item.fileId,
      number: index + 1 + (params.page_number * params.show_number - params.show_number),
      expanded: false,
    }));
    setDataList(datalist);
  }, [data]);

  //编辑
  const editVideoMutation = useMutation((EditData: EditWoomListRequestParams) => request(actions.WOOMMANAGE_EDITVIDEO, EditData), {
    onSuccess: () => {
      setModalVisible(false);
      queryClient.invalidateQueries([actions.WOOMMANAGE_GETVIDEOLIST]);
      message.open({
        key: "edit-success",
        type: "success",
        content: t("toast.edit-success"),
      });
    },
  });

  //删除
  const deleteVideoMutation = useMutation((fileId: string[]) => request(actions.WOOMMANAGE_DELETEVIDEO, { fileId }), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.WOOMMANAGE_GETVIDEOLIST]);
      message.open({
        key: "delete-successfully",
        type: "success",
        content: t("toast.delete-successfully"),
      });
    },
  });

  //获取不同语言的标签列表
  const [selectedTags, setSelectedTags] = useState<any[]>([]);
  const [cnfilteredInteresList, enfilteredInteresList, arfilteredInteresList] = useMemo(() => {
    const filteredInteresList = (lang: string) => {
      const usersTagsByLang = interestList?.map((item) => {
        // if (!item) {
        //   return null;
        // }
        // const value: number | undefined = item.id;
        return {
          value: item.id,
          disabled: selectedTags.length >= 10 ? (selectedTags.includes(item.id) ? false : true) : false,
          label: item.name.find((item) => item.language_type === lang)?.name || item.name[0].name || "",
        };
      });
      return usersTagsByLang;
    };
    return [filteredInteresList("cn"), filteredInteresList("en"), filteredInteresList("ar")];
  }, [interestList, selectedTags, setSelectedTags]);

  const handleFinnish = useCallback(
    ({ userId, status, emptyDesc, desc, filterRange }: FormValues) => {
      setParams(({ show_number }) => {
        const state: GetWoomListRequestParams = { page_number: 1, show_number, status, emptyDesc };
        if (userId !== "") {
          state.userId = userId;
        }
        if (status !== "") {
          state.emptyDesc = emptyDesc;
        }
        if (emptyDesc !== 0) {
          state.emptyDesc = emptyDesc;
        }
        if (emptyDesc == 0 && desc !== "") {
          state.desc = desc;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.startTime = startTime;
          state.endTime = endTime;
        }
        return state;
      });
      setSearchLoading(true);
    },
    [setParams]
  );

  const handleFieldsChange = useCallback(
    ([fieldData]: FieldData[]) => {
      if (fieldData) {
        const { name, value } = fieldData;
        if (Array.isArray(name) && name[0] === "emptyDesc") {
          setEmptyDescSelectValue(value);
        }
      }
    },
    [setEmptyDescSelectValue]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  //控制表格内容列超出部分的显示隐藏
  const onCollapse = (record: GetWoomListItem) => {
    const newData = [...(dataList ?? [])];
    const index = newData.findIndex((item) => record.key === item.key);
    newData[index] = {
      ...newData[index],
      expanded: false,
      key: record.key + 1,
    };
    setDataList(newData);
  };
  const onExpand = (record: GetWoomListItem) => {
    const newData = [...(dataList ?? [])];
    const index = newData.findIndex((item) => record.key === item.key);
    newData[index] = {
      ...newData[index],
      expanded: true,
    };
    setDataList(newData);
  };
  const currentLang = localStorage.getItem("i18nextLng");

  // Media Modal
  const [openMediaModal, setOpenMediaModal] = useState<{ open: boolean; mediaURL: string }>({ open: false, mediaURL: "" });

  //控制编辑表单打开
  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [videoPlyerUrl, setVideoPlyerUrl] = useState<string>("");
  const [videoCover, setVideoCover] = useState<string>("");

  //表单的值
  const [formPublisher, setFormPublisher] = useState<string>("");
  const [formNickName, setFormNickName] = useState<string>("");
  const [formPrivacy, setFormPrivacy] = useState<any>("");
  const [formContent, setFormContent] = useState<string>("");
  const [formRemark, setFormRemark] = useState<string>("");
  const handleFormRemark = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFormRemark(e.target.value);
  };
  const handleFormContent = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFormContent(e.target.value);
  };
  const handelPrivacySelect = (val: React.SetStateAction<string> | undefined) => {
    setFormPrivacy(val === undefined ? "" : val);
  };

  //行数据的ID
  const [editId, setEditId] = useState<string | null>(null);
  //触发编辑弹出框的方法
  const showFormModal = (record: GetWoomListItem) => {
    const video_id = record?.fileId;
    setEditId(video_id);

    form.setFieldsValue({
      publisher: record.userID,
      nickName: record.userName,
      privacy: String(record.status),
      content: record.desc,
      remark: record.remark,
      videoTags: record.interestArray,
    });

    setFormPublisher(record.userID);
    setFormNickName(record.userName);
    setFormPrivacy(record.status);
    setFormContent(record.desc);
    setFormRemark(record.remark);
    setVideoPlyerUrl(record.mediaUrl);
    setVideoCover(record.coverUrl);
    setSelectedTags(record.interestArray);

    setModalVisible(true);
  };

  //编辑短视频的请求
  const handleEditVideo = () => {
    const videoByFileID = dataList?.find((item) => item.fileId === editId);

    if (videoByFileID?.status == formPrivacy && videoByFileID?.desc === formContent.trim() && videoByFileID?.remark === formRemark.trim()) {
      message.error({
        content: t("toast.please-edit"),
        key: t("toast.please-edit"),
      });
      return false;
    }

    editVideoMutation.mutate({
      fileId: videoByFileID?.fileId,
      status: Number(formPrivacy),
      remark: formRemark,
      desc: formContent,
    });

    setModalVisible(false);
    form.resetFields();
    setFormPublisher("");
    setFormNickName("");
    setFormPrivacy("");
    setFormContent("");
    setFormRemark("");
    setVideoPlyerUrl("");
    setVideoCover("");
    setSelectedTags([]);
  };

  //取消弹框
  const handleCancelModal = () => {
    form.resetFields();
    setFormPublisher("");
    setFormNickName("");
    setFormPrivacy("");
    setFormContent("");
    setFormRemark("");
    setVideoPlyerUrl("");
    setVideoCover("");
    setSelectedTags([]);

    setModalVisible(false);
  };

  const columns: ColumnsType<GetWoomListItem> = useMemo(
    () => [
      {
        title: t("form.number"),
        dataIndex: "number",
        width: 50,
      },
      {
        title: t("form.publisher"),
        width: 120,
        render: (record) => {
          return record?.userName !== "" ? (
            <>
              <div>{record.userName + "/"}</div>
              <div>{record.userID}</div>
            </>
          ) : (
            t(`form.accountDeleted`)
          );
        },
      },
      {
        title: t("form.privacy"),
        dataIndex: "status",
        width: 100,
        render: (text: "1" | "4" | "5") => {
          return t(`form.privacyOption.${text}`);
        },
      },
      {
        title: t("form.postedTime"),
        dataIndex: "creatTime",
        width: 100,
        render: (text) => {
          let cDate = dayjs(text * 1000).format("YYYY/MM/DD");
          let cTime = dayjs(text * 1000).format("HH:mm:ss");
          return text === 0 ? (
            "-"
          ) : (
            <>
              <div>{cDate}</div>
              <div>{cTime}</div>
            </>
          );
        },
      },
      {
        title: t("form.media"),
        width: 160,
        render: (_, record) => {
          const cover = record?.coverUrl;
          return (
            <div className="video-cover">
              <Image preview={false} src={cover} />
              <span className="video-play-icon" onClick={() => setOpenMediaModal({ open: true, mediaURL: record.mediaUrl })}>
                <PlayCircleOutlined />
              </span>
            </div>
          );
        },
      },
      {
        title: t("form.content"),
        dataIndex: "desc",
        width: 200,
        render: (text, record) => {
          return (
            <>
              <div className="text-container" key={record.key}>
                <Paragraph
                  ellipsis={{
                    rows: 2,
                    expandable: true,
                    symbol: <DownOutlined />,
                    onExpand: () => onExpand(record),
                  }}
                  className={record.expanded ? "textMore" : "text"}
                >
                  {text}
                  {record.expanded && (
                    <div className="toggle" onClick={() => onCollapse(record)}>
                      <UpOutlined />
                    </div>
                  )}
                </Paragraph>
              </div>
            </>
          );
        },
      },
      {
        title: t("form.likes"),
        dataIndex: "likeNum",
        width: 80,
        render: (text, record) => {
          if (text > 0) {
            return <Link to={`/woom/woomLike?fid=${record?.fileId}&user=${record?.userName}`}>{text}</Link>;
          } else {
            return text;
          }
        },
      },
      {
        title: t("form.comments"),
        dataIndex: "commentNum",
        width: 80,
        render: (text, record) => {
          if (text > 0) {
            return <Link to={`/woom/woomComment?fid=${record?.fileId}`}>{text}</Link>;
          } else {
            return text;
          }
        },
      },
      {
        title: t("form.remark"),
        dataIndex: "remark",
        width: 120,
        render: (text) => {
          return text == "" ? "-" : text;
        },
      },
      {
        title: t("form.operation"),
        fixed: "right",
        width: 80,
        render: (_, record) => (
          <div>
            {isActionAllowed(actions.WOOMMANAGE_EDITVIDEO) && (
              <Button className="optionBtn" onClick={() => showFormModal(record)} type="primary" htmlType="button" size="small">
                {t("button.edit")}
              </Button>
            )}
            {isActionAllowed(actions.WOOMMANAGE_DELETEVIDEO) && (
              <Button
                className="optionBtn optionBtnDanger"
                onClick={() => setOpenModal({ open: true, key: "delete-video", fileID: record?.fileId })}
                type="primary"
                htmlType="button"
                size="small"
              >
                {t("button.delete")}
              </Button>
            )}
          </div>
        ),
      },
    ],
    [t, dataList]
  );

  //多选删除
  const handleMultipleDeleteClick = useCallback(
    () =>
      setDeleteSelection({
        columnWidth: 50,
        selectedRowKeys: [],
        onChange: (selectedRowKeys) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-delete-video",
              type: "info",
              content: t("toast.max-delete-video"),
            });
          }
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );

  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);
  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    switch (openModal.key) {
      case "multiple-delete":
        if (deleteSelection !== undefined) {
          deleteVideoMutation.mutate(deleteSelection?.selectedRowKeys as string[]);
        }
        return;
      case "delete-video":
        deleteVideoMutation.mutate([openModal.fileID]);
        return;
    }
  }, [deleteVideoMutation.mutate, deleteSelection, openModal]);

  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFieldsChange={handleFieldsChange} onFinish={handleFinnish}>
        <Form.Item name="userId" label={t("form.publisher")}>
          <Input placeholder={t("placehodler.isPublisher")} />
        </Form.Item>
        <Form.Item name="status" label={t("form.privacy")}>
          <Select
            options={([0, 4, 1] as const).map((value) => ({
              value,
              label: t(`form.status.options.${value}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="emptyDesc" label={t("form.content")}>
          <Select
            options={(["all", "empty"] as const).map((key, value) => ({
              value,
              label: t(`form.emptyDesc.options.${key}`),
            }))}
          />
        </Form.Item>
        {emptyDescSelectValue !== 1 && (
          <Form.Item name="desc">
            <Input placeholder={t("placehodler.isContent")} />
          </Form.Item>
        )}
        {emptyDescSelectValue === 1 && (
          <Form.Item>
            <Input disabled />
          </Form.Item>
        )}
        <Form.Item name="filterRange" label={t("form.postedTime")}>
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("button.search")}
          </Button>
        </Form.Item>
        {deleteSelection !== undefined && (
          <>
            <Form.Item>
              <Button className="filterBtn filterBtnPlain" htmlType="button" onClick={handleMultipleDeleteCancelClick}>
                {t("button.cancel")}
              </Button>
            </Form.Item>
            <Form.Item>
              <Button
                className="filterBtn filterBtnDanger"
                type="primary"
                htmlType="button"
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", fileID: "" })}
                disabled={deleteSelection.selectedRowKeys === undefined || deleteSelection.selectedRowKeys.length === 0}
              >
                {t("button.delete")}
              </Button>
            </Form.Item>
          </>
        )}
        {isActionAllowed(actions.WOOMMANAGE_DELETEVIDEO) && deleteSelection === undefined && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" htmlType="button" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleDeleteClick}>
              {t("button.select")}
            </Button>
          </Form.Item>
        )}
      </Form>
      <Table
        key={currentLang}
        rowKey="fileId"
        className="customTable"
        dataSource={dataList}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        rowSelection={deleteSelection}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.shortVideoCount,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
      <MediaModal open={openMediaModal.open} onCancel={() => setOpenMediaModal((state) => ({ ...state, open: false }))} mediaURL={openMediaModal.mediaURL} />
      <Modal
        title={t("form.editWoom")}
        open={modalVisible}
        onCancel={handleCancelModal}
        onOk={handleEditVideo}
        width={800}
        cancelText={t("button.cancel")} // 取消按钮文字
        okText={t("button.saveEdit")} // 确定按钮文字
      >
        <Form
          name="video"
          form={form}
          labelCol={{
            flex: "100px",
          }}
          labelAlign="right"
          labelWrap
          style={{
            maxHeight: 700,
            overflowY: "auto",
          }}
        >
          <Row>
            <Col span={14}>
              {/* 发布人 */}
              <Form.Item name="publisher" label={t("form.publisher")}>
                <Input value={formPublisher} disabled={true} />
              </Form.Item>
              {/* 昵称 */}
              <Form.Item name="nickName" label={t("form.nickName")}>
                <Input value={formNickName} disabled={true} />
              </Form.Item>
              {/* 类型 */}
              <Form.Item name="privacy" label={t("form.privacy")}>
                <Select onChange={handelPrivacySelect} value={formPrivacy} dropdownStyle={{ textAlign: "center" }}>
                  <Select.Option value="4">{t("privacy.4")}</Select.Option>
                  <Select.Option value="1">{t("privacy.1")}</Select.Option>
                </Select>
              </Form.Item>
              {/* 内容 */}
              <Form.Item name="content" label={t("form.content")}>
                <TextArea value={formContent} showCount maxLength={60} onChange={handleFormContent} />
              </Form.Item>
              {/* 备注 */}
              <Form.Item name="remark" label={t("form.remark")}>
                <TextArea value={formRemark} showCount maxLength={200} onChange={handleFormRemark} />
              </Form.Item>
            </Col>
            <Col span={9}>
              <span style={{ marginLeft: 10 }}>{t("form.woom")}:</span>
              <div className="video-cover-form">
                <Image preview={false} src={videoCover} />
                <span className="video-play-icon-form" onClick={() => setOpenMediaModal({ open: true, mediaURL: videoPlyerUrl })}>
                  <PlayCircleOutlined />
                </span>
              </div>
            </Col>
          </Row>
          {/* 标签cn */}
          <div className="tagWrap">
            <Form.Item name="videoTags" label={t("form.tag-cn")}>
              <Select mode="multiple" disabled style={{ maxWidth: 300, minWidth: "100%" }} options={cnfilteredInteresList}></Select>
            </Form.Item>
            <div className="tagCount">{selectedTags.length}/10</div>
          </div>
          {/* 标签en */}
          <div className="tagWrap">
            <Form.Item name="videoTags" label={t("form.tag-en")}>
              <Select
                mode="multiple"
                disabled
                style={{ maxWidth: 300, minWidth: "100%" }}
                className={"multiTags"}
                options={enfilteredInteresList}
                //   onChange={handleChangeTags}
                placeholder={t("placehodler.tagPlaceholder")}
              ></Select>
            </Form.Item>
            <div className="tagCount">{selectedTags.length}/10</div>
          </div>
          {/* 标签ar */}
          <div className="tagWrap">
            <Form.Item
              name="videoTags"
              label={t("form.tag-ar")}
              // initialValue={[]}
            >
              <Select
                mode="multiple"
                disabled
                style={{ maxWidth: 300, minWidth: "100%" }}
                className={"multiTags"}
                options={arfilteredInteresList}
                //   onChange={handleChangeTags}
                placeholder={t("placehodler.tagPlaceholder")}
              ></Select>
            </Form.Item>
            <div className="tagCount">{selectedTags.length}/10</div>
          </div>
        </Form>
      </Modal>
      <ConfirmModal open={openModal.open} type={openModal.key} onCancel={handleModalCancel} onOk={handleModalOk} confirmLoading={deleteVideoMutation.isLoading} />
    </>
  );
};

export default WoomManagementView;
