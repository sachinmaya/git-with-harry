import React from "react";

const Message: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg width="3em" height="3em" version="1.1" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg" fill="currentColor" {...props}>
    <g xmlns="http://www.w3.org/2000/svg" id="users01" transform="translate(-72.744 -93.222)">
      <rect width="40" height="40" transform="translate(73.244 93.222)" fill="none" />
      <ellipse cx="15" cy="9" rx="15" ry="9" transform="translate(78.242 101.339)" fill="#25e5af" />
      <g transform="translate(13.244 44.796)">
        <path
          d="M82.371,80.419l1.243-.22a18.16,18.16,0,0,0,9.924-5.105,12.931,12.931,0,0,0,3.81-9.011c0-7.869-7.682-14.431-17.348-14.431S62.652,58.214,62.652,66.083a12.927,12.927,0,0,0,3.795,9,18.145,18.145,0,0,0,9.888,5.112l1.238.222,2.4,4.32,2.4-4.313Zm-6.5,2.381C66.8,81.174,60,74.307,60,66.083,60,56.648,68.954,49,80,49s20,7.648,20,17.083c0,8.242-6.833,15.12-15.924,16.728l-2.17,3.905a2.21,2.21,0,0,1-3.863,0L75.867,82.8Z"
          fill="#111"
          stroke="#fff"
          strokeWidth="1"
        />
        <path
          d="M282.588,382.931a2.431,2.431,0,1,1,2.431,2.431A2.431,2.431,0,0,1,282.588,382.931Zm-8.088,0a2.431,2.431,0,1,1,2.431,2.431A2.431,2.431,0,0,1,274.5,382.931Zm16.133,0a2.431,2.431,0,1,1,2.431,2.431A2.431,2.431,0,0,1,290.633,382.931Z"
          transform="translate(-205.019 -316.848)"
          fill="#111"
        />
      </g>
    </g>
  </svg>
);

export default Message;
