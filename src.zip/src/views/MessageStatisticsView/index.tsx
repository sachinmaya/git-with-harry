import { QueryClient, useQuery } from "@tanstack/react-query";
import { Empty, message, Tabs, TabsProps } from "antd";
import dayjs from "dayjs";
import { FC, useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { actions } from "~/api/constants";
import { InternalServerError, NetworkError } from "~/api/errors";
import { ApiRequest, GetStatisticsParams } from "~/api/types";
import StatisticsAreaChart from "~/components/Statistics/StatisticsAreaChart";
import StatisticsCard from "~/components/Statistics/StatisticsCard";
import TabBarExtraContent, { tabRightButtonType } from "~/components/Statistics/TabBarExtraContent";
import usePermissions from "~/hooks/usePermissions";
import useRequest from "~/hooks/useRequest";
import monthOrWeekRange from "~/utils/monthOrWeekRange";
import yearRange from "~/utils/yearRange";
import { useDashboardView } from "../DashboardView";
import Message from "./icons/Message";
import Messages from "./icons/Messages";

const today = dayjs(new Date());

const initialParams: GetStatisticsParams = {
  from: dayjs(today).startOf("week").format("YYYY-MM-DD"),
  to: dayjs(today).endOf("week").format("YYYY-MM-DD"),
};

const getMessageStatisticsQuery = (request: ApiRequest, params: GetStatisticsParams = initialParams) => ({
  queryKey: [actions.GET_MESSAGE_STATISTICS, params],
  queryFn: async () => request(actions.GET_MESSAGE_STATISTICS, params),
});

export const meaasgeStaticsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getMessageStatisticsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

const MessageStatisticsView = () => {
  const { t } = useTranslation("message-statistics-view");
  const [params, setParams] = useState<GetStatisticsParams>(initialParams);
  const { setDashboardHeading } = useDashboardView();
  const { isActionAllowed } = usePermissions();
  const request = useRequest();
  const { data: messageStat, refetch } = useQuery({
    ...getMessageStatisticsQuery(request, params),
    keepPreviousData: true,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "message-statistics-query-failed",
        type: "error",
        content: t("toasts.message-statistics-query-failed"),
      });
    },
  });
  const newGroupGraphData = useMemo(() => {
    if (messageStat) {
      return messageStat.data.private_message_num_list.map((item) => {
        return {
          date: dayjs(item.date).format("DD/MM/YYYY"),
          value: item.message_num,
        };
      });
    }
    return [];
  }, [messageStat?.data.private_message_num_list]);
  const totalGroupGraphData = useMemo(() => {
    if (messageStat) {
      return messageStat.data.group_message_num_list.map((item) => {
        return {
          date: dayjs(item.date).format("DD/MM/YYYY"),
          value: item.message_num,
        };
      });
    }
    return [];
  }, [messageStat?.data.group_message_num_list]);

  useEffect(() => {
    setDashboardHeading("statistics", "message-statistics");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  if (!isActionAllowed(actions.GET_MESSAGE_STATISTICS)) {
    return <Empty description={false} />;
  }
  const items: TabsProps["items"] = [
    {
      key: "1",
      label: t("chart.tabs.single-chat"),
      children: <StatisticsAreaChart data={newGroupGraphData} text={t("chart.fields.messages")} />,
    },
    {
      key: "3",
      label: t("chart.tabs.group"),
      children: <StatisticsAreaChart data={totalGroupGraphData} text={t("chart.fields.messages")} />,
    },
  ];
  const handleRefetch = useCallback((from: string, to: string) => {
    setParams({ from: from, to: to });
    return refetch();
  }, []);

  const handleTabBtns = (value: tabRightButtonType) => {
    switch (value) {
      case "day":
        let day = today.format("YYYY-MM-DD");
        return handleRefetch(day, day);
      case "week":
      case "month":
        const [from, to] = monthOrWeekRange(value);
        return handleRefetch(from, to);
      case "year":
        const [yearFrom, yearTo] = yearRange();
        return handleRefetch(yearFrom, yearTo);
      default:
        return;
    }
  };
  return (
    <>
      {isActionAllowed(actions.GET_MESSAGE_STATISTICS) && (
        <>
          <div className="statisticsCardContainer">
            <StatisticsCard title={t("single-chat-messages")} count={messageStat?.data.private_message_num} icon={<Message />} />
            <StatisticsCard title={t("group-messages")} count={messageStat?.data.group_message_num} icon={<Messages />} />
          </div>
          <Tabs defaultActiveKey="1" items={items} size="small" className="tab" tabBarExtraContent={<TabBarExtraContent changeParams={handleTabBtns} search={handleRefetch} />} />
        </>
      )}
    </>
  );
};

export default MessageStatisticsView;
