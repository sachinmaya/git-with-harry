import { Button, DatePicker, Empty, Form, Image, Input, message, Modal, Select, Table } from "antd";
import React, { FC, useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import dayjs, { Dayjs } from "dayjs";
import { ApiRequest, ContentImagesArrayType, ContentVideosArrayType, GetMomentDetailsRequestParams, MomentDetails, TurnoffCommentRequestParams } from "~/api/types";
import { actions } from "~/api/constants";
import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { useDashboardView } from "../DashboardView";
import { ColumnsType } from "antd/es/table";
import Text from "antd/lib/typography/Text";
import { Link } from "react-router-dom";
import Paragraph from "antd/es/typography/Paragraph";
import usePermissions from "~/hooks/usePermissions";
import { InternalServerError, NetworkError } from "~/api/errors";
import Icon, { EyeOutlined } from "@ant-design/icons";
import VideoPlayer from "~/components/VideoPlayerModal";
import SearchIcon from "~/components/icons/SearchIcon";
import VideoContent from "~/components/VideoContent";

const initialParams: GetMomentDetailsRequestParams = {
  page_number: 1,
  show_number: 10,
  order_by: "start_time:desc",
};

const getMomentDeatilsQuery = (request: ApiRequest, params: GetMomentDetailsRequestParams = initialParams) => ({
  queryKey: [actions.GET_MOMENT_DETAILS, params],
  queryFn: async () => request(actions.GET_MOMENT_DETAILS, params),
});

export const MomentDetailsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getMomentDeatilsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};
interface FormValues {
  account: string;
  privacy: number;
  content_type: number;
  content: string;
  media_type: number;
  filter_range: null | Dayjs[];
}
const initialValue: FormValues = {
  account: "",
  privacy: 0,
  content_type: 0,
  content: "",
  media_type: 0,
  filter_range: null,
};

interface MomentPostViewProps {}
interface VideoData {
  open: boolean;
  video: ContentVideosArrayType | null;
}
const MomentPostView: FC<MomentPostViewProps> = () => {
  const { t } = useTranslation("moments-posts-view");
  const { setDashboardHeading } = useDashboardView();
  const [form] = Form.useForm();
  const request = useRequest();
  const { confirm, destroyAll } = Modal;
  const queryClient = useQueryClient();
  const contentType = Form.useWatch("content_type", form);
  const { isActionAllowed } = usePermissions();
  const [visible, setVisible] = useState<string | null>(null);
  const [vedioPlayer, setVedioPlayer] = useState<VideoData>({ open: false, video: null });
  const [params, setParams] = useState<GetMomentDetailsRequestParams>(initialParams);

  const { data, refetch, isRefetching } = useQuery({
    ...getMomentDeatilsQuery(request, params),
    keepPreviousData: true,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.error(t("toasts.moment-post-query-failed"));
    },
  });
  const { mutateAsync } = useMutation((params: TurnoffCommentRequestParams) => request(actions.SWITCH_MOMENT_COMMENT, params), {
    onSuccess(_, { comment_ctl }) {
      queryClient.invalidateQueries({
        queryKey: [actions.GET_MOMENT_DETAILS, params],
      });
      destroyAll();
      message.open({
        key: "turn-off-comment-successfully",
        type: "success",
        content: comment_ctl === 1 ? t("toasts.turn-on-comment") : t("toasts.turn-off-comment-successfully"),
      });
    },
    onError(error) {
      destroyAll();
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.error(t("toasts.turn-off-comment-failed"));
    },
  });

  useEffect(() => {
    setDashboardHeading("moments-management", "moments-post");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const onSumbit = useCallback(
    (values: FormValues) => {
      setParams(({ show_number, order_by }) => {
        let state: GetMomentDetailsRequestParams;
        let formatedValues = Object.fromEntries(Object.entries(values).filter(([_, v]) => v != "" && v != 0 && v !== null));
        if (formatedValues.filter_range) {
          const [startDate, endDate] = formatedValues.filter_range;
          delete formatedValues["filter_range"];
          formatedValues.start_time = startDate.unix();
          formatedValues.end_time = endDate.unix();
        }
        state = { ...formatedValues, page_number: 1, show_number, order_by };
        return state;
      });
      refetch();
    },
    [setParams, refetch]
  );
  const playVideo = (video: ContentVideosArrayType) => {
    if (video !== null) {
      return setVedioPlayer({ open: true, video: video });
    }
  };
  const closePlayer = () => setVedioPlayer({ open: false, video: null });
  const showMedia = (item: MomentDetails) => {
    if (item.mContentImagesArrayV2 !== null && item.mContentImagesArrayV2.length !== 0) {
      return (
        <>
          <Image
            preview={{ visible: false, mask: <EyeOutlined /> }}
            width={60}
            height={40}
            src={`${item.mContentImagesArrayV2[0].image_url}`}
            onClick={() => setVisible(item.moment_id)}
          />
          <div style={{ display: "none" }}>
            <Image.PreviewGroup preview={{ visible: visible === item.moment_id, onVisibleChange: (vis) => setVisible(vis ? item.moment_id : null) }}>
              {item.mContentImagesArrayV2.map((image: ContentImagesArrayType, index) => {
                return <Image src={`${image.image_url}`} key={index} />;
              })}
            </Image.PreviewGroup>
          </div>
        </>
      );
    }
    if (item.mContentVideosArrayV2 !== null && item.mContentVideosArrayV2.length !== 0) {
      return <VideoContent videoInfo={item.mContentVideosArrayV2[0]} playVideo={playVideo} />;
    }
    return t("columns.no-media");
  };

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );
  const handleRefetch = (original_id: string) => {
    setParams({ ...initialParams, original_id });
    return refetch();
  };
  const handleOffComment = (moment_id: string, comment_ctl: number) => {
    confirm({
      title: "",
      content: t("modal.comment-off.content"),
      icon: <></>,
      onOk: () => mutateAsync({ moment_id, comment_ctl }),
      okText: t("modal.comment-off.ok-btn"),
      cancelText: t("modal.comment-off.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const handleOnComment = (moment_id: string, comment_ctl: number) => {
    confirm({
      title: "",
      content: t("modal.comment-on.content"),
      icon: <></>,
      onOk: () => mutateAsync({ moment_id, comment_ctl }),
      okText: t("modal.comment-on.ok-btn"),
      cancelText: t("modal.comment-on.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const columns: ColumnsType<MomentDetails> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "account",
        width: 180,
        dataIndex: "user_id",
        title: t("columns.account"),
      },
      {
        key: "nickname",
        dataIndex: "user_name",
        width: 180,
        title: t("columns.nickname"),
        render: (value) => (
          <Text
            style={{ width: 150 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value}
          </Text>
        ),
      },
      {
        key: "type",
        title: t("columns.type"),
        dataIndex: "privacy",
        width: 80,
        render: (value) => {
          return value === 1 ? t(`form.type.options.private`) : t(`form.type.options.public`);
        },
      },

      {
        key: "media",
        title: t("columns.media"),
        dataIndex: "cover_photo",
        width: 100,
        render: (_, record) => showMedia(record),
      },
      {
        key: "content",
        title: t("columns.content"),
        dataIndex: "m_content_text",
        width: 180,
        render: (_, record) => (
          <Link to={`/moments/posts?momentId=${record.moment_id}`}>
            <Paragraph
              style={{ width: 130 }}
              ellipsis={{
                tooltip: record.m_content_text,
                rows: 2,
              }}
            >
              {record.m_content_text}
            </Paragraph>
          </Link>
        ),
      },
      { key: "post-time", title: t("columns.post-time"), dataIndex: "m_create_time", width: 180, render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss") },
      {
        key: "location",
        title: t("columns.location"),
        render: () => "-",
      },
      {
        key: "last-login-ip",
        width: 180,
        dataIndex: "last_login_ip",
        title: t("columns.last-log-in-ip"),
      },
      {
        key: "m_comments_count",
        width: 180,
        dataIndex: "m_comments_count",
        title: t("columns.comments"),
        render: (_, record) => (record.m_comments_count === 0 ? 0 : <Link to={`/moments/momentsComments?momentId=${record.moment_id}`}>{record.m_comments_count}</Link>),
      },
      {
        key: "m_likes_count",
        width: 180,
        dataIndex: "m_likes_count",
        title: t("columns.likes"),
        render: (_, record) => (record.m_likes_count === 0 ? 0 : <Link to={`/moments/momentsLikes?momentId=${record.moment_id}`}>{record.m_likes_count}</Link>),
      },
      {
        key: "m_repost_count",
        width: 180,
        dataIndex: "m_repost_count",
        title: t("columns.reposted"),
        render: (_, record) =>
          record.m_repost_count === 0 ? (
            0
          ) : (
            <Button type={"link"} onClick={() => handleRefetch(record.orignal_id)}>
              {record.m_repost_count}
            </Button>
          ),
      },
      {
        key: "options",
        width: 200,
        title: t("columns.operations.lable"),
        fixed: "right",
        hidden: !isActionAllowed(actions.SWITCH_MOMENT_COMMENT),
        render: (_, record) => {
          return record.comment_ctl === 1 && isActionAllowed(actions.SWITCH_MOMENT_COMMENT) ? (
            <button type="button" className="optionBtn optionBtnDanger" onClick={() => handleOffComment(record.moment_id, 2)}>
              {t("columns.operations.buttons.off-comment")}
            </button>
          ) : (
            isActionAllowed(actions.SWITCH_MOMENT_COMMENT) && (
              <button type="button" className="optionBtn optionBtnSuccess" onClick={() => handleOnComment(record.moment_id, 1)}>
                {t("columns.operations.buttons.on-comment")}
              </button>
            )
          );
        },
      },
    ],
    [t, setVisible, visible]
  );
  return (
    <>
      {isActionAllowed(actions.GET_MOMENT_DETAILS) ? (
        <>
          <Form name="moments-post-form" className="filterForm" form={form} initialValues={initialValue} layout="inline" colon={false} onFinish={onSumbit}>
            <Form.Item name="account">
              <Input
                placeholder={t("form.keyword.placeholder")}
                style={{
                  minWidth: 220,
                }}
              />
            </Form.Item>
            <Form.Item name="privacy" label={t("form.type.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "private", "public", "block"] as const).map((key, value) => ({
                  value,
                  label: t(`form.type.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="media_type" label={t("form.media.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "images", "video"] as const).map((key, value) => ({
                  value,
                  label: t(`form.media.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="content_type" label={t("form.content-type.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "empty"] as const).map((key, value) => ({
                  value,
                  label: t(`form.content-type.options.${key}`),
                }))}
              />
            </Form.Item>
            {contentType === 0 && (
              <Form.Item name="content">
                <Input placeholder={t("form.content-keyword.placeholder")} />
              </Form.Item>
            )}
            <Form.Item name="filter_range" label={t("form.post-time.lable")}>
              <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
            </Form.Item>
            <Form.Item>
              <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" icon={<Icon component={SearchIcon} />} loading={isRefetching}>
                {t("form.buttons.search")}
              </Button>
            </Form.Item>
          </Form>
          <Table
            rowKey="moment_id"
            dataSource={data?.data.moment_detail}
            columns={columns}
            scroll={{ x: true }}
            loading={isRefetching}
            pagination={{
              current: data?.data.current_number,
              total: data?.data.moments_nums,
              onChange: handlePaginationChange,
              pageSizeOptions: [10, 20, 50, 100, 1000],
              showQuickJumper: true,
              position: ["bottomCenter"],
              showTotal: (total: number) => t("pagination.show-total-text", { total }),
            }}
          />
          {vedioPlayer.video !== null && <VideoPlayer video={vedioPlayer.video} open={vedioPlayer.open} onCancel={closePlayer} />}
        </>
      ) : (
        <Empty description={false} />
      )}
    </>
  );
};

export default MomentPostView;
