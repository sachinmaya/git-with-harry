import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery,useMutation } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, SwitchMePageParams, GetMePageParams, SaveMePageParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button,  Form,  Input,  message,  Switch, Modal } from "antd";
import { ColumnsType } from "antd/es/table";
import { Link } from "react-router-dom";
import dayjs, { Dayjs } from "dayjs";
import { FieldData } from "rc-field-form/lib/interface";
import classes from "./styles.module.scss";
const date = new Date();
const new_date = date.toLocaleString();
const time = Date.parse(new_date);

const initialParams: GetMePageParams = {
  operationID: JSON.stringify(time),
  type: 4
};

const getMePageQuery = (request: ApiRequest, params: GetMePageParams = initialParams) => ({
  queryKey: [actions.GET_MEPAGE, params],
  queryFn: async () => request(actions.GET_MEPAGE, params),
});

export const mePageExchangeViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getMePageQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

const switchStatusMePage = (request: ApiRequest, params: SwitchMePageParams) => ({
  mutationFn: async () => request(actions.SWITCH_STATUS_MEPAGE, params),
});

interface FormValues {
  urlcn: string | undefined;
  urlen: string | undefined;
}



const MePageExchangeView: React.FC = () => {
  const { t } = useTranslation("me-page-exchange-view");
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const [sourceValue, setSourceValue] = useState<number>(0);
  const [params, setParams] = useState<GetMePageParams>(initialParams);
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
  const { data, refetch, isRefetching } = useQuery({
    ...getMePageQuery(request, params),
    keepPreviousData: true,
    onError: () => {
      // TODO: show error message
    },
  });
  const [statusMepage, setStatusMepage] = useState(data?.data.status)
  const [isPromotion, setIsPromotion] = useState(data?.data.status===1?true:false);
  const initialValues: FormValues = {
    urlcn: data?.data.url.cn,
    urlen: data?.data.url.en
  };
  
  useEffect(() => {
    setDashboardHeading("me", "exchange");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]); 

  const saveMePageMutation = useMutation(
    (params: SaveMePageParams) => request(actions.SAVE_MEPAGE, params),{
      onSuccess:()=>{
        message.success({content:t("form.update-success"),key:t("form.update-success")})
      },
    }
  )

  const handleFinnish = useCallback(
    ({ urlcn, urlen }: FormValues) => {
      saveMePageMutation.mutate({
        operationID: JSON.stringify(time),
        type: 4,
        url: {
            cn: urlcn===undefined?"":urlcn,
            en: urlen===undefined?"":urlen
        }
      })
      refetch();
    },
    [setParams, refetch]
  );



  const switchMePageStatus = (checked: boolean) => {    
    setIsPromotion(checked);
    setIsModalVisible(true)
  };

  const enableSwitchMutation = useMutation({
    ...switchStatusMePage(request, {
      operationID: JSON.stringify(time),
     type: 4,
     status:statusMepage===2?2:1
    }),
    onSuccess:()=>{
      message.success({content:statusMepage===2?t("modal.closed-success"):t("modal.open-success"),key:t("modal.closed-success")})
    }
  })
  const confirmSwitchStatus = () =>{
    setStatusMepage(statusMepage===1?2:1);
    enableSwitchMutation.mutate()
    setIsModalVisible(false)
  }
  const handleCancel = () =>{
    setIsModalVisible(false)
    setIsPromotion(!isPromotion);
  }

 
  return (
    <>
      <div className={classes.mepPage}>
        <div className={classes.switchMePage}>
            {t('switch-info')}: <Switch checked={isPromotion} onChange={switchMePageStatus} className={classes.switchbttn}/>
        </div>
        <div style={{ color: "#000", textAlign: "center"}}>{statusMepage===2 && t('disable-enable-msg')}</div>
        <Form initialValues={initialValues} onFinish={handleFinnish} className={classes.formArea}>
        <Form.Item
          label={t("form.url.cn.title")}
          name="urlcn"
          rules={[{ max: 255, message: t("form.url-max-length") },{type:'url',warningOnly:true,message:t('form.invalid-url')}]}
        >
          <Input placeholder={t("form.url.cn.placeholder")} disabled={statusMepage===2?true:false}/>
        </Form.Item>
        <Form.Item
          label={t("form.url.en.title")}
          name="urlen"
          rules={[{ max: 255, message: t("form.url-max-length") },{type:'url',warningOnly:true,message:t('form.invalid-url')}]}
        >
          <Input placeholder={t("form.url.en.placeholder")} disabled={statusMepage===2?true:false}/>
        </Form.Item>
        
        <Form.Item className={classes.buttonsArea}>
          <Button htmlType="submit" loading={isRefetching} disabled={statusMepage===2?true:false} className={classes.submitbutton}>
            {t("form.buttons.save")}
          </Button>
        </Form.Item>
      </Form>
      </div>  

      <Modal
        title={statusMepage === 1? t('modal.close-modal-title'):t('modal.open-modal-title')}
        open={isModalVisible} // 是否显示模态框
        onOk={confirmSwitchStatus} // 点击确定触发事件
        onCancel={handleCancel} // 点击取消触发事件
        closable={false} //  是否显示右上角关闭效果
        centered={true} //  是否垂直居中显示
        destroyOnClose={true} // 关闭时销毁 Modal 里的子元素
        cancelText={t("modal.buttons.cancel")} // 取消按钮文字
        okText={t("modal.buttons.ok")} // 确定按钮文字
      >
        <p>{statusMepage === 1? t('modal.close-modal-desc'):t('modal.open-modal-desc')}</p>
      </Modal>   
    </>
  );
};

export default MePageExchangeView;
