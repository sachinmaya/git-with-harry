import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery,useMutation } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, SwitchDiscoverParams, GetDiscoverParams, SaveDiscoverParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button,  Form,  Input,  message,  Switch, Modal } from "antd";
import { ColumnsType } from "antd/es/table";
import { Link } from "react-router-dom";
import dayjs, { Dayjs } from "dayjs";
import { FieldData } from "rc-field-form/lib/interface";
import classes from "./styles.module.scss";
const date = new Date();
const new_date = date.toLocaleString();
const time = Date.parse(new_date);

const initialParams: GetDiscoverParams = {
  operationID: JSON.stringify(time),
  platform_id: '1'
};

const getDiscoverQuery = (request: ApiRequest, params: GetDiscoverParams = initialParams) => ({
  queryKey: [actions.GET_DISCOVER, params],
  queryFn: async () => request(actions.GET_DISCOVER, params),
});

export const discoverViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getDiscoverQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

const switchDiscover = (request: ApiRequest, params: SwitchDiscoverParams) => ({
  mutationFn: async () => request(actions.SWITCH_STATUS_DISCOVER, params),
});

interface FormValues {
  url: string;
}



const DiscoverView: React.FC = () => {
  const { t } = useTranslation("discover-view");
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const [sourceValue, setSourceValue] = useState<number>(0);
  const [params, setParams] = useState<GetDiscoverParams>(initialParams);
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
  const { data, refetch, isRefetching } = useQuery({
    ...getDiscoverQuery(request, params),
    keepPreviousData: true,
    onError: () => {
      // TODO: show error message
    },
  });
  const [discover, setDiscover] = useState(data?.data.status)
  const [isPromotion, setIsPromotion] = useState(data?.data.status===1?true:false);
  const initialValues: FormValues = {
    url: data?.data.url === undefined ? '' : data?.data.url
  };
  
  useEffect(() => {
    setDashboardHeading("me", "discover");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]); 

  const saveDiscoverMutation = useMutation(
    (params: SaveDiscoverParams) => request(actions.SAVE_DISCOVER, params),{
      onSuccess:()=>{
        message.success({content:t("form.update-success"),key:t("form.update-success")})
      },
    }
  )

  const handleFinnish = useCallback(
    ({ url }: FormValues) => {
      saveDiscoverMutation.mutate({
        operationID: JSON.stringify(time),
        platform_id: '1',
        url: url
      })
      refetch();
    },
    [setParams, refetch]
  );



  const switchDiscoverStatus = (checked: boolean) => {    
    setIsPromotion(checked);
    setIsModalVisible(true)
  };

  const enableSwitchMutation = useMutation({
    ...switchDiscover(request, {
      operationID: JSON.stringify(time),
      platform_id: '1',
     status:discover===0?0:1
    }),
    onSuccess:()=>{
      message.success({content:discover===0?t("modal.closed-success"):t("modal.open-success"),key:t("modal.closed-success")})
    }
  })
  const confirmSwitchStatus = () =>{
    setDiscover(discover===1?0:1);
    enableSwitchMutation.mutate()
    setIsModalVisible(false)
  }
  const handleCancel = () =>{
    setIsModalVisible(false)
    setIsPromotion(!isPromotion);
  }

 
  return (
    <>
      <div className={classes.mepPage}>
        <div className={classes.switchMePage}>
            {t('switch-info')}: <Switch checked={isPromotion} onChange={switchDiscoverStatus} className={classes.switchbttn}/>
        </div>
        <div style={{ color: "#000", textAlign: "center"}}>{discover===0 && t('disable-enable-msg')}</div>
        <Form initialValues={initialValues} onFinish={handleFinnish} className={classes.formArea}>
        <Form.Item
          label={t("form.url.title")}
          name="url"
          rules={[{ max: 255, message: t("form.url-max-length") },{type:'url',warningOnly:true,message:t('form.invalid-url')}]}
        >
          <Input placeholder={t("form.url.placeholder")} disabled={discover===0?true:false}/>
        </Form.Item>        
        
        <Form.Item className={classes.buttonsArea}>
          <Button htmlType="submit" loading={isRefetching} disabled={discover===0?true:false} className={classes.submitbutton}>
            {t("form.buttons.save")}
          </Button>
        </Form.Item>
      </Form>
      </div>  

      <Modal
        title={discover === 1? t('modal.close-modal-title'):t('modal.open-modal-title')}
        open={isModalVisible} // 是否显示模态框
        onOk={confirmSwitchStatus} // 点击确定触发事件
        onCancel={handleCancel} // 点击取消触发事件
        closable={false} //  是否显示右上角关闭效果
        centered={true} //  是否垂直居中显示
        destroyOnClose={true} // 关闭时销毁 Modal 里的子元素
        cancelText={t("modal.buttons.cancel")} // 取消按钮文字
        okText={t("modal.buttons.ok")} // 确定按钮文字
      >
        <p>{discover === 1? t('modal.close-modal-desc'):t('modal.open-modal-desc')}</p>
      </Modal>   
    </>
  );
};

export default DiscoverView;
