import { Button, Form, Input, Modal, ModalProps, Select, Switch } from "antd";
import { t } from "i18next";
import React, { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { AddEditAppUpdateRequestParams, AddEditAppUpdateResponse, GetAppUpdateItem } from "~/api/types";

interface AddAppUpdateModalProps extends ModalProps {
  appUpdate?: GetAppUpdateItem;
  onFormSubmit: (values: AddEditAppUpdateRequestParams, mode: "add" | "edit",appId: string | undefined) => void;
  mode: "add" | "edit";
  appId: string | undefined;
}

export interface AddAppUpdateFormValues {
  version:string,
  type:string,
  isforce:string,
  status:string,
  title:string,
  download_url:string,
  content:string
}

const initialFormValues: AddAppUpdateFormValues = {
  version: "",
  type: "",
  isforce: "",
  status: "",
  title: "",
  download_url: "",
  content: "",
};

const initialParams: AddEditAppUpdateRequestParams = {
  version: "",
  client: "",
  isforce: "",
  status: "",
  title: "",
  download_url: "",
  remark: "",
};

const AddEditAppUpdateModal: React.FC<AddAppUpdateModalProps> = ({  appUpdate = initialFormValues, onFormSubmit, mode, appId, ...props }) => {
  const { t } = useTranslation("app-update-view");
  const [form] = Form.useForm();
  const [addEditAppUpdateParams, setAddEditAppUpdateParams] = useState<AddEditAppUpdateRequestParams>(initialParams);
  // console.log(appId);
  useEffect(() => {
    if (appUpdate) {
      form.setFieldsValue(appUpdate);
      form.setFields([{ name: "type", value: mode==="add"? undefined: appUpdate.type === 1 ? "ios" : "android" }]);
      form.setFields([{ name: "isforce", value: mode==="add"? undefined:appUpdate.isforce === 1 ? "no" : "yes" }]);
      form.setFields([{ name: "status", value: mode==="add"? undefined: appUpdate.status === 1 ? "off" : "on" }]);
    }
  }, [appUpdate]);

  const handleFormSubmit = useCallback(
    ({ version, type, isforce, status, title, download_url, content }: AddAppUpdateFormValues) => {
      setAddEditAppUpdateParams(() => {
        const state: AddEditAppUpdateRequestParams = initialParams;
        state.version = version;
        state.client = type;
        state.isforce = isforce;
        state.status = status;
        state.title = title;
        state.download_url = download_url;
        state.remark = content;
        return state;
      });
      form.resetFields();
      onFormSubmit(addEditAppUpdateParams, mode, appId);
    },
    [setAddEditAppUpdateParams, mode, appId]
  );
  
  return (
    <Modal
    //  className="confirmModal"
      title={mode === "add" ? t("add-edit-modal.add-modal-title") : t("add-edit-modal.edit-modal-title")}
      okText={mode === "add" ? t("add-edit-modal.buttons.add") : t("add-edit-modal.buttons.edit")}
      cancelText={t("add-edit-modal.buttons.cancel")}
      onOk={form.submit}
      {...props}
      destroyOnClose
      forceRender
    >
      <Form initialValues={mode!=="add" ? appUpdate : initialFormValues} form={form} onFinish={handleFormSubmit}>
        <Form.Item
          name="version"
          label={t("add-edit-modal.form.version.label")}
          rules={[{
                  required: true,
                  message: t("add-edit-modal.form.version.error"),
                  whitespace: true,
                }
          ]}
        >
          <Input />
        </Form.Item>  
        
        <Form.Item name="type" label={t("form.client.label")} rules={[{ required: true, message: t("add-edit-modal.form.client.error") }]}>
          <Select
              options={(["ios", "android"] as const).map((key, value) => ({
                value:key,
                label: t(`form.client.options.${key}`),
              }))}
              placeholder={t("form.client.placeholder")}
              style={{ width: 120 }}
          />
        </Form.Item>
        
        <Form.Item name="isforce" label={t("add-edit-modal.form.isforce.label")} rules={[{ required: true, message: t("add-edit-modal.form.isforce.error") }]}>
          <Select
              options={(["yes", "no"] as const).map((key, value) => ({
                value:key,
                label: t(`add-edit-modal.form.isforce.options.${key}`),
              }))}
              placeholder={t("add-edit-modal.form.isforce.placeholder")}
              style={{ width: 120 }}
          />
        </Form.Item>
        <Form.Item
          name="title"
          label={t("add-edit-modal.form.title.label")}
          rules={[{
                  required: true,
                  message: t("add-edit-modal.form.title.error"),
                  whitespace: true,
                }
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="download_url"
          label={t("add-edit-modal.form.download_url.label")}
          rules={[{
                  required: true,
                  message: t("add-edit-modal.form.download_url.error.please-enter-url"),
                  whitespace: true,
                }
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item name="status" label={t("form.status.label")} rules={[{ required: true, message: t("add-edit-modal.form.status.error") }]}>
          <Select
              options={(["on", "off"] as const).map((key, value) => ({
                value:key,
                label: t(`add-edit-modal.form.status.options.${key}`),
              }))}
              placeholder={t("add-edit-modal.form.status.placeholder")}
              style={{ width: 120 }}
          />
        </Form.Item>       
        <Form.Item name="content" label={t("add-edit-modal.form.remark.label")}>
          <Input.TextArea showCount maxLength={200} />
        </Form.Item>
       
      </Form>
    </Modal>
  );
};

export default AddEditAppUpdateModal;