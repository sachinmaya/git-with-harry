import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery, useMutation, useQueryClient  } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, GetAppUpdateItem, GetAppUpdateRequestParams, DeleteAppUpdateRequestParams,AddEditAppUpdateRequestParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, Table, message, Select } from "antd";
import Icon from "@ant-design/icons";
import Text from "antd/lib/typography/Text";
import { ColumnsType } from "antd/es/table";
import { Link } from "react-router-dom";
import dayjs, { Dayjs } from "dayjs";
import classes from "./styles.module.scss";

import { FieldData } from "rc-field-form/lib/interface";
import SearchIcon from "~/components/icons/SearchIcon";
import AddIcon from "~/components/icons/AddIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import { TableRowSelection } from "antd/es/table/interface";
import { InternalServerError, NetworkError } from "~/api/errors";
import ConfirmModal from '~/views/AppUpdateView/ConfirmModal';
import AddEditAppUpdateModal from '~/views/AppUpdateView/AddEditAppUpdateModal'
import datePickerRangeToString from "~/utils/datePickerRangeToString";
const initialParams: GetAppUpdateRequestParams = {
  page_number: 1,
  show_number: 10,
};

const getBacklistQuery = (request: ApiRequest, params: GetAppUpdateRequestParams = initialParams) => ({
  queryKey: [actions.GET_APPUPDATE, params],
  queryFn: async () => request(actions.GET_APPUPDATE, params),
});

export const appUpdateViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getBacklistQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};


interface FormValues {
  client: string;
  status: string;
  filterRange: null | Dayjs[];
}

const initialValues: FormValues = {
  client: "all",
  status: "all",
  filterRange: null,
};
type ModalKey = "delete-app-update" ;
const AppUpdateView: React.FC = () => {
  const { t } = useTranslation("app-update-view");
  const [form] = Form.useForm();
  const { setDashboardHeading } = useDashboardView();
  const [visible, setVisible] = useState("");
  const [isMultipleDelete, setIsMultipleDelete] = useState(false);

  const request = useRequest();
  const [params, setParams] = useState<GetAppUpdateRequestParams>(initialParams);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<GetAppUpdateItem> | undefined>(undefined); 
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; appUpdateID: string  }>({
    open: false,
    key: "delete-app-update",
    appUpdateID: "",
  });
  const [openAddEditModal, setOpenAddEditModal] = useState<{ open: boolean; mode: "add" | "edit"; appUpdate?: GetAppUpdateItem,appId?:string }>({ open: false, mode: "add" });
  const queryClient = useQueryClient();

  const { data, refetch, isRefetching } = useQuery({
    ...getBacklistQuery(request, params),
    keepPreviousData: true,
    onError: () => {
      // TODO: show error message
    },
  });
  const deleteAppUpdateMutation = useMutation((id: DeleteAppUpdateRequestParams) => request(actions.DELETE_APPUPDATE, id), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_APPUPDATE]);
      message.open({
        key: "app-update-delete-successfully",
        type: "success",
        content: t("toasts.app-update-delete-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-app-update-failed",
        type: "error",
        content: t("toasts.delete-app-update-failed"),
      });
    },
  });
  useEffect(() => {
    setDashboardHeading("version", "app-update");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);
  
  const columns: ColumnsType<GetAppUpdateItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "version",
        dataIndex: "version",
        width: 160,
        title: t("columns.version"),
      },
      {
        key: "type",
        width: 160,
        dataIndex: "type",
        title: t("columns.client"),
        render: (text) => {
          let val = '';
          if (text == 1) {
            val = t("columns.client-area.ios");
          } else {
            val = t("columns.client-area.android");
          }
          return val;
        },
      },
      {
        key: "isforce",
        width: 160,
        dataIndex: "isforce",
        title: t("columns.force-upgrade"),
        render: (text) => {
          let val = '';
          if (text == 1) {
            val = t("columns.is-force-area.no");
          } else {
            val = t("columns.is-force-area.yes");
          }
          return val;
        },
      },
      {
        key: "title",
        width: 160,
        dataIndex: "title",
        title: t("columns.heading"),
        render: (value) => value || "-",
      },
      {
        key: "download_url",
        width: 160,
        dataIndex: "download_url",
        title: t("columns.url"),
        render: (value) => value || "-",
      },
      {
        key: "content",
        width: 160,
        dataIndex: "content",
        title: t("columns.update-statement"),
        render: (value) => value || "-",
      },
      {
        key: "create_time",
        width: 160,
        dataIndex: "create_time",
        title: t("columns.add-time"),
        render: (value) =>  value===0? "-":dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "status",
        width: 160,
        dataIndex: "status",
        title: t("columns.status"),
        render: (text) => {
          let val = '';
          if (text == 1) {
            val = t("columns.status-area.close");
          } else {
            val = t("columns.status-area.open");
          }
          return val;
        },
      },
      {
        key: "options",
        width: 160,
        title: t("columns.options"),
        fixed: "right",
        render: (value, record) => (
          <> 
          <button type="button" className="optionBtn" onClick={() => setOpenAddEditModal((state) => ({ ...state, open: true, mode: "edit",appUpdate:record, appId:record.id }))}>
              {t("options.edit")}
            </button>
            <button type="button" className="optionBtn optionBtnDanger" onClick={() => setOpenModal({ open: true, key: "delete-app-update", appUpdateID: record.id })}>
              {t("options.delete")}
            </button>
          </>
        )
      },
    ],
    [t]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ filterRange, client, status }: FormValues) => {
      setParams(({ show_number }) => {
        const state: GetAppUpdateRequestParams = { page_number: 1, show_number };
        if (client !== "") {
          state.client = client;
        }
        if (status !== "") {
          state.status = status;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToString(filterRange);
          state.create_time_begin = startTime;
          state.create_time_end = endTime;
        }
        return state;
      });
      refetch();
    },
    [setParams, refetch]
  );

  const handleFieldsChange = ([fieldData]: FieldData[]) => {
    
  };  


  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    deleteAppUpdateMutation.mutate({id:openModal.appUpdateID});  
  }, [deleteAppUpdateMutation.mutate, deleteSelection, openModal]);
  
  const addEditMutation = useMutation(
    (appUpdate: AddEditAppUpdateRequestParams) => (openAddEditModal.mode === "add" ? request(actions.ADD_APPUPDATE, appUpdate) : request(actions.EDIT_APPUPDATE, appUpdate)),
    {
      onSuccess: () => {
        //setOpenModal((state) => ({ ...state, open: false }));
        queryClient.invalidateQueries([actions.GET_APPUPDATE, params]);
        message.open({
          key: openAddEditModal.mode === "add" ? "app-update-added-success" : "app-update-edited-success",
          type: "success",
          content: openAddEditModal.mode === "add" ? t("toasts.app-update-added-success") : t("toasts.app-update-edited-success"),
        });
        handleAddEditModalCancel();
      },
      onError: (error) => {
        if (error instanceof NetworkError) {
          return message.open({
            key: "network-error",
            type: "error",
            content: t("errors.network-error.message"),
          });
        }
        if (error instanceof InternalServerError) {
          return message.open({
            key: "internal-server-error",
            type: "error",
            content: t("errors.internal-server-error.message"),
          });
        }
      },
    }
  );


  const handleAddEditModalOk = useCallback(
    (values: AddEditAppUpdateRequestParams, mode: "add" | "edit", appId:string | undefined) => {
      console.log(values);
      const mutateData = mode==="add"? values : {...values,id:appId}
      console.log(mutateData);
      console.log(appId);
      addEditMutation.mutate(mutateData);
    },
    [openAddEditModal]
  );


  const handleAddEditModalCancel = () => {
    setOpenAddEditModal((state) => ({ ...state, open: false, appId:undefined }));
    form.resetFields();
  }
  return (
    <>
      <Form className="filterForm"  layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="client" label={t("form.client.label")}>
          <Select
              options={(["all", "ios", "android"] as const).map((key, value) => ({
                value:key,
                label: t(`form.client.options.${key}`),
              }))}
              placeholder={t("form.client.placeholder")}
              style={{ width: 120 }}
          />
        </Form.Item>

        <Form.Item name="status" label={t("form.status.label")}>
          <Select                
                placeholder={t("form.status.placeholder")}
                options={(["all", "off", "on"] as const).map((key,value) => ({
                  value:key,
                  label: t(`form.status.options.${key}`),
                }))}
                style={{ width: 120 }}
          />
        </Form.Item>
        <Form.Item name="filterRange"  label={t("form.filter-time.options.create-time")}>
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item>
        <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={isRefetching} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        <Form.Item>
        <Button 
          className="filterBtn filterBtnSuccess" 
          type="primary" 
          htmlType="button" 
          icon={<Icon component={AddIcon} />} 
          onClick={() => setOpenAddEditModal((state) => ({ ...state, open: true, mode: "add", appUpdate:undefined }))}>
            {t("form.buttons.add")}
          </Button>
        </Form.Item>
       
      </Form>
      <Table
        rowKey={'id'}
        dataSource={data?.data.appversions}
        className="customTable"
        columns={columns}
        scroll={{ x: 640 }}
        loading={isRefetching}
        rowSelection={deleteSelection}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.total,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />

      <ConfirmModal
        open={openModal.open}
        type={openModal.key}
        onCancel={handleModalCancel}
        onOk={handleModalOk}
        confirmLoading={deleteAppUpdateMutation.isLoading}
      />
      <AddEditAppUpdateModal
        appUpdate={openAddEditModal.appUpdate}
        onFormSubmit={handleAddEditModalOk}
        open={openAddEditModal.open}
        onCancel={handleAddEditModalCancel}
        mode={openAddEditModal.mode}
        appId = {openAddEditModal.appId}
      />

    </>
  );
};

export default AppUpdateView;
