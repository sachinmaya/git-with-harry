import React from "react";
import { Modal, ModalProps } from "antd";
import { useTranslation } from "react-i18next";

type ModalType = "delete-app-update";

interface DisableConfirmModalProps extends ModalProps {
  type: ModalType;
}

const ConfirmModal: React.FC<DisableConfirmModalProps> = ({ type, ...props }) => {
  const { t } = useTranslation("app-update-view");
  return (
    <Modal
      className="confirmModal"
      okButtonProps={{ danger: ["delete-app-update"].includes(type) }}
      okText={t(`modals.delete-app-update.buttons.ok`)}
      cancelText={t(`modals.delete-app-update.buttons.cancel`)}
      destroyOnClose
      {...props}
    >
      {t(`modals.delete-app-update.content`)}
    </Modal>
  );
};

export default ConfirmModal;
