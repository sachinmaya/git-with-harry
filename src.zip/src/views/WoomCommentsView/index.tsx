import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, GetWoomCommentsItem, GetWoomCommentsRequestParams, DeleteWoomCommentsRequestParams, EditWoomCommentsRequestParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, Select, Table, message } from "antd";
import Icon, { PlaySquareOutlined } from "@ant-design/icons";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import { ColumnsType } from "antd/es/table";
import { Link, useLocation } from "react-router-dom";
import dayjs, { Dayjs } from "dayjs";
import { FieldData } from "rc-field-form/lib/interface";
import ConfirmModal from "./ConfirmModal";
import MediaModal from "./MediaModal";
import EditModal from "./EditModal";
import "./index.scss";
import usePermissions from "~/hooks/usePermissions";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";

const getLocationSearch = () => {
  const search = location.search;
  const params = { fid: "" };
  if (search) {
    decodeURI(search)
      .slice(1)
      .split("&")
      .forEach((item) => {
        const p = item.split("=");
        if (p[0] === "fid") params.fid = p[1];
      });
  }
  return params;
};

const { fid } = getLocationSearch();

const initialParams: GetWoomCommentsRequestParams = {
  page_number: 1,
  show_number: 10,
  fileId: fid,
};

const getWoomCommentsQuery = (request: ApiRequest, params: GetWoomCommentsRequestParams = initialParams) => ({
  queryKey: [actions.GET_WOOM_COMMENTS, params],
  queryFn: async () => request(actions.GET_WOOM_COMMENTS, params),
});

export const woomCommentsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getWoomCommentsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

const getShortVideoType = (type: number) => {
  switch (type) {
    case 0:
      return "0";
    case 1:
      return "1";
    case 3:
      return "3";
    case 4:
      return "4";
    case 5:
      return "5";
  }
};

interface FormValues {
  userId: string;
  status: number;
  emptyDesc: number;
  desc: string;
  filterRange: null | Dayjs[];
  fileId: string;
  commentUserId: string;
  context: string;
}

const initialValues: FormValues = {
  userId: "",
  status: 0,
  emptyDesc: 0,
  desc: "",
  filterRange: null,
  fileId: fid,
  commentUserId: "",
  context: "",
};

type ModalKey = "multiple-delete" | "delete-comment";

const WoomCommentsView: React.FC = () => {
  const { t } = useTranslation("woom-comments-view");
  const { isActionAllowed, isPageAllowed } = usePermissions();
  const request = useRequest();
  const queryClient = useQueryClient();

  if (!isActionAllowed(actions.GET_WOOM_COMMENTS)) return null;

  // 查询
  const [emptyDescSelectValue, setEmptyDescSelectValue] = useState<number>(0);
  const [params, setParams] = useState<GetWoomCommentsRequestParams>(initialParams);
  const { data, isRefetching } = useQuery({
    ...getWoomCommentsQuery(request, params),
    keepPreviousData: true,
    onError: () => {},
  });

  // 删除
  const [commentIdList, setCommentIdList] = useState<string[]>([]);
  const deleteWoomCommentsMutation = useMutation((commentIdList: DeleteWoomCommentsRequestParams) => request(actions.DELETE_WOOM_COMMENTS, commentIdList), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_WOOM_COMMENTS]);
      message.open({
        key: "comment-delete-successfully",
        type: "success",
        content: t("toasts.delete-successfully"),
      });
    },
  });

  // 多选
  const [multipleChoice, setMultipleChoice] = useState<boolean>(false);
  const handleMultipleChoice = () => {
    setMultipleChoice(!multipleChoice);
    if (multipleChoice && commentIdList.length > 0) setCommentIdList([]);
  };
  const rowSelection: any = {
    columnWidth: 50,
    selectedRowKeys: commentIdList,
    onChange: (selectedRowKeys: any) => setCommentIdList(selectedRowKeys),
    renderCell: false,
  };

  // Confirm Modal
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; id: string }>({
    open: false,
    key: "multiple-delete",
    id: "",
  });
  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    switch (openModal.key) {
      case "multiple-delete":
        deleteWoomCommentsMutation.mutate({ commentIdList });
        setCommentIdList([]);
        break;
      case "delete-comment":
        deleteWoomCommentsMutation.mutate({ commentIdList: [openModal.id] });
        break;
    }
  }, [deleteWoomCommentsMutation.mutate, openModal]);

  // Media Modal
  const [openMediaModal, setOpenMediaModal] = useState<{ open: boolean; mediaURL: string }>({ open: false, mediaURL: "" });

  // Edit Modal
  const [openEditModal, setOpenEditModal] = useState<{ open: boolean; row: GetWoomCommentsItem; context: string; remark: string }>({
    open: false,
    row: {},
    context: "",
    remark: "",
  });
  // 编辑
  const editWoomCommentsMutation = useMutation((data: EditWoomCommentsRequestParams) => request(actions.EDIT_WOOM_COMMENTS, data), {
    onSuccess: () => {
      setOpenEditModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_WOOM_COMMENTS]);
      message.open({
        key: "comment-update-successfully",
        type: "success",
        content: t("toasts.update-successfully"),
      });
    },
  });
  // 保存编辑
  const saveEdit = () => {
    const data = {
      commentId: openEditModal.row.id,
      remark: openEditModal.remark,
      content: openEditModal.context,
    };
    editWoomCommentsMutation.mutate(data);
  };

  const columns: ColumnsType<GetWoomCommentsItem> = useMemo(
    () => [
      {
        key: "idx",
        width: 80,
        title: t("columns.idx"),
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "post-user",
        width: 160,
        title: t("columns.post-user"),
        render: (row) => (
          <>
            {row.postUserName || row.postUserId ? (
              <>
                <div className="text-no-wrap">{row.postUserName}</div>
                <div className="text-no-wrap">{row.postUserId}</div>
              </>
            ) : (
              <>{t("columns.deleted-user")}</>
            )}
          </>
        ),
      },
      {
        key: "short-video-type",
        width: 160,
        title: t("columns.short-video-type"),
        dataIndex: "fileStatus",
        render: (value) => {
          const shortVideoType = getShortVideoType(value);
          return shortVideoType && <div style={{ color: value === 5 ? "red" : undefined }}>{t(`enums.short-video-type.${shortVideoType}`)}</div>;
        },
      },
      {
        key: "short-video",
        width: 160,
        title: t("columns.short-video"),
        render: (row) => (
          <div className="video-cover">
            <Image preview={false} src={row.coverUrl} />
            <span className="video-play-icon" onClick={() => setOpenMediaModal({ open: true, mediaURL: row.mediaUrl })}>
              <PlaySquareOutlined />
            </span>
          </div>
        ),
      },
      {
        key: "commenter",
        width: 160,
        title: t("columns.commenter"),
        render: (row) => (
          <>
            {row.userName || row.userId ? (
              <>
                <div className="text-no-wrap">{row.userName}</div>
                <div className="text-no-wrap">{row.userId}</div>
              </>
            ) : (
              <>{t("columns.deleted-user")}</>
            )}
          </>
        ),
      },
      {
        key: "comment-time",
        width: 160,
        title: t("columns.comment-time"),
        dataIndex: "creatTime",
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "comment",
        width: 160,
        title: t("columns.comment"),
        dataIndex: "context",
      },
      {
        key: "comment-like",
        width: 160,
        title: t("columns.comment-like"),
        render: (row) => <>{isPageAllowed("/woom/woomCommentLike") && row.likeNum > 0 ? <Link to={`/woom/woomCommentLike?cid=${row.id}`}>{row.likeNum}</Link> : row.likeNum}</>,
      },
      {
        key: "comment-reply",
        width: 160,
        title: t("columns.comment-reply"),
        render: (row) => <>{isPageAllowed("/woom/woomSubComment") && row.replyNum > 0 ? <Link to={`/woom/woomSubComment?cid=${row.id}`}>{row.replyNum}</Link> : row.replyNum}</>,
      },
      {
        key: "comment-remark",
        width: 160,
        title: t("columns.comment-remark"),
        dataIndex: "remark",
      },
      {
        key: "operation",
        width: 160,
        title: t("columns.operation"),
        fixed: "right",
        align: "center",
        render: (row) => (
          <>
            {isActionAllowed(actions.EDIT_WOOM_COMMENTS) && (
              <div>
                <button className="optionBtn" onClick={() => setOpenEditModal({ open: true, row, context: row.context, remark: row.remark })}>
                  {t("columns.opt-edit")}
                </button>
              </div>
            )}
            {isActionAllowed(actions.DELETE_WOOM_COMMENTS) && (
              <div>
                <button className="optionBtn optionBtnDanger" onClick={() => setOpenModal({ open: true, key: "delete-comment", id: row.id })}>
                  {t("columns.opt-delete")}
                </button>
              </div>
            )}
          </>
        ),
      },
    ],
    [t]
  );

  const handleFinnish = useCallback(
    ({ userId, status, emptyDesc, desc, filterRange, fileId, commentUserId, context }: FormValues) => {
      setParams(({ show_number }) => {
        const state: GetWoomCommentsRequestParams = { page_number: 1, show_number, status, emptyDesc };
        if (userId !== "") {
          state.userId = userId;
        }
        if (emptyDesc == 0 && desc !== "") {
          state.desc = desc;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.startTime = startTime;
          state.endTime = endTime;
        }
        if (fileId !== "") {
          state.fileId = fileId;
        }
        if (commentUserId !== "") {
          state.commentUserId = commentUserId;
        }
        if (context !== "") {
          state.context = context;
        }
        return state;
      });
    },
    [setParams]
  );

  const handleFieldsChange = useCallback(
    ([fieldData]: FieldData[]) => {
      if (fieldData) {
        const { name, value } = fieldData;
        if (Array.isArray(name) && name[0] === "emptyDesc") {
          setEmptyDescSelectValue(value);
        }
      }
    },
    [setEmptyDescSelectValue]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) => {
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      }));
    },
    [setParams]
  );

  const { setDashboardHeading } = useDashboardView();
  useEffect(() => {
    setDashboardHeading("woom", "woom-comments");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const [form] = Form.useForm();
  const location = useLocation();
  useEffect(() => {
    const { fid } = getLocationSearch();
    const oldFid = form.getFieldValue("fileId");
    if (fid != oldFid) {
      form.setFieldValue("fileId", fid);
      form.submit();
    }
  }, [location]);

  return (
    <>
      <Form className="filterForm" form={form} layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="userId" label={t("form.userId.label")}>
          <Input />
        </Form.Item>
        <Form.Item name="status" label={t("form.status.label")}>
          <Select
            options={([0, 4, 1, 5] as const).map((value) => ({
              value,
              label: t(`form.status.options.${value}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="emptyDesc" label={t("form.emptyDesc.label")}>
          <Select
            options={(["all", "empty"] as const).map((key, value) => ({
              value,
              label: t(`form.emptyDesc.options.${key}`),
            }))}
          />
        </Form.Item>
        {emptyDescSelectValue !== 1 && (
          <Form.Item name="desc">
            <Input />
          </Form.Item>
        )}
        {emptyDescSelectValue === 1 && (
          <Form.Item>
            <Input disabled />
          </Form.Item>
        )}
        <Form.Item name="filterRange" label={t("form.comment-time.label")}>
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item name="fileId" label="Woom ID">
          <Input />
        </Form.Item>
        <Form.Item name="commentUserId" label={t("form.commentUserId.label")}>
          <Input placeholder={t("form.commentUserId.placeholder")} />
        </Form.Item>
        <Form.Item name="context" label={t("form.context.label")}>
          <Input placeholder={t("form.context.placeholder")} />
        </Form.Item>

        {/* 搜索 */}
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={isRefetching} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>

        {multipleChoice && (
          <>
            {/* 取消 */}
            <Form.Item>
              <Button className="filterBtn filterBtnPlain" type="primary" onClick={handleMultipleChoice}>
                {t("form.buttons.cancel")}
              </Button>
            </Form.Item>

            {/* 删除 */}
            <Form.Item>
              <Button
                className="filterBtn filterBtnDanger"
                type="primary"
                disabled={!commentIdList.length}
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", id: "" })}
              >
                {t("form.buttons.delete")}
              </Button>
            </Form.Item>
          </>
        )}

        {/* 批量删除 */}
        {isActionAllowed(actions.DELETE_WOOM_COMMENTS) && !multipleChoice && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleChoice}>
              {t("form.buttons.multi")}
            </Button>
          </Form.Item>
        )}
      </Form>

      <Table
        rowKey="id"
        className="customTable"
        dataSource={data?.data.shortVideoCommentList}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isRefetching}
        rowSelection={multipleChoice && { ...rowSelection }}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.shortVideoCommentCount,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />

      <ConfirmModal open={openModal.open} type={openModal.key} onCancel={handleModalCancel} onOk={handleModalOk} confirmLoading={deleteWoomCommentsMutation.isLoading} />
      <MediaModal open={openMediaModal.open} onCancel={() => setOpenMediaModal((state) => ({ ...state, open: false }))} mediaURL={openMediaModal.mediaURL} />
      <EditModal t={t} save={saveEdit} data={openEditModal} setData={setOpenEditModal} />
    </>
  );
};

export default WoomCommentsView;
