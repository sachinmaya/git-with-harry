import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, GetGameListItem, GetGameListRequestParams, GetCategoriesRequestParams, EditGamesRequestParams, AddGamesRequestParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, Select, Table, Rate, Modal, Upload, Checkbox, Space, Radio, Switch, Row, Col, message } from "antd";
import type { RadioChangeEvent } from "antd";
import type { CheckboxValueType } from "antd/es/checkbox/Group";
import { ColumnsType } from "antd/es/table";
import dayjs, { Dayjs } from "dayjs";
import SearchIcon from "~/components/icons/SearchIcon";
import AddIcon from "~/components/icons/AddIcon";
import Text from "antd/lib/typography/Text";
import { systemDefaultLocale } from "~/lib/i18next";
import { PlusOutlined, PaperClipOutlined, DeleteOutlined } from "@ant-design/icons";
import { InternalServerError, NetworkError } from "~/api/errors";
import type { RcFile, UploadProps } from "antd/es/upload";
import type { UploadFile } from "antd/es/upload/interface";
import axios, { AxiosProgressEvent, AxiosRequestConfig } from "axios";
import usePermissions from "~/hooks/usePermissions";
import { useAuth } from "~/hooks/useAuth";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";

const { TextArea } = Input;

const initialParams: GetGameListRequestParams = {
  page_number: 1,
  show_number: 10,
  operation_id: "get_game_list",
};

const getGameListQuery = (request: ApiRequest, params: GetGameListRequestParams = initialParams) => ({
  queryKey: [actions.GAMEMANAGE_GETGAMELIST, params],
  queryFn: async () => request(actions.GAMEMANAGE_GETGAMELIST, params),
});

const getCategoriesQuery = (
  request: ApiRequest,
  params: GetCategoriesRequestParams = {
    page_number: 1,
    show_number: -1,
    operation_id: "get_category_list",
    state: 1,
  }
) => ({
  queryKey: [actions.CATEGORYMANAGE_GETCATEGORY, params],
  queryFn: async () => request(actions.CATEGORYMANAGE_GETCATEGORY, params),
});

export const gameManagementViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getGameListQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  gameCodeVal: string;
  gameNameVal: string;
  categoriesVal: any;
  activityVal: any;
  platformVal: any;
  publisherVal: string;
  hotValue: any;
  stateVal: any;
  rangePickerVal: null | Dayjs[];
}

const initialValues: FormValues = {
  gameCodeVal: "",
  gameNameVal: "",
  categoriesVal: "",
  activityVal: "",
  platformVal: "",
  publisherVal: "",
  hotValue: "",
  stateVal: "",
  rangePickerVal: null,
};

interface PlatForm {
  1?:
    | {
        file_name?: string;
        package_url?: string;
        play_url?: string;
        size?: number;
        upload_time?: number;
      }
    | undefined;
  2?:
    | {
        file_name?: string;
        package_url?: string;
        play_url?: string;
        size?: number;
        upload_time?: number;
      }
    | undefined;
  3?:
    | {
        file_name?: string;
        package_url?: string;
        play_url?: string;
        size?: number;
        upload_time?: number;
      }
    | undefined;

  [key: number]:
    | {
        file_name?: string;
        package_url?: string;
        play_url?: string;
        size?: number;
        upload_time?: number;
      }
    | undefined;
}

const GameManagementView: React.FC = () => {
  const { t } = useTranslation("game-management-view");
  const { isActionAllowed } = usePermissions();
  const { value } = useAuth();
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const [params, setParams] = useState<GetGameListRequestParams>(initialParams);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [dataList, setDataList] = useState<GetGameListItem[] | undefined>(undefined);

  if (!isActionAllowed(actions.GAMEMANAGE_GETGAMELIST)) return null;

  const queryClient = useQueryClient();

  const { data, isPreviousData } = useQuery({
    ...getGameListQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "game-list-query-failed",
        type: "error",
        content: t("toasts.game-list-query-failed"),
      });
    },
  });
  useEffect(() => {
    const datalist = data?.data.game_list?.map((item, index) => ({
      ...item,
      key: item.game_code,
      number: index + 1 + (params.page_number * params.show_number - params.show_number),
    }));
    setDataList(datalist);
  }, [data]);

  const { data: categorydata, isRefetching: categoryIsRefetching } = useQuery({
    ...getCategoriesQuery(request, { page_number: 1, show_number: -1, operation_id: "get_category_list", state: 1 }),
    keepPreviousData: true,
    onError: () => {
      // TODO: show error message
    },
  });
  //   获取分类列表数据的请求方法;
  const currentLang = localStorage.getItem("i18nextLng") || systemDefaultLocale;
  const [categoryList, setCategoryList] = useState<
    | {
        value: string;
        label: string;
      }[]
    | undefined
  >(undefined);
  useEffect(() => {
    const datalist = categorydata?.data.category_list;
    if (currentLang == "en-US") {
      const array = datalist?.map((obj) => ({
        value: obj.category_id.toString(),
        label: obj.categories.en,
      }));

      return setCategoryList(array);
    } else if (currentLang == "zh-CN") {
      const array = datalist?.map((obj) => ({
        value: obj.category_id.toString(),
        label: obj.categories.cn,
      }));

      return setCategoryList(array);
    }
  }, [categorydata, currentLang]);

  useEffect(() => {
    setDashboardHeading("game-store", "game-management");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  //展示horizontal cover 的方法
  const [visible, setVisible] = useState<any>(null);
  const showImagesGallery = (game_id: string, horizontal_cover_Img: string[]) => {
    try {
      const horizontalCoverImgArry = horizontal_cover_Img;
      if (horizontalCoverImgArry.length === 0) return t("toasts.no-media");
      return (
        <>
          <Image
            preview={{ visible: false }}
            width={100}
            height={50}
            // src={`${horizontalCoverImgArry[0]}`}
            src={horizontalCoverImgArry[0]}
            onClick={() => setVisible(game_id)}
          />
          <div style={{ display: "none" }}>
            <Image.PreviewGroup
              preview={{
                visible: visible === game_id,
                onVisibleChange: (vis) => setVisible(vis ? game_id : null),
              }}
            >
              {horizontalCoverImgArry.map((item, index) => {
                return <Image src={item} key={index} />;
              })}
            </Image.PreviewGroup>
          </div>
        </>
      );
    } catch (error) {
      return "no-media";
    }
  };

  //展示list cover的方法
  const showListCover = (img: string) => {
    try {
      const listCoverImg = img;
      if (listCoverImg === undefined) return "no-media";

      return <Image width={50} height={50} src={listCoverImg} />;
    } catch (error) {
      return "no-media";
    }
  };

  const columns: ColumnsType<GetGameListItem> = useMemo(
    () => [
      {
        title: t("table.serial-number"),
        dataIndex: "number",
        width: 80,
        // render: (value, record, index) => index + 1 + (params.page_number * params.show_number - params.show_number),
      },
      {
        title: t("table.game-code"),
        dataIndex: "game_code",
        width: 120,
      },
      {
        title: t("table.game-NameCN"),
        dataIndex: "game_name",
        width: 150,
        render: (text) => {
          return text?.cn;
        },
      },
      {
        title: t("table.game-NameEN"),
        dataIndex: "game_name",
        width: 150,
        render: (text) => {
          return text?.en;
        },
      },
      {
        title: t("table.gameDescCN"),
        dataIndex: "description",
        width: 160,
        render: (text) => {
          return (
            <Text style={{ width: 160 }} ellipsis={{ tooltip: text?.cn }}>
              {text?.cn}
            </Text>
          );
        },
      },
      {
        title: t("table.gameDescEN"),
        dataIndex: "description",
        width: 160,
        render: (text) => {
          return (
            <Text style={{ width: 160 }} ellipsis={{ tooltip: text?.en }}>
              {text?.en}
            </Text>
          );
        },
      },
      {
        title: t("table.horizontal-cover"),
        dataIndex: "horizontal_cover",
        width: 160,
        render: (_, record) => {
          return showImagesGallery(record.game_code, record.horizontal_cover);
        },
      },
      {
        title: t("table.list-cover"),
        dataIndex: "list_cover",
        width: 150,
        render: (_, record) => {
          return showListCover(record.cover_img);
        },
      },
      {
        title: t("table.categoriesCN"),
        dataIndex: "categories",
        width: 150,
        render: (text) => {
          if (text !== null) {
            const arrCN = text?.map((item: { category: { cn: string } }) => {
              return item.category.cn;
            });
            return arrCN.join("，");
          } else {
            return "-";
          }
        },
      },
      {
        title: t("table.categoriesEN"),
        dataIndex: "categories",
        width: 150,
        render: (text) => {
          if (text !== null) {
            const arrEN = text?.map((item: { category: { en: string } }) => {
              return item.category.en;
            });
            return arrEN.join("，");
          } else {
            return "-";
          }
        },
      },
      {
        title: t("table.activity-classify"),
        dataIndex: "classification",
        width: 150,
        render: (text) => {
          try {
            if (text) {
              const arr = text?.map((item: "1" | "2") => {
                return t(`classification.${item}`);
              });

              return arr.join("、");
            } else {
              return "-";
            }
          } catch (error) {
            return "-";
          }
        },
      },
      {
        title: t("table.support-platform"),
        dataIndex: "platform_link",
        width: 150,
        render: (text) => {
          try {
            const arrKey = Object.keys(text) as ("1" | "2" | "3")[];
            if (arrKey.length !== 0) {
              const arr = arrKey.map((item) => {
                return t(`platform.${item}`);
              });

              return arr.join("、");
            } else {
              return "-";
            }
          } catch (error) {
            return "-";
          }
        },
      },
      {
        title: t("table.publisher"),
        dataIndex: "publisher",
        width: 150,
        render: (text) => {
          if (text == "") {
            return "-";
          } else {
            return text;
          }
        },
      },
      {
        title: t("table.priority"),
        dataIndex: "sort_priority",
        width: 150,
      },
      {
        title: t("table.hot"),
        dataIndex: "hot",
        width: 180,
        render: (_, record) => {
          try {
            if (record.hot) {
              return <Rate value={record.hot} count={record.hot} disabled />;
            } else {
              return "no data";
            }
          } catch (error) {
            return "no data";
          }
        },
      },
      {
        title: t("table.state"),
        dataIndex: "state",
        width: 150,
        render: (text) => {
          return text === 1 ? t("table.on") : t("table.off");
        },
      },
      {
        title: t("table.create-time"),
        dataIndex: "create_time",
        width: 150,
        render: (text) => {
          let cDate = dayjs(text * 1000).format("YYYY/MM/DD  HH:mm:ss");
          return text === 0 ? "-" : cDate;
        },
      },
      {
        title: t("table.operate"),
        dataIndex: "operate",
        fixed: "right",
        width: 140,
        render: (_, record) => {
          return (
            <div>
              {isActionAllowed(actions.GAMEMANAGE_EDITGAMELIST) && (
                <Button className="optionBtn" onClick={() => showFormModal("edit", record.game_code)} type="primary" htmlType="button" size="small">
                  {t("button.edit")}
                </Button>
              )}
              {isActionAllowed(actions.GAMEMANAGE_DELETEGAMELIST) && (
                <Button className="optionBtn optionBtnDanger" onClick={() => handleDelete(record.game_code)} type="primary" htmlType="button" danger size="small">
                  {t("button.delete")}
                </Button>
              )}
            </div>
          );
        },
      },
    ],
    [t, visible]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ gameCodeVal, gameNameVal, categoriesVal, activityVal, platformVal, publisherVal, hotValue, stateVal, rangePickerVal }: FormValues) => {
      setParams(({ show_number }) => {
        const state: GetGameListRequestParams = {
          page_number: 1,
          show_number,
          operation_id: "get_game_list",
        };
        if (gameCodeVal !== "") {
          state.game_code = gameCodeVal;
        }
        if (gameNameVal !== "") {
          state.game_name = gameNameVal;
        }
        if (categoriesVal !== "") {
          state.category = categoriesVal;
        }
        if (activityVal !== "") {
          state.classification = activityVal;
        }
        if (platformVal !== "") {
          state.platform = platformVal;
        }
        if (publisherVal !== "") {
          state.publisher = publisherVal;
        }
        if (hotValue !== "") {
          state.hot = hotValue;
        }
        if (stateVal !== "") {
          state.state = stateVal;
        }
        if (rangePickerVal !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(rangePickerVal);
          state.start_time = startTime;
          state.end_time = endTime;
        }
        return state;
      });
      setSearchLoading(true);
    },
    [setParams]
  );

  //删除的弹出框
  const [visibleDeleteModal, setVisibleDeleteModal] = useState(false);
  const [deleteCode, setDeleteCode] = useState<string>("");
  const handleCancelDelete = () => {
    setVisibleDeleteModal(false);
  };
  const handleDelete = (code: string) => {
    setDeleteCode(code);
    setVisibleDeleteModal(true);
  };

  //删除
  const deleteGameMutation = useMutation((games_code: string[]) => request(actions.GAMEMANAGE_DELETEGAMELIST, { games_code }), {
    onSuccess: () => {
      setVisibleDeleteModal(false);
      queryClient.invalidateQueries([actions.GAMEMANAGE_GETGAMELIST]);
      message.open({
        key: "game-deleted-successfully",
        type: "success",
        content: t("form.game-deleted-successfully"),
      });
    },
  });

  //编辑
  const editGameMutation = useMutation((EditData: EditGamesRequestParams) => request(actions.GAMEMANAGE_EDITGAMELIST, EditData), {
    onSuccess: () => {
      setModalVisible(false);
      queryClient.invalidateQueries([actions.GAMEMANAGE_GETGAMELIST]);
      message.open({
        key: "edit-success",
        type: "success",
        content: t("form.error.edit-success"),
      });
    },
  });

  //添加
  const addGameMutation = useMutation((AddData: AddGamesRequestParams) => request(actions.GAMEMANAGE_ADDGAMELIST, AddData), {
    onSuccess: () => {
      setModalVisible(false);
      queryClient.invalidateQueries([actions.GAMEMANAGE_GETGAMELIST]);
      message.open({
        key: "add-success",
        type: "success",
        content: t("form.error.add-success"),
      });
    },
  });

  //上传按钮
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div
        style={{
          marginTop: 8,
        }}
      >
        {t("button.selectPic")}
      </div>
    </div>
  );

  //   表单状态
  const [form] = Form.useForm();
  const [formType, setFormType] = useState("add");
  const [modalVisible, setModalVisible] = useState(false);
  const [gameCodeDisable, setGameCodeDisable] = useState(false);
  const [listcoverNoteShow, setListcoverNoteShow] = useState(false);
  const [horizontalNoteShow, sethorizontalNoteShow] = useState(false);
  const [categoryNoteShow, setCategoryNoteShow] = useState(false);
  const [platformNoteShow, setPlatformNoteShow] = useState(false);
  //行数据的ID
  const [editId, setEditId] = useState<string | null>(null);

  //表单输入框的值
  //game code
  const [formGameCode, setFormGameCode] = useState<string | undefined>("");
  const handleFormGameCode = (e: { target: { value: string } }) => {
    setFormGameCode(e.target.value);
  };
  //game name Cn
  const [formGameNameCn, setSormGameNameCn] = useState<string | undefined>("");
  const handleFormGameNameCN = (e: { target: { value: string } }) => {
    setSormGameNameCn(e.target.value);
  };
  //game name En
  const [formGameNameEn, setSormGameNameEn] = useState<string | undefined>("");
  const handleFormGameNameEN = (e: { target: { value: string } }) => {
    setSormGameNameEn(e.target.value);
  };
  // GAME PUBLISHER
  const [formPublisher, setFormPublisher] = useState<string | undefined>("");
  const handleFormPublisher = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFormPublisher(e.target.value);
  };
  //game desc Cn
  const [formGameDescCn, setFormGameDescCn] = useState<string | undefined>("");
  const handleFormGameDescCN = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFormGameDescCn(e.target.value);
  };
  //game desc En
  const [formGameDescEn, setFormGameDescEn] = useState<string | undefined>("");
  const handleFormGameDescEN = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFormGameDescEn(e.target.value);
  };
  //horizontal cover list
  const [horizentalList, setHorizentalList] = useState<UploadFile[]>([]);
  const handleHorizontalChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setHorizentalList(newFileList);
    if (newFileList.length === 0) {
      sethorizontalNoteShow(true);
    } else {
      sethorizontalNoteShow(false);
    }
  };
  const [previewHorizontalOpen, setPreviewHorizontalOpen] = useState<boolean>(false);
  const [previewHorizontalImage, setPreviewHorizontalImage] = useState<string>("");
  const [previewHorizontalTitle, setPreviewHorizontalTitle] = useState<string>("");
  const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  const handleHorizontalPreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as RcFile);
    }
    setPreviewHorizontalImage(file.url || (file.preview as string));
    setPreviewHorizontalOpen(true);
    setPreviewHorizontalTitle(file.name || file.url!.substring(file.url!.lastIndexOf("/") + 1));
  };
  const handleHorizontalCancel = () => setPreviewHorizontalOpen(false);
  //list cover
  const [listcover, setListcover] = useState<UploadFile[]>([]);
  const handleListCoverChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setListcover(newFileList);
    if (newFileList.length === 0) {
      setListcoverNoteShow(true);
    } else {
      setListcoverNoteShow(false);
    }
  };
  const [previewListCoverOpen, setPreviewListCoverOpen] = useState(false);
  const [previewListCoverImage, setPreviewListCoverImage] = useState("");
  const [previewListCoverTitle, setPreviewListCoverTitle] = useState("");
  const handleListCoverPreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as RcFile);
    }
    setPreviewListCoverImage(file.url || (file.preview as string));
    setPreviewListCoverOpen(true);
    setPreviewListCoverTitle(file.name || file.url!.substring(file.url!.lastIndexOf("/") + 1));
  };
  const handleListCoverCancel = () => setPreviewListCoverOpen(false);
  //表单分类选中个数
  const [selectCategories, setSelectCategories] = useState<any[] | undefined>([]);
  // 分类禁止的选项
  const disabledOptions = (selectCategories?.length as number) >= 5 ? categoryList?.filter((item) => !selectCategories?.includes(item.value)) : [];
  const handleSelectCategories = (checkedValue: any[]) => {
    if (checkedValue.length <= 5) {
      setSelectCategories(checkedValue);
    }

    if (checkedValue.length === 0) {
      setCategoryNoteShow(true);
    } else {
      setCategoryNoteShow(false);
    }
  };
  //表单热度值
  const [formHotVal, SetFormHotVal] = useState<number | undefined>(5);
  const handleFormHotVal = (hotval: number) => {
    SetFormHotVal(hotval);
  };
  //表单活动选中个数
  const [selectActivity, setSelectActivity] = useState<any[] | undefined>([]);
  const handleSelectActivity = (checkedValues: CheckboxValueType[]) => {
    setSelectActivity(checkedValues);
  };
  //支持平台
  //   H5
  const [h5Checked, setH5Checked] = useState(false);
  const handleH5Change = (e: { target: { checked: boolean | ((prevState: boolean) => boolean) } }) => {
    setH5Checked(e.target.checked);
  };
  const [h5Link, setH5Link] = useState<string | undefined>("");
  const handleH5Link = (e: { target: { value: string } }) => {
    setH5Link(e.target.value);
  };
  //android
  const [androidChecked, setAndroidChecked] = useState(false);
  const handleAndroidChange = (e: { target: { checked: boolean | ((prevState: boolean) => boolean) } }) => {
    setAndroidChecked(e.target.checked);
  };
  const [androidType, setAndroidType] = useState<any>(1);
  const handleAndroidType = ({ target: { value } }: RadioChangeEvent) => {
    setAndroidType(value);
  };
  const [androidLink, setAndroidLink] = useState<string | undefined>("");
  const handleAndroidLink = (e: { target: { value: string } }) => {
    setAndroidLink(e.target.value);
  };

  //androidList only contain the file info只包含文件显示信息
  const [androidList, setAndroidList] = useState<
    {
      fname: string | undefined;
      fsize: number | undefined;
      flastModified: number | undefined;
    }[]
  >([]);
  // 安卓链接
  const [androidPackageUrl, setAndroidPackageUrl] = useState<string | undefined>("");

  const [androidFile, setAndroidFile] = useState<UploadFile[]>([]);
  const handleAndroidFile: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setAndroidList([
      {
        fname: newFileList[0].name,
        fsize: newFileList[0].size,
        flastModified: newFileList[0].lastModified ?? 0,
      },
    ]);
    setAndroidFile(newFileList);
  };

  //iOS
  const [iosChecked, setIosChecked] = useState<boolean>();
  const handleIosChange = (e: { target: { checked: boolean } }) => {
    setIosChecked(e.target.checked);
  };
  const [iosLink, setIosLink] = useState<string | undefined>();
  const handleIosLink = (e: { target: { value: string } }) => {
    setIosLink(e.target.value);
  };
  //表单优先权
  const [formPriority, setFormPriority] = useState<any>(0);
  const handleFormPriority = (e: { target: { value: string } }) => {
    setFormPriority(e.target.value);
  };
  //表单状态值
  const [formState, setFormState] = useState(true);

  // 删除安卓文件;
  const handleRemove = () => {
    setAndroidList([]);
    setAndroidFile([]);
    setAndroidPackageUrl("");
  };

  //触发弹出框的方法
  const showFormModal = (type: string, id = "") => {
    const data_id = id;
    if (data_id) {
      setEditId(data_id);
      setGameCodeDisable(true);
      const gameById = dataList?.find((item) => item.game_code === data_id);
      let selectedCategoryById: any[] | undefined = [];
      if (gameById?.categories !== null) {
        selectedCategoryById = gameById?.categories.map((item) => {
          return item.category.id;
        });
      }
      form.setFieldsValue({
        gameCode: gameById?.game_code,
        gameNameCn: gameById?.game_name.cn,
        gameNameEn: gameById?.game_name.en,
        publisher: gameById?.publisher,
        gameDescCn: gameById?.description?.cn,
        gameDescEn: gameById?.description?.en,
        categories: selectedCategoryById,
        hot: gameById?.hot,
        activity: gameById?.classification,
        priority: gameById?.sort_priority,
        state: gameById?.state,
      });
      let id = 0;
      const horizontal_images =
        gameById?.horizontal_cover &&
        gameById?.horizontal_cover.map((item, index) => {
          id += id;
          let urlArr = item.split("/");
          return {
            key: index + 1,
            uid: `-${index + 1}`,
            name: urlArr[urlArr.length - 1],
            status: "done",
            url: item,
          } as UploadFile;
        });

      setHorizentalList(horizontal_images || []);

      let list_cover =
        gameById?.cover_img &&
        ([gameById?.cover_img].map((item, index) => {
          id += id;
          let urlArr = item.split("/");
          return {
            key: index + 1,
            uid: `-${index + 1}`,
            name: urlArr[urlArr.length - 1],
            status: "done",
            url: item,
          };
        }) as UploadFile[]);
      setSormGameNameCn(gameById?.game_name.cn);
      setSormGameNameEn(gameById?.game_name.en);
      setListcover(list_cover || []);
      setFormGameDescCn(gameById?.description?.cn);
      setFormGameDescEn(gameById?.description?.en);
      SetFormHotVal(gameById?.hot);
      setSelectActivity(gameById?.classification);
      setFormPriority(gameById?.sort_priority);
      setFormState(gameById?.state === 1 ? true : false);
      setSelectCategories(selectedCategoryById);
      setFormGameCode(gameById?.game_code);
      setFormPublisher(gameById?.publisher);
      if (Object.keys(gameById?.platform_link as PlatForm).includes("1")) {
        setH5Checked(true);
        const h5link = gameById?.platform_link[1]?.play_url;
        setH5Link(h5link);
      }
      if (Object.keys(gameById?.platform_link as PlatForm).includes("2")) {
        setAndroidChecked(true);
        setAndroidPackageUrl(gameById?.platform_link[2]?.package_url);
        const androidlink = gameById?.platform_link[2]?.play_url;
        if (gameById?.platform_link[2]?.package_url) {
          setAndroidType(1);
          setAndroidList([
            {
              fname: gameById.platform_link[2].file_name,
              fsize: gameById.platform_link[2].size,
              flastModified: gameById?.platform_link[2]?.upload_time ?? 0 * 1000,
            },
          ]);
        }
        if (androidlink) {
          setAndroidType(2);
          setAndroidLink(androidlink);
        }
      }
      if (Object.keys(gameById?.platform_link as PlatForm).includes("3")) {
        setIosChecked(true);
        const ioslink = gameById?.platform_link[3]?.play_url;
        setIosLink(ioslink);
      }
    } else {
      form.resetFields();
      form.setFieldsValue({ hot: formHotVal, priority: formPriority });
      setHorizentalList([]);
      setListcover([]);
      setSelectCategories([]);
      setEditId(null);
      setH5Checked(false);
      setH5Link("");
      setAndroidChecked(false);
      setAndroidFile([]);
      setAndroidLink("");
      setIosChecked(false);
      setIosLink("");
      setGameCodeDisable(false);
      setFormState(true);
      setFormPublisher("");
      SetFormHotVal(5);
      setFormPriority(0);
      setAndroidPackageUrl("");
      setAndroidList([]);
      setFormGameDescCn("");
      setFormGameDescEn("");
      setSelectActivity([]);
      setAndroidType(1);
    }
    setFormType(type);
    setModalVisible(true);
  };

  //取消弹框
  const handleCancelModal = () => {
    form.resetFields();
    setListcoverNoteShow(false);
    sethorizontalNoteShow(false);
    setPlatformNoteShow(false);
    setCategoryNoteShow(false);
    setModalVisible(false);

    setAndroidList([]);
    setEditId(null);
    setH5Checked(false);
    setH5Link("");
    setAndroidChecked(false);
    setAndroidFile([]);
    setAndroidLink("");
    setIosChecked(false);
    setIosLink("");
    setAndroidPackageUrl("");
    setFormPriority(0);
    setFormGameDescCn("");
    setFormGameDescEn("");
    setSelectCategories([]);
    setSelectActivity([]);
    setAndroidType(1);
  };

  const [progress, setProgress] = useState(0);
  const baseURL = import.meta.env.VITE_API_BASE_URL;
  const time = dayjs().valueOf();

  //   上传horizontal img
  const uploadHorizontalImages = async () => {
    const newImages = Promise.all(
      horizentalList.map(async (item) => {
        if (item.originFileObj !== undefined) {
          const fmData = new FormData();
          const config: AxiosRequestConfig<FormData> = {
            headers: { "content-type": "multipart/form-data", token: value?.token },
            onUploadProgress: (progressEvent: AxiosProgressEvent) => {
              const percent = Math.floor((progressEvent.loaded / (progressEvent.total ?? 1)) * 100);
              setProgress(percent);
              if (percent === 100) {
                setTimeout(() => setProgress(0), 1000);
              }
            },
          };
          fmData.append("files", item.originFileObj);
          fmData.append("operationID", time.toString());
          fmData.append("fileType", "1");
          fmData.append("snapShots", "");
          try {
            const res = await axios.post(baseURL + "/api/third/tencent_cloud_storage_multi_upload_persistence", fmData, config);
            return res.data.data.urls.join(",");
          } catch (err) {
            message.error({
              content: t("toasts.server-error"),
              key: t("toasts.server-error"),
            });
            return { error: "filde-upload-issues" };
          }
        }
      })
    );
    return newImages;
  };

  //   上传cover img
  const uploadCoverImages = async () => {
    const newImages = Promise.all(
      listcover.map(async (item) => {
        if (item.originFileObj !== undefined) {
          const fmData = new FormData();
          const config: AxiosRequestConfig<FormData> = {
            headers: { "content-type": "multipart/form-data", token: value?.token },
            onUploadProgress: (progressEvent: AxiosProgressEvent) => {
              const percent = Math.floor((progressEvent.loaded / (progressEvent.total ?? 1)) * 100);
              setProgress(percent);
              if (percent === 100) {
                setTimeout(() => setProgress(0), 1000);
              }
            },
          };
          fmData.append("files", item.originFileObj);
          fmData.append("operationID", time.toString());
          fmData.append("fileType", "1");
          fmData.append("snapShots", "");
          try {
            const res = await axios.post(baseURL + "/api/third/tencent_cloud_storage_multi_upload_persistence", fmData, config);
            return res.data.data.urls.join(",");
          } catch (err) {
            message.error({
              content: t("toasts.server-error"),
              key: t("toasts.server-error"),
            });
            return { error: "filde-upload-issues" };
          }
        }
      })
    );
    return newImages;
  };

  //   上传android apk
  const uploadAndroidApk = async () => {
    const newAndroidApk = Promise.all(
      androidFile.map(async (item) => {
        if (item.originFileObj !== undefined) {
          const fmData = new FormData();
          const config: AxiosRequestConfig<FormData> = {
            headers: { "content-type": "multipart/form-data", token: value?.token },
            onUploadProgress: (progressEvent: AxiosProgressEvent) => {
              const percent = Math.floor((progressEvent.loaded / (progressEvent.total ?? 1)) * 100);
              setProgress(percent);
              if (percent === 100) {
                setTimeout(() => setProgress(0), 1000);
              }
            },
          };
          fmData.append("files", item.originFileObj);
          fmData.append("operationID", time.toString());
          fmData.append("fileType", "1");
          fmData.append("snapShots", "");
          try {
            const res = await axios.post(baseURL + "/api/third/tencent_cloud_storage_multi_upload_persistence", fmData, config);
            return res.data.data.urls.join(",");
          } catch (err) {
            message.error({
              content: t("toasts.server-error"),
              key: t("toasts.server-error"),
            });
            return { error: "filde-upload-issues" };
          }
        }
      })
    );
    return newAndroidApk;
  };

  //   添加、编辑游戏的请求
  const handleAddEditGame = async () => {
    const gameName = {
      en: formGameNameEn?.trim(),
      cn: formGameNameCn?.trim(),
    };
    const gameDescription = {
      en: formGameDescEn?.trim(),
      cn: formGameDescCn?.trim(),
    };
    if (formType === "add") {
      //取得horizontal图片的地址
      const newHorizontalImages = (await uploadHorizontalImages()).filter((item) => item !== undefined);
      const oldHorizontalImages = horizentalList.filter((item) => item.originFileObj === undefined).map((item) => item.url);
      const newHorizontalImagesArr = [...oldHorizontalImages, ...newHorizontalImages];
      //取得listcover图片的地址
      const newCoverImages = (await uploadCoverImages()).filter((item) => item !== undefined);
      const oldCoverImages = listcover.filter((item) => item.originFileObj === undefined).map((item) => item.url);
      const newCoverImagesArr = [...oldCoverImages, ...newCoverImages];

      //获得android安装包地址
      const newAndroidApkUrl = (await uploadAndroidApk()).filter((item) => item !== undefined);
      const oldAndroidApkUrl = androidFile.filter((item) => item.originFileObj === undefined).map((item) => item.url);
      const newAndroidApkUrlArr = [...oldAndroidApkUrl, ...newAndroidApkUrl];

      //支持平台的值
      const platformObj: PlatForm = {};
      if (h5Checked) {
        if (h5Link == "") {
          setPlatformNoteShow(true);

          return false;
        }
        platformObj["1"] = {
          play_url: h5Link,
        };
      }
      if (androidChecked) {
        if (androidType == 1) {
          if (newAndroidApkUrlArr.length == 0) {
            setPlatformNoteShow(true);

            return false;
          }
          platformObj["2"] = {
            package_url: newAndroidApkUrlArr[0],

            size: androidList[0]?.fsize,
            file_name: androidList[0]?.fname,
          };
        } else if (androidType == 2) {
          if (androidLink == "") {
            setPlatformNoteShow(true);

            return false;
          }
          platformObj["2"] = {
            play_url: androidLink,
          };
        }
      }
      if (iosChecked) {
        if (iosLink == "") {
          setPlatformNoteShow(true);

          return false;
        }
        platformObj["3"] = {
          play_url: iosLink,
        };
      }

      if (
        formGameCode?.trim() === "" ||
        formGameNameEn?.trim() === "" ||
        formGameNameCn?.trim() === "" ||
        formPublisher?.trim() === "" ||
        newHorizontalImagesArr.length === 0 ||
        newCoverImagesArr.length === 0 ||
        selectCategories?.length === 0 ||
        formHotVal == 0 ||
        Object.keys(platformObj).length == 0
      ) {
        if (newCoverImagesArr.length === 0) {
          setListcoverNoteShow(true);
        }
        if (newHorizontalImagesArr.length === 0) {
          sethorizontalNoteShow(true);
        }
        if (Object.keys(platformObj).length == 0) {
          setPlatformNoteShow(true);
        }
        if (selectCategories?.length === 0) {
          setCategoryNoteShow(true);
        }

        return false;
      }
      //请求接口
      addGameMutation.mutate({
        game_code: formGameCode,
        game_name: gameName,
        description: gameDescription,
        horizontal_cover: newHorizontalImagesArr,
        cover_img: newCoverImagesArr[0],
        categories: selectCategories,
        hot: formHotVal,
        classification: selectActivity,
        platform_link: platformObj,
        publisher: formPublisher?.trim(),
        sort_priority: Number(formPriority),
        state: formState === true ? 1 : 2,
      });
    }

    if (formType === "edit") {
      const gameByCode = dataList?.find((item) => item.game_code === editId);
      //取得horizontal图片的地址
      const newHorizontalImages = (await uploadHorizontalImages()).filter((item) => item !== undefined);
      const oldHorizontalImages = horizentalList.filter((item) => item.originFileObj === undefined).map((item) => item.url);
      const newHorizontalImagesArr = [...oldHorizontalImages, ...newHorizontalImages];
      //取得listcover图片的地址
      const newCoverImages = (await uploadCoverImages()).filter((item) => item !== undefined);
      const oldCoverImages = listcover.filter((item) => item.originFileObj === undefined).map((item) => item.url);
      const newCoverImagesArr = [...oldCoverImages, ...newCoverImages];

      //获得android安装包地址
      const newAndroidApkUrl = (await uploadAndroidApk()).filter((item) => item !== undefined);
      const oldAndroidApkUrl = androidFile.filter((item) => item.originFileObj === undefined).map((item) => item.url);
      const newAndroidApkUrlArr = [...oldAndroidApkUrl, ...newAndroidApkUrl];

      //支持平台的值
      const platformObj: PlatForm = {};
      if (h5Checked) {
        if (h5Link == "") {
          setPlatformNoteShow(true);

          return false;
        }
        platformObj["1"] = {
          package_url: "",
          play_url: h5Link,
          file_name: "",
          size: 0,
          upload_time: 0,
        };
      }

      if (androidChecked) {
        if (androidType == 1) {
          if (androidPackageUrl == "" && newAndroidApkUrlArr.length == 0) {
            setPlatformNoteShow(true);

            return false;
          }

          platformObj["2"] = {
            package_url: newAndroidApkUrlArr[0] === undefined ? androidPackageUrl : newAndroidApkUrlArr[0],
            play_url: "",
            size: androidList[0]?.fsize,
            file_name: androidList[0]?.fname,
            upload_time: Math.floor(androidList[0]?.flastModified ?? 0 / 1000),
          };
        } else if (androidType == 2) {
          if (androidLink == "") {
            setPlatformNoteShow(true);

            return false;
          }
          platformObj["2"] = {
            package_url: "",
            play_url: androidLink,
            file_name: "",
            size: 0,
            upload_time: 0,
          };
        }
      }

      if (iosChecked) {
        if (iosLink == "") {
          setPlatformNoteShow(true);

          return false;
        }
        platformObj["3"] = {
          package_url: "",
          play_url: iosLink,
          file_name: "",
          size: 0,
          upload_time: 0,
        };
      }

      //如果内容为空，不发起请求
      if (
        formGameNameEn?.trim() === "" ||
        formGameNameCn?.trim() === "" ||
        formPublisher?.trim() === "" ||
        newHorizontalImagesArr.length === 0 ||
        newCoverImagesArr.length === 0 ||
        selectCategories?.length === 0 ||
        formHotVal == 0 ||
        Object.keys(platformObj).length == 0
      ) {
        if (newCoverImagesArr.length === 0) {
          setListcoverNoteShow(true);
        }
        if (newHorizontalImagesArr.length === 0) {
          sethorizontalNoteShow(true);
        }
        if (Object.keys(platformObj).length == 0) {
          setPlatformNoteShow(true);
        }
        if (selectCategories?.length === 0) {
          setCategoryNoteShow(true);
        }

        return false;
      }

      //如果内容没有修改，不发起请求
      const formStateNum = formState === true ? 1 : 2;
      const horizontalNoChange =
        gameByCode?.horizontal_cover.length === newHorizontalImagesArr.length && gameByCode.horizontal_cover.filter((t) => !newHorizontalImagesArr.includes(t)) ? true : false;

      const categoryNoChange =
        gameByCode?.categories?.map((item) => item.category.id).length === selectCategories?.length &&
        gameByCode?.categories?.map((item) => item.category.id).filter((t) => !selectCategories?.includes(t)).length === 0
          ? true
          : false;

      let activityNoChange: boolean | null = null;
      if (gameByCode?.classification !== null) {
        activityNoChange =
          gameByCode?.classification?.length === selectActivity?.length && gameByCode?.classification?.filter((t) => !selectActivity?.includes(t)).length === 0 ? true : false;
      } else {
        activityNoChange = selectActivity === null || selectActivity?.length === 0 ? true : false;
      }

      //判断两个对象是否相等
      const isObjectSame = (obj1: PlatForm, obj2: PlatForm) => {
        // 获取两个对象的键数组
        const keys1 = Object.keys(obj1).map(Number);
        const keys2 = Object.keys(obj2).map(Number);

        // 如果两个对象的键数量不相等，直接返回false
        if (keys1.length !== keys2.length) {
          return false;
        }

        // 循环比较每个键对应的值是否相等
        for (let i = 0; i < keys1.length; i++) {
          const key = keys1[i];
          const val1 = obj1[key];
          const val2 = obj2[key];

          // 如果值类型不同，直接返回false
          if (typeof val1 !== typeof val2) {
            return false;
          }

          // 如果是对象，递归比较
          if (typeof val1 === "object" && typeof val2 === "object") {
            if (!isObjectSame(val1, val2)) {
              return false;
            }
          } else if (val1 !== val2) {
            // 否则比较值是否相等
            return false;
          }
        }

        // 如果所有值都相等，返回true
        return true;
      };

      if (
        gameByCode?.game_name.en === formGameNameEn?.trim() &&
        gameByCode?.game_name.cn === formGameNameCn?.trim() &&
        gameByCode?.publisher === formPublisher?.trim() &&
        gameByCode?.description?.cn === formGameDescCn?.trim() &&
        gameByCode?.description?.en === formGameDescEn?.trim() &&
        horizontalNoChange &&
        gameByCode?.cover_img === newCoverImagesArr[0] &&
        categoryNoChange &&
        gameByCode?.hot == formHotVal &&
        activityNoChange &&
        isObjectSame(gameByCode?.platform_link ?? {}, platformObj) &&
        gameByCode?.sort_priority == Number(formPriority) &&
        gameByCode?.state === formStateNum
      ) {
        message.error({
          content: t("form.error.please-edit"),
          key: t("form.error.please-edit"),
        });

        return false;
      }

      //请求接口
      editGameMutation.mutate({
        game_code: formGameCode,
        game_name: gameName,
        description: gameDescription,
        horizontal_cover: newHorizontalImagesArr,
        cover_img: newCoverImagesArr[0],
        categories: selectCategories,
        hot: formHotVal,
        classification: selectActivity,
        platform_link: platformObj,
        publisher: formPublisher?.trim(),
        sort_priority: Number(formPriority),
        state: formState === true ? 1 : 2,
      });
    }

    form.resetFields();

    setListcoverNoteShow(false);
    sethorizontalNoteShow(false);
    setPlatformNoteShow(false);
    setCategoryNoteShow(false);

    setAndroidList([]);
    setEditId(null);
    setH5Checked(false);
    setH5Link("");
    setAndroidChecked(false);
    setAndroidFile([]);
    setAndroidLink("");
    setIosChecked(false);
    setIosLink("");
    setAndroidPackageUrl("");
    setFormPriority(0);
    setFormGameDescCn("");
    setFormGameDescEn("");
    setSelectCategories([]);
    setSelectActivity([]);
    setAndroidType(1);

    setModalVisible(false);
  };

  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish}>
        <Form.Item name="gameCodeVal">
          <Input placeholder={t("form.placeholder.game-code")} />
        </Form.Item>
        <Form.Item name="gameNameVal">
          <Input placeholder={t("form.placeholder.game-name")} />
        </Form.Item>
        <Form.Item name="categoriesVal" label={t("form.categories") + ":"}>
          <Select
            options={[
              { value: "", label: t("table.all") },
              ...(categoryList
                ? categoryList.map((item, index) => ({
                    value: item.value,
                    label: item.label,
                  }))
                : []),
            ]}
          />
        </Form.Item>
        <Form.Item name="activityVal" label={t("table.activity-classify") + ":"}>
          <Select
            options={[
              { value: "", label: t("table.all") },
              { value: "1", label: t("classification.1") },
              { value: "2", label: t("classification.2") },
            ]}
          />
        </Form.Item>
        <Form.Item name="platformVal" label={t("table.support-platform") + ":"}>
          <Select
            options={[
              { value: "", label: t("table.all") },
              { value: "1", label: "H5" },
              { value: "2", label: "Android" },
              { value: "3", label: "iOS" },
            ]}
          />
        </Form.Item>
        <Form.Item name="publisherVal" label={t("table.publisher")}>
          <Input />
        </Form.Item>
        <Form.Item name="hotValue" label={t("table.hot") + ":"}>
          <Select
            options={[
              { value: "", label: t("table.all") },
              { value: "5", label: t("star.5") },
              { value: "4", label: t("star.4") },
              { value: "3", label: t("star.3") },
              { value: "2", label: t("star.2") },
              { value: "1", label: t("star.1") },
            ]}
          />
        </Form.Item>
        <Form.Item name="stateVal" label={t("table.state") + ":"}>
          <Select
            options={[
              { value: "", label: t("table.all") },
              { value: "1", label: t("table.on") },
              { value: "2", label: t("table.off") },
            ]}
          />
        </Form.Item>
        <Form.Item name="rangePickerVal" label={t("table.create-time") + ":"}>
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<SearchIcon />}>
            {t("button.search")}
          </Button>
          {isActionAllowed(actions.GAMEMANAGE_ADDGAMELIST) && (
            <Button className="filterBtn filterBtnSuccess" onClick={() => showFormModal("add")} type="primary" htmlType="button" icon={<AddIcon />}>
              {t("button.add")}
            </Button>
          )}
        </Form.Item>
      </Form>
      <Table
        className="customTable"
        dataSource={dataList}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.game_num,
          onChange: handlePaginationChange,
          pageSize: data?.data.show_number,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showSizeChanger: true,
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
      {/* 删除弹出框 */}
      <Modal
        title={t("button.delete")}
        open={visibleDeleteModal}
        onOk={() => {
          deleteGameMutation.mutate([deleteCode]);
        }}
        confirmLoading={deleteGameMutation.isLoading}
        onCancel={handleCancelDelete}
        cancelText={t("button.cancel")} // 取消按钮文字
        okText={t("button.delete")} // 确定按钮文字
      >
        <p>{t("form.delete-confirm")}</p>
      </Modal>

      {/* 添加、编辑弹出框 */}
      <Modal
        title={formType == "add" ? t("button.add") : t("button.edit")}
        open={modalVisible}
        onOk={handleAddEditGame}
        onCancel={handleCancelModal}
        confirmLoading={editGameMutation.isLoading || addGameMutation.isLoading}
        width={600}
        cancelText={t("button.cancel")} // 取消按钮文字
        okText={formType == "add" ? t("button.confirm") : t("button.edit")} // 确定按钮文字
      >
        {/* 游戏代码 */}
        <Form
          name="game"
          form={form}
          labelCol={{
            flex: "140px",
          }}
          labelAlign="right"
          labelWrap
          style={{
            maxHeight: 700,
            overflowY: "auto",
          }}
        >
          <Form.Item
            name="gameCode"
            label={t("table.game-code")}
            validateTrigger={["onChange", "onBlur"]}
            rules={[
              {
                required: true,
                message: t("table.game-code") + " " + t("form.error.should-not-empty"),
                whitespace: true,
              },
            ]}
          >
            <Input value={formGameCode} onChange={handleFormGameCode} disabled={gameCodeDisable} />
          </Form.Item>
          {/* 游戏中文名 */}
          <Form.Item
            name="gameNameCn"
            label={t("table.game-NameCN")}
            validateTrigger={["onChange", "onBlur"]}
            rules={[
              {
                required: true,
                message: t("table.game-NameCN") + " " + t("form.error.should-not-empty"),
                whitespace: true,
              },
            ]}
          >
            <Input value={formGameNameCn} onChange={handleFormGameNameCN} showCount maxLength={50} />
          </Form.Item>
          {/* 游戏英文名 */}
          <Form.Item
            name="gameNameEn"
            label={t("table.game-NameEN")}
            validateTrigger={["onChange", "onBlur"]}
            rules={[
              {
                required: true,
                message: t("table.game-NameEN") + " " + t("form.error.should-not-empty"),
                whitespace: true,
              },
            ]}
          >
            <Input value={formGameNameEn} onChange={handleFormGameNameEN} showCount maxLength={50} />
          </Form.Item>
          {/* 供应商名 */}
          <Form.Item
            name="publisher"
            label={t("table.publisher")}
            validateTrigger={["onChange", "onBlur"]}
            rules={[
              {
                required: true,
                message: t("table.publisher") + " " + t("form.error.should-not-empty"),
                whitespace: true,
              },
            ]}
          >
            <TextArea value={formPublisher} onChange={handleFormPublisher} showCount maxLength={100} />
          </Form.Item>
          {/* 中文详情 */}
          <Form.Item name="gameDescCn" label={t("table.gameDescCN")}>
            <TextArea value={formGameDescCn} onChange={handleFormGameDescCN} rows={4} showCount maxLength={500} />
          </Form.Item>
          {/* 英文详情 */}
          <Form.Item name="gameDescEn" label={t("table.gameDescEN")}>
            <TextArea value={formGameDescEn} onChange={handleFormGameDescEN} rows={4} showCount maxLength={500} />
          </Form.Item>
          {/* 横向封面 */}
          <Form.Item
            name="horizontalCover"
            label={
              <span>
                <span style={{ color: "red", marginRight: "5px" }}>*</span>
                <span>{t("table.horizontal-cover")}</span>
              </span>
            }
          >
            <>
              <Upload
                listType="picture-card"
                fileList={horizentalList}
                onPreview={handleHorizontalPreview}
                onChange={handleHorizontalChange}
                accept=".webp,.png,jpg,.jpeg"
                beforeUpload={(file) => {
                  return false;
                }}
              >
                {horizentalList.length >= 5 ? null : uploadButton}
              </Upload>
              <Modal open={previewHorizontalOpen} title={previewHorizontalTitle} footer={null} onCancel={handleHorizontalCancel}>
                <img
                  alt="example"
                  style={{
                    width: "100%",
                  }}
                  src={previewHorizontalImage}
                />
              </Modal>
              <span style={{ color: "#d6d6d6" }}>{t("form.horizonImg")}</span>
              {horizontalNoteShow ? <div style={{ color: "red" }}>{t("table.horizontal-cover") + t("form.error.should-not-empty")}</div> : ""}
            </>
          </Form.Item>
          {/* 列表封面 */}
          <Form.Item
            name="listCover"
            label={
              <span>
                <span style={{ color: "red", marginRight: "5px" }}>*</span>
                <span>{t("table.list-cover")}</span>
              </span>
            }
          >
            <>
              <Upload
                listType="picture-card"
                fileList={listcover}
                onPreview={handleListCoverPreview}
                onChange={handleListCoverChange}
                accept=".webp,.png,jpg,.jpeg"
                beforeUpload={(file) => {
                  return false;
                }}
              >
                {listcover.length >= 1 ? null : uploadButton}
              </Upload>
              <Modal open={previewListCoverOpen} title={previewListCoverTitle} footer={null} onCancel={handleListCoverCancel}>
                <img
                  alt="example"
                  style={{
                    width: "100%",
                  }}
                  src={previewListCoverImage}
                />
              </Modal>
              <span style={{ color: "#d6d6d6" }}>{t("form.listImg")}</span>
              {listcoverNoteShow ? <div style={{ color: "red" }}>{t("table.list-cover") + t("form.error.should-not-empty")}</div> : ""}
            </>
          </Form.Item>
          {/* 分类 */}
          <Form.Item
            name="categories"
            label={
              <span>
                <span style={{ color: "red", marginRight: "5px" }}>*</span>
                <span>{t("form.categories")}</span>
              </span>
            }
          >
            <>
              <div>
                <Checkbox.Group value={selectCategories} onChange={handleSelectCategories}>
                  {categoryList !== undefined && categoryList?.length > 0 && (
                    <Row>
                      {categoryList?.map((item) => {
                        return (
                          <Col key={item.value} span={11}>
                            <Checkbox
                              value={item.value}
                              style={{
                                lineHeight: "32px",
                              }}
                              disabled={disabledOptions?.includes(item)}
                            >
                              {item.label}
                            </Checkbox>
                          </Col>
                        );
                      })}
                    </Row>
                  )}
                </Checkbox.Group>
              </div>
              {categoryNoteShow ? <div style={{ color: "red" }}>{t("form.categories") + t("form.error.should-not-empty")}</div> : ""}
            </>
          </Form.Item>
          {/* 热度 */}
          <Form.Item
            name="hot"
            label={t("table.hot")}
            validateTrigger={["onChange"]}
            rules={[
              {
                required: true,
              },
              {
                validator: (rule, value) => {
                  if (value === undefined || value === null || value == 0) {
                    return Promise.reject(t("table.hot") + " " + t("form.error.should-not-empty"));
                  }
                  return Promise.resolve();
                },
              },
            ]}
          >
            <Rate value={formHotVal} onChange={handleFormHotVal} />
          </Form.Item>
          {/* 活动分类 */}
          <Form.Item name="activity" label={t("table.activity-classify")}>
            <Checkbox.Group
              options={[
                {
                  value: "1",
                  label: t("classification.1"),
                },
                {
                  value: "2",
                  label: t("classification.2"),
                },
              ]}
              value={selectActivity}
              onChange={handleSelectActivity}
            ></Checkbox.Group>
          </Form.Item>
          {/* 支持平台 */}
          <Form.Item
            name="platform"
            label={
              <span>
                <span style={{ color: "red", marginRight: "5px" }}>*</span>
                <span>{t("table.support-platform")}</span>
              </span>
            }
          >
            <Space direction="vertical">
              <div>
                <Checkbox checked={h5Checked} onChange={handleH5Change}>
                  H5
                </Checkbox>
                <div>
                  {t("form.link")}:
                  <Input value={h5Link} onChange={handleH5Link} style={{ width: "280px", marginLeft: "10px" }} disabled={h5Checked ? false : true} />
                </div>
              </div>
              <div>
                <Checkbox checked={androidChecked} onChange={handleAndroidChange}>
                  Android
                </Checkbox>
                <div>
                  <Radio.Group onChange={handleAndroidType} value={androidType}>
                    <Radio value={1}> {t("form.file")}:</Radio>
                    <Radio value={2}> {t("form.link")}:</Radio>
                  </Radio.Group>
                </div>
                <div>
                  {androidType === 1 ? (
                    <>
                      <Upload
                        listType="text"
                        maxCount={1}
                        fileList={androidFile}
                        showUploadList={false}
                        onChange={handleAndroidFile}
                        beforeUpload={(file) => {
                          return false;
                        }}
                      >
                        <Button size="small" type="primary" className={!androidChecked ? "disableBtn" : ""} disabled={androidChecked ? false : true}>
                          Upload
                        </Button>
                      </Upload>
                      <div>
                        {androidList?.map((file, index) => (
                          <div key={index}>
                            <PaperClipOutlined />
                            <span>{file.fname === "" ? "-" : file.fname}</span>
                            <span style={{ marginRight: "4px" }}>
                              {Math.round((file.fsize ?? 0 / 1024 / 1024) * 100) / 100}
                              MB
                            </span>
                            <span style={{ marginRight: "10px" }}>{dayjs(file.flastModified).format("YYYY-MM-DD  HH:mm:ss")}</span>
                            <span>
                              <a onClick={() => handleRemove()}>
                                <DeleteOutlined />
                              </a>
                            </span>
                          </div>
                        ))}
                      </div>
                    </>
                  ) : (
                    <>
                      {t("form.link")}:
                      <Input value={androidLink} onChange={handleAndroidLink} style={{ width: "280px", marginLeft: "10px" }} disabled={androidChecked ? false : true} />
                    </>
                  )}
                </div>
              </div>
              <div>
                <Checkbox checked={iosChecked} onChange={handleIosChange}>
                  iOS
                </Checkbox>
                <div>
                  {t("form.link")}:
                  <Input value={iosLink} onChange={handleIosLink} style={{ width: "280px", marginLeft: "10px" }} disabled={iosChecked ? false : true} />
                </div>
              </div>
              {platformNoteShow ? <div style={{ color: "red" }}>{t("table.support-platform") + t("form.error.should-not-empty")}</div> : ""}
            </Space>
          </Form.Item>
          {/* 优先权 */}
          <Form.Item
            name="priority"
            label={t("table.priority")}
            rules={[
              () => ({
                validator(rule, value) {
                  if (/^100$|^(\d|[1-9]\d)$/.test(value)) {
                    //if中是正则表达是,判断是否是0-100的整数
                    return Promise.resolve();
                  } else {
                    return Promise.reject(t("form.error.withinHundred")); //如果违反规则，就会给出提示
                  }
                },
              }),
            ]}
          >
            <Input value={formPriority} onChange={handleFormPriority} style={{ width: "70px" }} />
          </Form.Item>
          {/* 状态 */}
          <Form.Item name="state" label={t("table.state")}>
            <Switch
              checked={formState}
              checkedChildren="ON"
              unCheckedChildren="OFF"
              onChange={() => {
                setFormState(!formState);
              }}
            />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default GameManagementView;
