import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, GetCategoriesItem, GetCategoriesRequestParams, setCategoryStateRequestParams, addCategoryRequestParams, editCategoryRequestParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Form, Input, DatePicker, Select, Button, Table, message, Modal, Switch } from "antd";
import { ColumnsType } from "antd/es/table";
import dayjs, { Dayjs } from "dayjs";
import Icon, { EyeOutlined } from "@ant-design/icons";
import { InternalServerError, NetworkError } from "~/api/errors";
import SearchIcon from "~/components/icons/SearchIcon";
import AddIcon from "~/components/icons/AddIcon";
import ConfirmModal from "~/views/CategoryManagementView/ConfirmModal";
import _ from "lodash";
import usePermissions from "~/hooks/usePermissions";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";

const initialParams: GetCategoriesRequestParams = {
  page_number: 1,
  show_number: 10,
  operation_id: "get_categories_list",
};

const getCategoriesQuery = (request: ApiRequest, params: GetCategoriesRequestParams = initialParams) => ({
  queryKey: [actions.CATEGORYMANAGE_GETCATEGORY, params],
  queryFn: async () => request(actions.CATEGORYMANAGE_GETCATEGORY, params),
});

export const categoryManagementViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getCategoriesQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  categoryName: string;
  creatorVal: string;
  createTimeVal: null | Dayjs[];
  editorVal: string;
  editTimeVal: null | Dayjs[];
  stateVal: any;
}

const initialValues: FormValues = {
  categoryName: "",
  creatorVal: "",
  createTimeVal: null,
  editorVal: "",
  editTimeVal: null,
  stateVal: "",
};

type ModalKey = "delete-category" | "on-category" | "off-category" | "add-category" | "edit-category";

const CategoryManagementView: React.FC = () => {
  const { t } = useTranslation("category-management-view");
  const { isActionAllowed } = usePermissions();
  const [form] = Form.useForm();
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const [params, setParams] = useState<GetCategoriesRequestParams>(initialParams);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [openModal, setOpenModal] = useState<{ open: boolean; formOpen: boolean; key: ModalKey; categoryID: any }>({
    open: false,
    formOpen: false,
    key: "delete-category",
    categoryID: "",
  });

  if (!isActionAllowed(actions.CATEGORYMANAGE_GETCATEGORY)) return null;

  const [dataList, setDataList] = useState<GetCategoriesItem[] | undefined>([]);
  const queryClient = useQueryClient();

  const { data, isPreviousData } = useQuery({
    ...getCategoriesQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "category-list-query-failed",
        type: "error",
        content: t("toasts.category-list-query-failed"),
      });
    },
  });
  useEffect(() => {
    const datalist = data?.data.category_list.map((item, index) => ({
      ...item,
      key: item.category_id,
      number: index + 1 + (params.page_number * params.show_number - params.show_number),
    }));
    setDataList(datalist);
  }, [data]);

  //切换分类状态
  const switchStatusMutation = useMutation((params: setCategoryStateRequestParams) => request(actions.CATEGORYMANAGE_SETSTATE, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.CATEGORYMANAGE_GETCATEGORY]);
      message.open({
        key: "status-update-success",
        type: "success",
        content: t("toasts.status-update-success"),
      });
    },
  });

  //删除分类
  const deleteCategoryMutation = useMutation((category_id: number) => request(actions.CATEGORYMANAGE_DELETECATEGORY, { category_id }), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.CATEGORYMANAGE_GETCATEGORY]);
      message.open({
        key: "category-deleted-successfully",
        type: "success",
        content: t("toasts.category-deleted-successfully"),
      });
    },
  });

  //添加分类
  const addCategoryMutation = useMutation((params: addCategoryRequestParams) => request(actions.CATEGORYMANAGE_ADDCATEGORY, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, formOpen: false }));
      queryClient.invalidateQueries([actions.CATEGORYMANAGE_GETCATEGORY]);
      message.open({
        key: "category-added-successfully",
        type: "success",
        content: t("toasts.category-added-successfully"),
      });
    },
  });

  //编辑分类
  const editCategoryMutation = useMutation((params: editCategoryRequestParams) => request(actions.CATEGORYMANAGE_EDITCATEGORY, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, formOpen: false }));
      queryClient.invalidateQueries([actions.CATEGORYMANAGE_GETCATEGORY]);
      message.open({
        key: "category-edited-successfully",
        type: "success",
        content: t("toasts.category-edited-successfully"),
      });
    },
  });

  useEffect(() => {
    setDashboardHeading("game-store", "game-category-management");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const columns: ColumnsType<GetCategoriesItem> = useMemo(
    () => [
      {
        title: t("table.serial-number"),
        dataIndex: "number",
        width: 80,
      },
      {
        title: t("table.categoriesCN"),
        dataIndex: "categories",
        width: 140,
        render: (text) => {
          return text?.cn;
        },
      },
      {
        title: t("table.categoriesEN"),
        dataIndex: "categories",
        width: 140,
        render: (text) => {
          return text?.en;
        },
      },
      {
        title: t("table.amount-of-use"),
        dataIndex: "used_amount",
        width: 140,
      },
      {
        title: t("table.creator"),
        dataIndex: "creator",
        width: 150,
        render: (text) => {
          return text === "" ? "-" : text;
        },
      },
      {
        title: t("table.create-time"),
        dataIndex: "create_time",
        width: 140,
        render: (text) => {
          let cDate = dayjs(text * 1000).format("YYYY/MM/DD  HH:mm:ss");
          return text === 0 ? "-" : cDate;
        },
      },
      {
        title: t("table.editor"),
        dataIndex: "editor",
        width: 150,
        render: (text) => {
          return text === "" ? "-" : text;
        },
      },
      {
        title: t("table.edited-time"),
        dataIndex: "edit_time",
        width: 140,
        render: (text) => {
          let cDate = dayjs(text * 1000).format("YYYY/MM/DD  HH:mm:ss");
          return text === 0 ? "-" : cDate;
        },
      },
      {
        title: t("table.priority"),
        dataIndex: "sort_priority",
        width: 120,
        render: (text) => {
          return text;
        },
      },
      {
        title: t("table.state"),
        dataIndex: "state",
        width: 120,
        render: (text) => {
          return text === 1 ? t("button.on") : t("button.off");
        },
      },
      {
        title: t("table.operate"),
        dataIndex: "operate",
        fixed: "right",
        width: 180,
        render: (_, record) => {
          return (
            <>
              {isActionAllowed(actions.CATEGORYMANAGE_EDITCATEGORY) && (
                <Button className="optionBtn" onClick={() => showFormModal("edit-category", record)} type="primary" htmlType="button" size="small">
                  {t("button.edit")}
                </Button>
              )}
              {isActionAllowed(actions.CATEGORYMANAGE_SETSTATE) &&
                (record.state === 1 ? (
                  <Button
                    className="optionBtn optionBtnDanger"
                    onClick={() => setOpenModal({ open: true, formOpen: false, key: "off-category", categoryID: record.category_id })}
                    type="primary"
                    htmlType="button"
                    size="small"
                  >
                    {t("button.off")}
                  </Button>
                ) : (
                  <Button
                    className="optionBtn optionBtnSuccess"
                    onClick={() => setOpenModal({ open: true, formOpen: false, key: "on-category", categoryID: record.category_id })}
                    type="primary"
                    htmlType="button"
                    size="small"
                  >
                    {t("button.on")}
                  </Button>
                ))}
              {isActionAllowed(actions.CATEGORYMANAGE_DELETECATEGORY) && (
                <Button
                  className="optionBtn optionBtnDanger"
                  onClick={() => setOpenModal({ open: true, formOpen: false, key: "delete-category", categoryID: record.category_id })}
                  type="primary"
                  htmlType="button"
                  danger
                  size="small"
                >
                  {t("button.delete")}
                </Button>
              )}
            </>
          );
        },
      },
    ],
    [t]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ categoryName, creatorVal, createTimeVal, editorVal, editTimeVal, stateVal }: FormValues) => {
      setParams(({ show_number }) => {
        const state: GetCategoriesRequestParams = { page_number: 1, show_number, operation_id: "get_categories_list" };
        if (categoryName !== "") {
          state.category_name = categoryName;
        }
        if (creatorVal !== "") {
          state.creator = creatorVal;
        }
        if (createTimeVal !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(createTimeVal);
          state.create_start_time = startTime;
          state.create_end_time = endTime;
        }
        if (editorVal !== "") {
          state.editor = editorVal;
        }
        if (editTimeVal !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(editTimeVal);
          state.edited_start_time = startTime;
          state.edited_end_time = endTime;
        }
        if (stateVal !== "") {
          state.state = stateVal;
        }

        return state;
      });
      setSearchLoading(true);
    },
    [setParams]
  );
  const handleModalCancel = useCallback(() => {
    setOpenModal((state) => ({ ...state, open: false, formOpen: false }));
  }, [setOpenModal]);

  const handleModalOk = useCallback(() => {
    let state: 1 | 2 | undefined = undefined;
    switch (openModal.key) {
      case "delete-category":
        deleteCategoryMutation.mutate(openModal.categoryID);
        return;
      case "on-category":
        state = 1;
        break;
      case "off-category":
        state = 2;
        break;
    }
    if (state !== undefined) switchStatusMutation.mutate({ state, category_id: openModal.categoryID });
  }, [deleteCategoryMutation.mutate, openModal]);

  //表单输入框的值
  //分类英文名
  const [formCategoryNameEn, setFormCategoryNameEn] = useState<string | undefined>("");
  const handleFormCategoryNameEN = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormCategoryNameEn(e.target.value);
  };
  //分类中文名
  const [formCategoryNameCn, setFormCategoryNameCn] = useState<string | undefined>("");
  const handleFormCategoryNameCN = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormCategoryNameCn(e.target.value);
  };
  //优先
  const [formPriority, setFormPriority] = useState<any>(0);
  const handleFormPriority = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormPriority(e.target.value);
  };
  //state
  const [formState, setFormState] = useState(true);

  //触发弹出框的方法
  const showFormModal = (type: ModalKey, record?: GetCategoriesItem) => {
    const category_id = record?.category_id;
    if (category_id) {
      form.setFieldsValue({
        categoryNameEn: record?.categories.en,
        categoryNameCn: record?.categories.cn,
        priority: record?.sort_priority,
        state: record?.state,
      });
      setFormCategoryNameEn(record?.categories.en);
      setFormCategoryNameCn(record?.categories.cn);
      setFormPriority(record?.sort_priority);
      setFormState(record?.state === 1 ? true : false);
      setOpenModal({ open: false, formOpen: true, key: type, categoryID: category_id });
    } else {
      form.resetFields();
      form.setFieldsValue({ priority: 0 });
      setFormCategoryNameEn("");
      setFormCategoryNameCn("");
      setFormPriority(0);
      setFormState(true);
      setOpenModal({ open: false, formOpen: true, key: type, categoryID: "" });
    }
  };
  console.log("paixu", formPriority);

  //添加、编辑分类的请求
  const handleAddEditCategory = async () => {
    const categoryName = {
      en: formCategoryNameEn?.trim(),
      cn: formCategoryNameCn?.trim(),
    };
    if (openModal.key === "add-category") {
      //内容为空不提交
      if (formCategoryNameEn?.trim() === "" || formCategoryNameCn?.trim() === "" || formPriority === "") {
        return false;
      }
      //请求接口
      addCategoryMutation.mutate({
        category_name: categoryName,
        sort_priority: parseInt(formPriority),
        state: formState === true ? 1 : 2,
      });
    }

    if (openModal.key === "edit-category") {
      const categoryById = dataList?.find((item) => item.category_id === openModal.categoryID);
      if (
        categoryById?.categories.cn === formCategoryNameCn?.trim() &&
        categoryById?.categories.en === formCategoryNameEn?.trim() &&
        categoryById?.sort_priority === parseInt(formPriority) &&
        categoryById?.state === (formState === true ? 1 : 2)
      ) {
        message.error({
          content: t("toasts.please-change-info"),
          key: t("toasts.please-change-info"),
        });
        return false;
      }
      if (formCategoryNameEn?.trim() === "" || formCategoryNameCn?.trim() === "" || formPriority === "") {
        message.error({
          content: t("toasts.please-fullfill-info"),
          key: t("toasts.please-fullfill-info"),
        });
        return false;
      }
      editCategoryMutation.mutate({
        category_id: openModal.categoryID,
        category_name: categoryName,
        sort_priority: parseInt(formPriority),
        state: formState === true ? 1 : 2,
      });
    }
    form.resetFields();
  };

  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish}>
        <Form.Item name="categoryName" label={t("form.categories-name")}>
          <Input placeholder={t("form.categories-name")} />
        </Form.Item>
        <Form.Item name="creatorVal" label={t("form.creator")}>
          <Input />
        </Form.Item>
        <Form.Item name="createTimeVal" label={t("form.create-time")}>
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item name="creatorVal" label={t("form.editor")}>
          <Input />
        </Form.Item>
        <Form.Item name="editTimeVal" label={t("form.edited-time")}>
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item name="stateVal" label={t("form.state")}>
          <Select
            options={[
              { value: "", label: t("table.all") },
              { value: "1", label: t("button.on") },
              { value: "2", label: t("button.off") },
            ]}
          />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("button.search")}
          </Button>
          {isActionAllowed(actions.CATEGORYMANAGE_ADDCATEGORY) && (
            <Button className="filterBtn filterBtnSuccess" onClick={() => showFormModal("add-category")} type="primary" htmlType="button" icon={<Icon component={AddIcon} />}>
              {t("button.add")}
            </Button>
          )}
        </Form.Item>
      </Form>
      <Table
        className="customTable"
        dataSource={dataList}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.categories_num,
          onChange: handlePaginationChange,
          pageSize: data?.data.show_number,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showSizeChanger: true,
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
      <ConfirmModal
        open={openModal.open}
        type={openModal.key as "delete-category" | "on-category" | "off-category"}
        onCancel={handleModalCancel}
        onOk={handleModalOk}
        confirmLoading={deleteCategoryMutation.isLoading || switchStatusMutation.isLoading}
      />
      {/* 新增/编辑分类 弹出框 */}
      <Modal
        title={openModal.key == "add-category" ? t("button.add") : t("button.edit")}
        open={openModal.formOpen}
        onCancel={handleModalCancel}
        width={600}
        cancelText={t("button.cancel")} // 取消按钮文字
        onOk={handleAddEditCategory}
        okText={openModal.key == "add-category" ? t("button.confirm") : t("button.edit")} // 确定按钮文字
        // className={"categories-modal"}
      >
        <Form
          name="game"
          form={form}
          labelCol={{
            flex: "170px",
          }}
          labelAlign="right"
          labelWrap
        >
          {/* 分类英文名 */}
          <Form.Item
            name="categoryNameEn"
            label={t("table.categoriesEN")}
            validateTrigger={["onChange", "onBlur"]}
            rules={[
              {
                required: true,
                message: t("error.please-enter-categoryEN"),
                whitespace: true,
              },
            ]}
          >
            <Input value={formCategoryNameEn} onChange={handleFormCategoryNameEN} showCount maxLength={50} />
          </Form.Item>
          {/* 分类中文名 */}
          <Form.Item
            name="categoryNameCn"
            label={t("table.categoriesCN")}
            validateTrigger={["onChange", "onBlur"]}
            rules={[
              {
                required: true,
                message: t("error.please-enter-categoryCN"),
                whitespace: true,
              },
            ]}
          >
            <Input value={formCategoryNameCn} onChange={handleFormCategoryNameCN} showCount maxLength={50} />
          </Form.Item>
          {/* 优先权 */}
          <Form.Item
            name="priority"
            label={t("table.priority")}
            rules={[
              () => ({
                validator(rule, value) {
                  if (/^100$|^(\d|[1-9]\d)$/.test(value)) {
                    //if中是正则表达是,判断是否是0-100的整数
                    return Promise.resolve();
                  } else {
                    return Promise.reject(t("toasts.overHundred")); //如果违反规则，就会给出提示
                  }
                },
              }),
            ]}
          >
            <Input value={formPriority} onChange={handleFormPriority} style={{ width: "70px" }} />
          </Form.Item>
          {/* 状态 */}
          <Form.Item name="state" label={t("table.state")}>
            <Switch
              checked={formState}
              checkedChildren={t("button.on")}
              unCheckedChildren={t("button.off")}
              onChange={() => {
                setFormState(!formState);
              }}
            />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default CategoryManagementView;
