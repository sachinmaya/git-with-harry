import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import {actions, errorCode} from "~/api/constants";
import { AddUserRequestParams, AlterUserRequestParams, ApiRequest, GetUsersItem, GetUsersRequestParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, message, Select, Table } from "antd";
import Icon, { EyeOutlined } from "@ant-design/icons";
import { ColumnsType } from "antd/es/table";
import { Link } from "react-router-dom";
import dayjs, { Dayjs } from "dayjs";
import { FieldData } from "rc-field-form/lib/interface";
import SearchIcon from "~/components/icons/SearchIcon";
import AddIcon from "~/components/icons/AddIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import { TableRowSelection } from "antd/es/table/interface";
import {InternalServerError, NetworkError, ResponseError} from "~/api/errors";
import ConfirmModal from "~/views/UserListView/ConfirmModal";
import usePermissions from "~/hooks/usePermissions";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";
import UserModal, { UserModalValues } from "~/views/UserListView/UserModal";

const initialParams: GetUsersRequestParams = {
  page_number: 1,
  show_number: 10,
  order_by: "start_time:desc",
};

const getUsersQuery = (request: ApiRequest, params: GetUsersRequestParams = initialParams) => ({
  queryKey: [actions.GET_USERS, params],
  queryFn: async () => request(actions.GET_USERS, params),
});

export const userListViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getUsersQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

const getGender = (gender: number) => {
  switch (gender) {
    case 1:
      return "male";
    case 2:
      return "female";
  }
};

const getDevice = (device: number) => {
  switch (device) {
    case 1:
      return "ios";
    case 2:
      return "android";
    case 3:
      return "desktop";
  }
};

interface FormValues {
  keyword: string;
  source: number;
  shareCode: string;
  gender: number;
  status: number[];
  remark: string;
  filterType: number;
  filterRange: null | Dayjs[];
  lastLoginDevice: number;
}

const initialValues: FormValues = {
  keyword: "",
  source: 0,
  shareCode: "",
  gender: 0,
  status: [],
  remark: "",
  filterType: 0,
  filterRange: null,
  lastLoginDevice: 0,
};

type ModalKey = "multiple-delete" | "delete-user" | "disable-user" | "enable-user" | "disable-video" | "enable-video" | "disable-audio" | "enable-audio";

const UserListView: React.FC = () => {
  const { t } = useTranslation("user-list-view");
  const { setDashboardHeading } = useDashboardView();
  const { isActionAllowed, isPageAllowed } = usePermissions();
  const request = useRequest();
  const [sourceValue, setSourceValue] = useState<number>(0);
  const [params, setParams] = useState<GetUsersRequestParams>(initialParams);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<GetUsersItem> | undefined>(undefined);
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; userID: string }>({
    open: false,
    key: "multiple-delete",
    userID: "",
  });
  const [userModal, setUserModal] = useState<{ open: boolean; user?: GetUsersItem }>({
    open: false,
  });

  const queryClient = useQueryClient();

  const { data, isPreviousData } = useQuery({
    ...getUsersQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.user-list-query-failed"),
      });
    },
  });

  const deleteUserMutation = useMutation((deleteUserIDList: string[]) => request(actions.DELETE_USERS, { deleteUserIDList }), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_USERS]);
      message.open({
        key: "user-delete-successfully",
        type: "success",
        content: t("toasts.user-delete-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.delete-user-failed"),
      });
    },
  });

  const switchStatusMutation = useMutation((params: any) => request(actions.SWITCH_STATUS, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_USERS]);
      message.open({
        key: "user-status-updated-successfully",
        type: "success",
        content: t("toasts.user-status-updated-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "user-status-update-failed",
        type: "error",
        content: t("toasts.user-status-update-failed"),
      });
    },
  });

  const addUserMutation = useMutation((params: AddUserRequestParams) => request(actions.ADD_USER, params), {
    onSuccess: () => {
      queryClient.invalidateQueries([actions.GET_USERS]);
      setUserModal({ open: false });
      message.open({
        key: "add-user-successfully",
        type: "success",
        content: t("toasts.add-user-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      if (error instanceof ResponseError) {
        if (error.errCode === errorCode.USER_ID_EXISTS) {
          message.open({
            key: "user-id-exists",
            type: "error",
            content: t("toasts.user-id-exists"),
          });
          return;
        }
        if (error.errCode === errorCode.INVITE_CODE_INVALID) {
          message.open({
            key: "invite-code-invalid",
            type: "error",
            content: t("toasts.invite-code-invalid"),
          });
          return;
        }
        if (error.errCode === errorCode.PHONE_NUMBER_EXISTS) {
          message.open({
            key: "number-already-exists",
            type: "error",
            content: t("toasts.number-already-exists"),
          });
          return;
        }
      }
      message.open({
        key: "add-user-failed",
        type: "error",
        content: t("toasts.add-user-failed"),
      });
    },
  });

  const alterUserMutation = useMutation((params: AlterUserRequestParams) => request(actions.ALTER_USER, params), {
    onSuccess: () => {
      queryClient.invalidateQueries([actions.GET_USERS]);
      setUserModal({ open: false });
      message.open({
        key: "alter-user-successfully",
        type: "success",
        content: t("toasts.alter-user-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      if (error instanceof ResponseError) {
        if (error.errCode === errorCode.USER_ID_EXISTS) {
          message.open({
            key: "user-id-exists",
            type: "error",
            content: t("toasts.user-id-exists"),
          });
          return;
        }
        if (error.errCode === errorCode.INVITE_CODE_INVALID) {
          message.open({
            key: "invite-code-invalid",
            type: "error",
            content: t("toasts.invite-code-invalid"),
          });
          return;
        }
        if (error.errCode === errorCode.PHONE_NUMBER_EXISTS) {
          message.open({
            key: "number-already-exists",
            type: "error",
            content: t("toasts.number-already-exists"),
          });
          return;
        }
      }
      message.open({
        key: "add-user-failed",
        type: "error",
        content: t("toasts.alter-user-failed"),
      });
    },
  });

  useEffect(() => {
    setDashboardHeading("users", "user-list");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const columns: ColumnsType<GetUsersItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => ((data?.data.current_number || 0) - 1) * (data?.data.show_number || 0) + (index + 1),
      },
      {
        key: "nickname",
        dataIndex: "nick_name",
        width: 160,
        title: t("columns.nickname"),
        render: (value) =>
          isPageAllowed("/users/linkedAccount") ? (
            <Link to="/users/linkedAccount" state={{ keyword: value }}>
              {value}
            </Link>
          ) : (
            value
          ),
      },
      {
        key: "profile-photo",
        width: 160,
        dataIndex: "profile_photo",
        title: t("columns.profile-photo"),
        render: (value) => (value === "" ? "-" : <Image src={value} rootClassName="thumbImagePreview" width={30} height={30} preview={{ mask: <EyeOutlined /> }} />),
      },
      {
        key: "phone",
        width: 160,
        dataIndex: "phone_number",
        title: t("columns.phone"),
        render: (value) => value || "-",
      },
      {
        key: "account",
        width: 160,
        dataIndex: "user_id",
        title: t("columns.account"),
      },
      {
        key: "email",
        width: 160,
        dataIndex: "email",
        title: t("columns.email"),
        render: (value) => value || "-",
      },
      {
        key: "gender",
        width: 160,
        dataIndex: "gender",
        title: t("columns.gender"),
        render: (value) => {
          const gender = getGender(value);
          return gender ? t(`enums.gender.${gender}`) : "-";
        },
      },
      {
        key: "share-code",
        width: 160,
        dataIndex: "source_code",
        title: t("columns.share-code"),
        render: (value) => value || "-",
      },
      {
        key: "create-time",
        width: 160,
        dataIndex: "create_time",
        title: t("columns.create-time"),
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "last-login-ip",
        width: 160,
        dataIndex: "login_ip",
        title: t("columns.last-login-ip"),
        render: (value) => value || "-",
      },
      {
        key: "location",
        width: 160,
        dataIndex: "address",
        title: t("columns.location"),
        render: (value) => value || "-",
      },
      {
        key: "last-login-time",
        width: 160,
        dataIndex: "last_login_time",
        title: t("columns.last-login-time"),
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "last-login-device",
        width: 160,
        dataIndex: "last_login_device",
        title: t("columns.last-login-device"),
        render: (value) => {
          const device = getDevice(value);
          return device ? t(`enums.device.${device}`) : "-";
        },
      },
      {
        key: "uuid",
        width: 160,
        dataIndex: "uuid",
        title: t("columns.uuid"),
        render: (value) => value || "-",
      },
      {
        key: "remark",
        width: 160,
        dataIndex: "remark",
        title: t("columns.remark"),
        render: (value) => value || "-",
      },
      {
        key: "status",
        width: 160,
        title: t("columns.status"),
        render: (value, record) => (
          <>
            <div>{t(`enums.account-status.${record.status ? "on" : "off"}`)}</div>
            <div>{t(`enums.video-status.${record.video_status ? "on" : "off"}`)}</div>
            <div>{t(`enums.audio-status.${record.audio_status ? "on" : "off"}`)}</div>
          </>
        ),
      },
      {
        key: "options",
        width: 200,
        title: t("columns.options"),
        fixed: "right",
        render: (value, record) => (
          <>
            {isActionAllowed(actions.SWITCH_STATUS) && record.status === 2 && (
              <button
                type="button"
                className="optionBtn optionBtnSuccess"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "enable-user",
                    userID: record.user_id,
                  })
                }
              >
                {t("options.enable")}
              </button>
            )}
            {isActionAllowed(actions.SWITCH_STATUS) && record.status === 1 && (
              <button
                type="button"
                className="optionBtn optionBtnDanger"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "disable-user",
                    userID: record.user_id,
                  })
                }
              >
                {t("options.disable")}
              </button>
            )}
            <button type="button" className="optionBtn" onClick={() => setUserModal({ open: true, user: record })}>
              {t("options.edit")}
            </button>
            {isActionAllowed(actions.DELETE_USERS) && (
              <button
                type="button"
                className="optionBtn optionBtnDanger"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "delete-user",
                    userID: record.user_id,
                  })
                }
              >
                {t("options.delete")}
              </button>
            )}
            {isActionAllowed(actions.SWITCH_STATUS) && record.video_status === 2 && (
              <button
                type="button"
                className="optionBtn optionBtnSuccess"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "enable-video",
                    userID: record.user_id,
                  })
                }
              >
                {t("options.enable-video")}
              </button>
            )}
            {isActionAllowed(actions.SWITCH_STATUS) && record.video_status === 1 && (
              <button
                type="button"
                className="optionBtn optionBtnDanger"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "disable-video",
                    userID: record.user_id,
                  })
                }
              >
                {t("options.disable-video")}
              </button>
            )}
            {isActionAllowed(actions.SWITCH_STATUS) && record.audio_status === 2 && (
              <button
                type="button"
                className="optionBtn optionBtnSuccess"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "enable-audio",
                    userID: record.user_id,
                  })
                }
              >
                {t("options.enable-audio")}
              </button>
            )}
            {isActionAllowed(actions.SWITCH_STATUS) && record.audio_status === 1 && (
              <button
                type="button"
                className="optionBtn optionBtnDanger"
                onClick={() =>
                  setOpenModal({
                    open: true,
                    key: "disable-audio",
                    userID: record.user_id,
                  })
                }
              >
                {t("options.disable-audio")}
              </button>
            )}
          </>
        ),
      },
    ],
    [t, data]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ filterRange, keyword, source, shareCode, remark, filterType, gender, status, lastLoginDevice }: FormValues) => {
      setParams(({ show_number, order_by }) => {
        const state: GetUsersRequestParams = { page_number: 1, show_number, order_by };
        if (keyword !== "") {
          state.user_id = keyword;
        }
        if (source !== 0) {
          state.source_id = source;
        }
        if (source == 2 && shareCode !== "") {
          state.code = shareCode;
        }
        if (gender !== 0) {
          state.gender = gender;
        }
        if (status.length > 0) {
          state.account_status = JSON.stringify(status.map((item) => item.toString()));
        }
        if (remark !== "") {
          state.code = remark;
        }
        if (filterType !== 0) {
          state.type = filterType;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = startTime;
          state.end_time = endTime;
        }
        if (lastLoginDevice !== 0) {
          state.last_login_device = lastLoginDevice;
        }
        return state;
      });
      setSearchLoading(true);
    },
    [setParams]
  );

  const handleFieldsChange = useCallback(
    ([fieldData]: FieldData[]) => {
      const { name, value } = fieldData;
      if (Array.isArray(name) && name[0] === "source") {
        setSourceValue(value);
      }
    },
    [setSourceValue]
  );

  const handleMultipleDeleteClick = useCallback(
    () =>
      setDeleteSelection({
        columnWidth: 50,
        selectedRowKeys: [],
        onChange: (selectedRowKeys) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );

  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);

  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);

  const handleModalOk = useCallback(() => {
    let status: 1 | 2, status_type: 1 | 2 | 3;
    switch (openModal.key) {
      case "multiple-delete":
        if (deleteSelection !== undefined) {
          deleteUserMutation.mutate(deleteSelection.selectedRowKeys as string[]);
        }
        return;
      case "delete-user":
        deleteUserMutation.mutate([openModal.userID]);
        return;
      case "disable-user":
        status_type = 1;
        status = 2;
        break;
      case "enable-user":
        status_type = 1;
        status = 1;
        break;
      case "disable-video":
        status_type = 2;
        status = 2;
        break;
      case "enable-video":
        status_type = 2;
        status = 1;
        break;
      case "disable-audio":
        status_type = 3;
        status = 2;
        break;
      case "enable-audio":
        status_type = 3;
        status = 1;
        break;
    }
    switchStatusMutation.mutate({ status, status_type, user_id: openModal.userID });
  }, [deleteUserMutation.mutate, deleteSelection, openModal]);

  const handleUserModalSubmit = useCallback(
    (values: UserModalValues) => {
      const { account, gender, faceUrl, nickname, password, phone, remark, source, shareCode, tags, email } = values;
      if (userModal.user === undefined) {
        addUserMutation.mutate({
          user_id: account,
          gender,
          password,
          name: nickname,
          email,
          interests: tags,
          remark,
          code: shareCode,
          face_url: faceUrl,
          phone_number: phone,
          source_id: source,
        });
        return;
      }
      alterUserMutation.mutate({
        user_id: account,
        gender,
        password,
        nickname,
        email,
        interests: tags.map(item => item.toString()),
        remark,
        face_url: faceUrl,
        phone_number: phone,
        source_id: source,
        code: shareCode
      })
    },
    [userModal, addUserMutation.mutate, alterUserMutation.mutate]
  );

  if (!isActionAllowed(actions.GET_USERS)) {
    return null;
  }

  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="keyword">
          <Input placeholder={t("form.keyword.placeholder")} style={{ width: 188 }} />
        </Form.Item>
        <Form.Item name="source">
          <Select
            options={(["all", "official", "share-code"] as const).map((key, value) => ({
              value,
              label: t(`form.source.options.${key}`),
            }))}
            style={{ width: 120 }}
          />
        </Form.Item>
        {sourceValue !== 1 && (
          <Form.Item name="shareCode">
            <Input placeholder={t("form.share-code.placeholder")} style={{ width: 188 }} />
          </Form.Item>
        )}
        {sourceValue === 1 && (
          <Form.Item>
            <Input placeholder={t("form.share-code.placeholder")} disabled style={{ width: 188 }} />
          </Form.Item>
        )}
        <Form.Item name="gender" label={t("form.gender.label")}>
          <Select
            options={(["all", "male", "female"] as const).map((key, value) => ({
              value,
              label: t(`form.gender.options.${key}`),
            }))}
            style={{ width: 120 }}
          />
        </Form.Item>
        <Form.Item name="status" label={t("form.status.label")}>
          <Select
            mode="multiple"
            placeholder={t("form.status.placeholder")}
            options={([1, 2, 3, 4, 5, 6] as const).map((value) => ({
              value,
              label: t(`form.status.options.${value}`),
            }))}
            style={{ width: 120 }}
          />
        </Form.Item>
        <Form.Item name="remark" label={t("form.remark.label")}>
          <Input placeholder={t("form.remark.placeholder")} />
        </Form.Item>
        <Form.Item name="filterType">
          <Select
            options={(["all", "create-time", "last-login-time"] as const).map((key, value) => ({
              value,
              label: t(`form.filter-type.options.${key}`),
            }))}
            style={{ width: 120 }}
          />
        </Form.Item>
        <Form.Item name="filterRange">
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} style={{ width: 280 }} />
        </Form.Item>
        <Form.Item name="lastLoginDevice" label={t("form.last-login-device.label")}>
          <Select
            options={(["all", "ios", "android", "desktop"] as const).map((key, value) => ({
              value,
              label: t(`form.last-login-device.options.${key}`),
            }))}
            style={{ width: 120 }}
          />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnSuccess" type="primary" htmlType="button" icon={<Icon component={AddIcon} />} onClick={() => setUserModal({ open: true })}>
            {t("form.buttons.create-new-user")}
          </Button>
        </Form.Item>
        {deleteSelection !== undefined && (
          <>
            <Form.Item>
              <Button className="filterBtn filterBtnPlain" htmlType="button" onClick={handleMultipleDeleteCancelClick}>
                {t("form.buttons.cancel")}
              </Button>
            </Form.Item>
            <Form.Item>
              <Button
                className="filterBtn filterBtnDanger"
                type="primary"
                htmlType="button"
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", userID: "" })}
                disabled={deleteSelection.selectedRowKeys === undefined || deleteSelection.selectedRowKeys.length === 0}
              >
                {t("form.buttons.delete")}
              </Button>
            </Form.Item>
          </>
        )}
        {isActionAllowed(actions.DELETE_USERS) && deleteSelection === undefined && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" htmlType="button" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleDeleteClick}>
              {t("form.buttons.multiple-delete")}
            </Button>
          </Form.Item>
        )}
      </Form>
      <Table
        rowKey="user_id"
        className="customTable"
        dataSource={data?.data.users || []}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        rowSelection={deleteSelection}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.user_nums,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
      <ConfirmModal
        open={openModal.open}
        type={openModal.key}
        onCancel={handleModalCancel}
        onOk={handleModalOk}
        confirmLoading={deleteUserMutation.isLoading || switchStatusMutation.isLoading}
      />
      <UserModal
        open={userModal.open}
        onCancel={() => setUserModal({ open: false })}
        user={userModal.user}
        confirmLoading={addUserMutation.isLoading || alterUserMutation.isLoading}
        onSubmit={handleUserModalSubmit}
      />
    </>
  );
};

export default UserListView;
