import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Form, Input, Modal, ModalProps, Select, Space, Spin, Upload } from "antd";
import { useTranslation } from "react-i18next";
import useGetInterestListQuery from "~/hooks/useGetInterestListQuery";
import useRequest from "~/hooks/useRequest";
import { UploadFile } from "antd/es/upload/interface";
import { GetUserInterestsRequestParams, GetUsersItem } from "~/api/types";
import { useQuery } from "@tanstack/react-query";
import { actions } from "~/api/constants";
import stringByteSlice from "string-byte-slice";
import useUpload from "~/hooks/useUpload";
import { UploadType } from "~/api";

interface FormValues {
  account: string;
  phone: string;
  nickname: string;
  password: string;
  faceUrlFileList: UploadFile[];
  email: string;
  gender: number;
  source: string;
  shareCode: string;
  tags: number[];
  remark: string;
}

const initialValues: FormValues = {
  account: "",
  phone: "",
  nickname: "",
  password: "",
  faceUrlFileList: [],
  email: "",
  gender: 1,
  source: "1",
  shareCode: "",
  tags: [],
  remark: "",
};

export type UserModalValues = Omit<FormValues, "faceUrlFileList"> & { faceUrl: string };

interface UserModalProps extends ModalProps {
  user?: GetUsersItem;
  onSubmit: (params: UserModalValues) => void;
}

const UserModal: React.FC<UserModalProps> = ({ user, onSubmit, ...rest }) => {
  const { t } = useTranslation("user-list-view");
  const [form] = Form.useForm<FormValues>();
  const request = useRequest();
  const upload = useUpload();
  const interestListQuery = useGetInterestListQuery(
    {
      show_number: -1,
      page_number: 1,
      time_type: 0,
    },
    request,
    { enabled: rest.open }
  );

  const userInterestListQueryParams: GetUserInterestsRequestParams = useMemo(
    () => ({
      show_number: -1,
      page_number: 1,
      user_id: user?.user_id || "",
    }),
    [user]
  );

  const userInterestListQuery = useQuery({
    queryKey: [actions.GET_USER_INTERESTS, userInterestListQueryParams],
    queryFn: () => request(actions.GET_USER_INTERESTS, userInterestListQueryParams),
    enabled: rest.open && user !== undefined,
    onSuccess: (res) => {
      form.setFieldValue(
        "tags",
        res.data.interests[0].interests.map((item) => item.id)
      );
    },
  });

  const [selectedTags, setSelectedTags] = useState<number[]>([]);
  const [faceUrlFilesList, setFaceUrlFilesList] = useState<UploadFile[]>([]);
  const [nicknameError, setNicknameError] = useState<boolean>(false);

  const [editMode, values] = useMemo(() => {
    if (user != undefined) {
      return [
        true,
        {
          account: user.user_id,
          phone: user.phone_number,
          nickname: user.nick_name,
          password: "",
          faceUrlFileList:
            user.profile_photo === ""
              ? []
              : [
                  {
                    uid: "-1",
                    name: "",
                    url: user.profile_photo,
                    status: "done",
                  } as UploadFile,
                ],
          email: user.email,
          gender: user.gender,
          source: user.source_id,
          shareCode: user.source_code,
          tags: [],
          remark: user.remark,
        },
      ];
    }
    return [false, initialValues];
  }, [user]);

  useEffect(() => {
    form.setFieldsValue(values);
    setFaceUrlFilesList(values.faceUrlFileList);
  }, [form, values]);

  const handleValuesChange = useCallback(
    (changedValues: FormValues) => {
      if (changedValues.tags !== undefined) {
        setSelectedTags(changedValues.tags);
      }
      if (changedValues.faceUrlFileList !== undefined) {
        setFaceUrlFilesList(changedValues.faceUrlFileList);
      }
    },
    [setSelectedTags]
  );

  const handleFinnish = useCallback(() => {
    const { email, gender, phone, remark, account, tags, password, faceUrlFileList } = form.getFieldsValue();
    const nickname = form.getFieldValue("nickname");
    const source = form.getFieldValue("source");
    const shareCode = form.getFieldValue("shareCode");
    if (nickname.length === 0) {
      setNicknameError(true);
      return;
    }
    if (faceUrlFileList[0].status !== "done") {
      return;
    }
    const faceUrl = faceUrlFileList[0].url || faceUrlFileList[0].response?.URL;
    onSubmit({
      nickname,
      source,
      shareCode,
      faceUrl,
      email,
      gender,
      phone,
      remark,
      account,
      tags,
      password,
    });
  }, [onSubmit, form, setNicknameError]);

  const handleFinnishFailed = useCallback(() => {
    const nickname = form.getFieldValue("nickname");
    if (nickname.length === 0) {
      setNicknameError(true);
    }
  }, [setNicknameError]);

  const handleAfterClose = useCallback(() => {
    setNicknameError(false);
    setFaceUrlFilesList([]);
  }, [form, setNicknameError, setFaceUrlFilesList]);

  return (
    <Modal
      destroyOnClose
      title={t(`modals.user-modal.title.${editMode ? "edit" : "create"}`)}
      onOk={form.submit}
      okText={t(`modals.user-modal.buttons.${editMode ? "save" : "create"}`)}
      afterClose={handleAfterClose}
      {...rest}
    >
      <Spin spinning={interestListQuery.isLoading || (userInterestListQuery.isLoading && user !== undefined)}>
        <Form form={form} initialValues={initialValues} onValuesChange={handleValuesChange} onFinish={handleFinnish} onFinishFailed={handleFinnishFailed}>
          <Space>
            <div>
              <Form.Item
                name="account"
                label={t("modals.user-modal.inputs.account.label")}
                rules={[
                  {
                    required: true,
                    message: t("modals.user-modal.inputs.account.errors.required"),
                  },
                ]}
              >
                <Input maxLength={11} showCount placeholder={t("modals.user-modal.inputs.account.placeholder")} disabled={editMode} />
              </Form.Item>
              <Form.Item name="phone" label={t("modals.user-modal.inputs.phone.label")}>
                <Input placeholder={t("modals.user-modal.inputs.phone.placeholder")} />
              </Form.Item>
              <Form.Item
                shouldUpdate
                label={t("modals.user-modal.inputs.nickname.label")}
                required
                validateStatus={nicknameError ? "error" : undefined}
                help={nicknameError ? t("modals.user-modal.inputs.nickname.errors.required") : undefined}
              >
                {(form) => (
                  <Input
                    value={stringByteSlice(form.getFieldValue("nickname"), 0, 36)}
                    maxLength={36}
                    showCount={{
                      formatter: ({ value }) => `${new TextEncoder().encode(value).length} / ${36}`,
                    }}
                    placeholder={t("modals.user-modal.inputs.nickname.placeholder")}
                    onChange={(e) => {
                      form.setFieldValue("nickname", e.target.value);
                      setNicknameError(e.target.value.length === 0);
                    }}
                  />
                )}
              </Form.Item>
              <Form.Item
                name="password"
                label={t("modals.user-modal.inputs.password.label")}
                rules={[
                  {
                    required: !editMode,
                    message: t("modals.user-modal.inputs.password.errors.required"),
                  },
                ]}
              >
                <Input maxLength={20} showCount placeholder={t("modals.user-modal.inputs.password.placeholder")} />
              </Form.Item>
            </div>
            <Form.Item
              name="faceUrlFileList"
              valuePropName="fileList"
              rules={[
                {
                  required: true,
                  message: t("modals.user-modal.inputs.faceUrl.errors.required"),
                },
                {
                  validator: (rule, value, callback) => {
                    if (value.length > 0) {
                      if (value[0].status === "error") {
                        return callback("upload-error");
                      }
                    }
                    callback();
                  },
                  message: t("modals.user-modal.inputs.faceUrl.errors.upload-error"),
                },
              ]}
              getValueFromEvent={(e: any) => e.fileList}
            >
              <Upload
                listType="picture-card"
                accept=".png,jpg,.jpeg,.gif"
                customRequest={({ file, onProgress, onSuccess, onError }) =>
                  upload({
                    type: UploadType.picture,
                    persist: true,
                    file: file as File,
                    onProgress,
                  })
                    .then(onSuccess)
                    .catch(onError)
                }
              >
                {faceUrlFilesList.length === 0 && t("modals.user-modal.inputs.faceUrl.placeholder")}
              </Upload>
            </Form.Item>
          </Space>
          <Form.Item name="email" label={t("modals.user-modal.inputs.email.label")} rules={[{ type: "email", message: t("modals.user-modal.inputs.email.errors.invalid") }]}>
            <Input placeholder={t("modals.user-modal.inputs.email.placeholder")} />
          </Form.Item>
          <Form.Item name="gender" label={t("modals.user-modal.inputs.gender.label")}>
            <Select
              options={[
                {
                  label: t("modals.user-modal.inputs.gender.options.male"),
                  value: 1,
                },
                { label: t("modals.user-modal.inputs.gender.options.female"), value: 2 },
              ]}
            />
          </Form.Item>
          <Form.Item shouldUpdate>
            {(form) => (
              <Space>
                <Select
                  disabled={editMode}
                  value={form.getFieldValue("source")}
                  onChange={(value) => form.setFieldsValue({ source: value, shareCode: "" })}
                  options={[
                    { label: t("modals.user-modal.inputs.share-code.options.official"), value: "1" },
                    {
                      label: t("modals.user-modal.inputs.share-code.options.share-code"),
                      value: "2",
                    },
                  ]}
                />
                <Input
                  disabled={editMode}
                  value={form.getFieldValue("source") === "1" ? t("modals.user-modal.inputs.share-code.official") : form.getFieldValue("shareCode")}
                  readOnly={form.getFieldValue("source") === "1"}
                  onChange={(e) => form.setFieldValue("shareCode", e.target.value)}
                />
              </Space>
            )}
          </Form.Item>
          {(["cn", "en", "ar"] as const).map((lang) => (
            <Form.Item
              key={lang}
              name="tags"
              label={t(`modals.user-modal.inputs.tags-${lang}.label`)}
              rules={[
                {
                  required: true,
                  message: t(`modals.user-modal.inputs.tags-${lang}.errors.required`),
                },
              ]}
            >
              <Select
                mode="multiple"
                placeholder={t(`modals.user-modal.inputs.tags-${lang}.placeholder`)}
                options={interestListQuery.data?.data.interests.map((item) => ({
                  label: item.name.find((translation) => translation.language_type === lang)?.name,
                  value: item.id,
                  disabled: selectedTags.length >= 10 && !selectedTags.some((tag) => tag === item.id),
                }))}
              />
            </Form.Item>
          ))}
          <Form.Item name="remark" label={t("modals.user-modal.inputs.remark.label")}>
            <Input.TextArea placeholder={t("modals.user-modal.inputs.remark.placeholder")} />
          </Form.Item>
        </Form>
      </Spin>
    </Modal>
  );
};

export default UserModal;
