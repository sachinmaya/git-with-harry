import React from "react";
import { Modal, ModalProps } from "antd";
import { useTranslation } from "react-i18next";

type ModalType = "multiple-delete" | "delete-user" | "disable-user" | "enable-user" | "disable-video" | "enable-video" | "disable-audio" | "enable-audio";

interface ConfirmModalProps extends ModalProps {
  type: ModalType;
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({ type, ...props }) => {
  const { t } = useTranslation("user-list-view");
  return (
    <Modal
      className="confirmModal"
      okButtonProps={{ danger: ["multiple-delete", "delete-user", "disable-user", "disable-video", "disable-audio"].includes(type) }}
      okText={t(`modals.${type}.buttons.ok`)}
      cancelText={t(`modals.${type}.buttons.cancel`)}
      destroyOnClose
      {...props}
    >
      {t(`modals.${type}.content`)}
    </Modal>
  );
};

export default ConfirmModal;
