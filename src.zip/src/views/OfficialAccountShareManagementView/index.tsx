import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, DeleteNewsShareParams, GetNewsShareListRequestParams, ShareItem } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, message, Select, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import Icon from "@ant-design/icons";
import { TableRowSelection } from "antd/es/table/interface";
import Text from "antd/lib/typography/Text";
import dayjs, { Dayjs } from "dayjs";
import { useLocation } from "react-router-dom";
import { FieldData } from "rc-field-form/lib/interface";
import { InternalServerError, NetworkError } from "~/api/errors";
import usePermissions from "~/hooks/usePermissions";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import ConfirmModal from "./ConfirmModal";
import ChangePrivacyModal from "./ChangePrivacyModal";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";

const initialParams: GetNewsShareListRequestParams = {
  page_number: 1,
  show_number: 10,
  order_by: "start_time:desc",
};

const getShareListQuery = (request: ApiRequest, params: GetNewsShareListRequestParams = initialParams) => ({
  queryKey: [actions.GET_SHARE_LIST, params],
  queryFn: async () => request(actions.GET_SHARE_LIST, params),
});

export const officialAccountShareManagementViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getShareListQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  shareBy: string;
  accountType: number;
  ip: string;
  postTopic: string;
  filterType: number;
  filterRange: null | Dayjs[];
  originalAuthor: string;
}

type ModalKey = "multiple-delete" | "delete-share";

const OfficialAccountShareManagementView: React.FC = () => {
  const { t } = useTranslation("share-management-view");
  const { setDashboardHeading } = useDashboardView();
  const { isActionAllowed } = usePermissions();
  const request = useRequest();
  const queryClient = useQueryClient();
  const location = useLocation();
  const [params, setParams] = useState<GetNewsShareListRequestParams>(() => ({ ...initialParams, title: location.state?.title || "" }));
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<ShareItem> | undefined>(undefined);
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; articleID: number; moment_id: string }>({
    open: false,
    key: "multiple-delete",
    articleID: 0,
    moment_id: "",
  });
  const [openPrivacyModal, setOpenPrivacyModal] = useState<{ open: boolean; moment_id: string; privacy: number }>({
    open: false,
    moment_id: "",
    privacy: 0,
  });

  const initialValues: FormValues = useMemo(
    () => ({
      shareBy: "",
      accountType: 0,
      ip: "",
      postTopic: location.state?.title || "",
      filterType: 0,
      filterRange: null,
      originalAuthor: "",
    }),
    [location.state]
  );
  const { data, refetch, isPreviousData } = useQuery({
    ...getShareListQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.Share-list-query-failed"),
      });
    },
  });

  const deleteShareMutation = useMutation((params: DeleteNewsShareParams) => request(actions.DELETE_SHARE, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_SHARE_LIST]);
      message.open({
        key: "delete-successfully",
        type: "success",
        content: t("toasts.delete-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-failed",
        type: "error",
        content: t("toasts.delete-failed"),
      });
    },
  });
  useEffect(() => {
    setDashboardHeading("official-account", "official-account-share-management");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const columns: ColumnsType<ShareItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "share_by",
        dataIndex: "share_user",
        width: 160,
        title: t("columns.share-by"),
        render: (value) => value || "-",
      },
      {
        key: "original_author",
        dataIndex: "original_user",
        width: 160,
        title: t("columns.original-author"),
        render: (value) => value || "-",
      },
      {
        key: "account_type",
        width: 160,
        dataIndex: "official_type",
        title: t("columns.account-type"),
        render: (value) => (
          <>
            {value === 1 && t("form.account-type.options.personal")}
            {value === 2 && t("form.account-type.options.business")}
          </>
        ),
      },
      {
        key: "post",
        width: 200,
        dataIndex: "article_title",
        title: t("columns.post"),
        render: (value) => (
          <Text
            style={{ width: 180 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "cover_picture",
        width: 160,
        dataIndex: "cover_photo",
        title: t("columns.cover-picture"),
        render: (value) => (value === "" ? "-" : <Image src={value} width={30} height={30} />),
      },
      {
        key: "comments",
        width: 160,
        dataIndex: "comment_counts",
        title: t("columns.comments"),
        render: (value) => value,
      },
      {
        key: "likes",
        width: 160,
        dataIndex: "like_counts",
        title: t("columns.likes"),
        render: (value) => value,
      },
      {
        key: "share_time",
        width: 160,
        dataIndex: "share_time",
        title: t("columns.share-time"),
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "ip",
        width: 160,
        dataIndex: "last_login_ip",
        title: t("columns.last-login-ip"),
        render: (value) => value,
      },
      {
        key: "operations",
        width: 160,
        title: t("columns.operations"),
        fixed: "right",
        render: (record) => {
          return (
            <>
              {isActionAllowed(actions.CHANGE_NEWS_LIKE_STATUS) && record.privacy === 1 && (
                <Button onClick={() => setOpenPrivacyModal({ open: true, moment_id: record.moment_id, privacy: record.privacy })} className="optionBtn optionBtnSuccess">
                  {t("form.buttons.public")}
                </Button>
              )}
              {isActionAllowed(actions.CHANGE_NEWS_LIKE_STATUS) && record.privacy === 2 && (
                <Button onClick={() => setOpenPrivacyModal({ open: true, moment_id: record.moment_id, privacy: record.privacy })} className="optionBtn">
                  {t("form.buttons.private")}
                </Button>
              )}
              {isActionAllowed(actions.DELETE_SHARE) && (
                <Button
                  className="optionBtn optionBtnDanger"
                  onClick={() => setOpenModal({ open: true, articleID: record.article_id, moment_id: record.moment_id, key: "delete-share" })}
                >
                  {t("form.buttons.delete")}
                </Button>
              )}
            </>
          );
        },
      },
    ],
    [t]
  );
  const handleMultipleDeleteClick = useCallback(
    () =>
      setDeleteSelection({
        columnWidth: 50,
        selectedRowKeys: [],
        onChange: (selectedRowKeys) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          console.log("selected rows", selectedRowKeys);
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );

  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );
  const handleFinnish = useCallback(
    ({ filterRange, shareBy, accountType, ip, postTopic, filterType, originalAuthor }: FormValues) => {
      setParams(({ show_number, order_by }) => {
        const state: GetNewsShareListRequestParams = { page_number: 1, show_number, order_by };
        if (shareBy !== "") {
          state.repost_user = shareBy.trim();
        }
        if (ip !== "") {
          state.ip = ip.trim();
        }
        if (postTopic !== "") {
          state.title = postTopic.trim();
        }
        if (filterType !== 0) {
          state.time_type = filterType;
        }
        if (accountType !== 0) {
          state.account_type = accountType;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = startTime;
          state.end_time = endTime;
        }
        if (originalAuthor !== "") {
          state.original_user = originalAuthor.trim();
        }

        return state;
      });
      setSearchLoading(true);
    },
    [setParams, refetch]
  );

  const handleFieldsChange = useCallback(([fieldData]: FieldData[]) => {
    const { name, value } = fieldData;
  }, []);
  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    switch (openModal.key) {
      case "delete-share":
        deleteShareMutation.mutate({ articles: [openModal.articleID], moment_ids: [openModal.moment_id] });
        return;
      case "multiple-delete":
        if (openModal.key === "multiple-delete" && deleteSelection !== undefined && deleteSelection.selectedRowKeys !== undefined) {
          deleteShareMutation.mutate({
            articles: deleteSelection.selectedRowKeys.map((item: any) => Number(item.split("-")[0])),
            moment_ids: deleteSelection.selectedRowKeys.map((item: any) => item.split("-")[1]),
          });
        }
        return;
    }
  }, [deleteShareMutation.mutate, openModal]);
  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="shareBy" label={t("form.share-by")}>
          <Input style={{ width: 158 }} />
        </Form.Item>
        <Form.Item name="accountType" label={t("form.account-type.label")}>
          <Select
            style={{ width: 158 }}
            options={(["all", "personal", "business"] as const).map((key, value) => ({
              value,
              label: t(`form.account-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="ip" label={t("form.ip")}>
          <Input style={{ width: 198 }} />
        </Form.Item>
        <Form.Item name="postTopic" label={t("form.post-topic")}>
          <Input style={{ width: 198 }} />
        </Form.Item>
        <Form.Item name="filterType">
          <Select
            style={{ width: 158 }}
            options={(["all", "share-time"] as const).map((key, value) => ({
              value,
              label: t(`form.filter-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="filterRange">
          <DatePicker.RangePicker style={{ width: 200 }} disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item name="originalAuthor" label={t("form.original-author")}>
          <Input style={{ width: 180 }} />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        {deleteSelection !== undefined && (
          <>
            <Form.Item>
              <Button htmlType="button" className="filterBtn filterBtnPlain" onClick={handleMultipleDeleteCancelClick}>
                {t("modals.multiple-delete.buttons.cancel")}
              </Button>
            </Form.Item>
            <Form.Item>
              <Button
                type="primary"
                htmlType="button"
                className="filterBtn filterBtnDanger"
                danger
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", articleID: 0, moment_id: "" })}
                disabled={deleteSelection.selectedRowKeys === undefined || deleteSelection.selectedRowKeys.length === 0}
              >
                {t("form.buttons.delete")}
              </Button>
            </Form.Item>
          </>
        )}
        {isActionAllowed(actions.DELETE_NEWS_LIKES) && deleteSelection === undefined && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" htmlType="button" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleDeleteClick}>
              {t("form.buttons.multiple-delete")}
            </Button>
          </Form.Item>
        )}
      </Form>
      <Table
        rowKey={(record) => `${record.article_id}-${record.moment_id}`}
        className="customTable"
        dataSource={data?.data.repost}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        rowSelection={deleteSelection}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.repost_nums,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
      <ConfirmModal open={openModal.open} type={openModal.key} onOk={handleModalOk} onCancel={handleModalCancel} confirmLoading={deleteShareMutation.isLoading} />
      <ChangePrivacyModal
        open={openPrivacyModal.open}
        onCancel={() => setOpenPrivacyModal((state) => ({ ...state, open: false }))}
        privacy={openPrivacyModal.privacy}
        handleCancel={() => setOpenPrivacyModal((state) => ({ ...state, open: false }))}
        moment_id={openPrivacyModal.moment_id}
      />
    </>
  );
};

export default OfficialAccountShareManagementView;
