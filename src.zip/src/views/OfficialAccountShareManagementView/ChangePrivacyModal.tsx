import React from "react";
import { Modal, ModalProps } from "antd";
import { Form, Input, message, Select } from "antd";
import { useForm } from "antd/lib/form/Form";
import { useTranslation } from "react-i18next";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ChangeSharePrivacyParams } from "~/api/types";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface FormValues {
  sharePrivacy: number;
}

interface ChangePrivacyModalProps extends ModalProps {
  moment_id: string;
  privacy: number;
  handleCancel: () => void;
}

const ChangePrivacyModal: React.FC<ChangePrivacyModalProps> = ({ moment_id, privacy, handleCancel, ...props }) => {
  const { t } = useTranslation("share-management-view");
  const [privacyForm] = useForm();
  const request = useRequest();
  const queryClient = useQueryClient();
  const initialValues: FormValues = {
    sharePrivacy: privacy,
  };
  const changePrivacyMutation = useMutation((params: ChangeSharePrivacyParams) => request(actions.CHANGE_SHARE_PRIVACY, params), {
    onSuccess: () => {
      handleCancel();
      queryClient.invalidateQueries([actions.GET_SHARE_LIST]);
      message.open({
        key: "process-successfully",
        type: "success",
        content: t("toasts.share-privacy-changed-success"),
      });
    },
  });

  const handleFinish = ({ sharePrivacy }: FormValues) => {
    changePrivacyMutation.mutate({ moment_id: moment_id, privacy: sharePrivacy });
  };

  return (
    <Modal
      className="confirmModal"
      okText={t(`modals.change-visibility.buttons.ok`)}
      cancelText={t(`modals.change-visibility.buttons.cancel`)}
      destroyOnClose={true}
      {...props}
      onOk={privacyForm.submit}
      onCancel={handleCancel}
    >
      <Form layout="inline" onFinish={handleFinish} form={privacyForm} initialValues={initialValues}>
        <Form.Item label={t("modals.change-visibility.content")} name="sharePrivacy" preserve={false}>
          <Select
            style={{ width: 120 }}
            options={[
              { value: 1, label: t("form.buttons.public") },
              { value: 2, label: t("form.buttons.private") },
            ]}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default ChangePrivacyModal;
