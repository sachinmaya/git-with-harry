import React, { FC, useCallback, useEffect, useMemo, useState } from "react";
import { useDashboardView } from "../DashboardView";
import dayjs, { Dayjs } from "dayjs";
import { Button, DatePicker, Empty, Form, Image, Input, message, Modal, Select, Table } from "antd";
import { useTranslation } from "react-i18next";
import { TableRowSelection } from "antd/es/table/interface";
import {
  ApiRequest,
  ContentImagesArrayType,
  ContentVideosArrayType,
  GetMomentLikesItem,
  GetMomentsLikesRequestParams,
  RemoveMomentLikesRequestParams,
  SwitchMomentLikesStatusRequestParams,
} from "~/api/types";
import { actions } from "~/api/constants";
import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { ColumnsType } from "antd/es/table";
import Text from "antd/lib/typography/Text";
import SearchIcon from "~/components/icons/SearchIcon";
import Icon, { EyeOutlined } from "@ant-design/icons";
import DeleteIcon from "~/components/icons/DeleteIcon";
import VideoPlayer from "~/components/VideoPlayerModal";
import usePermissions from "~/hooks/usePermissions";
import { InternalServerError, NetworkError } from "~/api/errors";
import VideoContent from "~/components/VideoContent";

const initialParams: GetMomentsLikesRequestParams = {
  page_number: 1,
  show_number: 10,
  order_by: "start_time:desc",
};

const getMomentsLikesQuery = (request: ApiRequest, params: GetMomentsLikesRequestParams = initialParams) => ({
  queryKey: [actions.GET_MOMENT_LIKES, params],
  queryFn: async () => request(actions.GET_MOMENT_LIKES, params),
});

export const MomentsLikesViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getMomentsLikesQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  publish_user: string;
  content_type: number;
  m_content_text: string;
  media_type: number;
  time_type: number;
  like_user: string;
  filter_range: null | Dayjs[];
}
const initialValue: FormValues = {
  publish_user: "",
  content_type: 0,
  m_content_text: "",
  media_type: 0,
  like_user: "",
  time_type: 0,
  filter_range: null,
};
const initialDelete: RemoveMomentLikesRequestParams = { moments_id: [], users_id: [] };
interface VideoData {
  open: boolean;
  video: ContentVideosArrayType | null;
}
interface MomentsLikesViewProps {}

const MomentsLikesView: FC<MomentsLikesViewProps> = () => {
  const { setDashboardHeading } = useDashboardView();
  const { t } = useTranslation("moments-likes-view");
  const [form] = Form.useForm();
  const contentType = Form.useWatch("content_type", form);
  const request = useRequest();
  const { confirm, destroyAll } = Modal;
  const queryClient = useQueryClient();
  const { isActionAllowed } = usePermissions();
  const [visible, setVisible] = useState<string | null>(null);
  const [vedioPlayer, setVedioPlayer] = useState<VideoData>({ open: false, video: null });
  const [deleteParams, setDeleteParams] = useState<RemoveMomentLikesRequestParams>(initialDelete);
  const [params, setParams] = useState<GetMomentsLikesRequestParams>(initialParams);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<GetMomentLikesItem> | undefined>(undefined);

  const { data, refetch, isRefetching } = useQuery({
    ...getMomentsLikesQuery(request, params),
    keepPreviousData: true,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.error(t("toasts.like-query-failed"));
    },
  });
  const deleteMutation = useMutation((params: RemoveMomentLikesRequestParams) => request(actions.REMOVE_MOMENTS_LIKES, params), {
    onSuccess() {
      queryClient.invalidateQueries({
        queryKey: [actions.GET_MOMENT_LIKES, params],
      });
      setDeleteSelection(undefined);
      setDeleteParams(initialDelete);
      destroyAll();
      message.open({
        key: "delete-multi-success",
        type: "success",
        content: t("toasts.delete-multi-success"),
      });
    },
    onError(error) {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      destroyAll();
      message.error(t("toasts.delete-failed"));
    },
  });
  const statusMutation = useMutation((params: SwitchMomentLikesStatusRequestParams) => request(actions.SWITCH_MOMENT_LIKES_STATUS, params), {
    onSuccess(data, { status }) {
      queryClient.invalidateQueries({
        queryKey: [actions.GET_MOMENT_LIKES, params],
      });
      setDeleteSelection(undefined);
      destroyAll();
      message.open({
        key: "hide-success",
        type: "success",
        content: status === 2 ? t("toasts.hide-success") : t("toasts.show-success"),
      });
    },
    onError(error, { status }) {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      destroyAll();
      message.error(status === 2 ? t("toasts.hide-failed") : t("toasts.show-failed"));
    },
  });

  useEffect(() => {
    setDashboardHeading("moments-management", "moments-likes");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const deleteLikes = () => {
    confirm({
      content: t("modal.delete-multi-likes.content"),
      icon: <></>,
      okType: "danger",
      okButtonProps: { type: "primary" },
      onOk: () => deleteMutation.mutateAsync(deleteParams),
      okText: t("modal.delete-multi-likes.ok-btn"),
      cancelText: t("modal.delete-multi-likes.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const deleteSingleLike = (like: GetMomentLikesItem) => {
    confirm({
      content: t("modal.delete-likes.content"),
      icon: <></>,
      okType: "danger",
      okButtonProps: { type: "primary" },
      onOk: () => deleteMutation.mutateAsync({ moments_id: [like.moment_id], users_id: [like.user_id] }),
      okText: t("modal.delete-likes.ok-btn"),
      cancelText: t("modal.delete-likes.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };

  const hideLike = (moment_id: string, user_id: string, status: number) => {
    confirm({
      content: t("modal.hide-likes.content"),
      icon: <></>,
      onOk: () => statusMutation.mutateAsync({ moment_id, user_id, status }),
      okText: t("modal.hide-likes.ok-btn"),
      cancelText: t("modal.hide-likes.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const showLike = (moment_id: string, user_id: string, status: number) => {
    confirm({
      content: t("modal.unhide-likes.content"),
      icon: <></>,
      onOk: () => statusMutation.mutateAsync({ moment_id, user_id, status }),
      okText: t("modal.unhide-likes.ok-btn"),
      cancelText: t("modal.unhide-likes.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const playVideo = (video: ContentVideosArrayType) => {
    if (video !== null) {
      return setVedioPlayer({ open: true, video: video });
    }
  };
  const closePlayer = () => setVedioPlayer({ open: false, video: null });
  const showMedia = (item: GetMomentLikesItem) => {
    if (item.mContentImagesArrayV2 !== null && item.mContentImagesArrayV2.length !== 0) {
      return (
        <>
          <Image
            preview={{ visible: false, mask: <EyeOutlined /> }}
            width={60}
            height={40}
            src={`${item.mContentImagesArrayV2[0].image_url}`}
            onClick={() => setVisible(item.moment_id)}
          />
          <div style={{ display: "none" }}>
            <Image.PreviewGroup preview={{ visible: visible === item.moment_id, onVisibleChange: (vis) => setVisible(vis ? item.moment_id : null) }}>
              {item.mContentImagesArrayV2.map((image: ContentImagesArrayType, index) => {
                return <Image src={`${image.image_url}`} key={index} />;
              })}
            </Image.PreviewGroup>
          </div>
        </>
      );
    }
    if (item.mContentVideosArrayV2 !== null && item.mContentVideosArrayV2.length !== 0) {
      return <VideoContent videoInfo={item.mContentVideosArrayV2[0]} playVideo={playVideo} />;
    }
    return t("columns.no-media");
  };
  const columns: ColumnsType<GetMomentLikesItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "account-nickname",
        width: 180,
        dataIndex: "user_id user_name",
        title: t("columns.account-nickname"),
        render: (_, record) => {
          let value = record.user_id && record.user_name ? `${record.user_id} / ${record.user_name}` : `${record.user_id} ${record.user_name} `;
          return (
            <Text
              style={{ width: 150 }}
              ellipsis={{
                tooltip: value,
              }}
            >
              {value}
            </Text>
          );
        },
      },
      {
        key: "type",
        title: t("columns.type.label"),
        dataIndex: "privacy",
        width: 80,
        render: (value: number) => (value === 1 ? t(`columns.type.options.1`) : t(`columns.type.options.2`)),
      },
      {
        key: "media",
        title: t("columns.media"),
        dataIndex: "mContentImagesArrayV2",
        width: 100,
        render: (_, record) => showMedia(record),
      },

      {
        key: "m_content_text",
        title: t("columns.moments"),
        dataIndex: "m_content_text",
        width: 180,
        render: (value) => (
          <Text
            style={{ width: 150 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value}
          </Text>
        ),
      },

      {
        key: "m_create_time",
        title: t("columns.post-time"),
        dataIndex: "m_create_time",
        width: 150,
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "user_name",
        title: t("columns.like-from"),
        dataIndex: "user_name",
        width: 150,
        onclick: () => {},
        render: (value) => (
          <Text
            style={{ width: 150 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value}
          </Text>
        ),
      },
      {
        key: "create_time",
        title: t("columns.like-time"),
        dataIndex: "create_time",
        width: 150,
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "options",
        width: 150,
        title: t("columns.operations.lable"),
        fixed: "right",
        hidden: !(isActionAllowed(actions.REMOVE_MOMENTS_LIKES) && isActionAllowed(actions.SWITCH_MOMENT_LIKES_STATUS)),
        render: (_, record) => {
          return (
            <>
              {isActionAllowed(actions.REMOVE_MOMENTS_LIKES) && (
                <button type="button" className="optionBtn optionBtnDanger" onClick={() => deleteSingleLike(record)}>
                  {t("columns.operations.buttons.delete")}
                </button>
              )}
              {record.status === 1 && isActionAllowed(actions.SWITCH_MOMENT_LIKES_STATUS) ? (
                <button type="button" className="optionBtn optionBtnBlock" onClick={() => hideLike(record.moment_id, record.user_id, 2)}>
                  {t("columns.operations.buttons.hide")}
                </button>
              ) : (
                isActionAllowed(actions.SWITCH_MOMENT_LIKES_STATUS) && (
                  <button type="button" className="optionBtn optionBtnUnblock" onClick={() => showLike(record.moment_id, record.user_id, 1)}>
                    {t("columns.operations.buttons.unhide")}
                  </button>
                )
              )}
            </>
          );
        },
      },
    ],
    [t, visible, setVisible]
  );
  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);
  const handleMultipleDelete = useCallback(
    () =>
      setDeleteSelection({
        selectedRowKeys: [],
        onChange: (selectedRowKeys, selectedRows) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          let moments_id: string[] = selectedRows.map((i) => i.moment_id);
          let users_id: string[] = selectedRows.map((i) => i.user_id);
          setDeleteParams({ moments_id, users_id });
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );
  const handleSubmit = useCallback(
    (values: FormValues) => {
      setParams(({ show_number, order_by }) => {
        let state: GetMomentsLikesRequestParams;
        let formatedValues = Object.fromEntries(Object.entries(values).filter(([_, v]) => v != "" && v != 0 && v !== null));
        if (formatedValues.filter_range) {
          const [startDate, endDate] = formatedValues.filter_range;
          delete formatedValues["filter_range"];
          formatedValues.start_time = startDate.unix();
          formatedValues.end_time = endDate.unix();
        }
        state = { ...formatedValues, page_number: 1, show_number, order_by };
        return state;
      });
      refetch();
    },
    [setParams, refetch]
  );
  return (
    <>
      {isActionAllowed(actions.GET_MOMENT_LIKES) ? (
        <>
          <Form className="filterForm" initialValues={initialValue} form={form} onFinish={handleSubmit} name={"moments-form"} layout="inline" colon={false}>
            <Form.Item name="publish_user">
              <Input
                placeholder={t("form.keyword.placeholder")}
                style={{
                  minWidth: 220,
                }}
              />
            </Form.Item>
            <Form.Item name="media_type" label={t("form.media.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "images", "video"] as const).map((key, value) => ({
                  value,
                  label: t(`form.media.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="content_type" label={t("form.content-type.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "empty"] as const).map((key, value) => ({
                  value,
                  label: t(`form.content-type.options.${key}`),
                }))}
              />
            </Form.Item>
            {contentType === 0 && (
              <Form.Item name="m_content_text">
                <Input placeholder={t("form.content-keyword.placeholder")} />
              </Form.Item>
            )}
            <Form.Item name="like_user" label={t("form.like-from.lable")}>
              <Input placeholder={t("form.like-from.placeholder")} />
            </Form.Item>
            <Form.Item name="time_type">
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "post-time", "like-time"] as const).map((key, value) => ({
                  value,
                  label: t(`form.post-time.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="filter_range">
              <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
            </Form.Item>
            <Form.Item>
              <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" icon={<Icon component={SearchIcon} />}>
                {t("form.buttons.search")}
              </Button>
            </Form.Item>
            {deleteSelection === undefined && isActionAllowed(actions.REMOVE_MOMENTS_LIKES) && (
              <Form.Item>
                <Button className="filterBtn filterBtnDanger" type="primary" onClick={handleMultipleDelete} icon={<Icon component={DeleteIcon} />}>
                  {t("form.buttons.select")}
                </Button>
              </Form.Item>
            )}
            {deleteSelection !== undefined && isActionAllowed(actions.REMOVE_MOMENTS_LIKES) && (
              <>
                {" "}
                <Form.Item>
                  <Button className="filterBtn filterBtnSuccess" type="primary" onClick={handleMultipleDeleteCancelClick}>
                    {t("form.buttons.cancel")}
                  </Button>
                </Form.Item>
                <Form.Item>
                  <Button className="filterBtn filterBtnDanger" type="primary" disabled={deleteSelection?.selectedRowKeys?.length == 0} onClick={deleteLikes}>
                    {t("form.buttons.delete")}
                  </Button>
                </Form.Item>
              </>
            )}
          </Form>
          <Table
            rowKey="create_time"
            dataSource={data?.data.likes ?? undefined}
            columns={columns}
            scroll={{ x: true }}
            loading={isRefetching}
            rowSelection={deleteSelection}
            pagination={{
              current: data?.data.current_number,
              total: data?.data.likes_nums,
              onChange: handlePaginationChange,
              pageSizeOptions: [10, 20, 50, 100, 1000],
              showQuickJumper: true,
              position: ["bottomCenter"],
              showTotal: (total: string | number) => t("pagination.show-total-text", { total }),
            }}
          />
          {vedioPlayer.video !== null && <VideoPlayer video={vedioPlayer.video} open={vedioPlayer.open} onCancel={closePlayer} />}
        </>
      ) : (
        <Empty description={false} />
      )}
    </>
  );
};

export default MomentsLikesView;
