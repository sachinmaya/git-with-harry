import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery, useMutation, useQueryClient  } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, GetBlacklistItem, GetBlacklistRequestParams, BlackListDeleteId,EditBlackListRequestParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, Table, message } from "antd";
import Icon from "@ant-design/icons";
import Text from "antd/lib/typography/Text";
import { ColumnsType } from "antd/es/table";
import { Link } from "react-router-dom";
import dayjs, { Dayjs } from "dayjs";
import classes from "./styles.module.scss";

import { FieldData } from "rc-field-form/lib/interface";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import { TableRowSelection } from "antd/es/table/interface";
import { InternalServerError, NetworkError } from "~/api/errors";
import ConfirmModal from '~/views/BlacklistView/ConfirmModal'
import EditBlacklistModal from '~/views/BlacklistView/EditBlacklistModal'
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";
const initialParams: GetBlacklistRequestParams = {
  page_number: 1,
  show_number: 10,
  order_by: "create_time:desc",
};
const getBacklistQuery = (request: ApiRequest, params: GetBlacklistRequestParams = initialParams) => ({
  queryKey: [actions.GET_BLACKLIST, params],
  queryFn: async () => request(actions.GET_BLACKLIST, params),
});

export const blacklistViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getBacklistQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};


interface FormValues {
  owner_user: string;
  block_user: string;
  filterRange: null | Dayjs[];
}

const initialValues: FormValues = {
  owner_user: "",
  block_user: "",
  filterRange: null,
};
type ModalKey = "multiple-delete" | "delete-blacklist" ;
type ModalEditKey = "edit-blacklist" ;
const BlacklistView: React.FC = () => {
  const { t } = useTranslation("blacklist-view");
  const { setDashboardHeading } = useDashboardView();
  const [visible, setVisible] = useState("");
  const [isMultipleDelete, setIsMultipleDelete] = useState(false);

  const request = useRequest();
  const [params, setParams] = useState<GetBlacklistRequestParams>(initialParams);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<GetBlacklistItem> | undefined>(undefined); 
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; userID: any  }>({
    open: false,
    key: "multiple-delete",
    userID: "",
  });
  const [openEditModal, setOpenEditModal] = useState<{ open: boolean; key: ModalEditKey; blacklist?: GetBlacklistItem,ownerUser:string,blockUser:string }>({
    open: false,
    key: "edit-blacklist",
    ownerUser:"",
    blockUser:""
  });
  const queryClient = useQueryClient();

  const { data, refetch, isRefetching } = useQuery({
    ...getBacklistQuery(request, params),
    keepPreviousData: true,
    onError: () => {
      // TODO: show error message
    },
  });
  const deleteBlacklistMutation = useMutation((friend_list: BlackListDeleteId[]) => request(actions.DELETE_BLACKLIST, { friend_list }), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_BLACKLIST]);
      message.open({
        key: "blacklist-delete-successfully",
        type: "success",
        content: t("toasts.blacklist-delete-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-blacklist-failed",
        type: "error",
        content: t("toasts.delete-blacklist-failed"),
      });
    },
  });
  useEffect(() => {
    setDashboardHeading("me", "blacklist");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);
  
  const columns: ColumnsType<GetBlacklistItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "owner_user_id",
        dataIndex: "owner_user_id",
        width: 160,
        title: t("columns.added-by"),
        render: (_, record) => {
          const sparetor = (record.owner_user_id && record.owner_user_name) && '/';
          return (
              <Text
                  style={{width: 150}}
                  ellipsis={{
                      tooltip: `${record.owner_user_id}${sparetor}${record.owner_user_name}`,
                  }}
              >
                  {`${record.owner_user_id}${sparetor}${record.owner_user_name}`}
              </Text>
          )
      },
      },
      {
        key: "block_user_id",
        width: 160,
        dataIndex: "block_user_id",
        title: t("columns.blackllist"),
        render: (_, record) => {
          const sparetor = (record.block_user_id && record.block_user_name) && '/';
          return (
              <Text
                  style={{width: 150}}
                  ellipsis={{
                      tooltip: `${record.block_user_id}${sparetor}${record.block_user_name}`,
                  }}
              >
                  {`${record.block_user_id}${sparetor}${record.block_user_name}`}
              </Text>
          )
        },
      },
      {
        key: "owner_profile",
        width: 160,
        dataIndex: "owner_profile",
        title: t("columns.profile-photo"),
        render: (text, record) => {
          if (text === "") {
              return t("columns.no-media");
          }
          return <Image
              preview={true}
              width={50}
              height={50}
              src={text}
          />;
      },
      },
      {
        key: "create_time",
        width: 160,
        dataIndex: "create_time",
        title: t("columns.adding-time"),
        render: (value) => value===0? "-":dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "remark",
        width: 160,
        dataIndex: "remark",
        title: t("columns.remark"),
        render: (value) => value || "-",
      },
      {
        key: "edit_user",
        width: 160,
        dataIndex: "edit_user",
        title: t("columns.edited-by"),
        render: (value) => value || "-",
      },
      {
        key: "edit_time",
        width: 160,
        dataIndex: "edit_time",
        title: t("columns.editing-time"),
        render: (value) =>  value===0? "-":dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "options",
        width: 160,
        title: t("columns.options"),
        fixed: "right",
        render: (value, record) => (
          <> 
          <button type="button" className="optionBtn" onClick={() => setOpenEditModal({ open: true, key: "edit-blacklist", blacklist: record,blockUser: record.block_user_id,ownerUser:record.owner_user_id})}>
              {t("options.edit")}
            </button>
            <button type="button" className="optionBtn optionBtnDanger" onClick={() => setOpenModal({ open: true, key: "delete-blacklist", userID: {black_id:record.block_user_id,owner_id:record.owner_user_id} })}>
              {t("options.delete")}
            </button>
          </>
        )
      },
    ],
    [t]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ filterRange, owner_user, block_user }: FormValues) => {
      setParams(({ show_number, order_by }) => {
        const state: GetBlacklistRequestParams = { page_number: 1, show_number, order_by };
        const trimOwnerUser = owner_user.trim();
        if (trimOwnerUser !== "") {
          state.owner_user = trimOwnerUser;
        }

        const trimBlockUser = block_user.trim();
        if (trimBlockUser !== "") {
          state.block_user = trimBlockUser;
        }       
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = startTime;
          state.end_time = endTime;
        }
        return state;
      });
      refetch();
    },
    [setParams, refetch]
  );

  const handleFieldsChange = ([fieldData]: FieldData[]) => {
    
  };  
  const [blacklistDeleteIds,setBlacklistDeleteIds] = useState<BlackListDeleteId[]>([]);
  const handleMultipleDeleteClick = useCallback(
    () =>
      setDeleteSelection({
        columnWidth: 50,
        selectedRowKeys: [],
        onChange: (selectedRowKeys,selectedRows) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          const newObjects = selectedRows.map((item)=> {
            return {"owner_id":item.owner_user_id,"black_id":item.block_user_id}
          })
          console.log(newObjects)
          setBlacklistDeleteIds(newObjects);          
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );
  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);
  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    switch (openModal.key) {
      case "multiple-delete":
        console.log(blacklistDeleteIds);
        if (deleteSelection !== undefined) {
          deleteBlacklistMutation.mutate(blacklistDeleteIds as BlackListDeleteId[]);
        }
        return;
      case "delete-blacklist":
        deleteBlacklistMutation.mutate([openModal.userID]);            
        break;
    }
  }, [deleteBlacklistMutation.mutate, deleteSelection, openModal]);
  
  const editBlacklistMutation = useMutation(
    (editBlacklist: EditBlackListRequestParams) => (request(actions.EDIT_BLACKLIST, editBlacklist)),
    {
      onSuccess: () => {
        handleEditModalCancel()
        queryClient.invalidateQueries([actions.GET_BLACKLIST, params]);
        message.open({
          key: "favourites-edited-success",
          type: "success",
          content: t("toasts.blacklist-edited-success"),
        });
      },
      onError: (error) => {
        if (error instanceof NetworkError) {
          return message.open({
            key: "network-error",
            type: "error",
            content: t("errors.network-error.message"),
          });
        }
        if (error instanceof InternalServerError) {
          return message.open({
            key: "internal-server-error",
            type: "error",
            content: t("errors.internal-server-error.message"),
          });
        }
      },
    }
  );

  const handleEditModalOk = useCallback(
    (values: EditBlackListRequestParams, blockUser:string, ownerUser:string) => {
      const newMutateData = {...values,owner_user:ownerUser,block_user:blockUser}
      
      editBlacklistMutation.mutate(newMutateData);
    },
    [editBlacklistMutation.mutate, openEditModal]
  );
  const handleEditModalCancel = useCallback(() => setOpenEditModal((state) => ({ ...state, open: false, blockUser:"", ownerUser:"" })), [setOpenEditModal]);
  return (
    <>
      <Form className="filterForm"  layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="owner_user" label={t("form.added-by.label")}>
          <Input placeholder={t("form.added-by.placeholder")} />
        </Form.Item>

        <Form.Item name="block_user" label={t("form.blacklist.label")}>
          <Input placeholder={t("form.blacklist.placeholder")} />
        </Form.Item>
        <Form.Item name="filterRange"  label={t("form.filter-time.options.create-time")}>
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={isRefetching} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        {deleteSelection !== undefined && (
          <>
            <Form.Item>
              <Button className="filterBtn filterBtnPlain" htmlType="button" onClick={handleMultipleDeleteCancelClick}>
                {t("form.buttons.cancel")}
              </Button>
            </Form.Item>
            <Form.Item>
              <Button
                className="filterBtn filterBtnDanger"
                type="primary"
                htmlType="button"
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", userID: null })}
                disabled={deleteSelection.selectedRowKeys === undefined || deleteSelection.selectedRowKeys.length === 0}
              >
                {t("form.buttons.delete")}
              </Button>
            </Form.Item>
          </>
        )}
        {deleteSelection === undefined && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" htmlType="button" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleDeleteClick}>
              {t("form.buttons.multiple-delete")}
            </Button>
          </Form.Item>
        )}
      </Form>
      <Table
        rowKey={'block_user_id'}
        dataSource={data?.data.black_list}
        className="customTable"
        columns={columns}
        scroll={{ x: 640 }}
        loading={isRefetching}
        rowSelection={deleteSelection}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.list_number,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />

      <ConfirmModal
        open={openModal.open}
        type={openModal.key}
        onCancel={handleModalCancel}
        onOk={handleModalOk}
        confirmLoading={deleteBlacklistMutation.isLoading}
      />
      <EditBlacklistModal  
        blacklist={openEditModal.blacklist} 
        onFormSubmit={handleEditModalOk} 
        open={openEditModal.open} 
        onCancel={handleEditModalCancel} 
        blockUser={openEditModal.blockUser}
        ownerUser={openEditModal.ownerUser}
        />
    </>
  );
};

export default BlacklistView;
