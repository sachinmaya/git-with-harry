import { Button, Form, Input, Modal, ModalProps, Select, Switch } from "antd";
import { t } from "i18next";
import React, { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import dayjs, { Dayjs } from "dayjs";
import { EditBlackListRequestParams, EditBlackListResponse, GetBlacklistItem } from "~/api/types";
import classes from "./styles.module.scss";
interface EditFavoritesModalProps extends ModalProps {
  blacklist?: GetBlacklistItem;
  onFormSubmit: (values: EditBlackListRequestParams, blockUser:string, ownerUser:string) => void;
  blockUser:string;
  ownerUser:string;
}

export interface EditBlacklistFormValues { 
  block_user_id: string;
  remark: any;
  create_time: any;
}

const initialFormValues: EditBlacklistFormValues = {
  block_user_id: "",
  remark: "",
  create_time: undefined,
};

const initialParams: EditBlackListRequestParams = {
  owner_user:"",
  block_user:"",
  remark: ""
};

const EditBlacklistModal: React.FC<EditFavoritesModalProps> = ({  blacklist, onFormSubmit, blockUser, ownerUser, ...props }) => {
  const { t } = useTranslation("blacklist-view");
  const [form] = Form.useForm();
  const [editFavoritesParams, setEditFavoritesParams] = useState<EditBlackListRequestParams>(initialParams);
    
  useEffect(() => {
    if(blacklist) {  
        const newFormValue:EditBlacklistFormValues = {
            block_user_id: `${blacklist.block_user_id}/${blacklist.block_user_name}`,
            create_time: dayjs(blacklist.create_time * 1000).format("YYYY/MM/DD HH:mm:ss"),
            remark: blacklist.remark,
        }
        form.setFieldsValue(newFormValue);
    }
  }, [blacklist]);

  const handleFormSubmit = useCallback(
    ({ remark, create_time,}: EditBlacklistFormValues) => {    
     
      setEditFavoritesParams(() => {
        const state: EditBlackListRequestParams = initialParams;
        state.remark = remark;
        return state;
      });
      form.resetFields();
      onFormSubmit(editFavoritesParams, blockUser, ownerUser);
    },
    [setEditFavoritesParams, blockUser, ownerUser]
  );

  return (
    <Modal title={t("add-edit-modal.edit-modal-title")} okText={t("add-edit-modal.buttons.edit")} cancelText={t(`add-edit-modal.buttons.cancel`)} onOk={form.submit} {...props} width={600}>
      <Form initialValues={blacklist} form={form} onFinish={handleFormSubmit}>
       
        <Form.Item name="block_user_id" label={t("add-edit-modal.form.blacklist.label")}>
          <Input  disabled={true}/>
        </Form.Item>
        <Form.Item name="create_time" label={t("add-edit-modal.form.adding-time.label")}>
          <Input  disabled={true}/>
        </Form.Item>
        <Form.Item name="remark" label={t("add-edit-modal.form.remark.label")}>
          <Input.TextArea showCount maxLength={200} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default EditBlacklistModal;