import { Button, Form, Input, message, Modal, ModalProps, QRCode } from "antd";
import React from "react";
import { useTranslation } from "react-i18next";
import Verified from "~/views/LoginView/assests/icons/Verified";
import classes from "./styles.module.scss";
import { AdminVerifyTOTPRequestParams } from "~/api/types";
import { useMutation } from "@tanstack/react-query";
import { actions } from "~/api/constants";
import useRequest from "~/hooks/useRequest";
import { InternalServerError, NetworkError } from "~/api/errors";
import { useAuth } from "~/hooks/useAuth";

interface QRCodeModalProps extends ModalProps {
  username: string;
  token: string;
  gAuthSetupProvUri: string;
}

const initialValue: AdminVerifyTOTPRequestParams = {
  totp: "",
};

const QRCodeModal: React.FC<QRCodeModalProps> = ({ username, token, gAuthSetupProvUri, ...rest }) => {
  const { t } = useTranslation("login");
  const [form] = Form.useForm<AdminVerifyTOTPRequestParams>();
  const request = useRequest();
  const { setAuth } = useAuth();
  const { mutate, isLoading } = useMutation((params: AdminVerifyTOTPRequestParams) => request(actions.ADMIN_VERIFY_TOTP, params, { token }), {
    onSuccess: ({ data: { token } }) => {
      setAuth({ token, username });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
        return;
      }
      if (error instanceof InternalServerError) {
        message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
        return;
      }
      message.open({
        key: "totp-failed",
        type: "error",
        content: t("errors.totp-failed"),
      });
    },
  });

  return (
    <Modal
      footer={null}
      centered
      className={classes.qr_modal}
      bodyStyle={{ padding: "40px" }}
      closable={false}
      destroyOnClose
      afterClose={() => {
        form.resetFields();
      }}
      {...rest}
    >
      <div className={classes.qr_modal_container}>
        <div className={classes.qr_modal_container_title}>{gAuthSetupProvUri !== "" ? t("qrcode-modal.titleWithQr") : t("qrcode-modal.titleWithoutQr")}</div>
        {gAuthSetupProvUri !== "" && <QRCode value={gAuthSetupProvUri} size={150} />}
        <div className={classes.qr_modal_flexbox}>
          <Form name="totp-verify" form={form} onFinish={mutate} style={{ display: "flex" }} initialValues={initialValue} disabled={isLoading}>
            <Form.Item
              name="totp"
              rules={[
                {
                  required: true,
                  message: t("qrcode-modal.rules.required"),
                },
                {
                  len: 6,
                  message: t("qrcode-modal.rules.length"),
                },
                {
                  pattern: /^[0-9_]+$/,
                  message: t("qrcode-modal.rules.number"),
                },
              ]}
            >
              <Input className={classes.qr_modal_flexbox_input} bordered={false} maxLength={6} placeholder={t("qrcode-modal.input-placeholder")} prefix={<Verified />} />
            </Form.Item>
            <Form.Item shouldUpdate>
              {() => (
                <Button
                  type="primary"
                  htmlType="submit"
                  className={classes.qr_modal_flexbox_button}
                  block
                  loading={isLoading}
                  disabled={!form.isFieldsTouched(true) || form.getFieldsError().filter(({ errors }) => errors.length > 0).length > 0}
                >
                  {gAuthSetupProvUri !== "" ? t("qrcode-modal.bind") : t("qrcode-modal.verify")}
                </Button>
              )}
            </Form.Item>
          </Form>
        </div>
      </div>
    </Modal>
  );
};

export default QRCodeModal;
