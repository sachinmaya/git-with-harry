import React from "react";

const User: React.FC<React.SVGAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <g transform="translate(-1195 -447)">
      <path
        d="M107.613,71.868c-2.709,0-4.733,1.756-4.733,4.305v.275c0,1.333,2.168,1.333,4.913,1.333h2.916c2.636,0,4.913,0,4.913-1.333v-.275c0-2.549-2.023-4.305-4.733-4.305Zm1.492-.671a3.67,3.67,0,1,0-3.891-3.664A3.788,3.788,0,0,0,109.105,71.2Z"
        transform="translate(1095.749 386.175)"
      />
      <rect width="20" height="20" transform="translate(1195 447)" fill="none" />
    </g>
  </svg>
);

export default User;
