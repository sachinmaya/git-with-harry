import React from "react";

const Verified: React.FC<React.SVGAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 20 20" {...props}>
    <g xmlns="http://www.w3.org/2000/svg" id="Verification" transform="translate(-1195.418 -447.418)">
      <rect width="20" height="20" transform="translate(1195.418 447.418)" fill="none" />
      <path
        d="M128.966,68.53a.987.987,0,0,0-.779-.866,18.394,18.394,0,0,1-2.519-.58,9.355,9.355,0,0,1-2.251-1.316,1.029,1.029,0,0,0-1.2,0,5.9,5.9,0,0,1-2.268,1.307,8.452,8.452,0,0,1-2.45.605.917.917,0,0,0-.77.866c-.019.435-.026,2.173-.026,4.085,0,3.462,4.085,6.813,6.129,6.813s5.505-2.363,6.059-6.76c.139-2.6.078-4.155.078-4.155ZM126.741,71.2l-4.268,4.025a.579.579,0,0,1-.71.069l-.112-.1L119.3,72.754a.588.588,0,0,1,.865-.8l1.939,2.034,3.843-3.636a.588.588,0,0,1,.8.866V71.2h0Z"
        transform="translate(1082.579 384.908)"
      />
    </g>
  </svg>
);

export default Verified;
