import React, { useCallback, useState } from "react";
import { Alert, Button, Dropdown, Form, Input } from "antd";
import { useTranslation } from "react-i18next";
import { Helmet } from "react-helmet-async";
import withNoAuthRequired from "~/hoc/withNoAuthRequired";
import { useMutation } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { useAuth } from "~/hooks/useAuth";
import { AdminLoginRequestParams } from "~/api/types";
import { actions } from "~/api/constants";
import { i18nextLocaleStorageKey, Language, supportedLocales, systemDefaultLocale } from "~/lib/i18next";
import Logo from "./assests/logo.png";
import classes from "./styles.module.scss";
import { CaretDownOutlined } from "@ant-design/icons";
import User from "~/views/LoginView/assests/icons/User";
import Lock from "~/views/LoginView/assests/icons/Lock";
import { InternalServerError, NetworkError, ResponseError } from "~/api/errors";
import QRCodeModal from "~/views/LoginView/QRCodeModal";

const initialValues: AdminLoginRequestParams = {
  admin_name: "",
  secret: "",
};

const LoginPage = () => {
  const { t, i18n } = useTranslation("login");
  const { setAuth } = useAuth();
  const [form] = Form.useForm<AdminLoginRequestParams>();
  const [qrModalProps, setQrModalProps] = useState<{
    open: boolean;
    username: string;
    token: string;
    gAuthSetupProvUri: string;
  }>({ open: false, username: "", token: "", gAuthSetupProvUri: "" });
  const request = useRequest();
  const [currentLocale, setCurrentCountry] = useState(() => localStorage.getItem(i18nextLocaleStorageKey) as Language | null);

  const { mutateAsync, isLoading, isError, error } = useMutation((params: AdminLoginRequestParams) => request(actions.ADMIN_LOGIN, params), {
    onSuccess: ({ data }, { admin_name: username }) => {
      const { token, gAuthSetupProvUri, gAuthSetupRequired, gAuthEnabled } = data;
      if (gAuthEnabled || (gAuthSetupRequired && !gAuthEnabled)) {
        setQrModalProps({ open: true, username, token, gAuthSetupProvUri });
        return;
      }
      return setAuth({ token, username });
    },
  });

  const handleLocaleClick = useCallback(
    (locale: Language | null) => {
      if (locale) {
        i18n.changeLanguage(locale).then(() => localStorage.setItem(i18nextLocaleStorageKey, locale));
        setCurrentCountry(locale);
        return;
      }
      i18n.changeLanguage(systemDefaultLocale).then(() => localStorage.removeItem(i18nextLocaleStorageKey));
      setCurrentCountry(null);
    },
    [i18n, setCurrentCountry]
  );

  return (
    <div className={classes.login}>
      <Helmet title={t("meta.title")} />
      <div className={classes.dropdown_wrapper}>
        <Dropdown
          menu={{
            selectable: true,
            selectedKeys: [currentLocale || "default"],
            items: [null, ...supportedLocales].map((locale) => ({
              key: locale || "default",
              label: t(`locales.${locale || "default"}`),
              onClick: () => handleLocaleClick(locale),
              icon: <div className={classes.dropdown_icon} />,
            })),
          }}
          rootClassName={classes.dropdown}
          placement="bottomRight"
          trigger={["click"]}
        >
          <button className={classes.dropdown_button}>
            {t(`locales.${currentLocale || "default"}`)}
            <CaretDownOutlined className={classes.dropdown_button_icon} />
          </button>
        </Dropdown>
      </div>
      <div className={classes.form}>
        <div className={classes.form_left}>
          <img src={Logo} alt="xlink-logo" />
          <div className={classes.form_left_caption}>{t("caption")}</div>
        </div>
        <div className={classes.form_right}>
          <h2>{t("form-heading")}</h2>
          <Form name="admin-login" form={form} initialValues={initialValues} onFinish={mutateAsync} disabled={isLoading} autoComplete="off" className={classes.form_right_form}>
            <Form.Item name="admin_name" rules={[{ required: true, message: t("inputs.username.errors.required") }]}>
              <Input placeholder={t("inputs.username.placeholder")} autoFocus prefix={<User />} bordered={false} className={classes.form_right_form_input} />
            </Form.Item>
            <Form.Item name="secret" rules={[{ required: true, message: t("inputs.password.errors.required") }]}>
              <Input.Password placeholder={t("inputs.password.placeholder")} prefix={<Lock />} bordered={false} className={classes.form_right_form_input} />
            </Form.Item>
            {isError && error instanceof NetworkError && (
              <Form.Item>
                <Alert type="error" message={t("errors.network-error.message")} description={t("errors.network-error.description")} />
              </Form.Item>
            )}
            {isError && error instanceof InternalServerError && (
              <Form.Item>
                <Alert type="error" message={t("errors.internal-server-error.message")} description={t("errors.internal-server-error.description")} />
              </Form.Item>
            )}
            {isError && error instanceof ResponseError && (
              <Form.Item>
                <Alert type="error" message={t("errors.login-failed.message")} description={t("errors.login-failed.description")} />
              </Form.Item>
            )}
            <Form.Item shouldUpdate>
              {() => (
                <Button
                  htmlType="submit"
                  block
                  loading={isLoading}
                  className={classes.form_right_form_button}
                  type="primary"
                  disabled={!form.isFieldsTouched(true) || form.getFieldsError().filter(({ errors }) => errors.length > 0).length > 0}
                >
                  {t("buttons.login")}
                </Button>
              )}
            </Form.Item>
          </Form>
        </div>
      </div>
      <QRCodeModal {...qrModalProps} onCancel={() => setQrModalProps((state) => ({ ...state, open: false }))} />
    </div>
  );
};

export default withNoAuthRequired(LoginPage);
