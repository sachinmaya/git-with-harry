import React from "react";
import { Modal, ModalProps } from "antd";
import { Form, Input, message } from "antd";
import { useForm } from "antd/lib/form/Form";
import { useTranslation } from "react-i18next";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { AlterNewsCommentsParams } from "~/api/types";
import { InternalServerError, NetworkError } from "~/api/errors";
import { useMutation, useQueryClient } from "@tanstack/react-query";
const { TextArea } = Input;

interface FormValues {
  commentedBy: string;
  content: string;
}

interface EditModalProps extends ModalProps {
  commentID: number;
  commentUser: string;
  comment: string;
  handleCancel: () => void;
}

const EditModal: React.FC<EditModalProps> = ({ commentID, commentUser, comment, handleCancel, ...props }) => {
  const { t } = useTranslation("comment-management-view");
  const [editForm] = useForm();
  const request = useRequest();
  const queryClient = useQueryClient();
  const initialValues: FormValues = {
    commentedBy: commentUser,
    content: comment,
  };
  const editCommentMutation = useMutation((params: AlterNewsCommentsParams) => request(actions.ALTER_NEWS_COMMENT, params), {
    onSuccess: () => {
      handleCancel();
      queryClient.invalidateQueries([actions.GET_NEWS_COMMENTS]);
      message.open({
        key: "update-successfully",
        type: "success",
        content: t("toasts.comment-update-success"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "un-hide-failed",
        type: "error",
        content: t("toasts.comment-update-failed"),
      });
    },
  });

  const handleFinish = ({ commentedBy, content }: FormValues) => {
    editCommentMutation.mutate({ comment_id: commentID.toString(), content: content, comment_user: commentedBy });
  };

  return (
    <Modal
      className="confirmModal"
      okText={t(`modals.edit-comment.buttons.ok`)}
      cancelText={t(`modals.edit-comment.buttons.cancel`)}
      destroyOnClose={true}
      {...props}
      onOk={editForm.submit}
      onCancel={handleCancel}
    >
      <Form onFinish={handleFinish} preserve={false} form={editForm} initialValues={initialValues}>
        <Form.Item label={t("modals.edit-comment.form.commented-by")} name="commentedBy" preserve={false}>
          <Input disabled={true} readOnly />
        </Form.Item>
        <Form.Item label={t("modals.edit-comment.form.comment")} name="content" preserve={false}>
          <TextArea rows={4} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default EditModal;
