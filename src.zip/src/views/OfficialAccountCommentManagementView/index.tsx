import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, GetNewsCommentsParams, DeleteNewsCommentParams, CommentItem, ChangeNewsCommentStatusParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Input, message, Select, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import Icon from "@ant-design/icons";
import { TableRowSelection } from "antd/es/table/interface";
import Text from "antd/lib/typography/Text";
import dayjs, { Dayjs } from "dayjs";
import { useLocation } from "react-router-dom";
import { FieldData } from "rc-field-form/lib/interface";
import { InternalServerError, NetworkError } from "~/api/errors";
import usePermissions from "~/hooks/usePermissions";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import ConfirmModal from "./ConfirmModal";
import EditModal from "./EditModal";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";

const initialParams: GetNewsCommentsParams = {
  page_number: 1,
  show_number: 10,
  time_type: 0,
  order_by: "start_time:desc",
};

const getCommentsListQuery = (request: ApiRequest, params: GetNewsCommentsParams = initialParams) => ({
  queryKey: [actions.GET_NEWS_COMMENTS, params],
  queryFn: async () => request(actions.GET_NEWS_COMMENTS, params),
});

export const officialAccountCommentManagementViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getCommentsListQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  officialAccount: string;
  accountType: number;
  ip: string;
  postTopic: string;
  filterType: number;
  filterRange: null | Dayjs[];
  commentedBy: string;
  comment: string;
}

type ModalKey = "multiple-delete" | "delete-comment" | "hide-comment" | "un-hide-comment";

enum CommentStatus {
  hide = 2,
  un_hide = 1,
}

const OfficialAccountCommentManagementView: React.FC = () => {
  const { t } = useTranslation("comment-management-view");
  const { setDashboardHeading } = useDashboardView();
  const { isActionAllowed } = usePermissions();
  const request = useRequest();
  const location = useLocation();
  const queryClient = useQueryClient();
  const [params, setParams] = useState<GetNewsCommentsParams>(() => ({ ...initialParams, title: location.state?.title || "" }));
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<CommentItem> | undefined>(undefined);
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; articleID: number; comment_id: number; parent_id: number }>({
    open: false,
    key: "multiple-delete",
    articleID: 0,
    comment_id: 0,
    parent_id: 0,
  });
  const [openEditModal, setOpenEditModal] = useState<{ open: boolean; comment_id: number; comment_user: string; content: string }>({
    open: false,
    comment_id: 0,
    comment_user: "",
    content: "",
  });

  const initialValues: FormValues = useMemo(
    () => ({
      officialAccount: "",
      accountType: 0,
      ip: "",
      postTopic: location.state?.title || "",
      filterType: 0,
      filterRange: null,
      commentedBy: "",
      comment: "",
    }),
    [location.state]
  );
  const { data, refetch, isPreviousData } = useQuery({
    ...getCommentsListQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "query-failed",
        type: "error",
        content: t("toasts.comment-list-query-failed"),
      });
    },
  });

  const deleteCommentMutation = useMutation((params: DeleteNewsCommentParams) => request(actions.DELETE_NEWS_COMMENTS, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_NEWS_COMMENTS]);
      message.open({
        key: "delete-successfully",
        type: "success",
        content: t("toasts.delete-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-failed",
        type: "error",
        content: t("toasts.delete-failed"),
      });
    },
  });

  const hideCommentMutation = useMutation((params: ChangeNewsCommentStatusParams) => request(actions.CHANGE_NEWS_COMMENT_STATUS, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_NEWS_COMMENTS]);
      message.open({
        key: "delete-successfully",
        type: "success",
        content: t("toasts.comment-hide-success"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "hide-failed",
        type: "error",
        content: t("toasts.comment-hide-failed"),
      });
    },
  });
  const unHideCommentMutation = useMutation((params: ChangeNewsCommentStatusParams) => request(actions.CHANGE_NEWS_COMMENT_STATUS, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_NEWS_COMMENTS]);
      message.open({
        key: "delete-successfully",
        type: "success",
        content: t("toasts.comment-un-hide-success"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "un-hide-failed",
        type: "error",
        content: t("toasts.comment-un-hide-failed"),
      });
    },
  });
  useEffect(() => {
    setDashboardHeading("official-account", "official-account-comment-management");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const columns: ColumnsType<CommentItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "account",
        dataIndex: "official_name",
        width: 160,
        title: t("columns.account"),
        render: (value) => (value === "" ? t("info.deleted-account") : value),
      },
      {
        key: "account_type",
        width: 160,
        dataIndex: "official_type",
        title: t("columns.account-type"),
        render: (value) => (
          <>
            {value === 0 && "-"}
            {value === 1 && t("form.account-type.options.personal")}
            {value === 2 && t("form.account-type.options.business")}
          </>
        ),
      },
      {
        key: "post",
        width: 200,
        dataIndex: "article_title",
        title: t("columns.post"),
        render: (value) => (
          <Text
            style={{ width: 180 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "comments",
        width: 200,
        dataIndex: "content",
        title: t("columns.comments"),
        render: (value) => (
          <Text
            style={{ width: 180 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "commentd_by",
        width: 160,
        dataIndex: "user_name",
        title: t("columns.commented-by"),
        render: (value) => (value === "" ? "-" : value),
      },
      {
        key: "comment_likes",
        width: 160,
        dataIndex: "comment_likes",
        title: t("columns.comment-likes"),
        render: (value) => value,
      },
      {
        key: "post_time",
        width: 160,
        dataIndex: "post_time",
        title: t("columns.post-time"),
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "comment_time",
        width: 160,
        dataIndex: "create_time",
        title: t("columns.comment-time"),
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "ip",
        width: 160,
        dataIndex: "last_login_ip",
        title: t("columns.last-login-ip"),
        render: (value) => (value === "" ? "-" : value),
      },
      {
        key: "operations",
        width: 160,
        title: t("columns.operations"),
        fixed: "right",
        render: (record) => {
          return (
            <>
              {isActionAllowed(actions.ALTER_NEWS_COMMENT) && (
                <Button
                  onClick={() => setOpenEditModal({ open: true, comment_user: record.create_by, comment_id: record.comment_id, content: record.content })}
                  type="primary"
                  htmlType="button"
                  className="optionBtn"
                >
                  {t("form.buttons.edit-post")}
                </Button>
              )}
              {isActionAllowed(actions.CHANGE_NEWS_COMMENT_STATUS) && record.status === 1 && (
                <Button
                  onClick={() =>
                    setOpenModal({ open: true, articleID: record.article_id, comment_id: record.comment_id, parent_id: record.parent_comment_id, key: "hide-comment" })
                  }
                  className="optionBtn optionBtnSuccess"
                >
                  {t("form.buttons.hide")}
                </Button>
              )}
              {isActionAllowed(actions.CHANGE_NEWS_COMMENT_STATUS) && record.status === 2 && (
                <Button
                  onClick={() =>
                    setOpenModal({ open: true, articleID: record.article_id, comment_id: record.comment_id, parent_id: record.parent_comment_id, key: "un-hide-comment" })
                  }
                  className="optionBtn"
                >
                  {t("form.buttons.un-hide")}
                </Button>
              )}
              {isActionAllowed(actions.DELETE_NEWS_COMMENTS) && (
                <Button
                  className="optionBtn optionBtnDanger"
                  onClick={() =>
                    setOpenModal({ open: true, articleID: record.article_id, comment_id: record.comment_id, parent_id: record.parent_comment_id, key: "delete-comment" })
                  }
                >
                  {t("form.buttons.delete")}
                </Button>
              )}
            </>
          );
        },
      },
    ],
    [t]
  );
  const handleMultipleDeleteClick = useCallback(
    () =>
      setDeleteSelection({
        columnWidth: 50,
        selectedRowKeys: [],
        onChange: (selectedRowKeys) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          console.log("selected rows", selectedRowKeys);
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );

  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );
  const handleFinnish = useCallback(
    ({ filterRange, officialAccount, accountType, ip, postTopic, filterType, comment, commentedBy }: FormValues) => {
      setParams(({ show_number, order_by }) => {
        const state: GetNewsCommentsParams = { page_number: 1, show_number, order_by, time_type: 0 };
        if (officialAccount !== "") {
          state.official_account = officialAccount.trim();
        }
        if (ip !== "") {
          state.ip = ip.trim();
        }
        if (accountType !== 0) {
          state.account_type = accountType;
        }
        if (postTopic !== "") {
          state.title = postTopic.trim();
        }
        if (filterType !== 0) {
          state.time_type = filterType;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = startTime;
          state.end_time = endTime;
        }
        if (comment !== "") {
          state.comment_key = comment.trim();
        }
        if (commentedBy !== "") {
          state.comment_user = commentedBy.trim();
        }

        return state;
      });
      setSearchLoading(true);
    },
    [setParams, refetch]
  );

  const handleFieldsChange = useCallback(([fieldData]: FieldData[]) => {
    const { name, value } = fieldData;
  }, []);
  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    switch (openModal.key) {
      case "hide-comment":
        hideCommentMutation.mutate({ comment_id: openModal.comment_id, status: CommentStatus.hide });
        return;
      case "un-hide-comment":
        unHideCommentMutation.mutate({ comment_id: openModal.comment_id, status: CommentStatus.un_hide });
        return;
        return;
      case "delete-comment":
        deleteCommentMutation.mutate({ articles: [openModal.articleID], comments: [openModal.comment_id], parents: [openModal.parent_id] });
        return;
      case "multiple-delete":
        if (openModal.key === "multiple-delete" && deleteSelection !== undefined && deleteSelection.selectedRowKeys !== undefined) {
          deleteCommentMutation.mutate({
            articles: deleteSelection.selectedRowKeys.map((item: any) => Number(item.split("-")[0])),
            comments: deleteSelection.selectedRowKeys.map((item: any) => Number(item.split("-")[1])),
            parents: deleteSelection.selectedRowKeys.map((item: any) => Number(item.split("-")[2])),
          });
        }

        return;
    }
  }, [deleteCommentMutation.mutate, openModal]);
  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="officialAccount" label={t("form.official-account")}>
          <Input style={{ width: 118 }} />
        </Form.Item>
        <Form.Item name="accountType" label={t("form.account-type.label")}>
          <Select
            style={{ width: 118 }}
            options={(["all", "personal", "business"] as const).map((key, value) => ({
              value,
              label: t(`form.account-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="ip" label={t("form.ip")}>
          <Input style={{ width: 118 }} />
        </Form.Item>
        <Form.Item name="postTopic" label={t("form.post-topic")}>
          <Input style={{ width: 158 }} />
        </Form.Item>
        <Form.Item name="filterType">
          <Select
            style={{ width: 118 }}
            options={(["all", "comment-time", "post-time"] as const).map((key, value) => ({
              value,
              label: t(`form.filter-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="filterRange">
          <DatePicker.RangePicker style={{ width: 230 }} disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item name="commentedBy" label={t("form.commented-by")}>
          <Input style={{ width: 178 }} />
        </Form.Item>
        <Form.Item name="comment" label={t("form.comment")}>
          <Input style={{ width: 171 }} />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        {deleteSelection !== undefined && (
          <>
            <Form.Item>
              <Button htmlType="button" className="filterBtn filterBtnPlain" onClick={handleMultipleDeleteCancelClick}>
                {t("modals.multiple-delete.buttons.cancel")}
              </Button>
            </Form.Item>
            <Form.Item>
              <Button
                type="primary"
                htmlType="button"
                className="filterBtn filterBtnDanger"
                danger
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", articleID: 0, parent_id: 0, comment_id: 0 })}
                disabled={deleteSelection.selectedRowKeys === undefined || deleteSelection.selectedRowKeys.length === 0}
              >
                {t("form.buttons.delete")}
              </Button>
            </Form.Item>
          </>
        )}
        {isActionAllowed(actions.DELETE_NEWS_LIKES) && deleteSelection === undefined && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" htmlType="button" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleDeleteClick}>
              {t("form.buttons.multiple-delete")}
            </Button>
          </Form.Item>
        )}
      </Form>
      <Table
        rowKey={(record) => `${record.article_id}-${record.comment_id}-${record.parent_comment_id}`}
        className="customTable"
        dataSource={data?.data.comments}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        rowSelection={deleteSelection}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.comments_nums,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
      <ConfirmModal open={openModal.open} type={openModal.key} onOk={handleModalOk} onCancel={handleModalCancel} confirmLoading={deleteCommentMutation.isLoading} />
      <EditModal
        open={openEditModal.open}
        onCancel={() => setOpenEditModal((state) => ({ ...state, open: false }))}
        handleCancel={() => setOpenEditModal((state) => ({ ...state, open: false }))}
        commentID={openEditModal.comment_id}
        commentUser={openEditModal.comment_user}
        comment={openEditModal.content}
      />
    </>
  );
};

export default OfficialAccountCommentManagementView;
