import React from "react";
import { Modal, ModalProps } from "antd";
import { useTranslation } from "react-i18next";

type ModalType = "multiple-delete" | "delete-comment-reply";

interface DisableConfirmModalProps extends ModalProps {
  type: ModalType;
}

const ConfirmModal: React.FC<DisableConfirmModalProps> = ({ type, ...props }) => {
  const { t } = useTranslation("woom-comments-reply-view");
  return (
    <Modal
      className="confirmModal"
      okButtonProps={{ danger: ["multiple-delete", "delete-comment-reply"].includes(type) }}
      okText={t(`modals.${type}.buttons.ok`)}
      cancelText={t(`modals.${type}.buttons.cancel`)}
      destroyOnClose
      {...props}
    >
      {t(`modals.${type}.content`)}
    </Modal>
  );
};

export default ConfirmModal;
