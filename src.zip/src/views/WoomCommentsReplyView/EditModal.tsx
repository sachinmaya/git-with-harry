import React from "react";
import { Modal, ModalProps, Input } from "antd";

interface EditModalProps extends ModalProps {
  t: any;
  data: any;
  setData: any;
  save: any;
}

class EditModal extends React.Component<EditModalProps> {
  state = {
    remark: undefined, //备注
    context: undefined, //回复内容
  };

  static getDerivedStateFromProps(props: any, state: any) {
    const { remark, context } = props.data;
    state.remark = remark;
    state.context = context;
    return null;
  }

  render() {
    const { t, data, setData, save } = this.props;
    const { open, row } = data;
    const { TextArea } = Input;

    return (
      <Modal
        title={t("modals.edit.title")}
        open={open}
        onOk={save}
        onCancel={() => setData((state: any) => ({ ...state, open: false }))}
        okText={t("modals.edit.save")}
        width="1000px"
        destroyOnClose={true}
      >
        <div className="popup-content">
          <div className="left">
            {/* 发布人账号 */}
            <div className="line">
              <span>{t("modals.edit.publisher-account")}</span>
              <Input disabled placeholder={row.publisher_id} />
            </div>
            {/* 发布人昵称 */}
            <div className="line">
              <span>{t("modals.edit.publisher-name")}</span>
              <Input disabled placeholder={row.publish_user} />
            </div>
            {/* Woom类型 */}
            <div className="line">
              <span>{t("modals.edit.woom-type")}</span>
              <Input disabled placeholder={t(`modals.edit.status${row.short_video_status}`)} />
            </div>
            {/* Woom内容 */}
            <div className="line">
              <span>{t("modals.edit.woom-content")}</span>
              <TextArea style={{ width: 300 }} placeholder={row.content} disabled />
            </div>
            {/* 上级评论内容 */}
            <div className="line">
              <span>{t("modals.edit.comment-content")}</span>
              <TextArea style={{ width: 300 }} placeholder={row.comment_content} disabled />
            </div>
            {/* 回复内容 */}
            <div className="line">
              <span>{t("modals.edit.reply-content")}</span>
              <TextArea
                rows={4}
                style={{ width: 300 }}
                maxLength={220}
                showCount
                value={this.state.context}
                onChange={(e) => setData((state: any) => ({ ...state, context: e.target.value }))}
              />
            </div>
            {/* 回复人 */}
            <div className="line">
              <span>{t("modals.edit.replyer")}</span>
              <Input disabled placeholder={`${row.reply_user_name}/${row.reply_user_id}`} />
            </div>
            {/* 备注 */}
            <div className="line">
              <span>{t("modals.edit.remark")}</span>
              <TextArea
                rows={4}
                style={{ width: 300 }}
                maxLength={200}
                showCount
                value={this.state.remark}
                onChange={(e) => setData((state: any) => ({ ...state, remark: e.target.value }))}
              />
            </div>
          </div>
          <div className="right">
            <video src={row.media_url} controls></video>
          </div>
        </div>
      </Modal>
    );
  }
}

export default EditModal;
