import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, GetWoomCommentsReplyRequestParams, GetWoomCommentsReplyItem, DeleteWoomCommentsReplyRequestParams, EditWoomCommentsReplyRequestParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Image, Input, Select, Table, message } from "antd";
import Icon, { PlaySquareOutlined } from "@ant-design/icons";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import { ColumnsType } from "antd/es/table";
import { Link, useLocation } from "react-router-dom";
import dayjs, { Dayjs } from "dayjs";
import { FieldData } from "rc-field-form/lib/interface";
import ConfirmModal from "./ConfirmModal";
import MediaModal from "./MediaModal";
import EditModal from "./EditModal";
import "./index.scss";
import usePermissions from "~/hooks/usePermissions";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";

const getLocationSearch = () => {
  const search = location.search;
  const params = { cid: "" };
  if (search) {
    decodeURI(search)
      .slice(1)
      .split("&")
      .forEach((item) => {
        const p = item.split("=");
        if (p[0] === "cid") params.cid = p[1];
      });
  }
  return params;
};

const { cid } = getLocationSearch();

const initialParams: GetWoomCommentsReplyRequestParams = {
  page_number: 1,
  show_number: 10,
  comment_id: cid,
};

const getWoomCommentsReplyQuery = (request: ApiRequest, params: GetWoomCommentsReplyRequestParams = initialParams) => ({
  queryKey: [actions.GET_WOOM_COMMENTS_REPLY, params],
  queryFn: async () => request(actions.GET_WOOM_COMMENTS_REPLY, params),
});

export const woomCommentsReplyViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getWoomCommentsReplyQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

const getShortVideoType = (type: number) => {
  switch (type) {
    case 0:
      return "0";
    case 1:
      return "1";
    case 3:
      return "3";
    case 4:
      return "4";
    case 5:
      return "5";
  }
};

interface FormValues {
  publisher: string;
  privacy: number;
  is_empty: number;
  content: string;
  filterRange: null | Dayjs[];
  comment_id: string;
  comment_user: string;
  comment: string;
  reply_user: string;
  reply_content: string;
}

const initialValues: FormValues = {
  publisher: "",
  privacy: 0,
  is_empty: 1,
  content: "",
  filterRange: null,
  comment_id: cid,
  comment_user: "",
  comment: "",
  reply_user: "",
  reply_content: "",
};

type ModalKey = "multiple-delete" | "delete-comment-reply";

const WoomCommentsReplyView: React.FC = () => {
  const { t } = useTranslation("woom-comments-reply-view");
  const { isActionAllowed, isPageAllowed } = usePermissions();
  const request = useRequest();
  const queryClient = useQueryClient();

  if (!isActionAllowed(actions.GET_WOOM_COMMENTS_REPLY)) return null;

  // 查询
  const [isEmptySelectValue, setIsEmptySelectValue] = useState<number>(1);
  const [params, setParams] = useState<GetWoomCommentsReplyRequestParams>(initialParams);
  const { data, isRefetching } = useQuery({
    ...getWoomCommentsReplyQuery(request, params),
    keepPreviousData: true,
    onError: () => {},
  });

  // 删除
  const [commentIds, setCommentIds] = useState<string[]>([]);
  const deleteWoomCommentsReplyMutation = useMutation((comment_ids: DeleteWoomCommentsReplyRequestParams) => request(actions.DELETE_WOOM_COMMENTS_REPLY, comment_ids), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_WOOM_COMMENTS_REPLY]);
      message.open({
        key: "comment-delete-successfully",
        type: "success",
        content: t("toasts.delete-successfully"),
      });
    },
  });

  // 多选
  const [multipleChoice, setMultipleChoice] = useState<boolean>(false);
  const handleMultipleChoice = () => {
    setMultipleChoice(!multipleChoice);
    if (multipleChoice && commentIds.length > 0) setCommentIds([]);
  };
  const rowSelection: any = {
    columnWidth: 50,
    selectedRowKeys: commentIds,
    onChange: (selectedRowKeys: any) => setCommentIds(selectedRowKeys),
    renderCell: false,
  };

  // Confirm Modal
  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; reply_comment_id: string }>({
    open: false,
    key: "multiple-delete",
    reply_comment_id: "",
  });
  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    switch (openModal.key) {
      case "multiple-delete":
        deleteWoomCommentsReplyMutation.mutate({ comment_ids: commentIds });
        setCommentIds([]);
        break;
      case "delete-comment-reply":
        deleteWoomCommentsReplyMutation.mutate({ comment_ids: [openModal.reply_comment_id] });
        break;
    }
  }, [deleteWoomCommentsReplyMutation.mutate, openModal]);

  // Media Modal
  const [openMediaModal, setOpenMediaModal] = useState<{ open: boolean; mediaURL: string }>({ open: false, mediaURL: "" });

  // Edit Modal
  const [openEditModal, setOpenEditModal] = useState<{ open: boolean; row: GetWoomCommentsReplyItem; context: string; remark: string }>({
    open: false,
    row: {},
    context: "",
    remark: "",
  });
  // 编辑
  const editWoomCommentsReplyMutation = useMutation((data: EditWoomCommentsReplyRequestParams) => request(actions.EDIT_WOOM_COMMENTS_REPLY, data), {
    onSuccess: () => {
      setOpenEditModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_WOOM_COMMENTS_REPLY]);
      message.open({
        key: "comment-update-successfully",
        type: "success",
        content: t("toasts.update-successfully"),
      });
    },
  });
  // 保存编辑
  const saveEdit = () => {
    const data = {
      short_video_id: openEditModal.row.file_id,
      reply_comment_id: openEditModal.row.reply_comment_id,
      remark: openEditModal.remark,
      reply_content: openEditModal.context,
    };
    editWoomCommentsReplyMutation.mutate(data);
  };

  const columns: ColumnsType<GetWoomCommentsReplyItem> = useMemo(
    () => [
      {
        key: "idx",
        width: 80,
        title: t("columns.idx"),
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "post-user",
        width: 160,
        title: t("columns.post-user"),
        render: (row) => (
          <>
            {row.publish_user || row.publisher_id ? (
              <>
                <div className="text-no-wrap">{row.publish_user}</div>
                <div className="text-no-wrap">{row.publisher_id}</div>
              </>
            ) : (
              <>{t("columns.deleted-user")}</>
            )}
          </>
        ),
      },
      {
        key: "short-video-type",
        width: 160,
        title: t("columns.short-video-type"),
        dataIndex: "short_video_status",
        render: (value) => {
          const shortVideoType = getShortVideoType(value);
          return shortVideoType && <div style={{ color: value === 5 ? "red" : undefined }}>{t(`enums.short-video-type.${shortVideoType}`)}</div>;
        },
      },
      {
        key: "short-video",
        width: 160,
        title: t("columns.short-video"),
        render: (row) => (
          <div className="video-cover">
            <Image preview={false} src={row.cover_url} />
            <span className="video-play-icon" onClick={() => setOpenMediaModal({ open: true, mediaURL: row.media_url })}>
              <PlaySquareOutlined />
            </span>
          </div>
        ),
      },
      {
        key: "replyer",
        width: 160,
        title: t("columns.replyer"),
        render: (row) => (
          <>
            {row.reply_user_name || row.reply_user_id ? (
              <>
                <div className="text-no-wrap">{row.reply_user_name}</div>
                <div className="text-no-wrap">{row.reply_user_id}</div>
              </>
            ) : (
              <>{t("columns.deleted-user")}</>
            )}
          </>
        ),
      },
      {
        key: "reply-time",
        width: 160,
        title: t("columns.reply-time"),
        dataIndex: "reply_time",
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "reply-content",
        width: 160,
        title: t("columns.reply-content"),
        dataIndex: "reply_comment_content",
      },
      {
        key: "like",
        width: 160,
        title: t("columns.like"),
        render: (row) => (
          <>
            {isPageAllowed("/woom/woomCommentLike") && row.like_count > 0 ? <Link to={`/woom/woomCommentLike?cid=${row.reply_comment_id}`}>{row.like_count}</Link> : row.like_count}
          </>
        ),
      },
      {
        key: "comment",
        width: 160,
        title: t("columns.comment"),
        render: (row) => <>{row.comment_count > 0 ? <Link to={`/woom/woomSubComment?cid=${row.reply_comment_id}`}>{row.comment_count}</Link> : row.comment_count}</>,
      },
      {
        key: "comment-remark",
        width: 160,
        title: t("columns.comment-remark"),
        dataIndex: "remark",
      },
      {
        key: "operation",
        width: 160,
        title: t("columns.operation"),
        fixed: "right",
        align: "center",
        render: (row) => (
          <>
            {isActionAllowed(actions.EDIT_WOOM_COMMENTS_REPLY) && (
              <div>
                <button className="optionBtn" onClick={() => setOpenEditModal({ open: true, row, context: row.reply_comment_content, remark: row.remark })}>
                  {t("columns.opt-edit")}
                </button>
              </div>
            )}
            {isActionAllowed(actions.DELETE_WOOM_COMMENTS_REPLY) && (
              <div>
                <button className="optionBtn optionBtnDanger" onClick={() => setOpenModal({ open: true, key: "delete-comment-reply", reply_comment_id: row.reply_comment_id })}>
                  {t("columns.opt-delete")}
                </button>
              </div>
            )}
          </>
        ),
      },
    ],
    [t]
  );

  const handleFinnish = useCallback(
    ({ publisher, privacy, is_empty, content, filterRange, comment_id, comment_user, comment, reply_user, reply_content }: FormValues) => {
      setParams(({ show_number }) => {
        const state: GetWoomCommentsReplyRequestParams = { page_number: 1, show_number, privacy, is_empty };
        if (publisher !== "") state.publisher = publisher;
        if (is_empty == 1 && content !== "") state.content = content;
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = startTime;
          state.end_time = endTime;
        }
        if (comment_id !== "") state.comment_id = comment_id;
        if (comment_user !== "") state.comment_user = comment_user;
        if (comment !== "") state.comment = comment;
        if (reply_user !== "") state.reply_user = reply_user;
        if (reply_content !== "") state.reply_content = reply_content;
        return state;
      });
    },
    [setParams]
  );

  const handleFieldsChange = useCallback(
    ([fieldData]: FieldData[]) => {
      if (fieldData) {
        const { name, value } = fieldData;
        if (Array.isArray(name) && name[0] === "is_empty") {
          setIsEmptySelectValue(value);
        }
      }
    },
    [setIsEmptySelectValue]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) => {
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      }));
    },
    [setParams]
  );

  const { setDashboardHeading } = useDashboardView();
  useEffect(() => {
    setDashboardHeading("woom", "woom-comments-reply");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const [form] = Form.useForm();
  const location = useLocation();
  useEffect(() => {
    const { cid } = getLocationSearch();
    const oldCid = form.getFieldValue("comment_id");
    if (cid != oldCid) {
      form.setFieldValue("comment_id", cid);
      form.submit();
    }
  }, [location]);

  return (
    <>
      <Form className="filterForm" form={form} layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="publisher" label={t("form.publisher.label")}>
          <Input />
        </Form.Item>
        <Form.Item name="privacy" label={t("form.privacy.label")}>
          <Select
            options={([0, 4, 1, 5] as const).map((value) => ({
              value,
              label: t(`form.privacy.options.${value}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="is_empty" label={t("form.is_empty.label")}>
          <Select
            options={(["all", "empty"] as const).map((key, value) => ({
              value: value + 1,
              label: t(`form.is_empty.options.${key}`),
            }))}
          />
        </Form.Item>
        {isEmptySelectValue !== 2 && (
          <Form.Item name="content">
            <Input />
          </Form.Item>
        )}
        {isEmptySelectValue === 2 && (
          <Form.Item>
            <Input disabled />
          </Form.Item>
        )}
        <Form.Item name="filterRange" label={t("form.comment-time.label")}>
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item name="comment_id" label={t("form.comment-ID.label")}>
          <Input />
        </Form.Item>
        <Form.Item name="comment_user" label={t("form.comment_user.label")}>
          <Input placeholder={t("form.comment_user.placeholder")} />
        </Form.Item>
        <Form.Item name="comment" label={t("form.comment.label")}>
          <Input placeholder={t("form.comment.placeholder")} />
        </Form.Item>
        <Form.Item name="reply_user" label={t("form.reply_user.label")}>
          <Input placeholder={t("form.reply_user.placeholder")} />
        </Form.Item>
        <Form.Item name="reply_content" label={t("form.reply_content.label")}>
          <Input placeholder={t("form.reply_content.placeholder")} />
        </Form.Item>

        {/* 搜索 */}
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={isRefetching} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>

        {multipleChoice && (
          <>
            {/* 取消 */}
            <Form.Item>
              <Button className="filterBtn filterBtnPlain" type="primary" onClick={handleMultipleChoice}>
                {t("form.buttons.cancel")}
              </Button>
            </Form.Item>

            {/* 删除 */}
            <Form.Item>
              <Button
                className="filterBtn filterBtnDanger"
                type="primary"
                disabled={!commentIds.length}
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", reply_comment_id: "" })}
              >
                {t("form.buttons.delete")}
              </Button>
            </Form.Item>
          </>
        )}

        {/* 批量删除 */}
        {isActionAllowed(actions.DELETE_WOOM_COMMENTS_REPLY) && !multipleChoice && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleChoice}>
              {t("form.buttons.multi")}
            </Button>
          </Form.Item>
        )}
      </Form>

      <Table
        rowKey="reply_comment_id"
        className="customTable"
        dataSource={data?.data.comment_replies}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isRefetching}
        rowSelection={multipleChoice && { ...rowSelection }}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.replies_count,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />

      <ConfirmModal open={openModal.open} type={openModal.key} onCancel={handleModalCancel} onOk={handleModalOk} confirmLoading={deleteWoomCommentsReplyMutation.isLoading} />
      <MediaModal open={openMediaModal.open} onCancel={() => setOpenMediaModal((state) => ({ ...state, open: false }))} mediaURL={openMediaModal.mediaURL} />
      <EditModal t={t} save={saveEdit} data={openEditModal} setData={setOpenEditModal} />
    </>
  );
};

export default WoomCommentsReplyView;
