import React, { createContext, Suspense, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { Dropdown, Layout, Menu } from "antd";
import { useTranslation } from "react-i18next";
import classes from "./styles.module.scss";
import StatisticsIcon from "./icons/StatisticsIcon";
import OfficialAccountIcon from "./icons/OfficialAccountIcon";
import PlatformManagementIcon from "~/views/DashboardView/icons/PlatformManagementIcon";
import UsersIcon from "~/views/DashboardView/icons/UsersIcon";
import GroupsIcon from "~/views/DashboardView/icons/GroupsIcon";
import Logo from "~/views/DashboardView/Logo";
import { i18nextLocaleStorageKey, Language, supportedLocales, systemDefaultLocale } from "~/lib/i18next";
import { CaretDownOutlined } from "@ant-design/icons";
import LanguageIcon from "~/views/DashboardView/icons/LanguageIcon";
import clsx from "clsx";
import { useAuth } from "~/hooks/useAuth";
import AvatarIcon from "~/views/DashboardView/icons/AvatarIcon";
import PowerIcon from "~/views/DashboardView/icons/PowerIcon";
import GameStoreIcon from "~/views/DashboardView/icons/GameStoreIcon";
import MessagesIcon from "~/views/DashboardView/icons/MessagesIcon";
import MomentsIcon from "~/views/DashboardView/icons/MomentsIcon";
import TagsIcon from "~/views/DashboardView/icons/TagsIcon";
import VersionIcon from "~/views/DashboardView/icons/VersionIcon";
import SettingIcon from "~/views/DashboardView/icons/SettingIcon";
import MeIcon from "~/views/DashboardView/icons/MeIcon";
import { Helmet } from "react-helmet-async";
import WoomIcon from "~/views/DashboardView/icons/WoomIcon";
import withAuthRequired from "~/hoc/withAuthRequired";
import usePermissions from "~/hooks/usePermissions";

type CategoryKey =
  | "statistics"
  | "official-account"
  | "platform-management"
  | "users"
  | "groups"
  | "game-store"
  | "messages"
  | "woom"
  | "interest-tags-management"
  | "moments-management"
  | "version"
  | "me"
  | "setting";

type SubCategoryKey =
  | "user-statistics"
  | "group-statistics"
  | "message-statistics"
  | "game-statistics"
  | "official-account-management"
  | "official-account-news-management"
  | "official-account-comment-management"
  | "official-account-like-management"
  | "official-account-share-management"
  | "admin-list"
  | "roles"
  | "operation-logs"
  | "google-authenticator-setting"
  | "user-list"
  | "linked-accounts"
  | "deleted-accounts"
  | "group-management"
  | "game-management"
  | "game-category-management"
  | "user-messages"
  | "group-messages"
  | "system-notification"
  | "woom-management"
  | "woom-likes"
  | "woom-comments"
  | "woom-comments-reply"
  | "woom-comments-like"
  | "interest-tags"
  | "user-tags"
  | "group-tags"
  | "woom-tags"
  | "moments"
  | "moments-post"
  | "moments-comments"
  | "moments-likes"
  | "app-update"
  | "deposit"
  | "withdraw"
  | "exchange"
  | "market"
  | "earn"
  | "otc"
  | "favourites"
  | "discover"
  | "blacklist"
  | "share-code-setting"
  | "api-management"
  | "page-management";

interface SubMenuItem {
  key: SubCategoryKey;
  url: string;
}

interface MenuItem {
  key: CategoryKey;
  icon: React.ReactNode;
  children: SubMenuItem[];
}

const leftMenuItems: MenuItem[] = [
  {
    key: "statistics",
    icon: <StatisticsIcon />,
    children: [
      {
        key: "user-statistics",
        url: "/statistics/usersSta",
      },
      {
        key: "group-statistics",
        url: "/statistics/groupsSta",
      },
      {
        key: "message-statistics",
        url: "/statistics/messagesSta",
      },
      {
        key: "game-statistics",
        url: "/statistics/gameSta",
      },
    ],
  },
  {
    key: "official-account",
    icon: <OfficialAccountIcon />,
    children: [
      {
        key: "official-account-management",
        url: "/officialAccount/officialAccountManagemnet",
      },
      {
        key: "official-account-news-management",
        url: "/officialAccount/newsManagement",
      },
      {
        key: "official-account-comment-management",
        url: "/officialAccount/commentManagement",
      },
      {
        key: "official-account-like-management",
        url: "/officialAccount/likeManagemnet",
      },
      {
        key: "official-account-share-management",
        url: "/officialAccount/shareManagement",
      },
    ],
  },
  {
    key: "platform-management",
    icon: <PlatformManagementIcon />,
    children: [
      {
        key: "admin-list",
        url: "/platformManagement/adminList",
      },
      {
        key: "roles",
        url: "/platformManagement/adminRole",
      },
      {
        key: "operation-logs",
        url: "/platformManagement/operationLogs",
      },
      {
        key: "google-authenticator-setting",
        url: "/platformManagement/googleAuthSetting",
      },
    ],
  },
  {
    key: "users",
    icon: <UsersIcon />,
    children: [
      {
        key: "user-list",
        url: "/users/usersList",
      },
      {
        key: "linked-accounts",
        url: "/users/linkedAccount",
      },
      {
        key: "deleted-accounts",
        url: "/users/deletedAccount",
      },
    ],
  },
  {
    key: "groups",
    icon: <GroupsIcon />,
    children: [
      {
        key: "group-management",
        url: "/groups/groupsAdm",
      },
    ],
  },
  {
    key: "game-store",
    icon: <GameStoreIcon />,
    children: [
      {
        key: "game-management",
        url: "/gameStore/gameManage",
      },
      {
        key: "game-category-management",
        url: "/gameStore/categoryManage",
      },
    ],
  },
  {
    key: "messages",
    icon: <MessagesIcon />,
    children: [
      {
        key: "user-messages",
        url: "/messages/usersMessages",
      },
      {
        key: "group-messages",
        url: "/messages/groupsMessages",
      },
      {
        key: "system-notification",
        url: "/messages/groupsSendMessages",
      },
    ],
  },
  {
    key: "woom",
    icon: <WoomIcon />,
    children: [
      {
        key: "woom-management",
        url: "/woom/woomManage",
      },
      {
        key: "woom-likes",
        url: "/woom/woomLike",
      },
      {
        key: "woom-comments",
        url: "/woom/woomComment",
      },
      {
        key: "woom-comments-reply",
        url: "/woom/woomSubComment",
      },
      {
        key: "woom-comments-like",
        url: "/woom/woomCommentLike",
      },
    ],
  },
  {
    key: "interest-tags-management",
    icon: <TagsIcon />,
    children: [
      {
        key: "interest-tags",
        url: "/interestTags/interestTagsManage",
      },
      {
        key: "user-tags",
        url: "/interestTags/interestUserTags",
      },
      {
        key: "group-tags",
        url: "/interestTags/interestGroupTags",
      },
      {
        key: "woom-tags",
        url: "/interestTags/InterestWoomTags",
      },
    ],
  },
  {
    key: "moments-management",
    icon: <MomentsIcon />,
    children: [
      {
        key: "moments",
        url: "/moments/moments",
      },
      {
        key: "moments-post",
        url: "/moments/momentsPost",
      },
      {
        key: "moments-comments",
        url: "/moments/momentsComments",
      },
      {
        key: "moments-likes",
        url: "/moments/momentsLikes",
      },
    ],
  },
  {
    key: "version",
    icon: <VersionIcon />,
    children: [
      {
        key: "app-update",
        url: "/version/appUpdate",
      },
    ],
  },
  {
    key: "me",
    icon: <MeIcon />,
    children: [
      {
        key: "deposit",
        url: "/mepage/deposit",
      },
      {
        key: "withdraw",
        url: "/mepage/withdraw",
      },
      {
        key: "exchange",
        url: "/mepage/exchange",
      },
      {
        key: "market",
        url: "/mepage/market",
      },
      {
        key: "earn",
        url: "/mepage/earn",
      },
      {
        key: "otc",
        url: "/mepage/otc",
      },
      {
        key: "favourites",
        url: "/mepage/favourites",
      },
      {
        key: "discover",
        url: "/mepage/discover",
      },
      {
        key: "blacklist",
        url: "/mepage/blacklist",
      },
    ],
  },
  {
    key: "setting",
    icon: <SettingIcon />,
    children: [
      {
        key: "share-code-setting",
        url: "/setting/shareCodeSetting",
      },
      {
        key: "api-management",
        url: "/setting/apis",
      },
      {
        key: "page-management",
        url: "/setting/pages",
      },
    ],
  },
];

interface DashboardViewContext {
  setDashboardHeading(categoryKey: CategoryKey | null, subCategoryKey: SubCategoryKey | null): void;
}

const dashboardViewContext = createContext<DashboardViewContext>({
  setDashboardHeading: () => null,
});

const DashboardView = () => {
  const navigate = useNavigate();
  const { isPageAllowed } = usePermissions();
  const { value: authValue, logOut } = useAuth();
  const [currentLocale, setCurrentCountry] = useState(() => localStorage.getItem(i18nextLocaleStorageKey) as Language | null);
  const { t, i18n } = useTranslation("dashboard-view");
  const [{ categoryKey, subCategoryKey }, setHeading] = useState<{
    categoryKey: CategoryKey | null;
    subCategoryKey: SubCategoryKey | null;
  }>({ categoryKey: null, subCategoryKey: null });
  const [languageDropdownOpen, setLanguageDropdownOpen] = useState<boolean>(false);
  const [authDropdownOpen, setAuthDropdownOpen] = useState<boolean>(false);
  const location = useLocation();

  const [selectedMenuKeys, initialSiderOpenKeys] = useMemo(() => {
    for (const item of leftMenuItems) {
      for (const child of item.children) {
        if (child.url === location.pathname) {
          return [[child.key], [item.key]];
        }
      }
    }
    return [[], []];
  }, [location]);

  const [siderOpenKeys, setSiderOpenKeys] = useState<CategoryKey[]>(initialSiderOpenKeys);

  useEffect(() => {
    setSiderOpenKeys(initialSiderOpenKeys);
  }, [initialSiderOpenKeys, setSiderOpenKeys]);

  const handleLocaleClick = useCallback(
    (locale: Language | null) => {
      setLanguageDropdownOpen(false);
      if (locale) {
        i18n.changeLanguage(locale).then(() => localStorage.setItem(i18nextLocaleStorageKey, locale));
        setCurrentCountry(locale);
        return;
      }
      i18n.changeLanguage(systemDefaultLocale).then(() => localStorage.removeItem(i18nextLocaleStorageKey));
      setCurrentCountry(null);
    },
    [i18n, setCurrentCountry]
  );

  const handleSiderOpenChange = useCallback((keys: string[]) => setSiderOpenKeys(keys.length > 0 ? [keys[keys.length - 1] as CategoryKey] : []), [setSiderOpenKeys]);

  const handleMenuItemClick = ({ keyPath, key }: { key: string; keyPath: string[] }) => {
    if (keyPath.length === 2) {
      const menuItem = leftMenuItems.find((item) => item.key === keyPath[1]);
      if (menuItem) {
        const subItem = menuItem.children.find((subItem) => subItem.key === key);
        subItem && navigate(subItem.url);
      }
    }
  };

  const setDashboardHeading = useCallback(
    (categoryKey: CategoryKey | null, subCategoryKey: SubCategoryKey | null) =>
      setHeading({
        categoryKey,
        subCategoryKey,
      }),
    [setHeading]
  );

  const permittedLeftMenuItems = useMemo(() => {
    return leftMenuItems
      .map((item) => ({
        ...item,
        children: item.children.filter((child) => isPageAllowed(child.url)),
      }))
      .filter((item) => item.children.length > 0);
  }, [isPageAllowed]);

  return (
    <>
      {subCategoryKey && <Helmet title={t(`left-menu.${subCategoryKey}`)} />}
      <Layout className={classes.rootLayout}>
        <div className={classes.navbar}>
          <div className={classes.logoAnchorWrapper}>
            <Link to="/" className={classes.logoAnchor}>
              <Logo />
            </Link>
          </div>
          {categoryKey && subCategoryKey && (
            <div className={classes.categoryWrapper}>
              <div className={classes.categoryTitle}>
                {t("header-template", {
                  category: t(`left-menu.${categoryKey}`),
                  subCategory: t(`left-menu.${subCategoryKey}`),
                })}
              </div>
              <div className={classes.categorySubCategory}>{t(`left-menu.${subCategoryKey}`)}</div>
            </div>
          )}
          <div className={classes.navbarRightMenu}>
            {authValue && (
              <Dropdown
                open={authDropdownOpen}
                onOpenChange={setAuthDropdownOpen}
                rootClassName={classes.navbarDropdown}
                menu={{
                  items: [
                    {
                      key: "sign-out",
                      label: t("buttons.sign-out"),
                      icon: <PowerIcon />,
                      onClick: logOut,
                    },
                  ],
                }}
                placement="bottomRight"
                trigger={["click"]}
              >
                <button className={clsx(classes.navbarDropdownButton, authDropdownOpen && classes.navbarDropdownButtonActive)}>
                  <AvatarIcon className={classes.navbarDropdownButtonIcon} />
                  {authValue.username}
                  <CaretDownOutlined className={classes.navbarDropdownButtonArrow} />
                </button>
              </Dropdown>
            )}
            <Dropdown
              open={languageDropdownOpen}
              onOpenChange={setLanguageDropdownOpen}
              rootClassName={classes.navbarDropdown}
              menu={{
                selectable: true,
                selectedKeys: [currentLocale || "default"],
                items: [null, ...supportedLocales].map((locale) => ({
                  key: locale || "default",
                  label: t(`locales.${locale || "default"}`),
                  onClick: () => handleLocaleClick(locale),
                })),
              }}
              placement="bottomRight"
              trigger={["click"]}
            >
              <button className={clsx(classes.navbarDropdownButton, languageDropdownOpen && classes.navbarDropdownButtonActive)}>
                <LanguageIcon className={classes.navbarDropdownButtonIcon} />
                {t(`locales.${currentLocale || "default"}`)}
                <CaretDownOutlined className={classes.navbarDropdownButtonArrow} />
              </button>
            </Dropdown>
          </div>
        </div>
        <Layout>
          <Layout.Sider width={236} className={classes.sider}>
            <Menu
              mode="inline"
              selectable
              selectedKeys={selectedMenuKeys}
              openKeys={siderOpenKeys}
              onOpenChange={handleSiderOpenChange}
              onClick={handleMenuItemClick}
              items={permittedLeftMenuItems.map(({ key, icon, children }) => ({
                key,
                label: t(`left-menu.${key}`),
                icon,
                children: children.map(({ key }) => ({
                  key,
                  icon: <div className={classes.circleIcon} />,
                  label: t(`left-menu.${key}`),
                })),
              }))}
            />
          </Layout.Sider>
          <Layout.Content className={classes.layoutContent}>
            <dashboardViewContext.Provider value={{ setDashboardHeading }}>
              <Suspense>
                <Outlet />
              </Suspense>
            </dashboardViewContext.Provider>
            <p className={classes.copyrights}>{t("copyrights")}</p>
          </Layout.Content>
        </Layout>
      </Layout>
    </>
  );
};

export const useDashboardView = () => useContext(dashboardViewContext);

export default withAuthRequired(DashboardView);
