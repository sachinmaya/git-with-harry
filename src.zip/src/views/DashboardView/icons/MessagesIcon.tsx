import React from "react";

const MessagesIcon: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <g transform="translate(0.223 0.444)">
      <path
        d="M9.722,0A9.722,9.722,0,0,0,0,9.722v8.641a1.08,1.08,0,0,0,1.08,1.08H9.722A9.722,9.722,0,1,0,9.722,0Zm0,12.962H5.4a1.08,1.08,0,0,1,0-2.16H9.722a1.08,1.08,0,1,1,0,2.16Zm4.321-4.321H5.4a1.08,1.08,0,1,1,0-2.16h8.641a1.08,1.08,0,1,1,0,2.16Z"
        transform="translate(0.056 -0.166)"
      />
    </g>
  </svg>
);

export default MessagesIcon;
