import React from "react";

const MeIcon: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <g transform="translate(0.223 0.445)">
      <path
        d="M79.693,10.611a5.306,5.306,0,1,0-5.308-5.3A5.315,5.315,0,0,0,79.693,10.611Zm8.209,4.53a7.054,7.054,0,0,0-1.6-2.183,7.508,7.508,0,0,0-5.042-2.011H78.131a7.5,7.5,0,0,0-5.042,2.011,7.054,7.054,0,0,0-1.6,2.183,6.3,6.3,0,0,0-.6,2.679A2.18,2.18,0,0,0,73.065,20H86.325A2.18,2.18,0,0,0,88.5,17.821a6.341,6.341,0,0,0-.6-2.679Z"
        transform="translate(-70.108 -0.445)"
      />
    </g>
  </svg>
);

export default MeIcon;
