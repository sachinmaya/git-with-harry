import React from "react";

const MomentsIcon: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <g transform="translate(0.222 0.444)">
      <path
        d="M50.751,70.258,42.265,63.6a2.154,2.154,0,0,0-2.586,0l-8.422,6.658a.664.664,0,1,0,.821,1.043l.271-.214v8.047a2.219,2.219,0,0,0,2.239,1.993H47.876a1.781,1.781,0,0,0,1.747-1.993V71.068l.3.236a.653.653,0,0,0,.411.143.668.668,0,0,0,.418-1.189Zm-7.806,5.65v1.386H38.959V73.575c0-.771.625-1.6,1.993-1.6s1.993.832,1.993,1.6v2.332Z"
        transform="translate(-31.226 -62.617)"
      />
    </g>
  </svg>
);

export default MomentsIcon;
