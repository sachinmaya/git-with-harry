import React from "react";

const VersionIcon: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <g transform="translate(0.223 0.447)">
      <path
        d="M12961.777,16800.555a10,10,0,1,1,10-10A10.012,10.012,0,0,1,12961.777,16800.555Zm-1.012-8.752v3.5a.983.983,0,0,0,.991.961.966.966,0,0,0,.683-.287l1.459-1.434.013-.008a.989.989,0,0,0,0-1.379l-.013-.014a.99.99,0,0,0-1.151-.168l-.013,0v-3.525a.982.982,0,0,0-.992-.957.968.968,0,0,0-.694.295l-1.4,1.43-.013.014a.993.993,0,0,0,.025,1.383l.013.008a.973.973,0,0,0,.676.27,1.018,1.018,0,0,0,.419-.09Zm1.012-7a1.613,1.613,0,1,0,1.611,1.615A1.615,1.615,0,0,0,12961.777,16784.8Z"
        transform="translate(-12951.999 -16781)"
      />
    </g>
  </svg>
);

export default VersionIcon;
