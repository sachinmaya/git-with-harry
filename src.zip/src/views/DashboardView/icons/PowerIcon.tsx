import React from "react";

const PowerIcon: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 12 12" fill="currentColor" {...props}>
    <g transform="translate(-1696 -69.999)">
      <path
        d="M109.446,64.727a.874.874,0,0,1,1.746,0v4.584a.874.874,0,0,1-1.746,0V64.727ZM110.1,75.9a5.309,5.309,0,0,1-5.455-5.151,5.166,5.166,0,0,1,3.491-4.8v1.834a3.459,3.459,0,0,0-1.746,2.967,3.715,3.715,0,0,0,7.419,0,3.417,3.417,0,0,0-1.309-2.668V66.134a5.129,5.129,0,0,1,3.055,4.62A5.309,5.309,0,0,1,110.1,75.9Zm0,0"
        transform="translate(1591.9 6.096)"
      />
    </g>
  </svg>
);

export default PowerIcon;
