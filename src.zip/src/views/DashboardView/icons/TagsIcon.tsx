import React from "react";

const TagsIcon: React.FC<React.HTMLAttributes<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <g transform="translate(0.222 0.444)">
      <path
        d="M17.159,93.872,8.927,85.64a1.048,1.048,0,0,0-.746-.309H1.055A1.057,1.057,0,0,0,0,86.386v7.125a1.048,1.048,0,0,0,.309.746l8.232,8.232a1.055,1.055,0,0,0,1.493,0l7.125-7.125a1.057,1.057,0,0,0,0-1.493ZM6.754,90.4a1.689,1.689,0,1,1-1.689-1.689A1.689,1.689,0,0,1,6.754,90.4Zm12.937,4.968-7.573,7.573a.422.422,0,1,1-.6-.6l7.573-7.573a.211.211,0,0,0,0-.3l-8.417-8.417a.422.422,0,0,1,.6-.6l8.417,8.417a1.057,1.057,0,0,1,0,1.493Z"
        transform="translate(-0.222 -84.641)"
      />
    </g>
  </svg>
);

export default TagsIcon;
