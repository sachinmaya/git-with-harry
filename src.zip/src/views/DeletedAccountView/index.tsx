import { ApiRequest, GetDeletedAccountRequestParams, DeletedAccountItem } from "~/api/types";
import { actions } from "~/api/constants";
import { QueryClient, useQuery } from "@tanstack/react-query";
import { InternalServerError, NetworkError } from "~/api/errors";
import { Button, Form, Input, message, Select, Table, Image, DatePicker } from "antd";
import Text from "antd/lib/typography/Text";
import dayjs, { Dayjs } from "dayjs";
import useRequest from "~/hooks/useRequest";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { useDashboardView } from "~/views/DashboardView";
import { ColumnsType } from "antd/es/table";
import Icon from "@ant-design/icons";
import SearchIcon from "~/components/icons/SearchIcon";
import usePermissions from "~/hooks/usePermissions";
import { useLocation } from "react-router-dom";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";

const initialParams: GetDeletedAccountRequestParams = {
  page_number: 1,
  show_number: 10,
};

const getLinkedAccountsQuery = (request: ApiRequest, params: GetDeletedAccountRequestParams = initialParams) => ({
  queryKey: [actions.GET_DELETED_ACCOUNT, params],
  queryFn: async () => request(actions.GET_DELETED_ACCOUNT, params),
});

export const deletedAccountViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getLinkedAccountsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  keyword: string;
  gender: string;
  reason: string;
  location:string;
  time_type:string;
  filterRange: null | Dayjs[];
  last_login_device:string;
  deleted_by:string;
}
const initialValues: FormValues ={
  keyword: "",
  gender: "all",
  reason:"",
  location:"",
  time_type: "all",
  filterRange: null,
  last_login_device:"all",
  deleted_by:""
};
const DeletedAccountView = () => {
  const { t } = useTranslation("deleted-accounts-view");
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const location = useLocation();
  const [params, setParams] = useState<GetDeletedAccountRequestParams>(() => (initialParams));
  const [searchLoading, setSearchLoading] = useState<boolean>(false);

  const { isActionAllowed } = usePermissions();

  

  const { data, isPreviousData } = useQuery({
    ...getLinkedAccountsQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.deleted-accounts-query-failed"),
      });
    },
  });

  useEffect(() => {
    setDashboardHeading("users", "deleted-accounts");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ keyword, gender, reason, location, time_type, filterRange, last_login_device,deleted_by, }: FormValues) => {
      setParams(({ show_number }) => {
        const state: GetDeletedAccountRequestParams = { page_number: 1, show_number };
        if (keyword !== "") {
          state.user = keyword;
        }
        if (gender !== "all") {
          state.gender = Number(gender);
        }
        if (reason !== "") {
          state.reason = reason;
        }
        if (location !== "") {
          state.location = location;
        }
        if (time_type !== "all") {
          state.time_type = time_type;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = String(startTime);
          state.end_time = String(endTime);
        }
        if (last_login_device !== "all") {
          state.last_login_device = last_login_device;
        }
        if (deleted_by !== "") {
          state.location = location;
        }
        return state;
      });
      setSearchLoading(true);
    },
    [setParams]
  );

  const columns: ColumnsType<DeletedAccountItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
          render: (value, record, index) => ((data?.data.current_number || 0) - 1) * (data?.data.show_number || 0) + (index + 1),
      },
      {
        key: "username",
        dataIndex: "username",
        width: 160,
        title: t("columns.nickname"),
      },
      {
        key: "profile_photo",
        width: 180,
        dataIndex: "profile_photo",
        title: t("columns.profile-photo"),
        render: (text) => {
          if (text === "") {
              return t("toasts.no-media");
          }
          return <Image
              preview={true}
              width={50}
              height={50}
              src={text}
          />;
        },
      },
      {
        key: "phone_number",
        width: 160,
        dataIndex: "phone_number",
        title: t("columns.phone"),
      },
      {
        key: "user_id",
        width: 200,
        dataIndex: "user_id",
        title: t("columns.xlink-id"),
        render: (value) => value || "-",
      },
      {
        key: "gender",
        width: 140,
        dataIndex: "gender",
        title: t("columns.gender"),
        render: (text) => {
          return  (
            <Text>
              {text === 2 ? t("form.gender.options.2"):t("form.gender.options.1")}
            </Text>
          );
        },
      },
      {
        key: "last_login_ip",
        width: 140,
        dataIndex: "last_login_ip",
        title: `${t("columns.last-log-in-ip")} (${t("columns.shared-by")})`,
        render: (value) => value || "-",
      },
      {
        key: "location",
        width: 140,
        dataIndex: "location",
        title: t("columns.location"),
        render: (value) => value || "-",
      },
      {
        key: "create_time",
        width: 140,
        dataIndex: "create_time",
        title: t("columns.id-create-time"),
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "delete_time",
        width: 140,
        dataIndex: "delete_time",
        title: t("columns.id-delete-time"),
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "deleted_by",
        width: 140,
        dataIndex: "deleted_by",
        title: t("columns.delete-by"),
        render: (value) => value || "-",
      },
      {
        key: "reason",
        width: 140,
        dataIndex: "reason",
        title: t("columns.reason"),
        render: (value) => value || "-",
      }
    ],
    [t, data]
  );

  if (!isActionAllowed(actions.GET_DELETED_ACCOUNT)) {
    return null;
  }

  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish}>
        <Form.Item name="keyword">
          <Input placeholder={t("form.keyword.placeholder")} style={{ width: 270 }} />
        </Form.Item>
        <Form.Item name="gender" label={t("form.gender.label")}>
          <Select
            style={{ width: 160 }}
            options={(["all","1", "2"] as const).map((value) => ({
              value:value,
              label: t(`form.gender.options.${value}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="reason" label={t("form.reason.label")}>
          <Input style={{ width: 250 }} />
        </Form.Item>
        <Form.Item name="location" label={t("form.location.label")}>
          <Input style={{ width: 250 }} />
        </Form.Item>
        
        <Form.Item name="time_type">
          <Select
            options={(["all", "1", "2"] as const).map((key) => ({
              value:key,
              label: t(`form.time-filter.options.${key}`),
            }))}
            style={{ width: 120 }}
          />
        </Form.Item>
        <Form.Item name="filterRange">
          <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} style={{ width: 280 }} />
        </Form.Item>
        <Form.Item name="last_login_device" label={t("form.last-login.label")}>
          <Select
            options={(["all", "1", "2", "3"] as const).map((key) => ({
              value:key,
              label: t(`form.last-login.options.${key}`),
            }))}
            style={{ width: 120 }}
          />
        </Form.Item> 
        <Form.Item name="deleted_by" label={t("form.deleted-by.label")}>
          <Input style={{ width: 250 }} />
        </Form.Item>   
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
      </Form>
      <Table
        rowKey="user_id"
        className="customTable"
        dataSource={data?.data.deleted_users}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.deleted_users_count,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => t("pagination.show-total-text", { total }),
        }}
      />
    </>
  );
};

export default DeletedAccountView;
