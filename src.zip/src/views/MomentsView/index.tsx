import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button, DatePicker, Empty, Form, Image, Input, message, Modal, Select, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import dayjs, { Dayjs } from "dayjs";
import React, { FC, useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { actions } from "~/api/constants";
import {
  AlterMomentRequestParams,
  ApiRequest,
  ChangeMomentsStatusRequestParams,
  ContentImagesArrayType,
  ContentVideosArrayType,
  DeleteMomentsRequestParams,
  GetMomentItem,
  GetMomentsRequestParams,
  MomentInterstItem,
} from "~/api/types";
import useRequest from "~/hooks/useRequest";
import { useDashboardView } from "../DashboardView";
import Text from "antd/lib/typography/Text";
import { Link } from "react-router-dom";
import Paragraph from "antd/es/typography/Paragraph";
import EditMoments from "./EditModal";
import { TableRowSelection } from "antd/es/table/interface";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import Icon, { EyeOutlined, PlaySquareOutlined } from "@ant-design/icons";
import usePermissions from "~/hooks/usePermissions";
import VideoPlayer from "~/components/VideoPlayerModal";
import { InternalServerError, NetworkError } from "~/api/errors";
import VideoContent from "~/components/VideoContent";

const initialParams: GetMomentsRequestParams = {
  page_number: 1,
  show_number: 10,
  order_by: "start_time:desc",
};

const getMomentsQuery = (request: ApiRequest, params: GetMomentsRequestParams = initialParams) => ({
  queryKey: [actions.GET_MOMENTS, params],
  queryFn: async () => request(actions.GET_MOMENTS, params),
});

export const MomentsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getMomentsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  account: string;
  privacy: number;
  content_type: number;
  content: string;
  is_reposted: number;
  original_user: string;
  media_type: number;
  status: number;
  filter_range: null | Dayjs[];
}
const initialValue: FormValues = {
  account: "",
  privacy: 0,
  content_type: 0,
  content: "",
  is_reposted: 0,
  original_user: "",
  media_type: 0,
  status: 0,
  filter_range: null,
};

const getTagByLang = (lang: "cn" | "en" | "ar", interests: MomentInterstItem[]) => {
  if (interests.length === 0) {
    return "-";
  }
  const tags = interests.map((item, key) => {
    const nameList = item.name;
    if (nameList !== null) {
      const index = nameList.findIndex((item) => item.language_type === lang);
      return nameList[index]?.name;
    }
  });
  return tags.join(", ");
};

interface VideoData {
  open: boolean;
  video: ContentVideosArrayType | null;
}
interface EditModalContent {
  open: boolean;
  moment: GetMomentItem | undefined;
}
interface MomentsViewProps {}

const MomentsView: FC<MomentsViewProps> = () => {
  const { t } = useTranslation("moments-view");
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const [form] = Form.useForm();
  const queryClient = useQueryClient();
  const isReposted = Form.useWatch("is_reposted", form);
  const status = Form.useWatch("status", form);
  const { isActionAllowed } = usePermissions();
  const [visible, setVisible] = useState<string | null>(null);
  const [vedioPlayer, setVedioPlayer] = useState<VideoData>({ open: false, video: null });
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<GetMomentItem> | undefined>(undefined);
  const [params, setParams] = useState<GetMomentsRequestParams>(initialParams);
  const [editModal, setEditModal] = useState<EditModalContent>({ open: false, moment: undefined });
  const [articleIds, setArticleIds] = useState<number[]>([]);
  const { confirm, destroyAll } = Modal;
  const { data, refetch, isRefetching } = useQuery({
    ...getMomentsQuery(request, params),
    keepPreviousData: true,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.error(t("toasts.moment-query-failed"));
    },
  });
  const deteleMutation = useMutation((params: DeleteMomentsRequestParams) => request(actions.DELETE_MOMENTS, params), {
    onSuccess() {
      queryClient.invalidateQueries({
        queryKey: [actions.GET_MOMENTS, params],
      });
      setDeleteSelection(undefined);
      destroyAll();
      message.open({
        key: "delete-successfully",
        type: "success",
        content: t("toasts.delete-successfully"),
      });
    },
    onError(error) {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.error(t("toasts.delete-failed"));
      destroyAll();
    },
  });
  const statusMutation = useMutation((params: ChangeMomentsStatusRequestParams) => request(actions.CHANGE_MOMENT_STATUS, params), {
    onSuccess() {
      queryClient.invalidateQueries({
        queryKey: [actions.GET_MOMENTS, params],
      });
      setDeleteSelection(undefined);
      destroyAll();
      message.open({
        key: "status-updated-successfully",
        type: "success",
        content: t("toasts.status-updated-successfully"),
      });
    },
    onError(error) {
      destroyAll();
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.error(t("toasts.status-update-failed"));
    },
  });
  const editMomentMutation = useMutation((params: AlterMomentRequestParams) => request(actions.ALTER_MOMENT, params), {
    onSuccess() {
      queryClient.invalidateQueries({
        queryKey: [actions.GET_MOMENTS, params],
      });
      setEditModal({ open: false, moment: undefined });
      message.open({
        key: "edit-moment-success",
        type: "success",
        content: t("toasts.edit-moment-success"),
      });
    },
    onError(error) {
      setEditModal({ open: false, moment: undefined });
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.error(t("toasts.edit-moment-failed"));
    },
  });

  useEffect(() => {
    setDashboardHeading("moments-management", "moments");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const handleMultiUnblock = () => statusMutation.mutateAsync({ moment_ids: deleteSelection?.selectedRowKeys as string[], status: 1 });
  const handleMutltiDelete = () => deteleMutation.mutateAsync({ moments: deleteSelection?.selectedRowKeys as string[], article_ids: articleIds });
  const handleEditModal = () => setEditModal({ open: false, moment: undefined });

  const changeMomentstatus = (status: number, ids: string[]) => statusMutation.mutateAsync({ moment_ids: ids, status: status });

  const handleDeleteMoments = (moments: string, article_ids: number) => deteleMutation.mutateAsync({ moments: [moments], article_ids: [article_ids] });

  const deleteMoment = (moments: string, article_ids: number) => {
    confirm({
      title: t("modal.delete-moment.title"),
      content: t("modal.delete-moment.content"),
      icon: <></>,
      onOk: () => handleDeleteMoments(moments, article_ids),
      okText: t("modal.delete-moment.ok-btn"),
      okType: "danger",
      okButtonProps: { type: "primary" },
      cancelText: t("modal.delete-moment.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const blockMoment = (status: number, ids: string[]) => {
    confirm({
      title: t("modal.block-moment.title"),
      content: t("modal.block-moment.content"),
      icon: <></>,
      onOk: () => changeMomentstatus(status, ids),
      okText: t("modal.block-moment.ok-btn"),
      cancelText: t("modal.block-moment.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const unblockMoment = (status: number, ids: string[]) => {
    confirm({
      title: t("modal.unblock-moment.title"),
      content: t("modal.unblock-moment.content"),
      icon: <></>,
      onOk: () => changeMomentstatus(status, ids),
      okText: t("modal.unblock-moment.ok-btn"),
      cancelText: t("modal.unblock-moment.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const deleteSelectedMoments = () => {
    confirm({
      title: t("modal.delete-multi-moments.title"),
      content: t("modal.delete-multi-moments.content"),
      icon: <></>,
      okType: "danger",
      okButtonProps: { type: "primary" },
      onOk: () => handleMutltiDelete(),
      okText: t("modal.delete-multi-moments.ok-btn"),
      cancelText: t("modal.delete-multi-moments.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const playVideo = (video: ContentVideosArrayType) => {
    if (video !== null) {
      return setVedioPlayer({ open: true, video: video });
    }
  };
  const closePlayer = () => setVedioPlayer({ open: false, video: null });
  const showMedia = (item: GetMomentItem) => {
    if (item.mContentImagesArrayV2 !== null && item.mContentImagesArrayV2.length !== 0) {
      return (
        <>
          <Image
            preview={{ visible: false, mask: <EyeOutlined /> }}
            width={60}
            height={40}
            src={`${item.mContentImagesArrayV2[0].image_url}`}
            onClick={() => setVisible(item.moment_id)}
          />
          <div style={{ display: "none" }}>
            <Image.PreviewGroup preview={{ visible: visible === item.moment_id, onVisibleChange: (vis) => setVisible(vis ? item.moment_id : null) }}>
              {item.mContentImagesArrayV2.map((image: ContentImagesArrayType, index) => {
                return <Image src={`${image.image_url}`} key={index} />;
              })}
            </Image.PreviewGroup>
          </div>
        </>
      );
    }
    if (item.mContentVideosArrayV2 !== null && item.mContentVideosArrayV2.length !== 0) {
      return <VideoContent videoInfo={item.mContentVideosArrayV2[0]} playVideo={playVideo} />;
    }
    return t("columns.no-media");
  };

  const handleEdit = (moment: GetMomentItem) => setEditModal({ open: true, moment });

  const columns: ColumnsType<GetMomentItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "account",
        width: 180,
        dataIndex: "user_id",
        title: t("columns.account"),
      },
      {
        key: "nickname",
        dataIndex: "user_name",
        width: 180,
        title: t("columns.nickname"),
        render: (value) => (
          <Text
            style={{ width: 150 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value}
          </Text>
        ),
      },
      {
        key: "type",
        title: t("columns.type"),
        dataIndex: "privacy",
        width: 80,
        render: (value) => {
          return value === 1 ? t(`form.type.options.private`) : t(`form.type.options.public`);
        },
      },
      { key: "post-time", title: t("columns.post-time"), dataIndex: "m_create_time", width: 180, render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss") },
      {
        key: "media",
        title: t("columns.media"),
        dataIndex: "cover_photo",
        width: 100,
        render: (_, record) => showMedia(record),
      },
      {
        key: "content",
        title: t("columns.content"),
        dataIndex: "m_content_text",
        width: 180,
        render: (_, record) => (
          <Link to={`/moments/posts?momentId=${record.moment_id}`}>
            <Paragraph
              style={{ width: 130, color: "#30B7E8" }}
              ellipsis={{
                tooltip: record.m_content_text,
                rows: 2,
              }}
            >
              {record.m_content_text}
            </Paragraph>
          </Link>
        ),
      },

      {
        key: "tags-cn",
        title: t("columns.tags-cn"),
        dataIndex: "interests",
        width: 150,
        onclick: () => {},
        render: (value) => (
          <Paragraph
            style={{ width: 150 }}
            ellipsis={{
              tooltip: getTagByLang("cn", value),
              rows: 2,
            }}
          >
            {getTagByLang("cn", value)}
          </Paragraph>
        ),
      },
      {
        key: "tags-en",
        title: t("columns.tags-en"),
        dataIndex: "interests",
        width: 150,
        onclick: () => {},
        render: (value) => (
          <Paragraph
            style={{ width: 150 }}
            ellipsis={{
              tooltip: getTagByLang("en", value),
              rows: 2,
            }}
          >
            {getTagByLang("en", value)}
          </Paragraph>
        ),
      },
      {
        key: "tags-ar",
        title: t("columns.tags-ar"),
        dataIndex: "interests",
        width: 150,
        onclick: () => {},
        render: (value) => (
          <Paragraph
            style={{ width: 150 }}
            ellipsis={{
              tooltip: getTagByLang("ar", value),
              rows: 2,
            }}
          >
            {getTagByLang("ar", value)}
          </Paragraph>
        ),
      },
      {
        key: "source",
        title: t("columns.source"),
        dataIndex: "article_id",
        render: (text) => {
          return text === 0 ? t("form.post-type.options.original") : t("form.post-type.options.reposted");
        },
      },
      {
        key: "author",
        width: 100,
        title: t("columns.author"),
        dataIndex: "last_login_ip",
        render: (_, record) => {
          const saprator = record.original_creator_name !== "" && record.original_creator_id !== "" ? "/" : " ";
          return record.original_creator_name === "" && record.original_creator_id === "" ? "-" : `${record.original_creator_name} ${saprator} ${record.original_creator_id}`;
        },
      },
      {
        key: "options",
        title: t("columns.operations.lable"),
        fixed: "right",
        width: 1000,
        hidden: !(isActionAllowed(actions.DELETE_MOMENTS) && isActionAllowed(actions.ALTER_MOMENT) && isActionAllowed(actions.CHANGE_MOMENT_STATUS)),
        render: (_, record) => {
          return (
            <>
              {isActionAllowed(actions.ALTER_MOMENT) && (
                <button type="button" className="optionBtn" onClick={() => handleEdit(record)}>
                  {t("columns.operations.buttons.edit")}
                </button>
              )}
              {isActionAllowed(actions.DELETE_MOMENTS) && (
                <button type="button" className="optionBtn optionBtnDanger" onClick={() => deleteMoment(record.moment_id, record.article_id)}>
                  {t("columns.operations.buttons.delete")}
                </button>
              )}
              {record.status === 1
                ? isActionAllowed(actions.CHANGE_MOMENT_STATUS) && (
                    <button type="button" className="optionBtn optionBtnBlock" onClick={() => blockMoment(2, [record.moment_id])}>
                      {t("columns.operations.buttons.block")}
                    </button>
                  )
                : isActionAllowed(actions.CHANGE_MOMENT_STATUS) && (
                    <button type="button" className="optionBtn optionBtnUnblock" onClick={() => unblockMoment(1, [record.moment_id])}>
                      {t("columns.operations.buttons.unblock")}
                    </button>
                  )}
            </>
          );
        },
      },
    ],
    [t, visible, setVisible]
  );
  const handleSubmit = useCallback(
    (values: FormValues) => {
      setParams(({ show_number, order_by }) => {
        let state: GetMomentsRequestParams;
        let formatedValues = Object.fromEntries(Object.entries(values).filter(([_, v]) => v != "" && v != 0 && v !== null));
        if (formatedValues.filter_range) {
          const [startDate, endDate] = formatedValues.filter_range;
          delete formatedValues["filter_range"];
          formatedValues.start_time = startDate.unix();
          formatedValues.end_time = endDate.unix();
        }
        state = { ...formatedValues, page_number: 1, show_number, order_by };
        return state;
      });
      refetch();
    },
    [setParams, refetch]
  );

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);
  const handleMultipleDeleteClick = useCallback(
    () =>
      setDeleteSelection({
        selectedRowKeys: [],
        onChange: (selectedRowKeys, selectedRows) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          setArticleIds(selectedRows.map((a) => a.article_id));
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );

  return (
    <>
      {isActionAllowed(actions.GET_MOMENTS) && (
        <>
          <Form initialValues={initialValue} form={form} onFinish={handleSubmit} name={"moments-form"} layout="inline" colon={false} className="filterForm">
            <Form.Item name="account">
              <Input placeholder={t("form.keyword.placeholder")} style={{ width: 220 }} />
            </Form.Item>
            <Form.Item name="privacy" label={t("form.type.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "private", "public", "block"] as const).map((key, value) => ({
                  value,
                  label: t(`form.type.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="media_type" label={t("form.media.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "images", "video"] as const).map((key, value) => ({
                  value,
                  label: t(`form.media.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="content_type" label={t("form.content-type.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "empty"] as const).map((key, value) => ({
                  value,
                  label: t(`form.content-type.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="content">
              <Input placeholder={t("form.content-keyword.placeholder")} />
            </Form.Item>
            <Form.Item name="is_reposted">
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "original", "reposted"] as const).map((key, value) => ({
                  value,
                  label: t(`form.post-type.options.${key}`),
                }))}
              />
            </Form.Item>
            {isReposted === 2 && (
              <Form.Item name="original_user">
                <Input placeholder={t("form.post-keyword.placeholder")} />
              </Form.Item>
            )}
            <Form.Item name="status" label={t("form.status.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "unblock", "blocked"] as const).map((key, value) => ({
                  value,
                  label: t(`form.status.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="filter_range" label={t("form.post-time.lable")}>
              <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
            </Form.Item>
            {isActionAllowed(actions.GET_MOMENTS) && (
              <Form.Item>
                <Button htmlType="submit" className="filterBtn filterBtnInfo" icon={<Icon component={SearchIcon} />} type="primary" loading={isRefetching}>
                  {t("form.buttons.search")}
                </Button>
              </Form.Item>
            )}
            {deleteSelection === undefined && isActionAllowed(actions.DELETE_MOMENTS) && (
              <Form.Item>
                <Button onClick={handleMultipleDeleteClick} icon={<Icon component={DeleteIcon} />} className="filterBtn filterBtnDanger" type="primary">
                  {t("form.buttons.select")}
                </Button>
              </Form.Item>
            )}
            {deleteSelection !== undefined && isActionAllowed(actions.DELETE_MOMENTS) && (
              <>
                <Form.Item>
                  <Button type="primary" onClick={handleMultipleDeleteCancelClick} className="filterBtn filterBtnSuccess">
                    {t("form.buttons.cancel")}
                  </Button>
                </Form.Item>
                <Form.Item>
                  <Button onClick={deleteSelectedMoments} className="filterBtn filterBtnDanger" type="primary" disabled={deleteSelection?.selectedRowKeys?.length == 0}>
                    {t("form.buttons.delete")}
                  </Button>
                </Form.Item>
                {isActionAllowed(actions.CHANGE_MOMENT_STATUS) &&
                  (status === 1 ? (
                    <Form.Item>
                      <Button className="filterBtn filterBtnUnblock" type="primary" onClick={handleMultiUnblock} disabled={deleteSelection?.selectedRowKeys?.length == 0}>
                        {t("form.buttons.block")}
                      </Button>
                    </Form.Item>
                  ) : (
                    <Form.Item>
                      <Button className="filterBtn filterBtnBlock" type="primary" onClick={handleMultiUnblock} disabled={deleteSelection?.selectedRowKeys?.length == 0}>
                        {t("form.buttons.unblock")}
                      </Button>
                    </Form.Item>
                  ))}
              </>
            )}
          </Form>
          {isActionAllowed(actions.GET_MOMENTS) && (
            <Table
              rowKey="moment_id"
              dataSource={data?.data.moments}
              columns={columns}
              scroll={{ x: true }}
              loading={isRefetching}
              rowSelection={deleteSelection}
              pagination={{
                current: data?.data.current_number,
                total: data?.data.moments_nums,
                onChange: handlePaginationChange,
                pageSizeOptions: [10, 20, 50, 100, 1000],
                showQuickJumper: true,
                position: ["bottomCenter"],
                showTotal: (total: string | number) => t("pagination.show-total-text", { total }),
              }}
            />
          )}
          {editModal.moment && <EditMoments open={editModal.open} close={handleEditModal} data={editModal.moment} onSubmit={(values) => editMomentMutation.mutate(values)} />}
          {vedioPlayer.video !== null && <VideoPlayer video={vedioPlayer.video} open={vedioPlayer.open} onCancel={closePlayer} />}
        </>
      )}
      {!isActionAllowed(actions.GET_MOMENTS) && <Empty description={false} />}
    </>
  );
};

export default MomentsView;
