import { useMutation } from "@tanstack/react-query";
import { Button, Form, Input, message, Select, Upload } from "antd";
import TextArea from "antd/es/input/TextArea";
import Modal from "antd/es/modal/Modal";
import type { RcFile, UploadProps } from "antd/es/upload";
import type { UploadFile } from "antd/es/upload/interface";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { UploadParams } from "~/api";
import { AlterMomentRequestParams, ContentImagesArrayType, ContentVideosArrayType, GetMomentItem, MomentInterstItem } from "~/api/types";
import useUpload from "~/hooks/useUpload";
import VideoSnapshot from "video-snapshot";
import fileFromUrl from "~/utils/fileFromUrl";
import VideoContent from "~/components/VideoContent";
import VideoPlayer from "~/components/VideoPlayerModal";

interface EditMomentsProps {
  open: boolean;
  close: () => void;
  data: GetMomentItem;
  onSubmit: (values: AlterMomentRequestParams) => void;
}
interface InitialValues {
  moments: string;
  media_type: number;
}

const getTagByLang = (lang: "cn" | "en" | "ar", interests: MomentInterstItem[]) => {
  if (interests.length === 0) {
    return "-";
  }
  const tags = interests.map((item, key) => {
    const nameList = item.name;
    if (nameList !== null) {
      const index = nameList.findIndex((item) => item.language_type === lang);
      return nameList[index]?.name;
    }
  });
  return tags.join(", ");
};
const getBase64 = (file: RcFile): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });

const EditMoments: React.FC<EditMomentsProps> = ({ open, close, data, onSubmit }) => {
  const { t } = useTranslation("moments-view");
  const [form] = Form.useForm();
  const mediaType = Form.useWatch("media_type", form);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [previewTitle, setPreviewTitle] = useState("");
  const [openPlayer, setOpenPlayer] = useState<boolean>(false);
  const upload = useUpload();
  const [videoInfo, setVideoInfo] = useState<ContentVideosArrayType[] | null>(data?.mContentVideosArrayV2);
  const [imageUrl, setImageUrl] = useState<ContentImagesArrayType[] | null>(data?.mContentImagesArrayV2);

  const getImageFileList: UploadFile[] = useMemo(() => {
    if (data === undefined || data === null || data?.mContentImagesArrayV2 === null) {
      return [];
    }
    const momentImages = data?.mContentImagesArrayV2.map((item, index) => {
      let urlArr = item.image_url.split("/");
      return {
        uid: `-${index + 1}`,
        name: urlArr[urlArr.length - 1],
        url: item.image_url,
      };
    });
    return momentImages;
  }, [data, open, close]);

  const getVideoFileList: UploadFile[] = useMemo(() => {
    if (data === undefined || data === null || data?.mContentVideosArrayV2 === null) {
      return [];
    }
    let momentVideo = [
      {
        key: 1,
        uid: `video-1`,
        name: data?.mContentVideosArrayV2[0].snap_shot_url,
      },
    ];
    return momentVideo;
  }, [data, open, close]);

  const [imagefileList, setImageFileList] = useState<UploadFile[]>(getImageFileList);
  const [videofileList, setVideoFileList] = useState<UploadFile[]>(getVideoFileList);
  const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  const uploadMutation = useMutation((params: UploadParams) => upload(params), {
    onSuccess(data, { type }) {
      if (type === 3) {
        let newImage: ContentImagesArrayType = {
          image_url: data.URL,
          snap_shot_url: "",
          image_width: data.imageWidth,
          image_height: data.imageHeight,
        };
        if (imageUrl === null) {
          return setImageUrl([newImage]);
        }
        return setImageUrl([...imageUrl, newImage]);
      }
      if (type === 2) {
        setVideoInfo([
          {
            video_url: data.URL,
            snap_shot_url: data.snapshotURL ? data.snapshotURL : "",
            video_width: data.imageWidth,
            video_height: data.imageHeight,
          },
        ]);
      }
    },
  });

  const inititalValues: InitialValues = useMemo(() => {
    if (data) {
      let values: InitialValues = {
        moments: data?.m_content_text,
        media_type: data?.mContentImagesArrayV2 !== null ? 0 : 1,
      };
      return values;
    }
    return {
      moments: "",
      media_type: 0,
    };
  }, [data]);

  const onFinish = async (values: InitialValues) => {
    if (values.media_type === 0) {
      if (imageUrl !== null && data !== undefined) {
        const imageContentArray = imageUrl.filter((image) => imagefileList.some((item) => item.url === image.image_url));
        return onSubmit({ moment_id: data?.moment_id, content: values.moments, m_content_images_array_v2: imageContentArray, m_content_videos_array_v2: null });
      }
      if (values.moments !== data.m_content_text) {
        return onSubmit({ moment_id: data?.moment_id, content: values.moments, m_content_images_array_v2: data.mContentImagesArrayV2, m_content_videos_array_v2: null });
      }
    }
    if (values.media_type === 1) {
      if (videoInfo !== null && data !== undefined) {
        return onSubmit({ moment_id: data?.moment_id, content: values.moments, m_content_images_array_v2: null, m_content_videos_array_v2: videoInfo });
      }
      if (values.moments !== data.m_content_text) {
        return onSubmit({ moment_id: data?.moment_id, content: values.moments, m_content_images_array_v2: null, m_content_videos_array_v2: data.mContentVideosArrayV2 });
      }
    }
  };
  const handleCancel = () => setPreviewOpen(false);

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as RcFile);
    }
    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
    setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf("/") + 1));
  };
  const handleVideoUpload = async (options: any) => {
    const { onSuccess, onError, file, onProgress } = options;
    const formData = new FormData();
    formData.append("video", file);
    const snapshoter = new VideoSnapshot(file);
    snapshoter
      .takeSnapshot()
      .then(fileFromUrl)
      .then((snapshot) => {
        uploadMutation.mutate(
          {
            file: file,
            snapshot,
            type: 2,
            persist: true,
          },
          {
            onSuccess() {
              return onSuccess("ok");
            },
            onError(err) {
              const error = new Error("Some error");
              onError({ err });
            },
          }
        );
      });
  };

  const handleChange: UploadProps["onChange"] = async ({ fileList: newFileList, file }) => {
    if (file.lastModified !== undefined) {
      await uploadMutation.mutate(
        { file: file as unknown as File, type: 3, persist: true },
        {
          onSuccess(data) {
            let p = newFileList;
            p[newFileList.length - 1] = {
              uid: (-newFileList.length).toString(),
              name: data.newName,
              url: data.URL,
            };
            return setImageFileList(newFileList);
          },
          onError(error) {
            let p = newFileList;
            p.pop();
            message.error("upload failed");
            return setImageFileList(p);
          },
        }
      );
    }
    return setImageFileList(newFileList);
  };
  if (data === undefined) {
    return <h6> {t("error.common")}</h6>;
  }
  const handleChangeVideo = ({ fileList: newFileList }: any) => {
    setVideoFileList(newFileList);
  };
  const handlePLayVideo = (video: ContentVideosArrayType) => {
    setOpenPlayer(true);
  };
  return (
    <Modal
      title={t("modal.edit-moment.title")}
      open={open}
      destroyOnClose
      onCancel={close}
      onOk={form.submit}
      okText={t("modal.edit-moment.ok-btn")}
      width={640}
      className="editModal"
    >
      <Form form={form} {...formItemLayout} initialValues={inititalValues} onFinish={onFinish}>
        <Form.Item label={t("modal.edit-moment.account")}>
          <Input value={data?.user_id} disabled />
        </Form.Item>
        <Form.Item label={t("modal.edit-moment.nickname")}>
          <Input value={data?.user_name} disabled />
        </Form.Item>
        <Form.Item label={t("modal.edit-moment.type.label")}>
          <Input value={data.privacy === 1 ? t(`modal.edit-moment.type.options.1`) : t(`modal.edit-moment.type.options.2`)} disabled />
        </Form.Item>
        <Form.Item label={t("modal.edit-moment.source.lable")}>
          <Input value={data?.article_id === 0 ? t(`modal.edit-moment.source.options.0`) : t(`modal.edit-moment.source.options.1`)} disabled />
        </Form.Item>
        <Form.Item label={t("modal.edit-moment.moments")} name="moments">
          <TextArea rows={8} maxLength={2200} showCount={true} />
        </Form.Item>
        <Form.Item name="media_type" label={t("modal.edit-moment.media.label")}>
          <Select
            options={(["images", "video"] as const).map((key, value) => ({
              value,
              label: t(`modal.edit-moment.media.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="m_content_images_array_v2" label=" " valuePropName="fileList">
          {mediaType === 0 ? (
            <>
              <Upload
                listType="picture-card"
                fileList={imagefileList}
                beforeUpload={async (file: File) => {
                  return false;
                }}
                onPreview={handlePreview}
                onChange={handleChange}
                maxCount={9}
                accept=".png,jpg,.jpeg,.gif"
              >
                {imagefileList.length >= 9 ? null : <Button>upload</Button>}
              </Upload>
              <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                <img alt="example" style={{ width: "100%" }} src={previewImage} />
              </Modal>
            </>
          ) : (
            <>
              {videoInfo !== null && <VideoContent videoInfo={videoInfo[0]} playVideo={handlePLayVideo} height={100} width={100} />}
              <Upload customRequest={(options) => handleVideoUpload(options)} fileList={videofileList} listType="picture" accept=".mp4" maxCount={1} onChange={handleChangeVideo}>
                <Button>upload</Button>
              </Upload>
            </>
          )}
        </Form.Item>
        <Form.Item label={t("modal.edit-moment.tags-cn")}>
          <Input value={getTagByLang("cn", data?.interests)} disabled />
        </Form.Item>
        <Form.Item label={t("modal.edit-moment.tags-en")}>
          <Input value={getTagByLang("en", data?.interests)} disabled />
        </Form.Item>
        <Form.Item label={t("modal.edit-moment.tags-ar")}>
          <Input value={getTagByLang("ar", data?.interests)} disabled />
        </Form.Item>
      </Form>
      {videoInfo !== null && <VideoPlayer video={videoInfo[0]} open={openPlayer} onCancel={() => setOpenPlayer(false)} />}
    </Modal>
  );
};

export default EditMoments;
