import React, { FC, useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { useDashboardView } from "../DashboardView";
import dayjs, { Dayjs } from "dayjs";
import { Button, DatePicker, Empty, Form, Image, Input, message, Modal, Select, Table } from "antd";
import {
  AlterMomentCommentRequestParams,
  ApiRequest,
  ContentImagesArrayType,
  ContentVideosArrayType,
  GetMomentCommentItem,
  GetMomentsCommentsRequestParams,
  RemoveMomentsCommentRequestParams,
  SwitchCommentStatusRequestParams,
} from "~/api/types";
import { actions } from "~/api/constants";
import { QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { TableRowSelection } from "antd/lib/table/interface";
import { ColumnsType } from "antd/es/table";
import Text from "antd/lib/typography/Text";
import { Link } from "react-router-dom";
import EditComment from "./EditModal";
import Icon, { EyeOutlined } from "@ant-design/icons";
import DeleteIcon from "~/components/icons/DeleteIcon";
import usePermissions from "~/hooks/usePermissions";
import SearchIcon from "~/components/icons/SearchIcon";
import VideoPlayer from "~/components/VideoPlayerModal";
import { InternalServerError, NetworkError } from "~/api/errors";
import VideoContent from "~/components/VideoContent";

const initialParams: GetMomentsCommentsRequestParams = {
  page_number: 1,
  show_number: 10,
  order_by: "start_time:desc",
};

const getMomentsCommentsQuery = (request: ApiRequest, params: GetMomentsCommentsRequestParams = initialParams) => ({
  queryKey: [actions.GET_MOMENT_COMMENT, params],
  queryFn: async () => request(actions.GET_MOMENT_COMMENT, params),
});

export const MomentsCommentsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getMomentsCommentsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  publish_user: string;
  content_type: number;
  m_content_text: string;
  comment_user: string;
  comment_content: string;
  media_type: number;
  comment_type: number;
  time_type: number;
  filter_range: null | Dayjs[];
}
const initialValue: FormValues = {
  publish_user: "",
  content_type: 0,
  m_content_text: "",
  comment_user: "",
  comment_content: "",
  media_type: 0,
  comment_type: 0,
  time_type: 0,
  filter_range: null,
};

interface MomentsCommentViewProps {}
interface VideoData {
  open: boolean;
  video: ContentVideosArrayType | null;
}
const MomentsCommentView: FC<MomentsCommentViewProps> = () => {
  const { t } = useTranslation("moments-comments-view");
  const { setDashboardHeading } = useDashboardView();
  const request = useRequest();
  const [form] = Form.useForm();
  const { confirm, destroyAll } = Modal;
  const queryClient = useQueryClient();
  const { isActionAllowed } = usePermissions();
  const [selectedComments, setSelectedComments] = useState<GetMomentCommentItem[]>([]);
  const [visible, setVisible] = useState<string | null>(null);
  const [vedioPlayer, setVedioPlayer] = useState<VideoData>({ open: false, video: null });
  const [params, setParams] = useState<GetMomentsCommentsRequestParams>(initialParams);
  const [editData, setEditData] = useState<{ open: boolean; comment: GetMomentCommentItem | undefined }>({
    open: false,
    comment: undefined,
  });
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<GetMomentCommentItem> | undefined>(undefined);
  const { data, refetch, isRefetching } = useQuery({
    ...getMomentsCommentsQuery(request, params),
    keepPreviousData: true,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "comment-query-failed",
        type: "error",
        content: t("toasts.comment-query-failed"),
      });
    },
  });
  const deleteMutation = useMutation((params: RemoveMomentsCommentRequestParams) => request(actions.REMOVE_MOMENT_COMMENT, params), {
    onSuccess() {
      queryClient.invalidateQueries({
        queryKey: [actions.GET_MOMENT_COMMENT, params],
      });
      setDeleteSelection(undefined);
      destroyAll();
      message.open({
        key: "delete-multi-success",
        type: "success",
        content: t("toasts.delete-multi-success"),
      });
    },
    onError(error) {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      destroyAll();
      message.error(t("toasts.delete-failed"));
    },
  });
  const SwitchCommentStatusMutation = useMutation((params: SwitchCommentStatusRequestParams) => request(actions.SWITCH_COMMENT_STATUS, params), {
    onSuccess(data, { status }) {
      queryClient.invalidateQueries({
        queryKey: [actions.GET_MOMENT_COMMENT, params],
      });
      destroyAll();
      message.open({
        key: "hide-success",
        type: "success",
        content: status === 2 ? t("toasts.hide-success") : t("toasts.show-success"),
      });
    },
    onError(error, { status }) {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      destroyAll();
      message.error(status === 2 ? t("toasts.hide-failed") : t("toasts.show-failed"));
    },
  });
  const editMutation = useMutation((params: AlterMomentCommentRequestParams) => request(actions.ALTER_MOMENT_COMMENT, params), {
    onSuccess() {
      queryClient.invalidateQueries({
        queryKey: [actions.GET_MOMENT_COMMENT, params],
      });
      setEditData({ open: false, comment: undefined });
      message.open({
        key: "update-success",
        type: "success",
        content: t("toasts.update-success"),
      });
    },
    onError(error) {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      setEditData({ open: false, comment: undefined });
      message.error(t("toasts.update-Failed"));
    },
  });
  const handleCloseEdit = () => setEditData({ open: false, comment: undefined });
  useEffect(() => {
    setDashboardHeading("moments-management", "moments-comments");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const handleMultiDelete = (data: GetMomentCommentItem[]) => {
    let deletparams: RemoveMomentsCommentRequestParams = {
      moment_ids: data.map((i) => i.moment_id),
      reply_ids: data.map((i) => i.reply_comment_id),
      comment_ids: data.map((i) => i.comment_id),
      parent_ids: data.map((i) => i.comment_parent_id),
    };
    return deleteMutation.mutateAsync(deletparams);
  };
  const handleEdit = (values: AlterMomentCommentRequestParams) => editMutation.mutateAsync(values);
  const deleteComment = () => {
    confirm({
      content: t("modal.delete-multi-comment.content"),
      icon: <></>,
      onOk: () => handleMultiDelete(selectedComments),
      okText: t("modal.delete-multi-comment.ok-btn"),
      okType: "danger",
      okButtonProps: { type: "primary" },
      cancelText: t("modal.delete-multi-comment.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const deleteSignleComment = (comment: GetMomentCommentItem) => {
    confirm({
      content: t("modal.delete-comment.content"),
      icon: <></>,
      onOk: () => handleMultiDelete([comment]),
      okText: t("modal.delete-comment.ok-btn"),
      okType: "danger",
      okButtonProps: { type: "primary" },
      cancelText: t("modal.delete-comment.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };

  const hideComment = (comment_id: string, status: number) => {
    confirm({
      content: t("modal.hide-comment.content"),
      icon: <></>,
      onOk: () => SwitchCommentStatusMutation.mutateAsync({ comment_id, status }),
      okText: t("modal.hide-comment.ok-btn"),
      cancelText: t("modal.hide-comment.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const showComment = (comment_id: string, status: number) => {
    confirm({
      content: t("modal.unhide-comment.content"),
      icon: <></>,
      onOk: () => SwitchCommentStatusMutation.mutateAsync({ comment_id, status }),
      okText: t("modal.unhide-comment.ok-btn"),
      cancelText: t("modal.unhide-comment.cancel-btn"),
      closable: true,
      className: "confirmModal",
    });
  };
  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );
  const handleSubmit = useCallback(
    (values: FormValues) => {
      let formatedValues = Object.fromEntries(Object.entries(values).filter(([_, v]) => v != "" && v != 0 && v !== null));
      if (formatedValues.length === 0) return;
      setParams(({ show_number, order_by }) => {
        let state: GetMomentsCommentsRequestParams;
        if (formatedValues.filter_range) {
          const [startDate, endDate] = formatedValues.filter_range;
          delete formatedValues["filter_range"];
          formatedValues.start_time = startDate.unix();
          formatedValues.end_time = endDate.unix();
        }
        state = { ...formatedValues, page_number: 1, show_number, order_by };
        return state;
      });
      refetch();
    },
    [setParams, refetch]
  );
  const playVideo = (video: ContentVideosArrayType) => {
    if (video !== null) {
      return setVedioPlayer({ open: true, video: video });
    }
  };
  const closePlayer = () => setVedioPlayer({ open: false, video: null });
  const showMedia = (item: GetMomentCommentItem) => {
    if (item.mContentImagesArrayV2 !== null && item.mContentImagesArrayV2.length !== 0) {
      return (
        <>
          <Image
            preview={{ visible: false, mask: <EyeOutlined /> }}
            width={60}
            height={40}
            src={`${item.mContentImagesArrayV2[0].image_url}`}
            onClick={() => setVisible(item.moment_id)}
          />
          <div style={{ display: "none" }}>
            <Image.PreviewGroup preview={{ visible: visible === item.moment_id, onVisibleChange: (vis) => setVisible(vis ? item.moment_id : null) }}>
              {item.mContentImagesArrayV2.map((image: ContentImagesArrayType, index) => {
                return <Image src={`${image.image_url}`} key={index} />;
              })}
            </Image.PreviewGroup>
          </div>
        </>
      );
    }
    if (item.mContentVideosArrayV2 !== null && item.mContentVideosArrayV2.length !== 0) {
      return <VideoContent videoInfo={item.mContentVideosArrayV2[0]} playVideo={playVideo} />;
    }
    return t("columns.no-media");
  };
  const columns: ColumnsType<GetMomentCommentItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "account-nickname",
        width: 180,
        dataIndex: "publish_account publish_name",
        title: t("columns.account-nickname"),
        render: (_, record) => {
          let value = record.publish_account && record.publish_name ? `${record.publish_account} / ${record.publish_name}` : `${record.publish_account} ${record.publish_name} `;
          return (
            <Text
              style={{ width: 150 }}
              ellipsis={{
                tooltip: value,
              }}
            >
              {value}
            </Text>
          );
        },
      },
      {
        key: "type",
        title: t("columns.type.label"),
        dataIndex: "privacy",
        width: 50,
        render: (value: number) => (value === 1 ? t(`columns.type.options.1`) : t(`columns.type.options.2`)),
      },
      {
        key: "media",
        title: t("columns.media"),
        dataIndex: "mContentImagesArrayV2",
        width: 100,
        render: (_, record) => showMedia(record),
      },

      {
        key: "m_content_text",
        title: t("columns.moments"),
        dataIndex: "m_content_text",
        width: 180,
        render: (value) => (
          <Text
            style={{ width: 150 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value}
          </Text>
        ),
      },

      {
        key: "m_create_time",
        title: t("columns.post-time"),
        dataIndex: "m_create_time",
        width: 150,
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "comment_content",
        title: t("columns.comment"),
        dataIndex: "comment_content",
        width: 150,
        onclick: () => {},
        render: (value) => (
          <Text
            style={{ width: 150 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value}
          </Text>
        ),
      },
      {
        key: "commentator",
        width: 110,
        title: t("columns.commentator"),
        dataIndex: "user_id",
      },
      {
        key: "commentator-location",
        title: t("columns.commentator-location"),
        dataIndex: "location",
        render: () => "-",
      },
      {
        key: "create_time",
        title: t("columns.comment-time"),
        dataIndex: "create_time",
        width: 150,
        render: (value) => dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss"),
      },
      {
        key: "reply-to-comment",
        title: t("columns.Reply-to-comment"),
        dataIndex: "comment_replies",
        render: (_, record) => (record.comment_replies === 0 ? 0 : <Link to={`/moments/momentsComments?momentId=${record.comment_id}`}>{record.comment_replies}</Link>),
      },
      {
        key: "options",
        width: 320,
        title: t("columns.operations.lable"),
        fixed: "right",
        hidden: !(isActionAllowed(actions.ALTER_MOMENT_COMMENT) && isActionAllowed(actions.REMOVE_MOMENT_COMMENT) && isActionAllowed(actions.SWITCH_COMMENT_STATUS)),
        render: (_, record) => {
          return (
            <div>
              {isActionAllowed(actions.ALTER_MOMENT_COMMENT) && (
                <button type="button" className="optionBtn optionBtnInfo" onClick={() => setEditData({ open: true, comment: record })}>
                  {t("columns.operations.buttons.edit")}
                </button>
              )}
              {isActionAllowed(actions.REMOVE_MOMENT_COMMENT) && (
                <button type="button" className="optionBtn optionBtnDanger" onClick={() => deleteSignleComment(record)}>
                  {t("columns.operations.buttons.delete")}
                </button>
              )}
              {record.status === 1 && isActionAllowed(actions.SWITCH_COMMENT_STATUS) ? (
                <button type="button" className="optionBtn optionBtnBlock" onClick={() => hideComment(record.comment_id, 2)}>
                  {t("columns.operations.buttons.hide")}
                </button>
              ) : (
                isActionAllowed(actions.SWITCH_COMMENT_STATUS) && (
                  <button type="button" className="optionBtn optionBtnSuccess" onClick={() => showComment(record.comment_id, 1)}>
                    {t("columns.operations.buttons.unhide")}
                  </button>
                )
              )}
            </div>
          );
        },
      },
    ],
    [t, visible, setVisible]
  );
  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);
  const handleMultipleDelete = useCallback(
    () =>
      setDeleteSelection({
        selectedRowKeys: [],
        onChange: (selectedRowKeys, selectedRows) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          setSelectedComments(selectedRows);
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );

  return (
    <>
      {isActionAllowed(actions.GET_MOMENT_COMMENT) ? (
        <>
          <Form initialValues={initialValue} className="filterForm" form={form} onFinish={handleSubmit} name={"moments-comments-form"} layout="inline" colon={false}>
            <Form.Item name="publish_user">
              <Input
                placeholder={t("form.keyword.placeholder")}
                style={{
                  minWidth: 220,
                }}
              />
            </Form.Item>
            <Form.Item name="media_type" label={t("form.media.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "images", "video"] as const).map((key, value) => ({
                  value,
                  label: t(`form.media.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="content_type" label={t("form.content-type.label")}>
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "empty"] as const).map((key, value) => ({
                  value,
                  label: t(`form.content-type.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="m_content_text">
              <Input placeholder={t("form.content-keyword.placeholder")} />
            </Form.Item>
            <Form.Item name="comment_user" label={t("form.commentator.lable")}>
              <Input
                placeholder={t("form.commentator.placeholder")}
                style={{
                  minWidth: 220,
                }}
              />
            </Form.Item>
            <Form.Item name="comment_content" label={t("form.comments.lable")}>
              <Input placeholder={t("form.comments.placeholder")} />
            </Form.Item>
            <Form.Item label={t("form.comment-location.lable")}>
              <Input placeholder={t("form.comment-location.placeholder")} />
            </Form.Item>
            <Form.Item name="time_type">
              <Select
                style={{
                  minWidth: 120,
                }}
                options={(["all", "post-time", "comment-time"] as const).map((key, value) => ({
                  value,
                  label: t(`form.post-time.options.${key}`),
                }))}
              />
            </Form.Item>
            <Form.Item name="filter_range">
              <DatePicker.RangePicker disabledDate={(date) => date.isAfter(dayjs())} />
            </Form.Item>
            {isActionAllowed(actions.GET_MOMENT_COMMENT) && (
              <Form.Item>
                <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={isRefetching} icon={<Icon component={SearchIcon} />}>
                  {t("form.buttons.search")}
                </Button>
              </Form.Item>
            )}
            {deleteSelection === undefined && isActionAllowed(actions.REMOVE_MOMENT_COMMENT) && (
              <Form.Item>
                <Button className="filterBtn filterBtnDanger" type="primary" onClick={handleMultipleDelete} icon={<Icon component={DeleteIcon} />}>
                  {t("form.buttons.select")}
                </Button>
              </Form.Item>
            )}
            {deleteSelection !== undefined && isActionAllowed(actions.REMOVE_MOMENT_COMMENT) && (
              <>
                {" "}
                <Form.Item>
                  <Button className="filterBtn filterBtnSuccess" type="primary" onClick={handleMultipleDeleteCancelClick}>
                    {t("form.buttons.cancel")}
                  </Button>
                </Form.Item>
                <Form.Item>
                  <Button className="filterBtn filterBtnDanger" type="primary" onClick={deleteComment} disabled={deleteSelection?.selectedRowKeys?.length == 0}>
                    {t("form.buttons.delete")}
                  </Button>
                </Form.Item>
              </>
            )}
          </Form>
          <Table
            rowKey="comment_id"
            dataSource={data?.data.comments ?? undefined}
            columns={columns}
            scroll={{ x: true }}
            loading={isRefetching}
            rowSelection={deleteSelection}
            pagination={{
              current: data?.data.current_number,
              total: data?.data.comments_nums,
              onChange: handlePaginationChange,
              pageSizeOptions: [10, 20, 50, 100, 1000],
              showQuickJumper: true,
              position: ["bottomCenter"],
              showTotal: (total: number) => t("pagination.show-total-text", { total }),
            }}
          />
          <EditComment open={editData.open} comment={editData.comment!} close={handleCloseEdit} onSubmit={handleEdit} />
          {vedioPlayer.video !== null && <VideoPlayer video={vedioPlayer.video} open={vedioPlayer.open} onCancel={closePlayer} />}
        </>
      ) : (
        <Empty description={false} />
      )}
    </>
  );
};

export default MomentsCommentView;
