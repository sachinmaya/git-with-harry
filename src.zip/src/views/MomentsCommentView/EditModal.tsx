import { Form, Modal, Input, Button } from "antd";
import React, { FC, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { AlterMomentCommentRequestParams, GetMomentCommentItem } from "~/api/types";

interface EditCommentProps {
  open: boolean;
  close: () => void;
  comment: GetMomentCommentItem;
  onSubmit: (values: AlterMomentCommentRequestParams) => void;
}
interface FormValues {
  comment: string;
  commentator: string;
}

const EditComment: FC<EditCommentProps> = ({ open, close, comment, onSubmit }) => {
  const { t } = useTranslation("moments-comments-view");
  const [form] = Form.useForm();
  const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };
  const initialValue = useMemo(() => {
    if (comment) {
      let values: FormValues = {
        comment: comment.comment_content,
        commentator: comment.user_id,
      };
      return values;
    }
  }, [comment]);

  const onFinish = (values: FormValues) => {
    if (comment.comment_content !== values.comment) {
      return onSubmit({ comment_id: comment.comment_id, content: values.comment });
    }
  };
  return (
    <Modal title={t("modal.edit-comment.title")} open={open} destroyOnClose onCancel={close} onOk={form.submit} okText={t("modal.edit-comment.form.ok-btn")} className="editModal">
      <Form initialValues={initialValue} onFinish={onFinish} {...formItemLayout} form={form}>
        <Form.Item name="commentator" label={t("modal.edit-comment.form.commentator")}>
          <Input disabled />
        </Form.Item>
        <Form.Item
          name="comment"
          label={t("modal.edit-comment.form.comments")}
          rules={[
            {
              required: true,
              message: t("modal.edit-comment.form.please-enter-comments"),
              whitespace: true,
            },
            {
              max: 2000,
              message: t("modal.edit-comment.form.comments-max-length"),
            },
          ]}
        >
          <Input.TextArea showCount maxLength={2000} rows={10} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default EditComment;
