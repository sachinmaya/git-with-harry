import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { QueryClient, useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { actions } from "~/api/constants";
import { ApiRequest, GetNewsLikesParams, LikeItem, DeleteNewsLikeParams, ChangeNewsLikeStatusParams } from "~/api/types";
import { useDashboardView } from "~/views/DashboardView";
import { Button, DatePicker, Form, Input, message, Select, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import Icon from "@ant-design/icons";
import { TableRowSelection } from "antd/es/table/interface";
import Text from "antd/lib/typography/Text";
import dayjs, { Dayjs } from "dayjs";
import { useLocation } from "react-router-dom";
import { FieldData } from "rc-field-form/lib/interface";
import { InternalServerError, NetworkError } from "~/api/errors";
import ConfirmModal from "./ConfirmModal";
import usePermissions from "~/hooks/usePermissions";
import SearchIcon from "~/components/icons/SearchIcon";
import DeleteIcon from "~/components/icons/DeleteIcon";
import datePickerRangeToTimestamp from "~/utils/datePickerRangeToTimestamp";

const initialParams: GetNewsLikesParams = {
  page_number: 1,
  show_number: 10,
  order_by: "start_time:desc",
  time_type: 0,
};

const getLikesListQuery = (request: ApiRequest, params: GetNewsLikesParams = initialParams) => ({
  queryKey: [actions.GET_NEWS_LIKES, params],
  queryFn: async () => request(actions.GET_NEWS_LIKES, params),
});

export const officialAccountLikeManagementViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getLikesListQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

interface FormValues {
  officialAccount: string;
  accountType: number;
  ip: string;
  postTopic: string;
  filterType: number;
  filterRange: null | Dayjs[];
  likedBy: string;
}

type ModalKey = "multiple-delete" | "delete-like" | "hide-like" | "un-hide-like";

enum like_status {
  un_hide = 1,
  hide = 2,
}
const OfficialAccountLikeManagementView: React.FC = () => {
  const { t, i18n } = useTranslation("like-management-view");
  const { t: tc } = useTranslation("common");
  const { setDashboardHeading } = useDashboardView();
  const { isActionAllowed } = usePermissions();
  const request = useRequest();
  const location = useLocation();
  const queryClient = useQueryClient();
  const [params, setParams] = useState<GetNewsLikesParams>(() => ({ ...initialParams, title: location.state?.title || "" }));
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [deleteSelection, setDeleteSelection] = useState<TableRowSelection<LikeItem> | undefined>(undefined);

  const [openModal, setOpenModal] = useState<{ open: boolean; key: ModalKey; articleID: number; userID: string }>({
    open: false,
    key: "multiple-delete",
    articleID: 0,
    userID: "",
  });

  const initialValues: FormValues = useMemo(
    () => ({
      officialAccount: "",
      accountType: 0,
      ip: "",
      postTopic: location.state?.title || "",
      filterType: 0,
      filterRange: null,
      likedBy: "",
    }),
    [location.state]
  );
  const hideLikeMutation = useMutation((params: ChangeNewsLikeStatusParams) => request(actions.CHANGE_NEWS_LIKE_STATUS, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_NEWS_LIKES]);
      message.open({
        key: "like-hide-successfully",
        type: "success",
        content: t("toasts.like-hide-success"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: tc("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: tc("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "like-hide-failed",
        type: "error",
        content: t("toasts.like-hide-failed"),
      });
    },
  });
  const unHideLikeMutation = useMutation((params: ChangeNewsLikeStatusParams) => request(actions.CHANGE_NEWS_LIKE_STATUS, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_NEWS_LIKES]);
      message.open({
        key: "like-hide-successfully",
        type: "success",
        content: t("toasts.like-un-hide-success"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: tc("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: tc("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "like-hide-failed",
        type: "error",
        content: t("toasts.like-un-hide-success"),
      });
    },
  });

  const deleteLikeMutation = useMutation((params: DeleteNewsLikeParams) => request(actions.DELETE_NEWS_LIKES, params), {
    onSuccess: () => {
      setOpenModal((state) => ({ ...state, open: false }));
      queryClient.invalidateQueries([actions.GET_NEWS_LIKES]);
      message.open({
        key: "delete-successfully",
        type: "success",
        content: t("toasts.delete-successfully"),
      });
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: tc("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: tc("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "like-hide-failed",
        type: "error",
        content: t("toasts.delete-failed"),
      });
    },
  });

  const { data, refetch, isPreviousData } = useQuery({
    ...getLikesListQuery(request, params),
    keepPreviousData: true,
    onSuccess: () => {
      setSearchLoading(false);
    },
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "delete-user-failed",
        type: "error",
        content: t("toasts.likes-list-query-failed"),
      });
    },
  });
  useEffect(() => {
    setDashboardHeading("official-account", "official-account-like-management");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);

  const columns: ColumnsType<LikeItem> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        width: 80,
        render: (value, record, index) => (params.page_number - 1) * params.show_number + (index + 1),
      },
      {
        key: "account",
        dataIndex: "official_name",
        width: 160,
        title: t("columns.account"),
        render: (value) => value || "-",
      },
      {
        key: "account_type",
        width: 160,
        dataIndex: "official_type",
        title: t("columns.account-type"),
        render: (value) => (
          <>
            {value === 1 && t("form.account-type.options.personal")}
            {value === 2 && t("form.account-type.options.business")}
          </>
        ),
      },
      {
        key: "post",
        width: 200,
        dataIndex: "article_title",
        title: t("columns.post"),
        render: (value) => (
          <Text
            style={{ width: 180 }}
            ellipsis={{
              tooltip: value,
            }}
          >
            {value === "" ? "-" : value}
          </Text>
        ),
      },
      {
        key: "liked_by",
        width: 160,
        dataIndex: "user_id",
        title: t("columns.liked-by"),
        render: (value) => (value === "" ? "-" : <span>{value}</span>),
      },
      {
        key: "post_time",
        width: 160,
        dataIndex: "post_time",
        title: t("columns.post-time"),
        render: (value) => (value === 0 || value === undefined ? "-" : dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss")),
      },
      {
        key: "like_time",
        width: 160,
        dataIndex: "create_time",
        title: t("columns.like-time"),
        render: (value) => (value === 0 || value === undefined ? "-" : dayjs(value * 1000).format("YYYY/MM/DD HH:mm:ss")),
      },
      {
        key: "ip",
        width: 160,
        dataIndex: "last_login_ip",
        title: t("columns.last-login-ip"),
        render: (value) => value,
      },
      {
        key: "operations",
        width: 160,
        title: t("columns.operations"),
        fixed: "right",
        render: (record) => {
          return (
            <>
              {isActionAllowed(actions.CHANGE_NEWS_LIKE_STATUS) && record.status === 1 && (
                <Button className="optionBtn optionBtnSuccess" onClick={() => setOpenModal({ open: true, articleID: record.article_id, userID: record.user_id, key: "hide-like" })}>
                  {t("form.buttons.hide")}
                </Button>
              )}
              {isActionAllowed(actions.CHANGE_NEWS_LIKE_STATUS) && record.status === 2 && (
                <Button
                  className="optionBtn"
                  type="primary"
                  ghost
                  onClick={() => setOpenModal({ open: true, articleID: record.article_id, userID: record.user_id, key: "un-hide-like" })}
                >
                  {t("form.buttons.un-hide")}
                </Button>
              )}
              {isActionAllowed(actions.DELETE_NEWS_LIKES) && (
                <Button
                  className="optionBtn optionBtnDanger"
                  onClick={() => setOpenModal({ open: true, articleID: record.article_id, userID: record.user_id, key: "delete-like" })}
                >
                  {t("form.buttons.delete")}
                </Button>
              )}
            </>
          );
        },
      },
    ],
    [t]
  );
  const handleMultipleDeleteClick = useCallback(
    () =>
      setDeleteSelection({
        columnWidth: 50,
        selectedRowKeys: [],
        onChange: (selectedRowKeys) => {
          if (selectedRowKeys.length > 100) {
            message.open({
              key: "max-multiple-delete",
              type: "info",
              content: t("toasts.max-multiple-delete", { count: 100 }),
            });
          }
          console.log("selected rows", selectedRowKeys);
          setDeleteSelection((state) => ({ ...state, selectedRowKeys: selectedRowKeys.slice(0, 100) }));
        },
      }),
    [t, setDeleteSelection]
  );

  const handleMultipleDeleteCancelClick = useCallback(() => setDeleteSelection(undefined), [setDeleteSelection]);

  const handlePaginationChange = useCallback(
    (page_number: number, show_number: number) =>
      setParams((state) => ({
        ...state,
        page_number,
        show_number,
      })),
    [setParams]
  );

  const handleFinnish = useCallback(
    ({ filterRange, officialAccount, accountType, likedBy, ip, postTopic, filterType }: FormValues) => {
      setParams(({ show_number, order_by }) => {
        const state: GetNewsLikesParams = { page_number: 1, show_number, order_by, time_type: 0 };
        if (officialAccount !== "") {
          state.official_account = officialAccount.trim();
        }
        if (accountType !== 0) {
          state.account_type = accountType;
        }
        if (likedBy !== "") {
          state.like_user = likedBy.trim();
        }
        if (ip !== "") {
          state.ip = ip.trim();
        }
        if (postTopic !== "") {
          state.title = postTopic.trim();
        }
        if (filterType !== 0) {
          state.time_type = filterType;
        }
        if (filterRange !== null) {
          const [startTime, endTime] = datePickerRangeToTimestamp(filterRange);
          state.start_time = startTime;
          state.end_time = endTime;
        }

        return state;
      });
      setSearchLoading(true);
    },
    [setParams, refetch]
  );

  const handleFieldsChange = useCallback(([fieldData]: FieldData[]) => {
    const { name, value } = fieldData;
  }, []);
  const handleModalCancel = useCallback(() => setOpenModal((state) => ({ ...state, open: false })), [setOpenModal]);
  const handleModalOk = useCallback(() => {
    switch (openModal.key) {
      case "hide-like":
        hideLikeMutation.mutate({ article_id: openModal.articleID, status: like_status.hide, user_id: openModal.userID });
        return;
      case "un-hide-like":
        unHideLikeMutation.mutate({ article_id: openModal.articleID, status: like_status.un_hide, user_id: openModal.userID });
        return;
      case "delete-like":
        deleteLikeMutation.mutate({ articles: [openModal.articleID], user_ids: [openModal.userID] });
        return;
      case "multiple-delete":
        if (openModal.key === "multiple-delete" && deleteSelection !== undefined && deleteSelection.selectedRowKeys !== undefined) {
          deleteLikeMutation.mutate({
            user_ids: deleteSelection.selectedRowKeys.map((item: any) => item.split("-")[1]),
            articles: deleteSelection.selectedRowKeys.map((item: any) => Number(item.split("-")[0])),
          });
        }
        return;
    }
  }, [hideLikeMutation.mutate, openModal, unHideLikeMutation.mutate]);

  return (
    <>
      <Form className="filterForm" layout="inline" initialValues={initialValues} onFinish={handleFinnish} onFieldsChange={handleFieldsChange}>
        <Form.Item name="officialAccount" label={t("form.official-account")}>
          <Input style={{ width: 118 }} />
        </Form.Item>
        <Form.Item name="accountType" label={t("form.account-type.label")}>
          <Select
            style={{ width: 118 }}
            options={(["all", "personal", "business"] as const).map((key, value) => ({
              value,
              label: t(`form.account-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="ip" label={t("form.ip")}>
          <Input style={{ width: 118 }} />
        </Form.Item>
        <Form.Item name="postTopic" label={t("form.post-topic")}>
          <Input style={{ width: 178 }} />
        </Form.Item>
        <Form.Item name="filterType">
          <Select
            style={{ width: 115 }}
            options={(["all", "like-time", "post-time"] as const).map((key, value) => ({
              value,
              label: t(`form.filter-type.options.${key}`),
            }))}
          />
        </Form.Item>
        <Form.Item name="filterRange">
          <DatePicker.RangePicker style={{ width: 215 }} disabledDate={(date) => date.isAfter(dayjs())} />
        </Form.Item>
        <Form.Item name="likedBy" label={t("form.liked-by")}>
          <Input style={{ width: 174 }} />
        </Form.Item>
        <Form.Item>
          <Button className="filterBtn filterBtnInfo" type="primary" htmlType="submit" loading={searchLoading} icon={<Icon component={SearchIcon} />}>
            {t("form.buttons.search")}
          </Button>
        </Form.Item>
        {deleteSelection !== undefined && (
          <>
            <Form.Item>
              <Button htmlType="button" className="filterBtn filterBtnPlain" onClick={handleMultipleDeleteCancelClick}>
                {t("modals.multiple-delete.buttons.cancel")}
              </Button>
            </Form.Item>

            <Form.Item>
              <Button
                type="primary"
                htmlType="button"
                className="filterBtn filterBtnDanger"
                danger
                onClick={() => setOpenModal({ open: true, key: "multiple-delete", articleID: 0, userID: "" })}
                disabled={deleteSelection.selectedRowKeys === undefined || deleteSelection.selectedRowKeys.length === 0}
              >
                {t("form.buttons.delete")}
              </Button>
            </Form.Item>
          </>
        )}
        {isActionAllowed(actions.DELETE_NEWS_LIKES) && deleteSelection === undefined && (
          <Form.Item>
            <Button className="filterBtn filterBtnDanger" type="primary" htmlType="button" icon={<Icon component={DeleteIcon} />} onClick={handleMultipleDeleteClick}>
              {t("form.buttons.multiple-delete")}
            </Button>
          </Form.Item>
        )}
      </Form>
      <Table
        rowKey={(record) => `${record.article_id}-${record.user_id}`}
        className="customTable"
        dataSource={data?.data.likes}
        columns={columns}
        scroll={{ x: 640 }}
        loading={isPreviousData || searchLoading}
        rowSelection={deleteSelection}
        pagination={{
          current: data?.data.current_number,
          total: data?.data.likes_nums,
          onChange: handlePaginationChange,
          pageSizeOptions: [10, 20, 50, 100, 1000],
          showQuickJumper: true,
          showTotal: (total) => tc("pagination.show-total-text", { total }),
        }}
      />
      <ConfirmModal
        open={openModal.open}
        type={openModal.key}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        confirmLoading={hideLikeMutation.isLoading || unHideLikeMutation.isLoading}
      />
    </>
  );
};

export default OfficialAccountLikeManagementView;
