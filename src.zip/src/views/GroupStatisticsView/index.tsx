import { QueryClient, useQuery } from "@tanstack/react-query";
import { Empty, message, Table, Tabs, TabsProps } from "antd";
import dayjs from "dayjs";
import { FC, useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { actions } from "~/api/constants";
import { InternalServerError, NetworkError } from "~/api/errors";
import { ActiveGroupStatistics, ApiRequest, GetStatisticsParams } from "~/api/types";
import StatisticsAreaChart from "~/components/Statistics/StatisticsAreaChart";
import StatisticsCard from "~/components/Statistics/StatisticsCard";
import TabBarExtraContent, { tabRightButtonType } from "~/components/Statistics/TabBarExtraContent";
import usePermissions from "~/hooks/usePermissions";
import useRequest from "~/hooks/useRequest";
import { useDashboardView } from "../DashboardView";
import Group from "./icons/Groups";
import Page from "./icons/Page";
import Text from "antd/lib/typography/Text";
import { ColumnsType } from "antd/es/table";
import monthOrWeekRange from "~/utils/monthOrWeekRange";
import yearRange from "~/utils/yearRange";

interface GroupStatisticsViewProps {}

const today = dayjs(new Date());

const initialParams: GetStatisticsParams = {
  from: dayjs(today).startOf("week").format("YYYY-MM-DD"),
  to: dayjs(today).endOf("week").format("YYYY-MM-DD"),
};

const getGroupStatisticsQuery = (request: ApiRequest, params: GetStatisticsParams = initialParams) => ({
  queryKey: [actions.GET_GROUP_STATISTICS, params],
  queryFn: async () => request(actions.GET_GROUP_STATISTICS, params),
});

export const groupStaticsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getGroupStatisticsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};

const getActiveGroupStatisticsQuery = (request: ApiRequest, params: GetStatisticsParams = initialParams) => ({
  queryKey: [actions.GET_ACTIVE_GROUP_STATISTICS, params],
  queryFn: async () => request(actions.GET_ACTIVE_GROUP_STATISTICS, params),
});

export const activeGroupStaticsViewLoader = (queryClient: QueryClient, request: ApiRequest) => async () => {
  const query = getActiveGroupStatisticsQuery(request);
  return queryClient.getQueryData(query.queryKey) ?? (await queryClient.fetchQuery(query));
};
const GroupStatisticsView: FC<GroupStatisticsViewProps> = () => {
  const { t } = useTranslation("group-statistics-view");
  const [params, setParams] = useState<GetStatisticsParams>(initialParams);
  const { setDashboardHeading } = useDashboardView();
  const { isActionAllowed } = usePermissions();
  const request = useRequest();
  const { data: groupStat, refetch } = useQuery({
    ...getGroupStatisticsQuery(request, params),
    keepPreviousData: true,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "group-statistics-query-failed",
        type: "error",
        content: t("toasts.group-statistics-query-failed"),
      });
    },
  });
  const { data: activegroupStat } = useQuery({
    ...getActiveGroupStatisticsQuery(request, params),
    keepPreviousData: true,
    onError: (error) => {
      if (error instanceof NetworkError) {
        return message.open({
          key: "network-error",
          type: "error",
          content: t("errors.network-error.message"),
        });
      }
      if (error instanceof InternalServerError) {
        return message.open({
          key: "internal-server-error",
          type: "error",
          content: t("errors.internal-server-error.message"),
        });
      }
      message.open({
        key: "active-group-statistics-query-failed",
        type: "error",
        content: t("toasts.active-group-statistics-query-failed"),
      });
    },
  });
  const newGroupGraphData = useMemo(() => {
    if (groupStat) {
      return groupStat.data.increase_group_num_list.map((item) => {
        return {
          date: dayjs(item.date).format("DD/MM/YYYY"),
          value: item.increase_group_num,
        };
      });
    }
    return [];
  }, [groupStat?.data.increase_group_num_list]);
  const totalGroupGraphData = useMemo(() => {
    if (groupStat) {
      return groupStat.data.total_group_num_list.map((item) => {
        return {
          date: dayjs(item.date).format("DD/MM/YYYY"),
          value: item.total_group_num,
        };
      });
    }
    return [];
  }, [groupStat?.data.total_group_num_list]);
  useEffect(() => {
    setDashboardHeading("statistics", "group-statistics");
    return () => setDashboardHeading(null, null);
  }, [setDashboardHeading]);
  if (!isActionAllowed(actions.GET_GROUP_STATISTICS) && !isActionAllowed(actions.GET_ACTIVE_GROUP_STATISTICS)) {
    return <Empty description={false} />;
  }
  const items: TabsProps["items"] = [
    {
      key: "1",
      label: t("chart.tabs.new"),
      children: <StatisticsAreaChart data={newGroupGraphData} text={t("chart.fields.groups")} />,
    },
    {
      key: "3",
      label: t("chart.tabs.cumulative"),
      children: <StatisticsAreaChart data={totalGroupGraphData} text={t("chart.fields.groups")} />,
    },
  ];
  const handleRefetch = useCallback((from: string, to: string) => {
    setParams({ from: from, to: to });
    return refetch();
  }, []);

  const handleTabBtns = (value: tabRightButtonType) => {
    switch (value) {
      case "day":
        let day = today.format("YYYY-MM-DD");
        return handleRefetch(day, day);
      case "week":
      case "month":
        const [from, to] = monthOrWeekRange(value);
        return handleRefetch(from, to);
      case "year":
        const [yearFrom, yearTo] = yearRange();
        return handleRefetch(yearFrom, yearTo);
      default:
        return;
    }
  };
  const findeIndex = (record: ActiveGroupStatistics, index: number) => {
    if (activegroupStat && activegroupStat?.data.active_group_list !== null) {
      let serilNo = activegroupStat.data.active_group_list.indexOf(record) + 1;
      return serilNo;
    }
    return index + 1;
  };
  const columns: ColumnsType<ActiveGroupStatistics> = useMemo(
    () => [
      {
        key: "no",
        title: t("columns.no"),
        render: (value, record, index) => findeIndex(record, index),
      },
      {
        key: "group_name",
        dataIndex: "group_name",
        title: t("columns.name"),
        render: (text) => (
          <Text style={{ width: 150 }} ellipsis={{ tooltip: text }}>
            {text}
          </Text>
        ),
      },
      {
        key: "group_id",
        dataIndex: "group_id",
        title: t("columns.id"),
        render: (text) => (text.length === 11 ? text.slice(0, 3) + "***" + text.slice(-3) : text),
      },
      {
        key: "message_num",
        dataIndex: "message_num",
        title: t("columns.messages"),
      },
    ],
    [t, activegroupStat]
  );

  return (
    <>
      {isActionAllowed(actions.GET_GROUP_STATISTICS) && (
        <>
          <div className="statisticsCardContainer">
            <StatisticsCard title={t("new-groups")} count={groupStat?.data.increase_group_num} icon={<Group />} />
            <StatisticsCard title={t("active-groups")} count={groupStat?.data.total_group_num} icon={<Page />} />
          </div>
          <Tabs defaultActiveKey="1" items={items} size="small" className="tab" tabBarExtraContent={<TabBarExtraContent changeParams={handleTabBtns} search={handleRefetch} />} />
        </>
      )}
      {isActionAllowed(actions.GET_ACTIVE_GROUP_STATISTICS) && (
        <>
          <div className="statiTableTitle">{t("active-groups")}</div>
          <div className="statisticsCardLayout statiTable">
            <Table
              dataSource={activegroupStat?.data.active_group_list === null ? [] : activegroupStat?.data.active_group_list.slice(0, 10) || []}
              bordered
              columns={columns}
              size="small"
              pagination={false}
            />
            <Table
              dataSource={activegroupStat?.data.active_group_list === null ? [] : activegroupStat?.data.active_group_list.slice(10) || []}
              bordered
              columns={columns}
              size="small"
              pagination={false}
            />
          </div>
        </>
      )}
    </>
  );
};

export default GroupStatisticsView;
