import i18next from "i18next";
import { initReactI18next } from "react-i18next";
import { getUserLocales } from "get-user-locale";
import { match } from "@formatjs/intl-localematcher";
import HttpBackend from "i18next-http-backend";

export type Language = "en-US" | "zh-CN";
export const i18nextLocaleStorageKey = "i18nextLng";
const lookupLocalStorage = localStorage.getItem(i18nextLocaleStorageKey);
const fallbackLocale: Language = "en-US";
export const supportedLocales: Language[] = ["en-US", "zh-CN"];
export const systemDefaultLocale = match(getUserLocales({ useFallbackLocale: false }), supportedLocales, fallbackLocale);

i18next
  .use(initReactI18next)
  .use(HttpBackend)
  .init({
    lng: lookupLocalStorage || systemDefaultLocale,
    fallbackLng: fallbackLocale,
    supportedLngs: supportedLocales,
    load: "currentOnly",
    fallbackNS: "common",
    defaultNS: "common",
    ns: [
      "login",
      "dashboard-view",
      "user-list-view",
      "linked-accounts-view",
      "group-management-view",
      "group-details-management-view",
      "game-management-view",
      "category-management-view",
      "woom-management-view",
      "woom-likes-view",
      "woom-comments-view",
      "woom-comments-reply-view",
      "woom-comments-like-view",
      "deleted-accounts-view",
      "user-select-modal",
      "user-pick-modal",
      "me-page-deposit-view",
      "me-page-withdraw-view",
      "me-page-exchange-view",
      "me-page-market-view",
      "me-page-earn-view",
      "me-page-otc-view",
      "app-update-view",
      "official-account-view",
      "share-mangement-view",
      "like-mangement-view",
      "moments-view",
      "moments-layout",
      "moments-comments-view",
      "moments-likes-view",
      "moments-posts-view",
      "group-management-view",
      "user-statistics-view",
      "group-statistics-view",
      "message-statistics-view",
      "game-statistics-view",
      "common",
    ],
    interpolation: {
      escapeValue: false,
    },
  });

export default i18next;
