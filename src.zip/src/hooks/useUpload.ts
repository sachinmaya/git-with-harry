import { useAuth } from "~/hooks/useAuth";
import { useMemo } from "react";
import Api from "~/api";
import { API_BASE_URL } from "~/config/constants";

const useUpload = () => {
  const { value, logOut } = useAuth();
  return useMemo(() => new Api({ baseURL: API_BASE_URL, token: value?.token, onTokenInvalidated: logOut }).upload, [value]);
};

export default useUpload;
