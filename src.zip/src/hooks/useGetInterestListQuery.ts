import { QueryKey, useQuery, UseQueryOptions } from "@tanstack/react-query";
import { actions } from "~/api/constants";
import { ApiRequest, GetInerestListParams, GetInterestListResponse } from "~/api/types";

type Options = Omit<UseQueryOptions<unknown, GetInterestListResponse, GetInterestListResponse, ["getInterestList", QueryKey[1]]>, "queryKey" | "queryFn">;

const useGetInterestListQuery = (params: GetInerestListParams, request: ApiRequest, options?: Options) =>
  useQuery({
    queryKey: ["getInterestList", params],
    queryFn: async () => request(actions.GET_INTEREST_LIST, params),
    keepPreviousData: true,
    ...options,
  });

export default useGetInterestListQuery;
