import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useLocalStorage } from "react-use";

interface AuthState {
  token: string;
  username: string;
}

interface AuthContext {
  state: AuthState | undefined;
  setState: (value: AuthState) => void;
  remove: () => void;
}

const authContext = createContext<AuthContext>({ state: undefined, setState: () => null, remove: () => null });

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState, remove] = useLocalStorage<AuthState>("auth");
  return <authContext.Provider value={{ state, setState, remove }}>{children}</authContext.Provider>;
};

export const useAuth = () => {
  const { state, setState, remove } = useContext(authContext);
  const isLoggedIn = useMemo(() => state !== undefined, [state]);
  const setAuth = useCallback((value: AuthState) => setState(value), [setState]);
  return { value: state, isLoggedIn, setAuth, logOut: remove };
};
