import { useAuth } from "~/hooks/useAuth";
import { useMemo } from "react";
import Api from "~/api";
import { API_BASE_URL } from "~/config/constants";

const useRequest = () => {
  const { value, logOut } = useAuth();
  return useMemo(() => new Api({ baseURL: API_BASE_URL, token: value?.token, onTokenInvalidated: logOut }).request, [value]);
};

export default useRequest;
