import { useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import useRequest from "~/hooks/useRequest";
import { Action, actions, action } from "~/api/constants";
import { PermissionsPageItem } from "~/api/types";

const pageTreeHavePath: (pages: PermissionsPageItem[], pagePath: string) => boolean = (pages, pagePath) =>
  pages.some((item) => item.pagePath === pagePath || (item.childs !== null && pageTreeHavePath(item.childs, pagePath)));

const usePermissions = () => {
  const request = useRequest();
  const { isSuccess, data } = useQuery([actions.PERMISSIONS], {
    queryFn: () => request(actions.PERMISSIONS),
    staleTime: 1000 * 60 * 60,
    suspense: true,
  });

  const isActionAllowed = useCallback(
    (actionKey: Action) => {
      if (isSuccess) {
        return data.data.adminRole.allowedApis.some(({ apiPath }) => apiPath === action[actionKey].url);
      }
      return false;
    },
    [isSuccess, data]
  );

  const isPageAllowed = useCallback(
    (pagePath: string) => {
      if (isSuccess) {
        return pageTreeHavePath(data.data.adminRole.allowedPages, pagePath);
      }
      return false;
    },
    [isSuccess, data]
  );

  return { isActionAllowed, isPageAllowed };
};

export default usePermissions;
