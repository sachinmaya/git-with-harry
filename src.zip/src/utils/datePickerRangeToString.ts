import {Dayjs} from "dayjs";

const datePickerRangeToString: (range: Dayjs[]) => string[] = (range) => {
    const [startDate, endDate] = range;
    return [
        startDate.startOf("day").format("YYYY-MM-DD HH:mm:ss"),
        endDate.endOf("day").format("YYYY-MM-DD HH:mm:ss")
    ];
};

export default datePickerRangeToString;
