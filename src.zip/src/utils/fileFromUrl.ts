import { v4 as uuid } from "uuid";
import mime from "mime";

const fileFromUrl = async (src: string, filename?: string) => {
  return fetch(src)
    .then((res) => res.blob())
    .then((blob) => new File([blob], `${filename || uuid()}.${mime.getExtension(blob.type)}`));
};

export default fileFromUrl;
