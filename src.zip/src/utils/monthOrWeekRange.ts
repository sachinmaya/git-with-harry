import dayjs from "dayjs";

const monthOrWeekRange = (text: "week" | "month") => {
  const today = dayjs(new Date());
  let from = dayjs(today).startOf(text).format("YYYY-MM-DD");
  let to = dayjs(today).endOf(text).format("YYYY-MM-DD");
  return [from, to];
};

export default monthOrWeekRange;
