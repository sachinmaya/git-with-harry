import dayjs from "dayjs";

const yearRange = () => {
  const today = dayjs(new Date());
  let thisyear = Number(dayjs().year());
  let yearTo = dayjs()
    .year(thisyear + 1)
    .startOf("year")
    .format("YYYY-MM-DD");
  return [dayjs(today).startOf("year").format("YYYY-MM-DD"), yearTo];
};

export default yearRange;
