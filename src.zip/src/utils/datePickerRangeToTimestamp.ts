import {Dayjs} from "dayjs";

const datePickerRangeToTimestamp: (range: Dayjs[]) => number[] = (range) => {
    const [startDate, endDate] = range;
    return [
        startDate.startOf("day").unix(),
        endDate.endOf("day").unix()
    ];
};

export default datePickerRangeToTimestamp;
