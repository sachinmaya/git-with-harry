import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "~/hooks/useAuth";

const withNoAuthRequired = <T extends object>(Component: React.ComponentType<T>) => {
  const displayName = Component.displayName || Component.name || "Component";
  const ComponentWithAuthRequired = (props: T) => {
    const { isLoggedIn } = useAuth();
    if (isLoggedIn) {
      return <Navigate to="/" replace />;
    }
    return <Component {...(props as T)} />;
  };
  ComponentWithAuthRequired.displayName = `withAuthRequired(${displayName})`;
  return ComponentWithAuthRequired;
};
export default withNoAuthRequired;
