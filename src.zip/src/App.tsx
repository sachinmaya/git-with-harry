import { Suspense } from "react";
import { ConfigProvider } from "antd";
import { RouterProvider } from "react-router-dom";
import { useTranslation, I18nextProvider } from "react-i18next";
import { QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Helmet, HelmetProvider } from "react-helmet-async";
import enUS from "antd/locale/en_US";
import zhCN from "antd/locale/zh_CN";
import i18next from "~/lib/i18next";
import queryClient from "~/lib/queryClient";
import { createRouter } from "~/router";
import { AuthProvider } from "~/hooks/useAuth";
import useRequest from "~/hooks/useRequest";

const RouterApp = () => {
  const queryClient = useQueryClient();
  const request = useRequest();
  return <RouterProvider router={createRouter(queryClient, request)} />;
}

const LocalizedApp = () => {
  const { t, i18n } = useTranslation();
  return (
    <ConfigProvider locale={i18n.language === "zh-CN" ? zhCN : enUS}>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <Helmet titleTemplate={t("meta.title-template")} />
          <Suspense>
            <RouterApp />
          </Suspense>
        </AuthProvider>
      </QueryClientProvider>
    </ConfigProvider>
  );
};

const App = () => {
  return (
    <HelmetProvider>
      <I18nextProvider i18n={i18next}>
        <LocalizedApp />
      </I18nextProvider>
    </HelmetProvider>
  );
};

export default App;
