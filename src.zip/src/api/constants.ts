export const errorCode = {
  NONE: 0,
  TOKEN_INVALIDATED_ERROR: 702,
  INVALID_TOTP_ERROR: 10004,
  ID_NOT_EXIST: 802,
  USER_ID_EXISTS: 821,
  INVITE_CODE_INVALID: 1906,
  PHONE_NUMBER_EXISTS: 1903,
} as const;

export type ErrorCode = (typeof errorCode)[keyof typeof errorCode];

export const actions = {
  ADMIN_LOGIN: "ADMIN_LOGIN",
  PERMISSIONS: "PERMISSIONS",
  GET_USERS: "GET_USERS",
  WOOMMANAGE_GETVIDEOLIST: "WOOMMANAGE_GETVIDEOLIST",
  WOOMMANAGE_EDITVIDEO: "WOOMMANAGE_EDITVIDEO",
  WOOMMANAGE_DELETEVIDEO: "WOOMMANAGE_DELETEVIDEO",
  GAMEMANAGE_GETGAMELIST: "GAMEMANAGE_GETGAMELIST",
  GAMEMANAGE_ADDGAMELIST: "GAMEMANAGE_ADDGAMELIST",
  GAMEMANAGE_EDITGAMELIST: "GAMEMANAGE_EDITGAMELIST",
  GAMEMANAGE_DELETEGAMELIST: "GAMEMANAGE_DELETEGAMELIST",
  CATEGORYMANAGE_GETCATEGORY: "CATEGORYMANAGE_GETCATEGORY",
  CATEGORYMANAGE_ADDCATEGORY: "CATEGORYMANAGE_ADDCATEGORY",
  CATEGORYMANAGE_EDITCATEGORY: "CATEGORYMANAGE_EDITCATEGORY",
  CATEGORYMANAGE_SETSTATE: "CATEGORYMANAGE_SETSTATE",
  CATEGORYMANAGE_DELETECATEGORY: "CATEGORYMANAGE_DELETECATEGORY",
  GET_OFFICIAL_ACCOUNTS: "GET_OFFICIAL_ACCOUNTS",
  PROCESS_OFFICIAL_ACCOUNT: "PROCESS_OFFICIAL_ACCOUNT",
  GET_INTEREST_LIST: "GET_INTEREST_LIST",
  DELETE_OFFICIAL_ACCOUNT: "DELETE_OFFICIAL_ACCOUNT",
  REGISTER_OFFICIAL_ACCOUNT: "REGISTER_OFFICIAL_ACCOUNT",
  ALTER_OFFICIAL_ACCOUNT: "ALTER_OFFICIAL_ACCOUNT",
  GET_NEWS_LIKES: "GET_NEWS_LIKES",
  CHANGE_NEWS_LIKE_STATUS: "CHANGE_NEWS_LIKE_STATUS",
  DELETE_NEWS_LIKES: "DELETE_NEWS_LIKES",
  GET_SHARE_LIST: "GET_SHARE_LIST",
  DELETE_SHARE: "DLETE_SHARE",
  CHANGE_SHARE_PRIVACY: "CHANGE_SHARE_PRIVACY",
  GET_NEWS_COMMENTS: "GET_NEWS_COMMENTS",
  DELETE_NEWS_COMMENTS: "DELETE_NEWS_COMMENTS",
  CHANGE_NEWS_COMMENT_STATUS: "CHANGE_NEWS_COMMENT_STATUS",
  ALTER_NEWS_COMMENT: "ALTER_NEWS_COMMENT",
  GET_NEWS_LIST: "GET_NEWS_LIST",
  CHANGE_NEWS_PRIVACY: "CHANGE_NEWS_PRIVACY",
  DELETE_NEWS: "DELETE_NEWS",
  ALTER_NEWS: "ALTER_NEWS",
  DELETE_USERS: "DELETE_USERS",
  SWITCH_STATUS: "SWITCH_STATUS",
  GET_USERS_THIRD_INFO: "GET_USERS_THIRD_INFO",
  GET_USER_INTERESTS: "GET_USER_INTERESTS",
  ADD_USER: "ADD_USER",
  ALTER_USER: "ALTER_USER",
  GET_MOMENTS: "GET_MOMENTS",
  DELETE_MOMENTS: "DELETE_MOMENTS",
  CHANGE_MOMENT_STATUS: "CHANGE_MOMENT_STATUS",
  ALTER_MOMENT: "ALTER_MOMENT",
  GET_MOMENT_DETAILS: "GET_MOMENT_DETAILS",
  SWITCH_MOMENT_COMMENT: "SWITCH_MOMENT_COMMENT",
  GET_MOMENT_COMMENT: "GET_MOMENT_COMMENT",
  REMOVE_MOMENT_COMMENT: "REMOVE_MOMENT_COMMENT",
  SWITCH_COMMENT_STATUS: "SWITCH_COMMENT_STATUS",
  ALTER_MOMENT_COMMENT: "ALTER_MOMENT_COMMENT",
  GET_MOMENT_LIKES: "GET_MOMENT_LIKES",
  REMOVE_MOMENTS_LIKES: "REMOVE_MOMENTS_LIKES",
  SWITCH_MOMENT_LIKES_STATUS: "SWITCH_MOMENT_LIKES_STATUS",
  GET_GROUPS: "GET_GROUPS",
  BAN_GROUP_CHAT: "BAN_GROUP_CHAT",
  OPEN_GROUP_CHAT: "OPEN_GROUP_CHAT",
  SET_VIDEO_AUDIO_STATUS: "SET_VIDEO_AUDIO_STATUS",
  DELETE_GROUP: "DELETE_GROUP",
  GET_GROUP_BY_ID: "GET_GROUP_BY_ID",
  GET_WOOM_LIKES: "GET_WOOM_LIKES",
  DELETE_WOOM_LIKES: "DELETE_WOOM_LIKES",
  GET_WOOM_COMMENTS: "GET_WOOM_COMMENTS",
  DELETE_WOOM_COMMENTS: "DELETE_WOOM_COMMENTS",
  EDIT_WOOM_COMMENTS: "EDIT_WOOM_COMMENTS",
  GET_WOOM_COMMENTS_REPLY: "GET_WOOM_COMMENTS_REPLY",
  DELETE_WOOM_COMMENTS_REPLY: "DELETE_WOOM_COMMENTS_REPLY",
  EDIT_WOOM_COMMENTS_REPLY: "EDIT_WOOM_COMMENTS_REPLY",
  GET_WOOM_COMMENTS_LIKE: "GET_WOOM_COMMENTS_LIKE",
  DELETE_WOOM_COMMENTS_LIKE: "DELETE_WOOM_COMMENTS_LIKE",
  EDIT_WOOM_COMMENTS_LIKE: "EDIT_WOOM_COMMENTS_LIKE",
  GET_INTERESTLIST: "GET_INTERESTLIST",
  GET_GROUP_MEMBERS: "GET_GROUP_MEMBERS",
  MUTE_GROUP_MEMBER: "MUTE_GROUP_MEMBER",
  CANCEL_MUTE_GROUP_MEMBER: "CANCEL_MUTE_GROUP_MEMBER",
  SET_GROUP_ADMIN: "SET_GROUP_ADMIN",
  SET_GROUP_ORDINARY_USER: "SET_GROUP_ORDINARY_USER",
  REMOVE_MEMBERS: "REMOVE_MEMBERS",
  ADD_MEMBERS: "ADD_MEMBERS",
  SET_GROUP_MASTER: "SET_GROUP_MASTER",
  ADMIN_VERIFY_TOTP: "ADMIN_VERIFY_TOTP",
  GET_DELETED_ACCOUNT: "GET_DELETED_ACCOUNT",
  GET_MEPAGE: "GET_MEPAGE",
  SWITCH_STATUS_MEPAGE:"SWITCH_STATUS_MEPAGE",
  SAVE_MEPAGE:"SAVE_MEPAGE",
  GET_DISCOVER:"GET_DISCOVER",
  SWITCH_STATUS_DISCOVER:"SWITCH_STATUS_DISCOVER",
  SAVE_DISCOVER:"SAVE_DISCOVER",
  GET_FAVORITES:"GET_FAVORITES",
  DELETE_FAVORITES:"DELETE_FAVORITES",
  EDIT_FAVORITES:"EDIT_FAVORITES",
  GET_BLACKLIST:"GET_BLACKLIST",
  DELETE_BLACKLIST:"DELETE_BLACKLIST",
  GET_APPUPDATE:"GET_APPUPDATE",
  ADD_APPUPDATE:"ADD_APPUPDATE",
  EDIT_APPUPDATE:"EDIT_APPUPDATE",
  DELETE_APPUPDATE:"DELETE_APPUPDATE",
  EDIT_BLACKLIST:"EDIT_BLACKLIST",
  GET_USER_STATISTICS: "GET_USER_STATISTICS",
  GET_ACTIVE_USER_STATISTICS: "GET_ACTIVE_USER_STATISTICS",
  GET_GROUP_STATISTICS: "GET_GROUP_STATISTICS",
  GET_ACTIVE_GROUP_STATISTICS: "GET_ACTIVE_GROUP_STATISTICS",
  GET_MESSAGE_STATISTICS: "GET_MESSAGE_STATISTICS",
  GET_GAME_STATISTICS: "GET_GAME_STATISTICS",
} as const;

export const action = {
  [actions.ADMIN_LOGIN]: {
    url: "/cms/admin/admin_login",
    method: "POST",
  },
  [actions.PERMISSIONS]: {
    url: "/cms/admin/permissions",
    method: "GET",
  },
  [actions.GET_USERS]: {
    url: "/cms/user/get_users",
    method: "GET",
  },
  [actions.WOOMMANAGE_GETVIDEOLIST]: {
    url: "/cms/short_video/get_short_video_list",
    method: "GET",
  },
  [actions.WOOMMANAGE_EDITVIDEO]: {
    url: "/cms/short_video/alter_short_video",
    method: "POST",
  },
  [actions.WOOMMANAGE_DELETEVIDEO]: {
    url: "/cms/short_video/delete_short_video",
    method: "POST",
  },
  [actions.GAMEMANAGE_GETGAMELIST]: {
    url: "/cms/game_store/get_game_list",
    method: "GET",
  },
  [actions.GAMEMANAGE_ADDGAMELIST]: {
    url: "/cms/game_store/add_game",
    method: "POST",
  },
  [actions.GAMEMANAGE_EDITGAMELIST]: {
    url: "/cms/game_store/edit_game",
    method: "POST",
  },
  [actions.GAMEMANAGE_DELETEGAMELIST]: {
    url: "/cms/game_store/delete_games",
    method: "POST",
  },
  [actions.CATEGORYMANAGE_GETCATEGORY]: {
    url: "/cms/game_store/get_category",
    method: "GET",
  },
  [actions.CATEGORYMANAGE_ADDCATEGORY]: {
    url: "/cms/game_store/add_category",
    method: "POST",
  },
  [actions.CATEGORYMANAGE_EDITCATEGORY]: {
    url: "/cms/game_store/edit_category",
    method: "POST",
  },
  [actions.CATEGORYMANAGE_SETSTATE]: {
    url: "/cms/game_store/set_category_status",
    method: "POST",
  },
  [actions.CATEGORYMANAGE_DELETECATEGORY]: {
    url: "/cms/game_store/delete_category",
    method: "POST",
  },
  [actions.GET_OFFICIAL_ACCOUNTS]: {
    url: "cms/news/get_official_accounts",
    method: "GET",
  },
  [actions.PROCESS_OFFICIAL_ACCOUNT]: {
    url: "cms/news/process",
    method: "POST",
  },
  [actions.GET_INTEREST_LIST]: {
    url: "cms/interest/get_interests",
    method: "GET",
  },
  [actions.DELETE_OFFICIAL_ACCOUNT]: {
    url: "/cms/news/delete_official_accounts",
    method: "POST",
  },
  [actions.ALTER_OFFICIAL_ACCOUNT]: {
    url: "/cms/news/alter_official_account",
    method: "POST",
  },
  [actions.REGISTER_OFFICIAL_ACCOUNT]: {
    url: "/cms/news/add_official_account",
    method: "POST",
  },
  [actions.GET_NEWS_LIKES]: {
    url: "/cms/news/get_news_likes",
    method: "GET",
  },
  [actions.CHANGE_NEWS_LIKE_STATUS]: {
    url: "/cms/news/change_news_like_status",
    method: "POST",
  },
  [actions.DELETE_NEWS_LIKES]: {
    url: "/cms/news/remove_news_likes",
    method: "POST",
  },
  [actions.GET_SHARE_LIST]: {
    url: "/cms/news/get_repost_articles",
    method: "GET",
  },
  [actions.DELETE_SHARE]: {
    url: "/cms/news/delete_reposts",
    method: "POST",
  },
  [actions.CHANGE_SHARE_PRIVACY]: {
    url: "/cms/news/change_repost_privacy",
    method: "POST",
  },
  [actions.GET_NEWS_COMMENTS]: {
    url: "/cms/news/get_news_comments",
    method: "GET",
  },
  [actions.DELETE_NEWS_COMMENTS]: {
    url: "/cms/news/remove_news_comments",
    method: "POST",
  },
  [actions.ALTER_NEWS_COMMENT]: {
    url: "/cms/news/alter_news_comment",
    method: "POST",
  },
  [actions.CHANGE_NEWS_COMMENT_STATUS]: {
    url: "/cms/news/change_news_comment_status",
    method: "POST",
  },
  [actions.GET_NEWS_LIST]: {
    url: "/cms/news/get_news",
    method: "GET",
  },
  [actions.ALTER_NEWS]: {
    url: "/cms/news/alter_news",
    method: "POST",
  },

  [actions.CHANGE_NEWS_PRIVACY]: {
    url: "/cms/news/change_privacy",
    method: "POST",
  },

  [actions.DELETE_NEWS]: {
    url: "/cms/news/delete_news",
    method: "POST",
  },
  [actions.DELETE_USERS]: {
    url: "/manager/delete_user",
    method: "POST",
  },
  [actions.SWITCH_STATUS]: {
    url: "/cms/user/switch_status",
    method: "POST",
  },
  [actions.GET_USERS_THIRD_INFO]: {
    url: "/cms/user/get_users_third_info",
    method: "GET",
  },
  [actions.GET_USER_INTERESTS]: {
    url: "/cms/interest/get_user_interests",
    method: "GET",
  },
  [actions.ADD_USER]: {
    url: "/cms/user/add_user",
    method: "POST",
  },
  [actions.ALTER_USER]: {
    url: "/cms/user/alter_user",
    method: "POST",
  },
  [actions.GET_MOMENTS]: {
    url: "/cms/moments/get_moments",
    method: "GET",
  },
  [actions.DELETE_MOMENTS]: {
    url: "/cms/moments/delete_moments",
    method: "POST",
  },
  [actions.CHANGE_MOMENT_STATUS]: {
    url: "/cms/moments/change_moment_status",
    method: "POST",
  },
  [actions.ALTER_MOMENT]: {
    url: "/cms/moments/alter_moment",
    method: "POST",
  },
  [actions.GET_MOMENT_DETAILS]: {
    url: "/cms/moments/get_moment_details",
    method: "GET",
  },
  [actions.SWITCH_MOMENT_COMMENT]: {
    url: "/cms/moments/ctl_comment",
    method: "POST",
  },
  [actions.GET_MOMENT_COMMENT]: {
    url: "/cms/moments/get_comments",
    method: "GET",
  },
  [actions.REMOVE_MOMENT_COMMENT]: {
    url: "/cms/moments/remove_comments",
    method: "POST",
  },
  [actions.SWITCH_COMMENT_STATUS]: {
    url: "/cms/moments/switch_comment_hide_state",
    method: "POST",
  },
  [actions.ALTER_MOMENT_COMMENT]: {
    url: "/cms/moments/alter_comment",
    method: "POST",
  },
  [actions.GET_MOMENT_LIKES]: {
    url: "/cms/moments/get_likes",
    method: "GET",
  },
  [actions.REMOVE_MOMENTS_LIKES]: {
    url: "/cms/moments/remove_likes",
    method: "POST",
  },
  [actions.SWITCH_MOMENT_LIKES_STATUS]: {
    url: "/cms/moments/switch_like_hide_state",
    method: "POST",
  },
  [actions.GET_GROUPS]: {
    url: "/cms/group/get_groups",
    method: "GET",
  },
  [actions.BAN_GROUP_CHAT]: {
    url: "/cms/group/ban_group_chat",
    method: "POST",
  },
  [actions.OPEN_GROUP_CHAT]: {
    url: "/cms/group/open_group_chat",
    method: "POST",
  },
  [actions.SET_VIDEO_AUDIO_STATUS]: {
    url: "/cms/group/set_video_audio_status",
    method: "POST",
  },
  [actions.DELETE_GROUP]: {
    url: "/cms/group/delete_group",
    method: "POST",
  },
  [actions.GET_GROUP_BY_ID]: {
    url: "/cms/group/get_group_by_id",
    method: "GET",
  },
  [actions.GET_GROUP_MEMBERS]: {
    url: "/cms/group/get_group_members",
    method: "GET",
  },
  [actions.MUTE_GROUP_MEMBER]: {
    url: "/cms/group/mute_group_member",
    method: "POST",
  },
  [actions.CANCEL_MUTE_GROUP_MEMBER]: {
    url: "/cms/group/cancel_mute_group_member",
    method: "POST",
  },
  [actions.SET_GROUP_ADMIN]: {
    url: "/cms/group/set_group_admin",
    method: "POST",
  },
  [actions.SET_GROUP_ORDINARY_USER]: {
    url: "/cms/group/set_group_ordinary_user",
    method: "POST",
  },
  [actions.REMOVE_MEMBERS]: {
    url: "/cms/group/remove_members",
    method: "POST",
  },
  [actions.ADD_MEMBERS]: {
    url: "/cms/group/add_members",
    method: "POST",
  },
  [actions.SET_GROUP_MASTER]: {
    url: "/cms/group/set_group_master",
    method: "POST",
  },
  [actions.ADMIN_VERIFY_TOTP]: {
    url: "/cms/admin/admin_verify_totp",
    method: "POST",
  },
  [actions.GET_WOOM_LIKES]: {
    url: "/cms/short_video/get_short_video_like_list",
    method: "GET",
  },
  [actions.DELETE_WOOM_LIKES]: {
    url: "/cms/short_video/delete_short_video_like",
    method: "POST",
  },
  [actions.GET_WOOM_COMMENTS]: {
    url: "/cms/short_video/get_short_video_comment_list",
    method: "GET",
  },
  [actions.DELETE_WOOM_COMMENTS]: {
    url: "/cms/short_video/delete_short_video_comment",
    method: "POST",
  },
  [actions.EDIT_WOOM_COMMENTS]: {
    url: "/cms/short_video/alter_short_video_comment",
    method: "POST",
  },
  [actions.GET_WOOM_COMMENTS_REPLY]: {
    url: "/cms/short_video/comment_replies",
    method: "GET",
  },
  [actions.DELETE_WOOM_COMMENTS_REPLY]: {
    url: "/cms/short_video/delete_replies",
    method: "POST",
  },
  [actions.EDIT_WOOM_COMMENTS_REPLY]: {
    url: "/cms/short_video/alter_reply",
    method: "POST",
  },
  [actions.GET_WOOM_COMMENTS_LIKE]: {
    url: "/cms/short_video/comment_likes",
    method: "GET",
  },
  [actions.DELETE_WOOM_COMMENTS_LIKE]: {
    url: "/cms/short_video/delete_likes",
    method: "POST",
  },
  [actions.EDIT_WOOM_COMMENTS_LIKE]: {
    url: "/cms/short_video/alter_like",
    method: "POST",
  },
  [actions.GET_INTERESTLIST]: {
    url: "/cms/interest/get_interests",
    method: "GET",
  },
  [actions.GET_DELETED_ACCOUNT]: {
    url: "/cms/user/get_deleted_users",
    method: "GET",
  },
  [actions.GET_MEPAGE]: {
    url: "/cms/me_page/get_url",
    method: "GET",
  },
  [actions.SWITCH_STATUS_MEPAGE]: {
    url: "/cms/me_page/switch_status",
    method: "POST",
  },
  [actions.SAVE_MEPAGE]: {
    url: "/cms/me_page/save_url",
    method: "POST",
  },
  [actions.GET_DISCOVER]: {
    url: "/cms/discover/get_discover",
    method: "POST",
  },
  [actions.SWITCH_STATUS_DISCOVER]: {
    url: "/cms/discover/switch_discover",
    method: "POST",
  },
  [actions.SAVE_DISCOVER]: {
    url: "/cms/discover/save_discover_url",
    method: "POST",
  },
  [actions.GET_FAVORITES]: {
    url: "/cms/favorites/get_favorites",
    method: "GET",
  },
  [actions.DELETE_FAVORITES]:{
    url: "/cms/favorites/delete_favorites",
    method: "POST",
  },
  [actions.EDIT_FAVORITES]:{
    url: "/cms/favorites/alter_favorites",
    method: "POST",
  },
  [actions.GET_BLACKLIST]: {
    url: "/cms/blacks/get_blacks",
    method: "GET",
  },
  [actions.DELETE_BLACKLIST]: {
    url: "/cms/blacks/remove_black",
    method: "POST",
  },
  [actions.EDIT_BLACKLIST]: {
    url: "/cms/blacks/alter_remark",
    method: "POST",
  },
  [actions.GET_APPUPDATE]: {
    url: "/cms/version/search",
    method: "POST",
  },
  [actions.ADD_APPUPDATE]: {
    url: "/cms/version/add",
    method: "POST",
  },
  [actions.EDIT_APPUPDATE]: {
    url: "/cms/version/edit",
    method: "POST",
  },
  [actions.DELETE_APPUPDATE]: {
    url: "/cms/version/remove",
    method: "POST",
  },
  [actions.GET_USER_STATISTICS]: {
    url: "/cms/statistics/get_user_statistics",
    method: "GET",
  },
  [actions.GET_ACTIVE_USER_STATISTICS]: {
    url: "/cms/statistics/get_active_user",
    method: "GET",
  },
  [actions.GET_GROUP_STATISTICS]: {
    url: "/cms/statistics/get_group_statistics",
    method: "GET",
  },
  [actions.GET_ACTIVE_GROUP_STATISTICS]: {
    url: "/cms/statistics/get_active_group",
    method: "GET",
  },
  [actions.GET_MESSAGE_STATISTICS]: {
    url: "/cms/statistics/get_messages_statistics",
    method: "GET",
  },
  [actions.GET_GAME_STATISTICS]: {
    url: "/cms/statistics/get_game_statistics",
    method: "GET",
  },
} as const;

export type Action = keyof typeof action;
