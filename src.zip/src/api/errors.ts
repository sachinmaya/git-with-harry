import { ApiResponse } from "./types";

export class NetworkError extends Error {
  constructor() {
    super("Network error");
  }
}

export class InternalServerError extends Error {
  constructor() {
    super("Internal Server error");
  }
}

export class ResponseError<T> extends Error {
  public readonly errCode: number;

  constructor(responseData: ApiResponse<T>) {
    super(responseData.errMsg);
    this.errCode = responseData.errCode;
  }
}
