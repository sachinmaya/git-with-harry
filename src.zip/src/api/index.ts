import _ from "lodash";
import { v4 as uuid } from "uuid";
import Axios, { AxiosError, AxiosInstance, AxiosResponse } from "axios";
import { Action, action, errorCode } from "./constants";
import { ApiConstructorParams, ApiRequest, ApiResponse } from "./types";
import { InternalServerError, NetworkError, ResponseError } from "./errors";

export enum UploadType {
  file = 1,
  video = 2,
  picture = 3,
}

export interface UploadParams {
  file: File;
  snapshot?: File;
  type: UploadType;
  persist: boolean;
  onProgress?: (progress: { percent: number }) => void;
  signal?: AbortSignal;
}

interface UploadResponse {
  URL: string;
  newName: string;
  snapshotURL?: string;
  snapshotName?: string;
  imageHeight: number;
  imageWidth: number;
}

const unifyResponseData = ({ code, errCode, err_msg, errMsg, data }: any) =>
  ({
    errCode: code ?? errCode,
    errMsg: err_msg ?? errMsg,
    data,
  } as ApiResponse<any>);

class Api {
  private readonly axios: AxiosInstance;
  private readonly token?: string;
  private readonly onTokenInvalidated?: () => void;

  constructor({ baseURL, token, onTokenInvalidated }: ApiConstructorParams) {
    this.axios = Axios.create({ baseURL });
    this.token = token;
    this.onTokenInvalidated = onTokenInvalidated;
  }

  public request: ApiRequest = async (key: Action, body?: any, headers: { [key: string]: string } = {}) => {
    const clonedBody = _.cloneDeep(body);
    const { method, url } = action[key];
    let response: AxiosResponse;
    if (typeof clonedBody === "object") {
      const oid = uuid();
      if (typeof clonedBody.OperationID === "undefined") {
        clonedBody.OperationID = oid;
      }
      if (typeof clonedBody.operation_id === "undefined") {
        clonedBody.operation_id = oid;
      }
      if (typeof body.operationID === "undefined") {
        body.operationID = oid;
      }
    }

    try {
      response = await this.axios.request({
        url,
        method,
        data: method === "POST" && clonedBody,
        params: method === "GET" && clonedBody,
        headers: {
          token: this.token,
          ...headers,
        },
      });
    } catch (error) {
      const { response } = error as AxiosError<any>;
      if (response !== undefined) {
        if (response.status >= 400 && response.status < 500) {
          const responseData = unifyResponseData(response.data);
          if (this.onTokenInvalidated !== undefined && responseData.errCode === errorCode.TOKEN_INVALIDATED_ERROR) {
            this.onTokenInvalidated();
          }
          throw new ResponseError(responseData);
        }
        if (response.status >= 500) {
          throw new InternalServerError();
        }
      }
      throw new NetworkError();
    }

    const responseData = unifyResponseData(response.data);
    if (this.onTokenInvalidated !== undefined && responseData.errCode === errorCode.TOKEN_INVALIDATED_ERROR) {
      this.onTokenInvalidated();
    }
    if (responseData.errCode !== errorCode.NONE) {
      throw new ResponseError(responseData);
    }

    return responseData;
  };

  public upload: (params: UploadParams) => Promise<UploadResponse> = async (params) => {
    const formData = new FormData();
    formData.append("file", params.file);
    //@ts-ignore
    formData.append("fileType", params.type);
    if (params.type === UploadType.video) {
      formData.append("snapShot", params.snapshot || "");
    }
    formData.append("operationID", uuid());
    let response: AxiosResponse;
    try {
      response = await this.axios.postForm(params.persist ? "/api/third/tencent_cloud_storage_upload_persistence" : "/api/third/tencent_cloud_storage_upload", formData, {
        headers: {
          token: this.token,
        },
        signal: params.signal,
        onUploadProgress: (progressEvent) => {
          if (params.onProgress) {
            const { loaded, total } = progressEvent;
            if (total) {
              params.onProgress({ percent: Math.round((loaded / total) * 100) });
            }
          }
        },
      });
    } catch (error) {
      const { response } = error as AxiosError<any>;
      if (response !== undefined) {
        if (response.status >= 400 && response.status < 500) {
          const responseData = unifyResponseData(response.data);
          if (this.onTokenInvalidated !== undefined && responseData.errCode === errorCode.TOKEN_INVALIDATED_ERROR) {
            this.onTokenInvalidated();
          }
          throw new ResponseError(responseData);
        }
        if (response.status >= 500) {
          throw new InternalServerError();
        }
      }
      throw new NetworkError();
    }
    const responseData = unifyResponseData(response.data);
    if (this.onTokenInvalidated !== undefined && responseData.errCode === errorCode.TOKEN_INVALIDATED_ERROR) {
      this.onTokenInvalidated();
    }
    if (responseData.errCode !== errorCode.NONE) {
      throw new ResponseError(responseData);
    }
    return responseData.data;
  };
}

export default Api;
