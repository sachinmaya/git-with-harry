import { actions, ErrorCode } from "./constants";

export interface ApiResponse<T> {
  errCode: ErrorCode;
  errMsg: string;
  data: T;
}

export interface ApiConstructorParams {
  baseURL: string;
  token?: string;
  onTokenInvalidated?: () => void;
}

export interface AdminLoginRequestParams {
  admin_name: string;
  secret: string;
}

export interface AdminLoginResponse {
  token: string;
  gAuthEnabled: boolean;
  gAuthSetupRequired: boolean;
  gAuthSetupProvUri: string;
}

export interface AdminVerifyTOTPRequestParams {
  totp: string;
}

export interface GetUsersRequestParams {
  page_number: number;
  show_number: number;
  order_by: string;
  start_time?: number;
  end_time?: number;
  user_id?: string;
  source_id?: number;
  code?: string;
  uuid?: string;
  update_ip?: string;
  type?: number;
  gender?: number;
  account_status?: string;
  remark?: string;
  last_login_device?: number;
}

export interface GetUsersItem {
  profile_photo: string;
  nick_name: string;
  user_id: string;
  create_time: number;
  is_block: boolean;
  status: number;
  source_id: string;
  source_code: string;
  update_ip: string;
  phone_number: string;
  address: string;
  last_login_time: number;
  email: string;
  uuid: string;
  last_login_device?: number;
  video_status: number;
  audio_status: number;
  gender: number;
  remark: string;
  login_ip: string;
}

export interface GetUsersResponse {
  current_number: number;
  show_number: number;
  user_nums: number;
  users: GetUsersItem[] | null;
}

export interface GetGameListRequestParams {
  page_number: number;
  show_number: number;
  operation_id: string;
  name_type?: string;
  game_code?: string;
  game_name?: string;
  category?: string;
  classification?: number;
  platform?: number;
  publisher?: string;
  hot?: number;
  state?: number;
  start_time?: number;
  end_time?: number;
}

export interface GetGameListItem {
  key: string;
  number: number;
  categories: { category: { id: string; cn: string; en: string } }[];
  classification?: string[];
  cover_img: string;
  create_time: number;
  description?: { cn: string; en: string };
  game_code: string;
  game_name: { cn: string; en: string };
  horizontal_cover: string[];
  hot: number;
  platform_link: {
    1?: {
      file_name?: string;
      package_url?: string;
      play_url?: string;
      size?: number;
      upload_time?: number;
    };
    2?: {
      file_name?: string;
      package_url?: string;
      play_url?: string;
      size?: number;
      upload_time?: number;
    };
    3?: {
      file_name?: string;
      package_url?: string;
      play_url?: string;
      size?: number;
      upload_time?: number;
    };
  };
  publisher: string;
  sort_priority: number;
  state: number;
}

export interface GetGameListResponse {
  current_number: number;
  show_number: number;
  game_num: number;
  game_list: GetGameListItem[];
}

export interface GetCategoriesRequestParams {
  page_number: number;
  show_number: number;
  operation_id: string;
  name_type?: string;
  category_name?: string;
  creator?: string;
  editor?: string;
  state?: number;
  create_start_time?: number;
  create_end_time?: number;
  edited_start_time?: number;
  edited_end_time?: number;
}

export interface GetCategoriesItem {
  categories: { cn: string; en: string };
  category_id: number;
  creator: string;
  editor: string;
  sort_priority: number;
  state: number;
  used_amount: number;
  create_time: number;
  edit_time: number;
}

export interface GetCategoriesResponse {
  current_number: number;
  show_number: number;
  categories_num: number;
  category_list: GetCategoriesItem[];
}

export interface setCategoryStateRequestParams {
  state: 1 | 2;
  category_id: number;
}

export type setCategoryStateResponse = null;

export interface deleteCategoryRequestParams {
  category_id: number;
}

export type deleteCategoryResponse = null;

export interface addCategoryRequestParams {
  category_name: { en?: string; cn?: string };
  sort_priority: number;
  state: number;
}

export type addCategoryResponse = null;

export interface editCategoryRequestParams {
  category_id: number;
  category_name: { en?: string; cn?: string };
  sort_priority: number;
  state: number;
}

export type editCategoryResponse = null;

export interface DeleteGamesRequestParams {
  games_code: string[];
}

export type DeleteGamesResponse = [];

//official account management
export interface GetOfficialAccountsRequestParams {
  page_number: number;
  show_number: number;
  order_by: string;
  process_status?: number;
  start_time?: number;
  end_time?: number;
  time_type?: number;
  tags_id?: string;
  official_account?: string;
  is_system?: number;
  id_type?: number;
  id_number?: string;
  account_type?: number;
  bio?: string;
}

export interface GetOfficialAccountItem {
  Interests: InterestItem[];
  bio: string;
  country_code: string;
  create_time: number;
  face_url: string;
  id: number;
  id_name: string;
  id_number: string;
  id_type: number;
  initial_nickname: string;
  is_system: number;
  nickname: string;
  process_by: string;
  process_feedback: string;
  process_status: number;
  process_time: number;
  type: number;
  user_id: string;
}

export interface GetOfficialAccountResponse {
  current_number: number;
  show_number: number;
  official_nums: number;
  pending_nums: number;
  official: GetOfficialAccountItem[];
}

export interface ProcessOfficialAccountParams {
  official_id: number;
  process_feedback: string;
  process_status: number;
}

export type ProcessOfficialAccountResponse = [];

export interface DeleteOfficialAccountParams {
  officials: string[];
}

export interface RegisterOfficialAccountParams {
  user_id: string;
  nickname: string;
  initial_nickname: string;
  type: number;
  id_type: number;
  id_name: string;
  id_number: string;
  is_system: number;
  interests: number[];
  profile_photo: string;
  bio: string;
}

export type RegisterOfficialAccountResponse = null;

export interface EditOfficialAccountParams {
  id: number;
  type: number;
  id_type: number;
  id_name: string;
  id_number: string;
  nickname: string;
  is_system: number;
  face_url: string;
  bio: string;
  interests: number[];
}

export type EditOfficialAccountResponse = null;

export type AddEditOfficialAccountParams = {
  user_id: string;
  id: number;
  type: number;
  id_type: number;
  id_name: string;
  id_number: string;
  nickname: string;
  is_system: number;
  face_url: string;
  bio: string;
  interests: number[];
};

// Like List
export interface GetNewsLikesParams {
  page_number: number;
  show_number: number;
  order_by: string;
  official_account?: string;
  account_type?: number;
  ip?: string;
  time_type: number;
  start_time?: number;
  end_time?: number;
  title?: string;
  like_user?: string;
}

export type LikeItem = {
  article_id: number;
  article_title: string;
  cover_photo: string;
  create_by: string;
  create_time: string;
  delete_time: string;
  deleted_by: string;
  last_login_ip: string;
  last_login_time: string;
  official_name: string;
  official_type: number;
  post_time: number;
  status: number;
  update_by: string;
  update_time: number;
  user_id: string;
  user_name: string;
  user_profile_img: string;
  unique_key?: string;
};

export interface GetNewsLikesResponse {
  current_number: number;
  likes: LikeItem[];
  likes_nums: number;
  show_number: number;
}

export interface ChangeNewsLikeStatusParams {
  article_id: number;
  status: number;
  user_id: string;
}

export type ChangeNewsLikeStatusRespons = null;

export interface DeleteNewsLikeParams {
  articles: number[];
  user_ids: string[];
}

export type DeleteNewsLikeResponse = null;

// Share list
export interface GetNewsShareListRequestParams {
  page_number: number;
  show_number: number;
  ip?: string;
  time_type?: number;
  start_time?: number;
  end_time?: number;
  repost_user?: string;
  title?: string;
  original_user?: string;
  original_user_type?: string;
  order_by: string;
  account_type?: number;
}

export type ShareItem = {
  article_id: number;
  article_title: string;
  comment_counts: number;
  cover_photo: string;
  delete_time: number;
  deleted_by: string;
  last_login_ip: string;
  like_counts: number;
  moment_id: string;
  official_type: number;
  original_user: string;
  privacy: number;
  share_time: number;
  share_user: string;
};

export interface GetNewsShareListResponse {
  current_number: number;
  repost: ShareItem[];
  repost_nums: number;
  show_number: number;
}

export interface DeleteNewsShareParams {
  articles: number[];
  moment_ids: string[];
}

export type DeleteNewsShareResponse = null;

export interface ChangeSharePrivacyParams {
  moment_id: string;
  privacy: number;
}

export type ChangeSharePrivacyResponse = null;

//Comments List

export interface GetNewsCommentsParams {
  page_number: number;
  show_number: number;
  official_account?: string;
  account_type?: number;
  ip?: string;
  time_type: number;
  start_time?: number;
  end_time?: number;
  title?: string;
  comment_user?: string;
  comment_key?: string;
  order_by: string;
}

export type CommentItem = {
  article_id: number;
  article_title: string;
  comment_id: number;
  comment_likes: number;
  comment_reply_count: number;
  content: string;
  cover_photo: string;
  create_by: string;
  create_time: number;
  delete_time: number;
  deleted_by: string;
  last_login_ip: string;
  last_login_time: number;
  official_id: number;
  official_name: string;
  official_type: number;
  parent_comment_id: number;
  post_time: number;
  status: number;
  update_by: string;
  update_time: number;
  user_id: string;
  user_name: string;
  user_profile_img: string;
};

export interface GetNewsCommentsResponse {
  current_number: number;
  show_number: number;
  comments_nums: number;
  comments: CommentItem[];
}

export interface DeleteNewsCommentParams {
  articles: number[];
  comments: number[];
  parents: number[];
}

export type DeleteNewsCommentResponse = null;

export interface ChangeNewsCommentStatusParams {
  comment_id: number;
  status: number;
}

export type ChangeNewsCommentStatusResponse = null;

export interface AlterNewsCommentsParams {
  comment_id: string;
  comment_user: string;
  content: string;
}

export type AlterNewsCommentResponse = null;

//News List

export interface GetNewsListParams {
  page_number: number;
  show_number: number;
  official_account?: string;
  account_type?: number;
  ip?: string;
  time_type?: number;
  start_time?: number;
  end_time?: number;
  title?: string;
  order_by: string;
}

export type NewsItem = {
  article_id: number;
  comment_counts: number;
  content: string;
  cover_photo: string;
  create_time: number;
  delete_time: number;
  deleted_by: number;
  last_login_ip: string;
  last_login_time: string;
  like_counts: number;
  official_id: number;
  official_name: string;
  official_profile_img: string;
  official_status: number;
  official_type: number;
  privacy: number;
  repost_counts: number;
  status: number;
  title: string;
  update_by: string;
  update_time: number;
};

export interface GetNewsListResponse {
  current_number: number;
  news_nums: number;
  show_number: number;
  articles: NewsItem[];
}

export interface DeleteNewsParams {
  articles: number[];
}

export type DeleteNewsResponse = null;

export interface ChangeNewsPrivacyParams {
  article_id: number;
  privacy: number;
}

export type ChangeNewsPrivacyResponse = null;

export interface EditNewsParams {
  article_id: number;
  content: string;
  title: string;
}

export type EditNewsResponse = null;

//Interest List
export interface GetInerestListParams {
  show_number: number;
  page_number: number;
  time_type: number;
}

export interface InterestNameItem {
  language_type: string;
  name: string;
}

export interface InterestItem {
  id: number;
  is_default: number;
  create_time: number;
  create_user: string;
  remark: string;
  update_time: number;
  update_user: string;
  status: number;
  name: InterestNameItem[];
}

export type GetInterestListData = {
  current_number: number;
  interest_nums: number;
  show_number: number;
  interests: InterestItem[];
};

export type GetInterestListResponse = {
  data: GetInterestListData;
};

export interface DeleteUsersRequestParams {
  deleteUserIDList: string[];
}

export type DeleteUsersResponse = [];

export interface SwitchStatusRequestParams {
  status: 1 | 2;
  status_type: 1 | 2 | 3;
  user_id: string;
}

export type SwitchStatusResponse = null;

export interface EditGamesRequestParams {
  categories?: string[];
  classification?: string[];
  cover_img: string;
  description?: { cn?: string; en?: string };
  game_code?: string;
  game_name?: { cn?: string; en?: string };
  horizontal_cover: string[];
  hot?: number;
  platform_link: {
    1?: {
      file_name?: string;
      package_url?: string;
      play_url?: string;
      size?: number;
      upload_time?: number;
    };
    2?: {
      file_name?: string;
      package_url?: string;
      play_url?: string;
      size?: number;
      upload_time?: number;
    };
    3?: {
      file_name?: string;
      package_url?: string;
      play_url?: string;
      size?: number;
      upload_time?: number;
    };
  };
  publisher?: string;
  sort_priority?: number;
  state: number;
}

export type EditGamesResponse = null;

export interface AddGamesRequestParams {
  categories?: string[];
  classification?: string[];
  cover_img: string;
  description?: { cn?: string; en?: string };
  game_code?: string;
  game_name?: { cn?: string; en?: string };
  horizontal_cover: string[];
  hot?: number;
  platform_link: {
    1?: {
      file_name?: string;
      package_url?: string;
      play_url?: string;
      size?: number;
      upload_time?: number;
    };
    2?: {
      file_name?: string;
      package_url?: string;
      play_url?: string;
      size?: number;
      upload_time?: number;
    };
    3?: {
      file_name?: string;
      package_url?: string;
      play_url?: string;
      size?: number;
      upload_time?: number;
    };
  };
  publisher?: string;
  sort_priority?: number;
  state: number;
}

export type AddGamesResponse = null;

export interface GetUsersThirdInfoRequestParams {
  page_number: number;
  show_number: number;
  user_id?: string;
  third_type?: number;
  third_name?: string;
}

export interface ThirdUserItem {
  nick_name: string;
  phone_number: string;
  user_id: string;
  email: string;
  official_name: string;
  wallet: string;
  facebook: string;
  google: string;
  apple: string;
}

export interface GetUsersThirdInfoResponse {
  current_number: number;
  show_number: number;
  user_nums: number;
  users: ThirdUserItem[];
}

export interface GetUserInterestsRequestParams {
  show_number: number;
  page_number: number;
  user_id: string;
}

export interface GetUserInterestsItem {
  type: number;
  user_id: string;
  username: string;
  interests: GetInterestListItem[];
}

export interface GetUserInterestsResponse {
  current_number: number;
  interest_nums: number;
  show_number: number;
  interests: GetUserInterestsItem[];
}

export interface AddUserRequestParams {
  phone_number: string;
  user_id: string;
  name: string;
  password: string;
  source_id: string;
  email: string;
  code: string;
  gender: number;
  remark: string;
  interests: number[];
  face_url: string;
}

export type AddUserResponse = null

export interface AlterUserRequestParams {
  "user_id" : string,
  "nickname" : string,
  "phone_number" : string,
  "email" : string,
  "gender" : number,
  "interests": string[],
  "remark": string,
  "code" : string,
  "password" : string,
  "source_id" : string,
  "face_url": string
}

export type AlterUserResponse = null

export interface GetDeletedAccountRequestParams {
  page_number: number;
  show_number: number;
  user?: string;
  gender?: number;
  reason?: string;
  location?: string;
  last_login_device?: string;
  deleted_by?: string;
  time_type?: string;
  start_time?: string;
  end_time?: string;
}

export interface DeletedAccountItem {
  user_id: string;
  username: string;
  profile_photo: string;
  phone_number: string;
  gender: number;
  last_login_ip: string;
  location: string;
  create_time: number;
  delete_time: number;
  deleted_by: string;
  reason: string;
}

export interface GetDeletedAccountResponse {
  current_number: number;
  show_number: number;
  deleted_users_count: number;
  deleted_users: DeletedAccountItem[];
}

interface PermissionsApiItem {
  apiName: string;
  apiPath: string;
  id: number;
}

interface PermissionsPageItem {
  id: number;
  pageName: string;
  pagePath: string;
  fatherPageID: number;
  isMenu: number;
  sortPriority: number;
  childs: null | PermissionsPageItem[];
  childsCount: number;
  status: number;
  adminAPIsIDs: number[];
  isButton: number;
}

export interface PermissionsResponse {
  adminRole: {
    allowedApis: PermissionsApiItem[];
    allowedPages: PermissionsPageItem[];
  };
}

export interface GetGroupsRequestParams {
  page_number: number;
  show_number: number;
  group?: string;
  owner?: string;
  is_open?: number;
  group_status?: string;
  remark?: string;
  creator?: string;
  start_time?: number;
  end_time?: number;
  order_by: string;
}

export interface GetGroupsItem {
  group_name: string;
  group_id: string;
  group_master_name: string;
  group_master_id: string;
  create_time: string;
  is_ban_chat: boolean;
  is_ban_private_chat: boolean;
  profile_photo: string;
  group_notification: string;
  group_introduction: string;
  remark: string;
  video_status: number;
  audio_status: number;
  status: number;
  is_open: number;
  members: number;
}

export interface GetGroupsResponse {
  current_number: number;
  group_nums: number;
  show_number: number;
  groups: GetGroupsItem[];
}

export interface BanGroupChatRequestParams {
  group_id: string;
}

export type BanGroupChatResponse = null;

export interface OpenGroupChatRequestParams {
  group_id: string;
}

export type OpenGroupChatResponse = null;

export interface SetVideoAudioStatusRequestParams {
  groupID: string;
  status: 1 | 2;
  status_type: 1 | 2;
}

export type SetVideoAudioStatusResponse = null;

export interface DeleteGroupRequestParams {
  group_id: string;
}

export type DeleteGroupResponse = null;

export interface GetGroupMembersRequestParams {
  page_number: number;
  show_number: number;
  group_id: string;
  role_level: string;
  member?: string;
  remark_name?: string;
  remark?: string;
  start_time?: number;
  end_time?: number;
  permission: string;
  status: string;
}

export interface GetGroupMembersItem {
  member_position: number;
  member_name: string;
  member_nick_name: string;
  member_id: string;
  member_group_face_url: string;
  role_level: 1 | 2 | 3;
  join_time: string;
  join_source: number;
  inviter_user_id: string;
  mute_end_time: number;
  remark: string;
  video_status: number;
  audio_status: number;
}

export interface GetGroupMembersResponse {
  current_number: number;
  group_members: GetGroupMembersItem[];
  group_name: string;
  member_nums: number;
  show_number: number;
}

/**
 * WOOM Management
 */
export interface GetWoomListRequestParams {
  page_number: number;
  show_number: number;
  userId?: string;
  status?: number;
  emptyDesc?: number;
  desc?: string;
  startTime?: number;
  endTime?: number;
}

export interface GetWoomListItem {
  key: any;
  expanded: any;
  commentLikeNum: number;
  commentNum: number;
  coverUrl: string;
  creatTime: number;
  desc: string;
  fileId: string;
  id: number;
  interestArray: number[];
  interestId: string;
  likeNum: number;
  mediaUrl: string;
  remark: string;
  replyNum: number;
  status: number;
  userID: string;
  userName: string;
}

export interface GetWoomListResponse {
  current_number: number;
  show_number: number;
  shortVideoCount: number;
  shortVideoList: GetWoomListItem[];
}

export interface EditWoomListRequestParams {
  fileId?: string;
  desc?: string;
  remark?: string;
  status?: number;
}

export type EditWoomListResponse = null;

export interface DeleteWoomListRequestParams {
  fileId: string[];
}

export type DeleteWoomListResponse = null;

/**
 * Get InterestList
 */
export interface GetInterestListRequestParams {
  page_number: number;
  show_number: number;
  time_type?: number;
}

interface LanguageName {
  language_type: string;
  name: string;
}

export interface GetInterestListItem {
  create_time?: number;
  create_user?: string;
  delete_time?: number;
  id: number;
  is_default?: number;
  name: LanguageName[];
  remark: string;
  status: number;
  update_time: number;
  update_user: string;
}

export interface GetInterestListResponse {
  current_number: number;
  show_number: number;
  interest_nums: number;
  interests: GetInterestListItem[];
}

/**
 * WOOM LIKES
 */
export interface GetWoomLikesRequestParams {
  page_number: number;
  show_number: number;
  userId?: string;
  status?: number;
  emptyDesc?: number;
  desc?: string;
  startTime?: number;
  endTime?: number;
  likeUserId?: string;
  fileId?: string;
}

export interface GetWoomLikesItem {
  id: string;
  postUserName: string;
  postUserId: string;
  fileStatus: number;
  coverUrl: string;
  mediaUrl: string;
  userName: string;
  userId: string;
  creatTime: number;
}

export interface GetWoomLikesResponse {
  current_number: number;
  show_number: number;
  shortVideoLikeCount: number;
  shortVideoLikeList: GetWoomLikesItem[];
}

export interface DeleteWoomLikesRequestParams {
  likeIdList: string[];
}

export type DeleteWoomLikesResponse = null;

/**
 * WOOM COMMENTS
 */
export interface GetWoomCommentsRequestParams {
  page_number: number;
  show_number: number;
  userId?: string;
  status?: number;
  emptyDesc?: number;
  desc?: string;
  startTime?: number;
  endTime?: number;
  fileId?: string;
  commentUserId?: string;
  context?: string;
}

export interface GetWoomCommentsItem {
  id?: string;
  userId?: string;
  postUserName?: string;
  postUserId?: string;
  fileStatus?: number;
  coverUrl?: string;
  mediaUrl?: string;
  userName?: string;
  userId?: string;
  creatTime?: number;
  context?: string;
  likeNum?: number;
  replyNum?: number;
  remark?: string;
}

export interface GetWoomCommentsResponse {
  current_number: number;
  show_number: number;
  shortVideoCommentCount: number;
  shortVideoCommentList: GetWoomCommentsItem[];
}

export interface DeleteWoomCommentsRequestParams {
  commentIdList: string[];
}

export type DeleteWoomCommentsResponse = null;

export interface EditWoomCommentsRequestParams {
  commentId?: string;
  remark: string;
  content: string;
}

export type EditWoomCommentsResponse = null;

/**
 * WOOM COMMENTS REPLY
 */
export interface GetWoomCommentsReplyRequestParams {
  page_number: number;
  show_number: number;
  publisher?: string;
  privacy?: number;
  is_empty?: number;
  content?: string;
  start_time?: number;
  end_time?: number;
  comment_id?: string;
  comment_user?: string;
  comment?: string;
  reply_user?: string;
  reply_content?: string;
}

export interface GetWoomCommentsReplyItem {
  reply_comment_id?: number;
  file_id?: string;
  publish_user?: string;
  publisher_id?: string;
  short_video_status?: number;
  cover_url?: string;
  media_url?: string;
  reply_user_name?: string;
  reply_user_id?: string;
  reply_time?: number;
  reply_comment_content?: string;
  like_count?: number;
  comment_count?: number;
  remark?: string;
}

export interface GetWoomCommentsReplyResponse {
  current_number: number;
  show_number: number;
  replies_count: number;
  comment_replies: GetWoomCommentsReplyItem[];
}

export interface DeleteWoomCommentsReplyRequestParams {
  comment_ids: string[];
}

export type DeleteWoomCommentsReplyResponse = null;

export interface EditWoomCommentsReplyRequestParams {
  short_video_id?: string;
  reply_comment_id?: number;
  remark: string;
  reply_content: string;
}

export type EditWoomCommentsReplyResponse = null;

/**
 * WOOM COMMENTS LIKE
 */
export interface GetWoomCommentsLikeRequestParams {
  page_number: number;
  show_number: number;
  publisher?: string;
  privacy?: number;
  is_empty?: number;
  content?: string;
  start_time?: number;
  end_time?: number;
  comment_id?: string;
  comment_user?: string;
  comment?: string;
  reply_user?: string;
  reply_content?: string;
  like_user?: string;
}

export interface GetWoomCommentsLikeItem {
  like_id?: number;
  file_id?: string;
  publish_user?: string;
  publisher_id?: string;
  short_video_status?: number;
  cover_url?: string;
  media_url?: string;
  comment_content?: string;
  like_user_id?: string;
  like_user_name?: string;
  like_time?: number;
  remark?: string;
}

export interface GetWoomCommentsLikeResponse {
  current_number: number;
  show_number: number;
  likes_count: number;
  comment_likes: GetWoomCommentsLikeItem[];
}

export interface DeleteWoomCommentsLikeRequestParams {
  likes: string[];
}

export type DeleteWoomCommentsLikeResponse = null;

export interface EditWoomCommentsLikeRequestParams {
  short_video_id?: string;
  like_id?: number;
  remark: string;
}

export type EditWoomCommentsLikeResponse = null;

export interface MuteGroupMemberRequestParams {
  groupID: string;
  mutedSeconds: number;
  userID: string;
}

export type MuteGroupMemberResponse = null;

export interface CancelMuteGroupMemberRequestParams {
  groupID: string;
  userID: string;
}

export type CancelMuteGroupMemberResponse = null;

export interface SetGroupAdminRequestParams {
  group_id: string;
  user_id: string;
}

export type SetGroupAdminResponse = null;

export interface SetGroupOrdinaryUserRequestParams {
  group_id: string;
  user_id: string;
}

export type SetGroupOrdinaryUserResponse = null;

export interface RemoveMembersRequestParams {
  group_Id: string;
  members: string[];
}

export type RemoveMembersResponse = null;

export interface AddMembersRequestParams {
  group_Id: string;
  members: string[];
}

export type AddMembersResponse = null;

export interface SetGroupMasterRequestParams {
  group_id: string;
  user_id: string;
}

export type SetGroupMasterResponse = null;

export interface GetGroupByIdRequestParams {
  group_id: string;
}

export interface GetGroupByIdResponse {
  group_name: string;
  group_id: string;
  group_master_name: string;
  group_master_id: string;
  create_time: string;
  is_ban_chat: boolean;
  is_ban_private_chat: boolean;
  profile_photo: string;
  group_notification: string;
  group_introduction: string;
  remark: string;
  video_status: number;
  audio_status: number;
  status: number;
  is_open: number;
  members: number;
  member_list: {
    nick_name: string;
    user_id: string;
  }[];
}

export interface MePageUrl {
  cn: string;
  en: string;
}

export interface GetMePageParams {
  operationID?: string;
  type: 1 | 2 | 3 | 4 | 5 | 6 | 7;
}

export interface GetMePageResponse {
  id: number;
  url: MePageUrl;
  status: number;
  create_time: number;
  create_user: string;
  update_time: number;
  update_user: string;
  delete_time: number;
  delete_user: string;
}

export interface SwitchMePageParams {
  operationID?: string;
  type: 1 | 2 | 3 | 4 | 5 | 6 | 7;
  status: 1 | 2;
}

export interface SwitchMePageResponse {
  errCode: number;
  errMsg: string;
}

export interface SaveMePageParams {
  operationID?: string;
  type: 1 | 2 | 3 | 4 | 5 | 6 | 7;
  url: MePageUrl;
}

export interface SaveMePageResponse {
  errCode: number;
  errMsg: string;
}

export interface GetDiscoverParams {
  operationID?: string;
  platform_id?: string;
}

export interface GetDiscoverResponse {
  id: number;
  url: string;
  status: number;
  platform_id: number;
  create_time: number;
  create_user: string;
  update_time: number;
  update_user: string;
}

export interface SwitchDiscoverParams {
  operationID?: string;
  platform_id: string;
  status: 0 | 1;
}

export type SwitchDiscoverResponse = null;

export interface SaveDiscoverParams {
  operationID?: string;
  platform_id: string;
  url: string;
}

export type SaveDiscoverResponse = null;

export interface GetFavoritesRequestParams {
  page_number: number;
  show_number: number;
  order_by?: string;
  account?: string;
  content?: string;
  content_type?: string;
  publish_user?: string;
  time_type?: number;
  start_time?: number;
  end_time?: number;
}

export interface GetFavoritesItem {
  favorite_id: string;
  user_id: string;
  user_name: string;
  content_type: number;
  content: string;
  create_time: number;
  publish_user: string;
  publish_time: number;
  remark: string;
  edit_user: string;
  update_by: string;
  update_time: number;
  content_creator_name: string;
  file_size: number;
  source_type: number;
  create_by: string;
}

export interface GetFavoritesResponse {
  current_number: number;
  show_number: number;
  favorite_nums: number;
  favorites: GetFavoritesItem[];
}

export interface GetBlacklistRequestParams {
  page_number: number;
  show_number: number;
  order_by: string;
  owner_user?: string;
  block_user?: string;
  remark?: string;
  start_time?: number;
  end_time?: number;
}

export interface GetBlacklistItem {
  owner_user_name: string;
  owner_user_id: string;
  owner_profile: string;
  block_user_name: string;
  block_user_id: string;
  create_time: number;
  remark: string;
  edit_user: string;
  edit_time: number;
  ex: string;
}

export interface GetBlacklistResponse {
  current_number: number;
  show_number: number;
  list_number: number;
  black_list: GetBlacklistItem[];
}

export interface DeleteUsersRequestParams {
  deleteUserIDList: string[];
}

export type DeleteUsersResponse = [];

export interface SwitchStatusRequestParams {
  status: 1 | 2;
  status_type: 1 | 2 | 3;
  user_id: string;
}

export type SwitchStatusResponse = null;

export interface GetUsersThirdInfoRequestParams {
  page_number: number;
  show_number: number;
  user_id?: string;
  third_type?: number;
  third_name?: string;
}

export interface ThirdUserItem {
  nick_name: string;
  phone_number: string;
  user_id: string;
  email: string;
  official_name: string;
  wallet: string;
  facebook: string;
  google: string;
  apple: string;
}

export interface GetUsersThirdInfoResponse {
  current_number: number;
  show_number: number;
  user_nums: number;
  users: ThirdUserItem[];
}

export interface DeleteFavoritesRequestParams {
  favorite_ids: string[];
}

export type DeleteFavoritesResponse = [];

export interface BlackListDeleteId {
  owner_id?: string;
  black_id?: string;
}

export interface DeleteBlackListRequestParams {
  friend_list: BlackListDeleteId[] | [];
}

export type DeleteBlackListResponse = [];

export interface EditFavoritesRequestParams {
  operation_id: string;
  favorite_id: string;
  remark: string;
}

export type EditFavoritesResponse = null;

export interface GetAppUpdateRequestParams {
  page_number: number;
  show_number: number;
  client?: string;
  create_time_begin?: string;
  create_time_end?: string;
  status?: string;
}

export interface GetAppUpdateItem {
  content: string;
  create_time: number;
  create_user: string;
  download_url: string;
  id: string;
  isforce: number;
  status: number;
  title: string;
  type: number;
  update_time: number;
  update_user: string;
  version: string;
}

export interface GetAppUpdateResponse {
  current_number: number;
  show_number: number;
  total: number;
  appversions: GetAppUpdateItem[];
}

export interface AddEditAppUpdateRequestParams {
  id?: string;
  version: string;
  client: string;
  isforce: string;
  status: string;
  title: string;
  download_url: string;
  remark: string;
}

export type AddEditAppUpdateResponse = null;

export interface DeleteAppUpdateRequestParams {
  id: string;
}

export type DeleteAppUpdateResponse = null;

export interface EditBlackListRequestParams {
  owner_user: string;
  block_user: string;
  remark: string;
}

export type EditBlackListResponse = null;
export interface GetStatisticsParams {
  from: string;
  to: string;
}
type ActiveUserNum = {};
export interface GetUserStatisticsResponse {
  active_user_num: number;
  active_user_num_list: {
    date: string;
    active_user_num: number;
  }[];
  increase_user_num: number;
  increase_user_num_list: { date: string; increase_user_num: number }[];
  total_user_num: number;
  total_user_num_list: { date: string; total_user_num: number }[];
}
export interface ActiveUserStatistics {
  message_num: number;
  nick_name: string;
  user_id: string;
}
export interface GetActiveUserStatisticsResponse {
  active_user_list: ActiveUserStatistics[];
}
export interface GetGrouptStatisticsResponse {
  increase_group_num: number;
  increase_group_num_list: { date: string; increase_group_num: number }[];
  total_group_num: number;
  total_group_num_list: { date: string; total_group_num: number }[];
}
export interface ActiveGroupStatistics {
  message_num: number;
  group_name: string;
  group_id: string;
}
export interface GetMessageStatisticsResponse {
  group_message_num: number;
  group_message_num_list: { date: string; message_num: number }[];
  private_message_num: number;
  private_message_num_list: { date: string; message_num: number }[];
}
export interface GetActiveGroupStatisticsResponse {
  active_group_list: ActiveGroupStatistics[];
}

export interface ActiveGameList {
  game_code: string;
  game_name: { cn: string; en: string };
  played_number: number;
}
export interface GetGameStatisticsResponse {
  cumulative_played: number;
  game_played_num_list: { data: string; num: number }[];
  game_played_today: number;
  ActiveGameList: ActiveGameList[];
}

interface GetMomentsRequestParams {
  page_number: number;
  show_number: number;
  order_by: string;
  account?: string;
  privacy?: number;
  content?: string;
  media_type?: number;
  start_time?: number;
  end_time?: number;
  is_reposted?: number;
  is_blocked?: number;
  original_user?: string;
  content_type?: number;
}

export interface GetMomentsResponse {
  current_number: number;
  show_number: number;
  moments: GetMomentItem[];
  moments_nums: number;
}

export interface DeleteMomentsRequestParams {
  moments: string[];
  article_ids: number[];
}

export interface ChangeMomentsStatusRequestParams {
  moment_ids: string[];
  status: number;
}

export interface AlterMomentRequestParams {
  moment_id: string;
  content: string;
  m_content_images_array_v2: ContentImagesArrayType[] | null;
  m_content_videos_array_v2: ContentVideosArrayType[] | null;
}

export interface GetMomentsCommentsRequestParams {
  page_number: number;
  show_number: number;
  order_by: string;
  m_content_text?: string;
  comment_user?: string;
  comment_content?: string;
  publish_user?: string;
  article_id?: string;
  time_type?: number;
  start_time?: number;
  end_time?: number;
  parent_mment_id?: number;
  content_type?: number;
  media_type?: number;
  comment_type?: number;
  reply_comment_id?: number;
}

export interface GetMomentsCommentsResponse {
  comments: GetMomentCommentItem[] | null;
  comments_nums: number;
  current_number: number;
  show_number: number;
}

export interface RemoveMomentsCommentRequestParams {
  comment_ids: string[];
  moment_ids: string[];
  parent_ids: string[];
  reply_ids: string[];
}

export interface SwitchCommentStatusRequestParams {
  comment_id: string;
  status: number;
}

export interface AlterMomentCommentRequestParams {
  comment_id: string;
  content: string;
}

export interface GetMomentsLikesRequestParams {
  page_number: number;
  show_number: number;
  order_by: string;
  publish_user?: string;
  m_content_text?: string;
  like_user?: string;
  start_time?: number;
  end_time?: number;
  moment_id?: string;
  content_type?: number;
  media_type?: number;
}

export interface GetMomentLikesItem {
  account: string;
  account_nickname: string;
  create_time: number;
  mContentImagesArrayV2: ContentImagesArrayType[] | null;
  mContentVideosArrayV2: ContentVideosArrayType[] | null;
  m_content_images_array: string;
  m_content_text: string;
  m_content_thumbnil_array: string;
  m_content_videos_array: string;
  m_create_time: number;
  moment_id: string;
  privacy: number;
  status: number;
  user_id: string;
  user_name: string;
}

export interface GetMomentsLikesResponse {
  current_number: number;
  likes: GetMomentLikesItem[] | null;
  likes_nums: number;
  show_number: number;
}

export interface RemoveMomentLikesRequestParams {
  moments_id: string[];
  users_id: string[];
}

export interface SwitchMomentLikesStatusRequestParams {
  moment_id: string;
  user_id: string;
  status: number;
}

export interface BanGroupChatRequestParams {
  group_id: string;
}

export interface GetMomentDetailsRequestParams {
  page_number: number;
  show_number: number;
  media_type?: number;
  content?: string;
  start_time?: number;
  end_time?: number;
  order_by: string;
  content_type?: number;
  account?: string;
  privacy?: number;
  original_id?: string;
}

export interface TurnoffCommentRequestParams {
  moment_id: string;
  comment_ctl: number;
}

export interface GetMomentItem {
  moment_id: string;
  m_create_time: number;
  m_content_text: string;
  m_content_images_array: string;
  m_content_videos_array: string;
  mContentImagesArrayV2: ContentImagesArrayType[] | null;
  mContentVideosArrayV2: ContentVideosArrayType[] | null;
  m_content_thumbnil_array: string;
  user_id: string;
  user_name: string;
  article_id: number;
  orignal_id: string;
  original_creator_id: string;
  original_creator_name: string;
  moment_type: number;
  privacy: number;
  status: number;
  interests: MomentInterstItem[];
  key?: string;
}

export interface ContentImagesArrayType {
  image_url: string;
  snap_shot_url: string;
  image_width: number;
  image_height: number;
}

export interface ContentVideosArrayType {
  video_url: string;
  snap_shot_url: string;
  video_width: number;
  video_height: number;
}

export interface MomentInterstItem {
  id: number;
  status: number;
  remark: string;
  create_user: string;
  create_time: number;
  update_user: string;
  update_time: number;
  delete_time: number;
  is_default: number;
  name: LanguageType[];
}

export interface GetMomentCommentItem {
  comment_content: string;
  comment_id: string;
  comment_parent_id: string;
  comment_replies: number;
  commented_use_id: string;
  commented_user_name: string;
  create_by: string;
  create_time: number;
  like: number;
  mContentImagesArrayV2: ContentImagesArrayType[] | null;
  mContentVideosArrayV2: ContentVideosArrayType[] | null;
  m_content_images_array: string;
  m_content_text: string;
  m_content_thumbnil_array: string;
  m_content_videos_array: string;
  m_create_time: number;
  moment_id: string;
  privacy: number;
  publish_account: string;
  publish_name: string;
  reply_comment_id: string;
  status: number;
  user_id: string;
  user_name: string;
}

export interface MomentDetails {
  comment_ctl: number;
  last_login_ip: string;
  mContentImagesArrayV2: ContentImagesArrayType[] | null;
  mContentVideosArrayV2: ContentVideosArrayType[] | null;
  m_comments_count: number;
  m_content_images_array: string;
  m_content_text: string;
  m_content_thumbnil_array: string;
  m_content_videos_array: string;
  m_create_time: number;
  m_likes_count: number;
  m_repost_count: number;
  moment_id: string;
  original_creator_name: string;
  orignal_creator_id: string;
  orignal_id: string;
  privacy: number;
  user_id: string;
  user_name: string;
}

export type ApiRequest = {
  (key: typeof actions.ADMIN_LOGIN, body: AdminLoginRequestParams): Promise<ApiResponse<AdminLoginResponse>>;
  (
    key: typeof actions.ADMIN_VERIFY_TOTP,
    body: AdminVerifyTOTPRequestParams,
    headers: {
      [key: string]: string;
    }
  ): Promise<ApiResponse<AdminLoginResponse>>;
  (key: typeof actions.PERMISSIONS): Promise<ApiResponse<PermissionsResponse>>;
  (key: typeof actions.GET_USERS, body: GetUsersRequestParams): Promise<ApiResponse<GetUsersResponse>>;
  (key: typeof actions.DELETE_USERS, body: DeleteUsersRequestParams): Promise<ApiResponse<DeleteUsersResponse>>;
  (key: typeof actions.SWITCH_STATUS, body: SwitchStatusRequestParams): Promise<ApiResponse<SwitchStatusResponse>>;
  (key: typeof actions.GET_USERS_THIRD_INFO, body: GetUsersThirdInfoRequestParams): Promise<ApiResponse<GetUsersThirdInfoResponse>>;
  (key: typeof actions.GET_USER_INTERESTS, body: GetUserInterestsRequestParams): Promise<ApiResponse<GetUserInterestsResponse>>;
  (key: typeof actions.ADD_USER, body: AddUserRequestParams): Promise<ApiResponse<AddUserResponse>>;
  (key: typeof actions.ALTER_USER, body: AlterUserRequestParams): Promise<ApiResponse<AlterUserResponse>>;
  (key: typeof actions.GET_DELETED_ACCOUNT, body: GetDeletedAccountRequestParams): Promise<ApiResponse<GetDeletedAccountResponse>>;
  (key: typeof actions.GET_GROUPS, body: GetGroupsRequestParams): Promise<ApiResponse<GetGroupsResponse>>;
  (key: typeof actions.BAN_GROUP_CHAT, body: BanGroupChatRequestParams): Promise<ApiResponse<BanGroupChatResponse>>;
  (key: typeof actions.OPEN_GROUP_CHAT, body: OpenGroupChatRequestParams): Promise<ApiResponse<OpenGroupChatResponse>>;
  (key: typeof actions.SET_VIDEO_AUDIO_STATUS, body: SetVideoAudioStatusRequestParams): Promise<ApiResponse<SetVideoAudioStatusResponse>>;
  (key: typeof actions.GET_GROUP_MEMBERS, body: GetGroupMembersRequestParams): Promise<ApiResponse<GetGroupMembersResponse>>;
  (key: typeof actions.MUTE_GROUP_MEMBER, body: MuteGroupMemberRequestParams): Promise<ApiResponse<MuteGroupMemberResponse>>;
  (key: typeof actions.CANCEL_MUTE_GROUP_MEMBER, body: CancelMuteGroupMemberRequestParams): Promise<ApiResponse<CancelMuteGroupMemberResponse>>;
  (key: typeof actions.SET_GROUP_ADMIN, body: SetGroupAdminRequestParams): Promise<ApiResponse<SetGroupAdminResponse>>;
  (key: typeof actions.SET_GROUP_ORDINARY_USER, body: SetGroupOrdinaryUserRequestParams): Promise<ApiResponse<SetGroupOrdinaryUserResponse>>;
  (key: typeof actions.REMOVE_MEMBERS, body: RemoveMembersRequestParams): Promise<ApiResponse<RemoveMembersResponse>>;
  (key: typeof actions.DELETE_GROUP, body: DeleteGroupRequestParams): Promise<ApiResponse<DeleteGroupResponse>>;
  (key: typeof actions.ADD_MEMBERS, body: AddMembersRequestParams): Promise<ApiResponse<AddMembersResponse>>;
  (key: typeof actions.SET_GROUP_MASTER, body: SetGroupMasterRequestParams): Promise<ApiResponse<SetGroupMasterResponse>>;
  (key: typeof actions.GET_GROUP_BY_ID, body: GetGroupByIdRequestParams): Promise<ApiResponse<GetGroupByIdResponse>>;
  (key: typeof actions.GAMEMANAGE_GETGAMELIST, body: GetGameListRequestParams): Promise<ApiResponse<GetGameListResponse>>;
  (key: typeof actions.GAMEMANAGE_DELETEGAMELIST, body: DeleteGamesRequestParams): Promise<ApiResponse<DeleteGamesResponse>>;
  (key: typeof actions.GAMEMANAGE_EDITGAMELIST, body: EditGamesRequestParams): Promise<ApiResponse<EditGamesResponse>>;
  (key: typeof actions.GAMEMANAGE_ADDGAMELIST, body: AddGamesRequestParams): Promise<ApiResponse<AddGamesResponse>>;
  (key: typeof actions.CATEGORYMANAGE_GETCATEGORY, body: GetCategoriesRequestParams): Promise<ApiResponse<GetCategoriesResponse>>;
  (key: typeof actions.CATEGORYMANAGE_SETSTATE, body: setCategoryStateRequestParams): Promise<ApiResponse<setCategoryStateResponse>>;
  (key: typeof actions.CATEGORYMANAGE_ADDCATEGORY, body: addCategoryRequestParams): Promise<ApiResponse<addCategoryResponse>>;
  (key: typeof actions.CATEGORYMANAGE_EDITCATEGORY, body: editCategoryRequestParams): Promise<ApiResponse<editCategoryResponse>>;
  (key: typeof actions.CATEGORYMANAGE_DELETECATEGORY, body: deleteCategoryRequestParams): Promise<ApiResponse<deleteCategoryResponse>>;
  (key: typeof actions.GET_INTERESTLIST, body: GetInterestListRequestParams): promises<ApiResponse<GetInterestListResponse>>;
  (key: typeof actions.WOOMMANAGE_GETVIDEOLIST, body: GetWoomListRequestParams): Promise<ApiResponse<GetWoomListResponse>>;
  (key: typeof actions.WOOMMANAGE_EDITVIDEO, body: EditWoomListRequestParams): Promise<ApiResponse<EditWoomListResponse>>;
  (key: typeof actions.WOOMMANAGE_DELETEVIDEO, body: DeleteWoomListRequestParams): Promise<ApiResponse<DeleteWoomListResponse>>;
  (key: typeof actions.GET_WOOM_LIKES, body: GetWoomLikesRequestParams): Promise<ApiResponse<GetWoomLikesResponse>>;
  (key: typeof actions.DELETE_WOOM_LIKES, body: DeleteWoomLikesRequestParams): Promise<ApiResponse<DeleteWoomLikesResponse>>;
  (key: typeof actions.GET_WOOM_COMMENTS, body: GetWoomCommentsRequestParams): Promise<ApiResponse<GetWoomCommentsResponse>>;
  (key: typeof actions.DELETE_WOOM_COMMENTS, body: DeleteWoomCommentsRequestParams): Promise<ApiResponse<DeleteWoomCommentsResponse>>;
  (key: typeof actions.EDIT_WOOM_COMMENTS, body: EditWoomCommentsRequestParams): Promise<ApiResponse<EditWoomCommentsResponse>>;
  (key: typeof actions.GET_WOOM_COMMENTS_REPLY, body: GetWoomCommentsReplyRequestParams): Promise<ApiResponse<GetWoomCommentsReplyResponse>>;
  (key: typeof actions.DELETE_WOOM_COMMENTS_REPLY, body: DeleteWoomCommentsReplyRequestParams): Promise<ApiResponse<DeleteWoomCommentsReplyResponse>>;
  (key: typeof actions.EDIT_WOOM_COMMENTS_REPLY, body: EditWoomCommentsReplyRequestParams): Promise<ApiResponse<EditWoomCommentsReplyResponse>>;
  (key: typeof actions.GET_WOOM_COMMENTS_LIKE, body: GetWoomCommentsLikeRequestParams): Promise<ApiResponse<GetWoomCommentsLikeResponse>>;
  (key: typeof actions.DELETE_WOOM_COMMENTS_LIKE, body: DeleteWoomCommentsLikeRequestParams): Promise<ApiResponse<DeleteWoomCommentsLikeResponse>>;
  (key: typeof actions.EDIT_WOOM_COMMENTS_LIKE, body: EditWoomCommentsLikeRequestParams): Promise<ApiResponse<EditWoomCommentsLikeResponse>>;
  (key: typeof actions.GET_MEPAGE, body: GetMePageParams): Promise<ApiResponse<GetMePageResponse>>;
  (key: typeof actions.SWITCH_STATUS_MEPAGE, body: SwitchMePageParams): Promise<ApiResponse<SwitchMePageResponse>>;
  (key: typeof actions.SAVE_MEPAGE, body: SaveMePageParams): Promise<ApiResponse<SaveMePageResponse>>;
  (key: typeof actions.GET_DISCOVER, body: GetDiscoverParams): Promise<ApiResponse<GetDiscoverResponse>>;
  (key: typeof actions.SWITCH_STATUS_DISCOVER, body: SwitchDiscoverParams): Promise<ApiResponse<SwitchDiscoverResponse>>;
  (key: typeof actions.SAVE_DISCOVER, body: SaveDiscoverParams): Promise<ApiResponse<SaveDiscoverResponse>>;
  (key: typeof actions.GET_FAVORITES, body: GetFavoritesRequestParams): Promise<ApiResponse<GetFavoritesResponse>>;
  (key: typeof actions.DELETE_FAVORITES, body: DeleteFavoritesRequestParams): Promise<ApiResponse<DeleteFavoritesResponse>>;
  (key: typeof actions.EDIT_FAVORITES, body: EditFavoritesRequestParams): Promise<ApiResponse<EditFavoritesResponse>>;
  (key: typeof actions.GET_BLACKLIST, body: GetBlacklistRequestParams): Promise<ApiResponse<GetBlacklistResponse>>;
  (key: typeof actions.DELETE_BLACKLIST, body: DeleteBlackListRequestParams): Promise<ApiResponse<DeleteBlackListResponse>>;
  (key: typeof actions.GET_APPUPDATE, body: GetAppUpdateRequestParams): Promise<ApiResponse<GetAppUpdateResponse>>;
  (key: typeof actions.ADD_APPUPDATE, body: AddEditAppUpdateRequestParams): Promise<ApiResponse<AddEditAppUpdateResponse>>;
  (key: typeof actions.EDIT_APPUPDATE, body: AddEditAppUpdateRequestParams): Promise<ApiResponse<AddEditAppUpdateResponse>>;
  (key: typeof actions.DELETE_APPUPDATE, body: DeleteAppUpdateRequestParams): Promise<ApiResponse<DeleteAppUpdateResponse>>;
  (key: typeof actions.EDIT_BLACKLIST, body: EditBlackListRequestParams): Promise<ApiResponse<EditBlackListResponse>>;
  (key: typeof actions.GET_OFFICIAL_ACCOUNTS, body: GetOfficialAccountsRequestParams): Promise<ApiResponse<GetOfficialAccountResponse>>;
  (key: typeof actions.PROCESS_OFFICIAL_ACCOUNT, body: ProcessOfficialAccountParams): Promise<ApiResponse<ProcessOfficialAccountParams>>;
  (key: typeof actions.GET_INTEREST_LIST, body: GetInerestListParams): Promise<ApiResponse<GetInterestListResponse>>;
  (key: typeof actions.DELETE_OFFICIAL_ACCOUNT, body: DeleteOfficialAccountParams): Promise<ApiResponse<DeleteOfficialAccountParams>>;
  (key: typeof actions.REGISTER_OFFICIAL_ACCOUNT, body: RegisterOfficialAccountParams): Promise<ApiResponse<RegisterOfficialAccountResponse>>;
  (key: typeof actions.ALTER_OFFICIAL_ACCOUNT, body: EditOfficialAccountParams): Promise<ApiResponse<EditOfficialAccountResponse>>;
  (key: typeof actions.GET_NEWS_LIKES, body: GetNewsLikesParams): Promise<ApiResponse<GetNewsLikesResponse>>;
  (key: typeof actions.CHANGE_NEWS_LIKE_STATUS, body: ChangeNewsLikeStatusParams): Promise<ApiResponse<ChangeNewsLikeStatusRespons>>;
  (key: typeof actions.DELETE_NEWS_LIKES, body: DeleteNewsLikeParams): Promise<ApiResponse<DeleteNewsLikeResponse>>;
  (key: typeof actions.GET_SHARE_LIST, body: GetNewsShareListRequestParams): Promise<ApiResponse<GetNewsShareListResponse>>;
  (key: typeof actions.DELETE_SHARE, body: DeleteNewsShareParams): Promise<ApiResponse<DeleteNewsShareResponse>>;
  (key: typeof actions.CHANGE_SHARE_PRIVACY, body: ChangeSharePrivacyParams): Promise<ApiResponse<ChangeSharePrivacyResponse>>;
  (key: typeof actions.GET_NEWS_COMMENTS, body: GetNewsCommentsParams): Promise<ApiResponse<GetNewsCommentsResponse>>;
  (key: typeof actions.DELETE_NEWS_COMMENTS, body: DeleteNewsCommentParams): Promise<ApiResponse<DeleteNewsCommentResponse>>;
  (key: typeof actions.ALTER_NEWS_COMMENT, body: AlterNewsCommentsParams): Promise<ApiResponse<AlterNewsCommentResponse>>;
  (key: typeof actions.CHANGE_NEWS_COMMENT_STATUS, body: ChangeNewsCommentStatusParams): Promise<ApiResponse<ChangeNewsCommentStatusResponse>>;
  (key: typeof actions.GET_NEWS_LIST, body: GetNewsListParams): Promise<ApiResponse<GetNewsListResponse>>;
  (key: typeof actions.DELETE_NEWS, body: DeleteNewsParams): Promise<ApiResponse<DeleteNewsResponse>>;
  (key: typeof actions.ALTER_NEWS, body: EditNewsParams): Promise<ApiResponse<EditNewsResponse>>;
  (key: typeof actions.CHANGE_NEWS_PRIVACY, body: ChangeNewsPrivacyParams): Promise<ApiResponse<ChangeNewsPrivacyResponse>>;
  (key: typeof actions.GET_MOMENTS, body: GetMomentsRequestParams): Promise<ApiResponse<GetMomentsResponse>>;
  (key: typeof actions.DELETE_MOMENTS, body: DeleteMomentsRequestParams);
  (key: typeof actions.CHANGE_MOMENT_STATUS, body: ChangeMomentsStatusRequestParams);
  (key: typeof actions.ALTER_MOMENT, body: AlterMomentRequestParams);
  (key: typeof actions.GET_MOMENT_COMMENT, body: GetMomentsCommentsRequestParams): Promise<ApiResponse<GetMomentsCommentsResponse>>;
  (key: typeof actions.REMOVE_MOMENT_COMMENT, body: RemoveMomentsCommentRequestParams);
  (key: typeof actions.SWITCH_COMMENT_STATUS, body: SwitchCommentStatusRequestParams);
  (key: typeof actions.ALTER_MOMENT_COMMENT, body: AlterMomentCommentRequestParams);
  (key: typeof actions.GET_MOMENT_LIKES, body: GetMomentsLikesRequestParams): Promise<ApiResponse<GetMomentsLikesResponse>>;
  (key: typeof actions.REMOVE_MOMENTS_LIKES, body: RemoveMomentLikesRequestParams);
  (key: typeof actions.SWITCH_MOMENT_LIKES_STATUS, body: SwitchMomentLikesStatusRequestParams);
  (key: typeof actions.GET_MOMENT_DETAILS, body: GetMomentDetailsRequestParams): Promise<ApiResponse<GetMomentDetailsResponse>>;
  (key: typeof actions.SWITCH_MOMENT_COMMENT, body: TurnoffCommentRequestParams);
  (key: typeof actions.GET_USER_STATISTICS, body: GetStatisticsParams): Promise<ApiResponse<GetUserStatisticsResponse>>;
  (key: typeof actions.GET_ACTIVE_USER_STATISTICS, body: GetStatisticsParams): Promise<ApiResponse<GetActiveUserStatisticsResponse>>;
  (key: typeof actions.GET_GROUP_STATISTICS, body: GetStatisticsParams): Promise<ApiResponse<GetGrouptStatisticsResponse>>;
  (key: typeof actions.GET_ACTIVE_GROUP_STATISTICS, body: GetStatisticsParams): Promise<ApiResponse<GetActiveGroupStatisticsResponse>>;
  (key: typeof actions.GET_MESSAGE_STATISTICS, body: GetStatisticsParams): Promise<ApiResponse<GetMessageStatisticsResponse>>;
  (key: typeof actions.GET_GAME_STATISTICS, body: GetStatisticsParams): Promise<ApiResponse<GetGameStatisticsResponse>>;
};
