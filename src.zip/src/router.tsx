import React from "react";
import { createBrowserRouter, Navigate } from "react-router-dom";
import { QueryClient } from "@tanstack/react-query";
import { ApiRequest } from "~/api/types";

const LoginView = React.lazy(() => import("~/views/LoginView"));
const DashboardView = React.lazy(() => import("~/views/DashboardView"));
const UserListView = React.lazy(() => import("~/views/UserListView"));
const GameManagementView = React.lazy(() => import("~/views/GameManagementView"));
const CategoryManagementView = React.lazy(() => import("~/views/CategoryManagementView"));
const LinkedAccountView = React.lazy(() => import("~/views/LinkedAccountView"));
const DeletedAccountView = React.lazy(() => import("~/views/DeletedAccountView"));
const GroupManagementView = React.lazy(() => import("~/views/GroupManagementView"));
const GroupDetailsManagementView = React.lazy(() => import("~/views/GroupDetailsManagementView"));
const WoomManagementView = React.lazy(() => import("~/views/WoomManagementView"));
const WoomLikesView = React.lazy(() => import("~/views/WoomLikesView"));
const WoomCommentsView = React.lazy(() => import("~/views/WoomCommentsView"));
const WoomCommentsReplyView = React.lazy(() => import("~/views/WoomCommentsReplyView"));
const WoomCommentsLikeView = React.lazy(() => import("~/views/WoomCommentsLikeView"));
const MePageDepositView = React.lazy(() => import("~/views/MePageDepositView"));
const MePageWithdrawView = React.lazy(() => import("~/views/MePageWithdrawView"));
const MePageExchangeView = React.lazy(() => import("~/views/MePageExchangeView"));
const MePageMarketView = React.lazy(() => import("~/views/MePageMarketView"));
const MePageEarnView = React.lazy(() => import("~/views/MePageEarnView"));
const MePageOtcView = React.lazy(() => import("~/views/MePageOtcView"));
const FavouritesView = React.lazy(() => import("~/views/FavouritesView"));
const DiscoverView = React.lazy(() => import("~/views/DiscoverView"));
const BlacklistView = React.lazy(() => import("~/views/BlacklistView"));
const AppUpdateView = React.lazy(() => import("~/views/AppUpdateView"));
const OfficialAccountView = React.lazy(() => import("~/views/OfficialAccountManagementView"));
const LikeManagementView = React.lazy(() => import("~/views/OfficialAccountLikeManagementView"));
const ShareManagementView = React.lazy(() => import("~/views/OfficialAccountShareManagementView"));
const CommentManagementView = React.lazy(() => import("~/views/OfficialAccountCommentManagementView"));
const NewsManagementView = React.lazy(() => import("~/views/OfficialAccountNewsManagementView"));
const MomentsView = React.lazy(() => import("~/views/MomentsView"));
const MomentsCommentView = React.lazy(() => import("~/views/MomentsCommentView"));
const MomentsLikesView = React.lazy(() => import("~/views/MomentsLikesView"));
const MomentPostView = React.lazy(() => import("~/views/MomentPostView"));
const MomentsLayout = React.lazy(() => import("~/views/MomentsLayout"));
const UserStatisticsView = React.lazy(() => import("~/views/UserStatisticsView"));
const GroupStatisticsView = React.lazy(() => import("~/views/GroupStatisticsView"));
const MessageStatisticsView = React.lazy(() => import("~/views/MessageStatisticsView"));
const GameStatisticsView = React.lazy(() => import("~/views/GameStatisticsView"));

import { userListViewLoader } from "~/views/UserListView";
import { gameManagementViewLoader } from "~/views/GameManagementView";
import { categoryManagementViewLoader } from "~/views/CategoryManagementView";
import { linkedAccountsViewLoader } from "~/views/LinkedAccountView";
import { deletedAccountViewLoader } from "~/views/DeletedAccountView";
import { groupManagementViewLoader } from "~/views/GroupManagementView";
import { groupGroupsMembersViewLoader } from "~/views/GroupDetailsManagementView";
import { woomManagementViewLoader } from "~/views/WoomManagementView";
import { woomLikesViewLoader } from "~/views/WoomLikesView";
import { woomCommentsViewLoader } from "~/views/WoomCommentsView";
import { woomCommentsReplyViewLoader } from "~/views/WoomCommentsReplyView";
import { woomCommentsLikeViewLoader } from "~/views/WoomCommentsLikeView";
import { mePageDepositViewLoader } from "~/views/MePageDepositView";
import { mePageWithdrawViewLoader } from "~/views/MePageWithdrawView";
import { mePageExchangeViewLoader } from "~/views/MePageExchangeView";
import { mePageMarketViewLoader } from "~/views/MePageMarketView";
import { mePageEarnViewLoader } from "~/views/MePageEarnView";
import { mePageOtcViewLoader } from "~/views/MePageOtcView";
import { favouritesViewLoader } from "~/views/FavouritesView";
import { discoverViewLoader } from "~/views/DiscoverView";
import { blacklistViewLoader } from "~/views/BlacklistView";
import { appUpdateViewLoader } from "~/views/AppUpdateView";
import { officialAccountManagementViewLoader } from "~/views/OfficialAccountManagementView";
import { officialAccountLikeManagementViewLoader } from "~/views/OfficialAccountLikeManagementView";
import { officialAccountShareManagementViewLoader } from "~/views/OfficialAccountShareManagementView";
import { officialAccountCommentManagementViewLoader } from "~/views/OfficialAccountCommentManagementView";
import { officialAccountNewsManagementViewLoader } from "~/views/OfficialAccountNewsManagementView";
import { MomentsViewLoader } from "./views/MomentsView";
import { MomentsCommentsViewLoader } from "~/views/MomentsCommentView";
import { MomentsLikesViewLoader } from "~/views/MomentsLikesView";
import { MomentDetailsViewLoader } from "~/views/MomentPostView";
import { activeUserStaticsViewLoader, userStaticsViewLoader } from "~/views/UserStatisticsView";
import { activeGroupStaticsViewLoader, groupStaticsViewLoader } from "./views/GroupStatisticsView";
import { meaasgeStaticsViewLoader } from "./views/MessageStatisticsView";
import { gameStaticsViewLoader } from "./views/GameStatisticsView";

export const createRouter = (queryClient: QueryClient, request: ApiRequest) =>
  createBrowserRouter([
    {
      element: <DashboardView />,
      children: [
        {
          path: "/",
          element: <Navigate to="/statistics/usersSta" />,
        },
        {
          path: "/users/usersList",
          element: <UserListView />,
          loader: userListViewLoader(queryClient, request),
        },
        {
          path: "/gameStore/gameManage",
          element: <GameManagementView />,
          loader: gameManagementViewLoader(queryClient, request),
        },
        {
          path: "/gameStore/categoryManage",
          element: <CategoryManagementView />,
          loader: categoryManagementViewLoader(queryClient, request),
        },
        {
          path: "/users/linkedAccount",
          element: <LinkedAccountView />,
          loader: deletedAccountViewLoader(queryClient, request),
        },
        {
          path: "/users/deletedAccount",
          element: <DeletedAccountView />,
          loader: linkedAccountsViewLoader(queryClient, request),
        },
        //moments
        {
          path: "/moments/moments",
          element: <MomentsView />,
          loader: MomentsViewLoader(queryClient, request),
        },
        {
          element: <MomentsLayout />,
          children: [
            {
              path: "/moments/momentsPost",
              element: <MomentPostView />,
              loader: MomentDetailsViewLoader(queryClient, request),
            },
            {
              path: "/moments/momentsComments",
              element: <MomentsCommentView />,
              loader: MomentsCommentsViewLoader(queryClient, request),
            },
            {
              path: "/moments/momentsLikes",
              element: <MomentsLikesView />,
              loader: MomentsLikesViewLoader(queryClient, request),
            },
          ],
        },

        {
          path: "/groups/groupsAdm",
          element: <GroupManagementView />,
          loader: groupManagementViewLoader(queryClient, request),
        },
        {
          path: "/groups/groupsAdm/:groupID",
          element: <GroupDetailsManagementView />,
          loader: groupGroupsMembersViewLoader(queryClient, request),
        },
        {
          path: "/woom/woomManage",
          element: <WoomManagementView />,
          loader: woomManagementViewLoader(queryClient, request),
        },
        {
          path: "/woom/woomLike",
          element: <WoomLikesView />,
          loader: woomLikesViewLoader(queryClient, request),
        },
        {
          path: "/woom/woomComment",
          element: <WoomCommentsView />,
          loader: woomCommentsViewLoader(queryClient, request),
        },
        {
          path: "/woom/woomSubComment",
          element: <WoomCommentsReplyView />,
          loader: woomCommentsReplyViewLoader(queryClient, request),
        },
        {
          path: "/woom/woomCommentLike",
          element: <WoomCommentsLikeView />,
          loader: woomCommentsLikeViewLoader(queryClient, request),
        },
        {
          path: "/mepage/deposit",
          element: <MePageDepositView />,
          loader: mePageDepositViewLoader(queryClient, request),
        },
        {
          path: "/mepage/withdraw",
          element: <MePageWithdrawView />,
          loader: mePageWithdrawViewLoader(queryClient, request),
        },
        {
          path: "/mepage/exchange",
          element: <MePageExchangeView />,
          loader: mePageExchangeViewLoader(queryClient, request),
        },
        {
          path: "/mepage/market",
          element: <MePageMarketView />,
          loader: mePageMarketViewLoader(queryClient, request),
        },
        {
          path: "/mepage/earn",
          element: <MePageEarnView />,
          loader: mePageEarnViewLoader(queryClient, request),
        },
        {
          path: "/mepage/otc",
          element: <MePageOtcView />,
          loader: mePageOtcViewLoader(queryClient, request),
        },
        {
          path: "/mepage/favourites",
          element: <FavouritesView />,
          loader: favouritesViewLoader(queryClient, request),
        },
        {
          path: "/mepage/discover",
          element: <DiscoverView />,
          loader: discoverViewLoader(queryClient, request),
        },
        {
          path: "/mepage/blacklist",
          element: <BlacklistView />,
          loader: blacklistViewLoader(queryClient, request),
        },
        {
          path: "/version/appUpdate",
          element: <AppUpdateView />,
          loader: appUpdateViewLoader(queryClient, request),
        },
        {
          path: "/officialAccount/officialAccountManagemnet",
          element: <OfficialAccountView />,
          loader: officialAccountManagementViewLoader(queryClient, request),
        },
        {
          path: "/officialAccount/likeManagemnet",
          element: <LikeManagementView />,
          loader: officialAccountLikeManagementViewLoader(queryClient, request),
        },
        {
          path: "/officialAccount/shareManagement",
          element: <ShareManagementView />,
          loader: officialAccountShareManagementViewLoader(queryClient, request),
        },
        {
          path: "/officialAccount/commentManagement",
          element: <CommentManagementView />,
          loader: officialAccountCommentManagementViewLoader(queryClient, request),
        },
        {
          path: "/officialAccount/newsManagement",
          element: <NewsManagementView />,
          loader: officialAccountNewsManagementViewLoader(queryClient, request),
        },
        {
          path: "/statistics/usersSta",
          element: <UserStatisticsView />,
          loader: userStaticsViewLoader(queryClient, request) || activeUserStaticsViewLoader(queryClient, request),
        },
        {
          path: "/statistics/groupsSta",
          element: <GroupStatisticsView />,
          loader: groupStaticsViewLoader(queryClient, request) || activeGroupStaticsViewLoader(queryClient, request),
        },
        {
          path: "/statistics/messagesSta",
          element: <MessageStatisticsView />,
          loader: meaasgeStaticsViewLoader(queryClient, request) || activeGroupStaticsViewLoader(queryClient, request),
        },
        {
          path: "/statistics/gameSta",
          element: <GameStatisticsView />,
          loader: gameStaticsViewLoader(queryClient, request) || activeGroupStaticsViewLoader(queryClient, request),
        },
      ],
    },
    {
      path: "/login",
      element: <LoginView />,
    },
  ]);
